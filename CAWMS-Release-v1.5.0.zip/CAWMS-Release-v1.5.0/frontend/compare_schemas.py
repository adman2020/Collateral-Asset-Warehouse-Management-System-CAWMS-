#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
比较旧版本SQL文件与新数据库的结构差异
"""

import re
import sys
import mysql.connector
from mysql.connector import Error

def parse_old_schema(sql_file):
    """解析旧版本SQL文件中的表结构"""
    tables = {}
    
    with open(sql_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 分割SQL语句
    statements = content.split(';')
    
    current_table = None
    table_definition = []
    
    for stmt in statements:
        stmt = stmt.strip()
        if not stmt:
            continue
        
        # 查找CREATE TABLE语句
        create_match = re.match(r'CREATE TABLE IF NOT EXISTS (\w+)\s*\((.*)', stmt, re.IGNORECASE | re.DOTALL)
        if create_match:
            table_name = create_match.group(1)
            # 获取括号内的内容
            rest = create_match.group(2)
            # 需要找到匹配的右括号
            paren_count = 1
            pos = 0
            for i, char in enumerate(rest):
                if char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                    if paren_count == 0:
                        pos = i
                        break
            
            if pos > 0:
                table_def = rest[:pos]
                tables[table_name] = table_def.strip()
                # 可能会有ENGINE等选项在括号后
                # 这里暂时忽略
            continue
        
        # 如果没有CREATE TABLE语句，可能是其他语句
        # 这里我们只关注表结构
    
    return tables

def get_current_schema():
    """获取当前数据库的表结构"""
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='G-;fnxjV4Ck(',
            database='cawms'
        )
        
        cursor = connection.cursor()
        
        # 获取所有表名
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        
        schema = {}
        
        for table in tables:
            table_name = table[0]
            
            # 获取表结构
            cursor.execute(f"SHOW CREATE TABLE `{table_name}`")
            result = cursor.fetchone()
            
            if result:
                create_stmt = result[1]
                # 提取列定义部分（括号内的内容）
                match = re.search(r'CREATE TABLE `[^`]+`\s*\((.*?)\)[^)]*$', create_stmt, re.DOTALL)
                if match:
                    schema[table_name] = match.group(1).strip()
                else:
                    schema[table_name] = "/* 无法解析表定义 */"
        
        cursor.close()
        connection.close()
        
        return schema
    
    except Error as e:
        print(f"连接数据库错误: {e}")
        return {}

def compare_schemas(old_schema, new_schema):
    """比较两个数据库结构"""
    old_tables = set(old_schema.keys())
    new_tables = set(new_schema.keys())
    
    added_tables = new_tables - old_tables
    removed_tables = old_tables - new_tables
    common_tables = old_tables & new_tables
    
    differences = {}
    
    # 比较共有表的结构差异
    for table in common_tables:
        old_def = old_schema[table]
        new_def = new_schema[table]
        
        if old_def != new_def:
            # 简单比较：分割成行
            old_lines = [line.strip() for line in old_def.split(',') if line.strip()]
            new_lines = [line.strip() for line in new_def.split(',') if line.strip()]
            
            old_set = set(old_lines)
            new_set = set(new_lines)
            
            added_columns = new_set - old_set
            removed_columns = old_set - new_set
            
            if added_columns or removed_columns:
                differences[table] = {
                    'added': list(added_columns),
                    'removed': list(removed_columns)
                }
    
    return {
        'added_tables': list(added_tables),
        'removed_tables': list(removed_tables),
        'differences': differences
    }

def generate_diff_report(old_file, new_schema, comparison):
    """生成差异报告"""
    with open(old_file, 'r', encoding='utf-8') as f:
        old_content = f.read()
    
    report_lines = []
    
    # 标题
    report_lines.append("=" * 80)
    report_lines.append("CAWMS数据库结构差异报告")
    report_lines.append("=" * 80)
    report_lines.append(f"旧版本文件: {old_file}")
    report_lines.append(f"当前数据库: cawms (MySQL 8.4.8)")
    report_lines.append(f"比较时间: 2026-04-21")
    report_lines.append("")
    
    # 1. 表数量变化
    old_table_count = len(old_file)  # 这个不准确，稍后修复
    report_lines.append("1. 表数量变化")
    report_lines.append("-" * 40)
    
    # 从旧文件解析实际表数量
    old_tables = re.findall(r'CREATE TABLE IF NOT EXISTS (\w+)', old_content, re.IGNORECASE)
    report_lines.append(f"旧版本表数量: {len(old_tables)}")
    report_lines.append(f"新版本表数量: {len(new_schema)}")
    report_lines.append("")
    
    # 2. 新增的表
    if comparison['added_tables']:
        report_lines.append("2. 新增的表")
        report_lines.append("-" * 40)
        for table in sorted(comparison['added_tables']):
            report_lines.append(f"  + {table}")
        report_lines.append("")
    
    # 3. 删除的表（理论上不应有）
    if comparison['removed_tables']:
        report_lines.append("3. 删除的表")
        report_lines.append("-" * 40)
        for table in sorted(comparison['removed_tables']):
            report_lines.append(f"  - {table}")
        report_lines.append("")
    
    # 4. 结构变更的表
    if comparison['differences']:
        report_lines.append("4. 结构变更的表")
        report_lines.append("-" * 40)
        
        for table, diff in comparison['differences'].items():
            report_lines.append(f"表: {table}")
            
            if diff['added']:
                report_lines.append("  新增列:")
                for col in diff['added']:
                    report_lines.append(f"    + {col}")
            
            if diff['removed']:
                report_lines.append("  删除列:")
                for col in diff['removed']:
                    report_lines.append(f"    - {col}")
            
            report_lines.append("")
    
    # 5. 建议的更新脚本
    report_lines.append("5. 建议的更新脚本")
    report_lines.append("-" * 40)
    report_lines.append("-- 基于差异生成的更新脚本")
    report_lines.append("-- 请谨慎执行，建议在测试环境先验证")
    report_lines.append("")
    report_lines.append("USE cawms;")
    report_lines.append("")
    
    # 为新表生成CREATE语句（简化版）
    if comparison['added_tables']:
        report_lines.append("-- 创建新表")
        for table in sorted(comparison['added_tables']):
            # 这里应该从当前数据库获取实际的CREATE语句
            # 简化处理，只提示
            report_lines.append(f"-- TODO: 创建表 {table} 的语句需要从当前数据库导出")
        report_lines.append("")
    
    # 为变更的表生成ALTER语句
    if comparison['differences']:
        report_lines.append("-- 修改现有表结构")
        for table, diff in comparison['differences'].items():
            if diff['added']:
                report_lines.append(f"-- 表 {table} 新增列:")
                for col in diff['added']:
                    # 提取列定义
                    col_def = col
                    # 简单的ALTER语句生成
                    report_lines.append(f"ALTER TABLE `{table}` ADD COLUMN {col_def};")
                report_lines.append("")
    
    report_lines.append("-- 更新完成")
    
    return "\n".join(report_lines)

def main():
    if len(sys.argv) != 3:
        print("用法: python compare_schemas.py <旧版本SQL文件> <输出报告文件>")
        sys.exit(1)
    
    old_file = sys.argv[1]
    report_file = sys.argv[2]
    
    print("解析旧版本SQL文件...")
    old_schema = parse_old_schema(old_file)
    print(f"解析到 {len(old_schema)} 个表")
    
    print("连接当前数据库...")
    new_schema = get_current_schema()
    print(f"当前数据库有 {len(new_schema)} 个表")
    
    print("比较结构差异...")
    comparison = compare_schemas(old_schema, new_schema)
    
    print("生成差异报告...")
    report = generate_diff_report(old_file, new_schema, comparison)
    
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(f"差异报告已生成: {report_file}")
    
    # 打印摘要
    print("\n=== 差异摘要 ===")
    print(f"新增表: {len(comparison['added_tables'])} 个")
    print(f"删除表: {len(comparison['removed_tables'])} 个")
    print(f"结构变更表: {len(comparison['differences'])} 个")
    
    if comparison['added_tables']:
        print(f"新增的表: {', '.join(sorted(comparison['added_tables']))}")

if __name__ == '__main__':
    main()