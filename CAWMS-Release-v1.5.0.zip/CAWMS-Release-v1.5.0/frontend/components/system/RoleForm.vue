<template>
  <div class="role-form">
    <n-form ref="formRef" :model="formData" :rules="formRules" label-width="100">
      <div class="form-row">
        <n-form-item label="角色名称" path="roleName" class="form-item-half">
          <n-input v-model:value="formData.roleName" placeholder="请输入角色名称" />
        </n-form-item>
        <n-form-item label="角色代码" path="roleCode" class="form-item-half">
          <n-input v-model:value="formData.roleCode" :disabled="isEdit" placeholder="请输入角色代码" />
        </n-form-item>
      </div>
      <n-form-item label="数据范围" path="dataScope">
        <n-select v-model:value="formData.dataScope" :options="dataScopeOptions" placeholder="请选择数据范围" />
      </n-form-item>
      <n-form-item label="描述" path="description">
        <n-input v-model:value="formData.description" type="textarea" :rows="3" placeholder="请输入描述" />
      </n-form-item>
      <n-form-item label="状态" path="status">
        <n-select v-model:value="formData.status" :options="[{ label: '活跃', value: 'ACTIVE' }, { label: '未激活', value: 'INACTIVE' }]" />
      </n-form-item>
      <div class="form-actions">
        <n-button @click="handleClose">取消</n-button>
        <n-button type="primary" :loading="submitting" @click="handleSubmit">{{ isEdit ? '保存' : '创建' }}</n-button>
      </div>
    </n-form>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import type { FormInst } from 'naive-ui'
import { createRole, updateRole, getRoleDetail, type RoleCreateRequest } from '~/api/system'

const props = defineProps<{ roleId: number | null }>()
const emit = defineEmits<{ success: []; close: [] }>()

const message = useMessage()
const formRef = ref<FormInst | null>(null)
const submitting = ref(false)
const isEdit = computed(() => props.roleId !== null)

const formData = reactive<RoleCreateRequest>({
  roleCode: '',
  roleName: '',
  description: '',
  dataScope: 'ALL',
  status: 'ACTIVE'
})

const dataScopeOptions = [
  { label: '全部数据', value: 'ALL' },
  { label: '本部门数据', value: 'DEPT' },
  { label: '本部门及以下数据', value: 'DEPT_AND_CHILD' },
  { label: '仅本人数据', value: 'SELF' },
  { label: '自定义数据', value: 'CUSTOM' }
]

const formRules = {
  roleName: { required: true, message: '请输入角色名称', trigger: 'blur' },
  roleCode: { required: true, message: '请输入角色代码', trigger: 'blur' }
}

onMounted(async () => {
  if (isEdit.value && props.roleId) {
    try {
      const role = await getRoleDetail(props.roleId)
      formData.roleCode = role.roleCode
      formData.roleName = role.roleName
      formData.description = role.description || ''
      formData.dataScope = role.dataScope || 'ALL'
      formData.status = role.status || 'ACTIVE'
    } catch (e: any) {
      message.error(e.message || '加载角色详情失败')
    }
  }
})

const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    submitting.value = true
    if (isEdit.value && props.roleId) {
      await updateRole(props.roleId, {
        roleName: formData.roleName,
        description: formData.description,
        dataScope: formData.dataScope,
        status: formData.status
      })
      message.success('保存成功')
    } else {
      await createRole(formData)
      message.success('创建成功')
    }
    emit('success')
  } catch (e: any) {
    message.error(e.message || '提交失败')
  } finally {
    submitting.value = false
  }
}

const handleClose = () => emit('close')
</script>

<style scoped>
.role-form {
  padding: 8px 0;
}
.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
}
@media (max-width: 600px) {
  .form-row {
    grid-template-columns: 1fr;
  }
}
.form-item-half {
  min-width: 0;
}
.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 24px;
}
</style>
