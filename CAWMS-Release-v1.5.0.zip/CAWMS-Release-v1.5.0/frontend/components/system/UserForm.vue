<template>
  <div class="user-form">
    <n-form ref="formRef" :model="formData" :rules="formRules" label-width="100">
      <n-grid :cols="2" :x-gap="24">
        <n-grid-item>
          <n-form-item :label="t('system.users.username')" path="username">
            <n-input v-model:value="formData.username" :placeholder="t('system.users.usernamePlaceholder')" />
          </n-form-item>
        </n-grid-item>
        <n-grid-item>
          <n-form-item :label="t('system.users.realName')" path="realName">
            <n-input v-model:value="formData.realName" :placeholder="t('system.users.realNamePlaceholder')" />
          </n-form-item>
        </n-grid-item>
        <n-grid-item>
          <n-form-item :label="t('system.users.email')" path="email">
            <n-input v-model:value="formData.email" placeholder="email@example.com" />
          </n-form-item>
        </n-grid-item>
        <n-grid-item>
          <n-form-item :label="t('system.users.phone')" path="phone">
            <n-input v-model:value="formData.phone" placeholder="13800138000" />
          </n-form-item>
        </n-grid-item>
        <n-grid-item>
          <n-form-item :label="t('system.users.department')" path="departmentName">
            <n-input v-model:value="formData.departmentName" :placeholder="t('system.users.departmentPlaceholder')" />
          </n-form-item>
        </n-grid-item>
        <n-grid-item>
          <n-form-item :label="t('system.users.status')" path="status">
            <n-select
              v-model:value="formData.status"
              :options="statusOptions"
              :placeholder="t('system.users.statusPlaceholder')"
            />
          </n-form-item>
        </n-grid-item>
        <n-grid-item v-if="!isEdit">
          <n-form-item :label="t('system.users.password')" path="password">
            <n-input v-model:value="formData.password" type="password" placeholder="******" />
          </n-form-item>
        </n-grid-item>
        <n-grid-item :span="2">
          <n-form-item :label="t('system.users.roles')" path="roleNames">
            <n-select
              v-model:value="formData.roleNames"
              multiple
              :options="roleOptions"
              :placeholder="t('system.users.rolePlaceholder')"
            />
          </n-form-item>
        </n-grid-item>
        <n-grid-item :span="2">
          <n-form-item :label="t('common.remark')" path="remarks">
            <n-input v-model:value="formData.remarks" type="textarea" :rows="3" />
          </n-form-item>
        </n-grid-item>
      </n-grid>
      <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px;">
        <n-button @click="handleClose">{{ t('common.cancel') }}</n-button>
        <n-button type="primary" :loading="submitting" @click="handleSubmit">
          {{ isEdit ? t('common.save') : t('common.create') }}
        </n-button>
      </div>
    </n-form>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { FormInst } from 'naive-ui'
import { createUser, updateUser, getUserDetail, type UserCreateRequest } from '~/api/system'
import { getRoleList, type SystemRole } from '~/api/system'

const props = defineProps<{ userId: number | null }>()
const emit = defineEmits<{ success: []; close: [] }>()

const message = useMessage()
const { t } = useI18n()
const formRef = ref<FormInst | null>(null)
const submitting = ref(false)
const isEdit = computed(() => props.userId !== null)

const roleOptions = ref<{ label: string; value: string }[]>([])

const formData = reactive<Partial<UserCreateRequest>>({
  username: '',
  password: '',
  realName: '',
  email: '',
  phone: '',
  departmentName: '',
  status: 'ACTIVE',
  roleNames: [],
  remarks: ''
})

const statusOptions = [
  { label: t('system.users.statusActive'), value: 'ACTIVE' },
  { label: t('system.users.statusInactive'), value: 'INACTIVE' },
  { label: t('system.users.statusLocked'), value: 'LOCKED' }
]

const formRules = {
  username: { required: true, message: t('system.users.usernameRequired'), trigger: 'blur' },
  realName: { required: true, message: t('system.users.realNameRequired'), trigger: 'blur' },
  password: { required: !isEdit.value, message: t('system.users.passwordRequired'), trigger: 'blur' },
  email: { required: true, type: 'email', message: t('system.users.emailInvalid'), trigger: 'blur' }
}

const loadRoles = async () => {
  try {
    const res = await getRoleList({ page: 1, size: 100 })
    roleOptions.value = (res.records || []).map((r: SystemRole) => ({
      label: r.roleName,
      value: r.roleCode
    }))
  } catch (e) {
    console.error('加载角色列表失败', e)
  }
}

const loadUserDetail = async () => {
  if (!props.userId) return
  try {
    const user = await getUserDetail(props.userId)
    Object.assign(formData, {
      username: user.username,
      realName: user.realName,
      email: user.email,
      phone: user.phone,
      departmentName: user.departmentName,
      status: user.status,
      roleNames: user.roleNames || [],
      remarks: ''
    })
  } catch (e: any) {
    message.error(e.message || t('system.users.loadDetailFailed'))
  }
}

const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    submitting.value = true

    const payload: UserCreateRequest = {
      username: formData.username || '',
      password: formData.password || '',
      realName: formData.realName || '',
      email: formData.email || '',
      phone: formData.phone || '',
      departmentName: formData.departmentName || '',
      status: formData.status || 'ACTIVE',
      roleNames: formData.roleNames || []
    }

    if (isEdit.value && props.userId) {
      await updateUser(props.userId, payload)
      message.success(t('message.updateSuccess'))
    } else {
      await createUser(payload)
      message.success(t('message.createSuccess'))
    }
    emit('success')
  } catch (e: any) {
    message.error(e.message || t('message.operationFailed'))
  } finally {
    submitting.value = false
  }
}

const handleClose = () => emit('close')

onMounted(() => {
  loadRoles()
  if (isEdit.value) {
    loadUserDetail()
  }
})
</script>

