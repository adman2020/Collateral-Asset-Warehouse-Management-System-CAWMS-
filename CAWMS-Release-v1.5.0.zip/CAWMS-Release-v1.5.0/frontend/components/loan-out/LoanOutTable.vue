<template>
  <div class="loan-out-table">
    <div class="table-header">
      <div class="header-left">
        <h3 class="table-title">借出记录列表</h3>
        <div class="header-stats">
          <NTag type="info" size="small">共 {{ total }} 条记录</NTag>
          <NTag v-if="overdueCount > 0" type="error" size="small">逾期 {{ overdueCount }} 条</NTag>
          <NTag v-if="nearDueCount > 0" type="warning" size="small">即将到期 {{ nearDueCount }} 条</NTag>
        </div>
      </div>
      <div class="header-right">
        <NSpace>
          <NButton size="small" @click="handleRefresh">
            <template #icon>
              <NIcon><RefreshOutline /></NIcon>
            </template>
            刷新
          </NButton>
          <NButton size="small" @click="handleExport" type="info">
            <template #icon>
              <NIcon><DownloadOutline /></NIcon>
            </template>
            导出报告
          </NButton>
          <NButton size="small" @click="handleSendReminders" type="warning">
            <template #icon>
              <NIcon><NotificationsOutline /></NIcon>
            </template>
            发送提醒
          </NButton>
          <NButton size="small" type="primary" @click="handleCreate">
            <template #icon>
              <NIcon><AddOutline /></NIcon>
            </template>
            新建借出
          </NButton>
        </NSpace>
      </div>
    </div>

    <!-- 筛选条件 -->
    <div class="filter-section">
      <NForm inline label-placement="left" label-width="80px">
        <NFormItem label="借出状态">
          <NSelect
            v-model:value="filterParams.status"
            :options="statusOptions"
            placeholder="全部状态"
            clearable
            style="width: 120px;"
          />
        </NFormItem>
        <NFormItem label="借用人">
          <NInput
            v-model:value="filterParams.borrower"
            placeholder="请输入借用人姓名"
            clearable
            style="width: 120px;"
          />
        </NFormItem>
        <NFormItem label="借出部门">
          <NSelect
            v-model:value="filterParams.department"
            :options="departmentOptions"
            placeholder="全部部门"
            clearable
            style="width: 150px;"
          />
        </NFormItem>
        <NFormItem label="逾期状态">
          <NSelect
            v-model:value="filterParams.overdueStatus"
            :options="overdueOptions"
            placeholder="全部"
            clearable
            style="width: 100px;"
          />
        </NFormItem>
        <NFormItem>
          <NButton type="primary" @click="handleSearch">查询</NButton>
          <NButton @click="handleReset" style="margin-left: 8px;">重置</NButton>
        </NFormItem>
      </NForm>
    </div>

    <!-- 数据表格 -->
    <NDataTable
      :columns="columns"
      :data="tableData"
      :pagination="pagination"
      :loading="loading"
      :row-key="(row) => row.id"
      @update:page="handlePageChange"
      @update:page-size="handlePageSizeChange"
      striped
      bordered
    />

    <!-- 批量操作 -->
    <div v-if="selectedRows.length > 0" class="batch-actions">
      <NSpace align="center">
        <span>已选择 {{ selectedRows.length }} 条记录</span>
        <NButton size="small" @click="handleBatchReturn" :disabled="!canBatchReturn">
          <template #icon>
            <NIcon><CheckmarkDoneOutline /></NIcon>
          </template>
          批量归还
        </NButton>
        <NButton size="small" @click="handleBatchExtend" :disabled="!canBatchExtend">
          <template #icon>
            <NIcon><CalendarOutline /></NIcon>
          </template>
          批量续借
        </NButton>
        <NButton size="small" @click="handleBatchRemind" type="warning">
          <template #icon>
            <NIcon><AlertCircleOutline /></NIcon>
          </template>
          批量提醒
        </NButton>
        <NButton size="small" @click="clearSelection">
          取消选择
        </NButton>
      </NSpace>
    </div>

    <!-- 统计卡片 -->
    <div class="stat-cards">
      <NCard size="small" class="stat-card">
        <div class="stat-content">
          <div class="stat-icon loaned">
            <NIcon><ArrowUpOutline /></NIcon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.loaned || 0 }}</div>
            <div class="stat-label">借出中</div>
          </div>
        </div>
      </NCard>
      <NCard size="small" class="stat-card">
        <div class="stat-content">
          <div class="stat-icon overdue">
            <NIcon><AlertCircleOutline /></NIcon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.overdue || 0 }}</div>
            <div class="stat-label">已逾期</div>
          </div>
        </div>
      </NCard>
      <NCard size="small" class="stat-card">
        <div class="stat-content">
          <div class="stat-icon near-due">
            <NIcon><TimeOutline /></NIcon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.nearDue || 0 }}</div>
            <div class="stat-label">即将到期</div>
          </div>
        </div>
      </NCard>
      <NCard size="small" class="stat-card">
        <div class="stat-content">
          <div class="stat-icon returned">
            <NIcon><CheckmarkDoneOutline /></NIcon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.returned || 0 }}</div>
            <div class="stat-label">已归还</div>
          </div>
        </div>
      </NCard>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  NDataTable,
  NButton,
  NIcon,
  NTag,
  NSpace,
  NForm,
  NFormItem,
  NSelect,
  NInput,
  NCard,
  useMessage,
  useDialog,
  DataTableColumn,
  PaginationProps,
  h
} from 'naive-ui'
import {
  RefreshOutline,
  DownloadOutline,
  AddOutline,
  CheckmarkDoneOutline,
  NotificationsOutline,
  AlertCircleOutline,
  CalendarOutline,
  ArrowUpOutline,
  TimeOutline,
  EyeOutline,
  PencilOutline,
  ReturnDownBackOutline,
  ExtensionPuzzleOutline
} from '@vicons/ionicons5'
import { ref, reactive, computed, onMounted } from 'vue'

// 类型定义
interface LoanOutItem {
  id: string
  code: string
  assetName: string
  assetCode: string
  borrower: string
  department: string
  loanDate: string
  expectedReturnDate: string
  actualReturnDate: string | null
  status: string
  overdueDays: number
  isOverdue: boolean
  isNearDue: boolean
  purpose: string
  createdAt: string
}

interface FilterParams {
  status: string | null
  borrower: string
  department: string | null
  overdueStatus: string | null
  dateRange: [number, number] | null
}

interface Stats {
  loaned: number
  overdue: number
  nearDue: number
  returned: number
  total: number
}

// 响应式状态
const loading = ref(false)
const tableData = ref<LoanOutItem[]>([])
const selectedRows = ref<LoanOutItem[]>([])
const total = ref(0)
const overdueCount = ref(0)
const nearDueCount = ref(0)
const stats = reactive<Stats>({
  loaned: 0,
  overdue: 0,
  nearDue: 0,
  returned: 0,
  total: 0
})

const filterParams = reactive<FilterParams>({
  status: null,
  borrower: '',
  department: null,
  overdueStatus: null,
  dateRange: null
})

// 分页配置
const pagination = reactive<PaginationProps>({
  page: 1,
  pageSize: 10,
  pageSizes: [10, 20, 50, 100],
  showSizePicker: true,
  showQuickJumper: true,
  itemCount: 0,
  prefix: (info) => `共 ${info.itemCount} 条记录`
})

// 工具
const message = useMessage()
const dialog = useDialog()

// 选项数据
const statusOptions = [
  { label: '借出中', value: 'LOANED' },
  { label: '已归还', value: 'RETURNED' },
  { label: '已逾期', value: 'OVERDUE' },
  { label: '已取消', value: 'CANCELLED' }
]

const departmentOptions = [
  { label: '信贷部', value: 'CREDIT' },
  { label: '风险管理部', value: 'RISK_MANAGEMENT' },
  { label: '运营部', value: 'OPERATIONS' },
  { label: '科技部', value: 'TECHNOLOGY' },
  { label: '财务部', value: 'FINANCE' },
  { label: '行政部', value: 'ADMINISTRATION' }
]

const overdueOptions = [
  { label: '全部', value: 'ALL' },
  { label: '已逾期', value: 'OVERDUE' },
  { label: '即将到期', value: 'NEAR_DUE' },
  { label: '正常', value: 'NORMAL' }
]

// 表格列定义
const columns = ref<DataTableColumn<LoanOutItem>[]>([
  {
    type: 'selection',
    width: 50
  },
  {
    title: '借出单号',
    key: 'code',
    width: 140,
    sorter: true
  },
  {
    title: '资产名称',
    key: 'assetName',
    width: 180
  },
  {
    title: '资产编号',
    key: 'assetCode',
    width: 120
  },
  {
    title: '借用人',
    key: 'borrower',
    width: 100
  },
  {
    title: '借出部门',
    key: 'department',
    width: 120,
    render: (row) => {
      const deptMap: Record<string, string> = {
        'CREDIT': '信贷部',
        'RISK_MANAGEMENT': '风险管理部',
        'OPERATIONS': '运营部',
        'TECHNOLOGY': '科技部',
        'FINANCE': '财务部',
        'ADMINISTRATION': '行政部'
      }
      return deptMap[row.department] || row.department
    }
  },
  {
    title: '借出日期',
    key: 'loanDate',
    width: 100,
    sorter: true
  },
  {
    title: '预计归还',
    key: 'expectedReturnDate',
    width: 100,
    sorter: true,
    render: (row) => {
      const dateStr = row.expectedReturnDate
      if (row.isOverdue) {
        return h('span', { style: { color: 'var(--error-color)', fontWeight: '500' } }, dateStr)
      } else if (row.isNearDue) {
        return h('span', { style: { color: 'var(--warning-color)', fontWeight: '500' } }, dateStr)
      }
      return dateStr
    }
  },
  {
    title: '状态',
    key: 'status',
    width: 100,
    render: (row) => {
      let tagType: any = 'default'
      let tagText = row.status
      
      if (row.isOverdue) {
        tagType = 'error'
        tagText = '已逾期'
      } else if (row.status === 'LOANED') {
        if (row.isNearDue) {
          tagType = 'warning'
          tagText = '即将到期'
        } else {
          tagType = 'info'
          tagText = '借出中'
        }
      } else if (row.status === 'RETURNED') {
        tagType = 'success'
        tagText = '已归还'
      } else if (row.status === 'CANCELLED') {
        tagType = 'default'
        tagText = '已取消'
      }
      
      return h(NTag, { type: tagType, size: 'small' }, { default: () => tagText })
    }
  },
  {
    title: '逾期天数',
    key: 'overdueDays',
    width: 80,
    align: 'center',
    render: (row) => {
      if (row.isOverdue && row.overdueDays > 0) {
        return h('span', { style: { color: 'var(--error-color)', fontWeight: '600' } }, `${row.overdueDays}天`)
      }
      return row.overdueDays > 0 ? `${row.overdueDays}天` : '-'
    }
  },
  {
    title: '借用用途',
    key: 'purpose',
    width: 150,
    ellipsis: {
      tooltip: true
    }
  },
  {
    title: '操作',
    key: 'actions',
    width: 200,
    fixed: 'right',
    render: (row) => {
      return h('div', { class: 'action-buttons' }, [
        h(NButton, {
          size: 'small',
          type: 'info',
          ghost: true,
          onClick: () => handleView(row)
        }, {
          icon: () => h(NIcon, null, { default: () => h(EyeOutline) }),
          default: () => '查看'
        }),
        h(NButton, {
          size: 'small',
          type: 'primary',
          ghost: true,
          onClick: () => handleReturn(row),
          disabled: !canReturn(row)
        }, {
          icon: () => h(NIcon, null, { default: () => h(ReturnDownBackOutline) }),
          default: () => '归还'
        }),
        h(NButton, {
          size: 'small',
          type: 'warning',
          ghost: true,
          onClick: () => handleExtend(row),
          disabled: !canExtend(row)
        }, {
          icon: () => h(NIcon, null, { default: () => h(ExtensionPuzzleOutline) }),
          default: () => '续借'
        }),
        h(NButton, {
          size: 'small',
          type: 'error',
          ghost: true,
          onClick: () => handleRemind(row),
          disabled: !canRemind(row)
        }, {
          icon: () => h(NIcon, null, { default: () => h(AlertCircleOutline) }),
          default: () => row.isOverdue ? '催还' : '提醒'
        })
      ])
    }
  }
])

// 计算属性
const canBatchReturn = computed(() => {
  return selectedRows.value.some(row => canReturn(row))
})

const canBatchExtend = computed(() => {
  return selectedRows.value.some(row => canExtend(row))
})

// 方法
const canReturn = (row: LoanOutItem) => {
  return row.status === 'LOANED' || row.status === 'OVERDUE'
}

const canExtend = (row: LoanOutItem) => {
  return row.status === 'LOANED' && !row.isOverdue
}

const canRemind = (row: LoanOutItem) => {
  return row.status === 'LOANED'
}

const handleRefresh = async () => {
  loading.value = true
  try {
    // 模拟API调用
    await new Promise(resolve => setTimeout(resolve, 800))
    loadMockData()
    message.success('数据刷新成功')
  } catch (error) {
    message.error('刷新失败')
  } finally {
    loading.value = false
  }
}

const handleSearch = () => {
  pagination.page = 1
  loadMockData()
}

const handleReset = () => {
  filterParams.status = null
  filterParams.borrower = ''
  filterParams.department = null
  filterParams.overdueStatus = null
  filterParams.dateRange = null
  pagination.page = 1
  loadMockData()
}

const handlePageChange = (page: number) => {
  pagination.page = page
  loadMockData()
}

const handlePageSizeChange = (pageSize: number) => {
  pagination.pageSize = pageSize
  pagination.page = 1
  loadMockData()
}

const handleCreate = () => {
  message.info('跳转到创建页面')
  // router.push('/loan-out/create')
}

const handleExport = () => {
  message.success('导出功能开发中...')
}

const handleSendReminders = () => {
  const overdueItems = tableData.value.filter(item => item.isOverdue)
  const nearDueItems = tableData.value.filter(item => item.isNearDue && !item.isOverdue)
  
  if (overdueItems.length === 0 && nearDueItems.length === 0) {
    message.warning('没有需要提醒的记录')
    return
  }
  
  dialog.info({
    title: '发送提醒',
    content: `确定要发送提醒吗？\n逾期记录: ${overdueItems.length} 条\n即将到期: ${nearDueItems.length} 条`,
    positiveText: '确认发送',
    negativeText: '取消',
    onPositiveClick: () => {
      message.success('提醒发送成功')
    }
  })
}

const handleView = (row: LoanOutItem) => {
  message.info(`查看借出记录: ${row.code}`)
  // router.push(`/loan-out/${row.id}`)
}

const handleReturn = (row: LoanOutItem) => {
  if (!canReturn(row)) {
    message.warning('当前状态不允许归还')
    return
  }
  message.info(`归还资产: ${row.code}`)
  // router.push(`/loan-out/${row.id}/return`)
}

const handleExtend = (row: LoanOutItem) => {
  if (!canExtend(row)) {
    message.warning('当前状态不允许续借')
    return
  }
  dialog.info({
    title: '申请续借',
    content: `确定要为借出记录 ${row.code} 申请续借吗？`,
    positiveText: '确认续借',
    negativeText: '取消',
    onPositiveClick: () => {
      message.success('续借申请已提交，请等待审批')
    }
  })
}

const handleRemind = (row: LoanOutItem) => {
  if (!canRemind(row)) {
    message.warning('当前状态不允许发送提醒')
    return
  }
  const action = row.isOverdue ? '催还' : '提醒'
  dialog.info({
    title: `${action}通知`,
    content: `确定要向 ${row.borrower} 发送${action}通知吗？`,
    positiveText: `确认${action}`,
    negativeText: '取消',
    onPositiveClick: () => {
      message.success(`${action}通知已发送`)
    }
  })
}

const handleBatchReturn = () => {
  if (!canBatchReturn.value) {
    message.warning('没有可归还的记录')
    return
  }
  const codes = selectedRows.value
    .filter(row => canReturn(row))
    .map(row => row.code)
    .join(', ')
  dialog.info({
    title: '批量归还',
    content: `确定要批量归还选中的 ${codes} 吗？`,
    positiveText: '确认归还',
    negativeText: '取消',
    onPositiveClick: () => {
      message.success('批量归还请求已提交')
      clearSelection()
    }
  })
}

const handleBatchExtend = () => {
  if (!canBatchExtend.value) {
    message.warning('没有可续借的记录')
    return
  }
  const codes = selectedRows.value
    .filter(row => canExtend(row))
    .map(row => row.code)
    .join(', ')
  dialog.info({
    title: '批量续借',
    content: `确定要批量续借选中的 ${codes} 吗？`,
    positiveText: '确认续借',
    negativeText: '取消',
    onPositiveClick: () => {
      message.success('批量续借申请已提交')
      clearSelection()
    }
  })
}

const handleBatchRemind = () => {
  const codes = selectedRows.value.map(row => row.code).join(', ')
  dialog.info({
    title: '批量提醒',
    content: `确定要批量提醒选中的 ${codes} 吗？`,
    positiveText: '确认提醒',
    negativeText: '取消',
    onPositiveClick: () => {
      message.success('批量提醒已发送')
      clearSelection()
    }
  })
}

const clearSelection = () => {
  selectedRows.value = []
}

// 加载模拟数据
const loadMockData = () => {
  loading.value = true
  
  // 模拟数据
  const mockData: LoanOutItem[] = [
    {
      id: '1',
      code: 'LO20240328001',
      assetName: '笔记本电脑',
      assetCode: 'AST00123',
      borrower: '张三',
      department: 'TECHNOLOGY',
      loanDate: '2026-03-28',
      expectedReturnDate: '2026-04-28',
      actualReturnDate: null,
      status: 'LOANED',
      overdueDays: 0,
      isOverdue: false,
      isNearDue: false,
      purpose: '项目开发使用',
      createdAt: '2026-03-28 10:30:00'
    },
    {
      id: '2',
      code: 'LO20240328002',
      assetName: '投影仪',
      assetCode: 'AST00456',
      borrower: '李四',
      department: 'OPERATIONS',
      loanDate: '2026-03-25',
      expectedReturnDate: '2026-04-10',
      actualReturnDate: null,
      status: 'LOANED',
      overdueDays: 2,
      isOverdue: true,
      isNearDue: true,
      purpose: '会议演示',
      createdAt: '2026-03-25 14:20:00'
    },
    {
      id: '3',
      code: 'LO20240328003',
      assetName: '服务器',
      assetCode: 'AST00789',
      borrower: '王五',
      department: 'TECHNOLOGY',
      loanDate: '2026-04-01',
      expectedReturnDate: '2026-05-01',
      actualReturnDate: null,
      status: 'LOANED',
      overdueDays: 0,
      isOverdue: false,
      isNearDue: true,
      purpose: '系统测试',
      createdAt: '2026-04-01 09:15:00'
    },
    {
      id: '4',
      code: 'LO20240328004',
      assetName: '打印机',
      assetCode: 'AST00234',
      borrower: '赵六',
      department: 'FINANCE',
      loanDate: '2026-03-20',
      expectedReturnDate: '2026-03-30',
      actualReturnDate: '2026-03-29',
      status: 'RETURNED',
      overdueDays: 0,
      isOverdue: false,
      isNearDue: false,
      purpose: '财务报表打印',
      createdAt: '2026-03-20 16:45:00'
    },
    {
      id: '5',
      code: 'LO20240328005',
      assetName: '办公桌椅',
      assetCode: 'AST00567',
      borrower: '钱七',
      department: 'ADMINISTRATION',
      loanDate: '2026-03-15',
      expectedReturnDate: '2026-04-15',
      actualReturnDate: null,
      status: 'LOANED',
      overdueDays: 0,
      isOverdue: false,
      isNearDue: false,
      purpose: '新员工办公',
      createdAt: '2026-03-15 11:30:00'
    }
  ]

  // 应用筛选条件
  let filteredData = [...mockData]
  
  if (filterParams.status) {
    filteredData = filteredData.filter(item => item.status === filterParams.status)
  }
  
  if (filterParams.borrower) {
    filteredData = filteredData.filter(item => 
      item.borrower.includes(filterParams.borrower)
    )
  }
  
  if (filterParams.department) {
    filteredData = filteredData.filter(item => item.department === filterParams.department)
  }
  
  if (filterParams.overdueStatus) {
    if (filterParams.overdueStatus === 'OVERDUE') {
      filteredData = filteredData.filter(item => item.isOverdue)
    } else if (filterParams.overdueStatus === 'NEAR_DUE') {
      filteredData = filteredData.filter(item => item.isNearDue && !item.isOverdue)
    } else if (filterParams.overdueStatus === 'NORMAL') {
      filteredData = filteredData.filter(item => !item.isOverdue && !item.isNearDue)
    }
  }

  // 计算统计
  overdueCount.value = filteredData.filter(item => item.isOverdue).length
  nearDueCount.value = filteredData.filter(item => item.isNearDue && !item.isOverdue).length
  
  stats.total = filteredData.length
  stats.loaned = filteredData.filter(item => item.status === 'LOANED' && !item.isOverdue).length
  stats.overdue = filteredData.filter(item => item.isOverdue).length
  stats.nearDue = filteredData.filter(item => item.isNearDue && !item.isOverdue).length
  stats.returned = filteredData.filter(item => item.status === 'RETURNED').length

  // 模拟分页
  const startIndex = (pagination.page - 1) * pagination.pageSize
  const endIndex = startIndex + pagination.pageSize
  const pageData = filteredData.slice(startIndex, endIndex)
  
  tableData.value = pageData
  total.value = filteredData.length
  pagination.itemCount = filteredData.length
  
  loading.value = false
}

// 生命周期
onMounted(() => {
  loadMockData()
})
</script>

<style scoped>
.loan-out-table {
  padding: 16px;
}

.table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.header-left {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.table-title {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
  color: var(--text-color);
}

.header-stats {
  display: flex;
  gap: 8px;
  align-items: center;
}

.filter-section {
  padding: 16px;
  background-color: var(--background-color-light);
  border-radius: 8px;
  margin-bottom: 16px;
}

.batch-actions {
  padding: 12px 16px;
  background-color: var(--primary-color-soft);
  border: 1px solid var(--primary-color);
  border-radius: 6px;
  margin: 16px 0;
}

.stat-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-top: 24px;
}

.stat-card {
  transition: all 0.3s;
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.stat-content {
  display: flex;
  align-items: center;
  gap: 16px;
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.stat-icon.loaned {
  background-color: var(--info-color-soft);
  color: var(--info-color);
}

.stat-icon.overdue {
  background-color: var(--error-color-soft);
  color: var(--error-color);
}

.stat-icon.near-due {
  background-color: var(--warning-color-soft);
  color: var(--warning-color);
}

.stat-icon.returned {
  background-color: var(--success-color-soft);
  color: var(--success-color);
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: 700;
  line-height: 1;
  margin-bottom: 4px;
  color: var(--text-color);
}

.stat-label {
  font-size: 12px;
  color: var(--text-color-secondary);
}

.action-buttons {
  display: flex;
  gap: 4px;
}

@media (max-width: 1200px) {
  .stat-cards {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .table-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }
  
  .header-right {
    width: 100%;
  }
  
  .filter-section {
    padding: 12px;
  }
  
  .stat-cards {
    grid-template-columns: 1fr;
  }
  
  .header-stats {
    flex-wrap: wrap;
  }
}
</style>