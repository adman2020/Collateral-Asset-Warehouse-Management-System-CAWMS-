<template>
  <NDropdown
    trigger="click"
    :options="languageOptions"
    @select="handleLanguageSelect"
  >
    <div class="lang-flag-btn" :class="locale" :title="currentLabel">
      <img
        v-if="!imgErrorMap[locale]"
        :src="currentFlag"
        :alt="currentCode"
        class="flag-img"
        @error="onImgError(locale)"
      />
      <span v-else class="flag-text">{{ currentCode }}</span>
    </div>
  </NDropdown>
</template>

<script setup lang="ts">
import { NDropdown } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { computed, h, reactive } from 'vue'

const { locale } = useI18n()
const nuxtApp = useNuxtApp()

const setLocale = async (lang: string) => {
  const i18n = nuxtApp.$i18n as any
  if (i18n.setLocale) {
    await i18n.setLocale(lang)
  } else {
    locale.value = lang
  }
}

const langMap: Record<string, { code: string; label: string; flag: string }> = {
  zh: { code: '中', label: '中文', flag: new URL('~/assets/images/flags/zh.png', import.meta.url).href },
  vi: { code: 'VI', label: 'Tiếng Việt', flag: new URL('~/assets/images/flags/vi.png', import.meta.url).href },
  en: { code: 'EN', label: 'English', flag: new URL('~/assets/images/flags/en.png', import.meta.url).href }
}

const currentCode = computed(() => langMap[locale.value]?.code || '中')
const currentLabel = computed(() => langMap[locale.value]?.label || '中文')
const currentFlag = computed(() => langMap[locale.value]?.flag || langMap.zh.flag)

// 图片加载失败状态跟踪（兜底：加载失败回退到色块+文字）
const imgErrorMap = reactive<Record<string, boolean>>({})
const onImgError = (key: string) => {
  imgErrorMap[key] = true
}

const renderOption = (key: string) => {
  const item = langMap[key]
  const hasError = imgErrorMap[key]
  return h('div', { style: 'display:flex;align-items:center;gap:8px' }, [
    hasError
      ? h('span', {
          class: `fallback-circle ${key}`,
          style: 'display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:50%;color:white;font-size:11px;font-weight:600;'
        }, item.code)
      : h('img', {
          src: item.flag,
          alt: item.code,
          style: 'width:22px;height:22px;border-radius:50%;object-fit:cover;',
          onError: () => onImgError(key)
        }),
    h('span', {}, item.label)
  ])
}

const languageOptions = computed(() => [
  { label: () => renderOption('zh'), key: 'zh' },
  { label: () => renderOption('vi'), key: 'vi' },
  { label: () => renderOption('en'), key: 'en' }
])

const handleLanguageSelect = async (key: string | number) => {
  const lang = key as string
  localStorage.setItem('locale', lang)
  await setLocale(lang)
}
</script>

<style scoped>
.lang-flag-btn {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform 0.2s;
  user-select: none;
  border: 1px solid rgba(0,0,0,0.08);
  overflow: hidden;
}
.lang-flag-btn.zh {
  background: #DE2910;
}
.lang-flag-btn.vi {
  background: #DA020E;
}
.lang-flag-btn.en {
  background: #012169;
}
.lang-flag-btn:hover {
  transform: scale(1.08);
  box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}
.flag-img {
  width: 32px;
  height: 32px;
  object-fit: cover;
}
.flag-text {
  font-size: 12px;
  font-weight: 700;
  color: white;
  line-height: 1;
}
.fallback-circle.zh {
  background: #DE2910;
}
.fallback-circle.vi {
  background: #DA020E;
}
.fallback-circle.en {
  background: #012169;
}
</style>
