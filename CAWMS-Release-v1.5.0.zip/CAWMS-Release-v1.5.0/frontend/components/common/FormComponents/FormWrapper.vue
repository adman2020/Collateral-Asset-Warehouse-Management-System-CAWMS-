<template>
  <NForm
    ref="formRef"
    :model="model"
    :rules="rules"
    :label-placement="labelPlacement"
    :label-width="labelWidth"
    :label-align="labelAlign"
    :size="size"
    :disabled="disabled"
    :show-require-mark="showRequireMark"
    :require-mark-placement="requireMarkPlacement"
    :inline="inline"
    class="form-wrapper"
  >
    <slot />
  </NForm>
</template>

<script setup lang="ts">
import { NForm, FormInst, FormRules } from 'naive-ui'
import type { FormItemRule } from 'naive-ui'

interface Props {
  // 表单数据模型
  model: Record<string, any>
  // 验证规则
  rules?: FormRules
  // 标签位置
  labelPlacement?: 'left' | 'top'
  // 标签宽度
  labelWidth?: string | number
  // 标签对齐方式
  labelAlign?: 'left' | 'right'
  // 尺寸
  size?: 'small' | 'medium' | 'large'
  // 是否禁用
  disabled?: boolean
  // 是否显示必填标记
  showRequireMark?: boolean
  // 必填标记位置
  requireMarkPlacement?: 'right' | 'left' | 'right-hanging'
  // 是否行内布局
  inline?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  model: () => ({}),
  rules: () => ({}),
  labelPlacement: 'left',
  labelWidth: 'auto',
  labelAlign: 'right',
  size: 'medium',
  disabled: false,
  showRequireMark: true,
  requireMarkPlacement: 'right',
  inline: false
})

// 表单引用
const formRef = ref<FormInst | null>(null)

// 表单验证方法
const validate = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (!formRef.value) {
      reject(new Error('表单引用不存在'))
      return
    }
    
    formRef.value.validate((errors) => {
      if (errors) {
        reject(errors)
      } else {
        resolve()
      }
    })
  })
}

const validateField = (paths: string | string[]) => {
  if (!formRef.value) return
  
  formRef.value.validate(paths, (errors) => {
    if (errors) {
      console.log('字段验证错误:', errors)
    }
  })
}

const restoreValidation = () => {
  if (!formRef.value) return
  formRef.value.restoreValidation()
}

// 获取表单数据
const getFormData = () => {
  return { ...props.model }
}

// 重置表单
const resetForm = () => {
  if (!formRef.value) return
  formRef.value.restoreValidation()
}

// 暴露方法给父组件
defineExpose({
  validate,
  validateField,
  restoreValidation,
  getFormData,
  resetForm,
  formRef
})
</script>

<style scoped>
.form-wrapper {
  width: 100%;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .form-wrapper :deep(.n-form-item-label) {
    padding-bottom: 4px;
  }
}

/* 表单间距调整 */
.form-wrapper :deep(.n-form-item) {
  margin-bottom: 20px;
}

.form-wrapper :deep(.n-form-item:last-child) {
  margin-bottom: 0;
}

/* 行内表单样式 */
.form-wrapper.inline-form :deep(.n-form-item) {
  margin-bottom: 0;
  margin-right: 16px;
}

.form-wrapper.inline-form :deep(.n-form-item:last-child) {
  margin-right: 0;
}
</style>