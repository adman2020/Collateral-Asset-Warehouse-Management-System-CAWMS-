<template>
  <NFormItem
    :label="label"
    :path="path"
    :rule="rule"
    :required="required"
    :show-require-mark="showRequireMark"
    :show-feedback="showFeedback"
    :feedback="feedback"
    :size="size"
    :label-width="labelWidth"
    :label-align="labelAlign"
    :label-placement="labelPlacement"
    :disabled="disabled"
    class="form-item-wrapper"
  >
    <template v-if="$slots.label" #label>
      <slot name="label" />
    </template>
    
    <slot />
    
    <template v-if="$slots.feedback" #feedback>
      <slot name="feedback" />
    </template>
  </NFormItem>
</template>

<script setup lang="ts">
import { NFormItem } from 'naive-ui'
import type { FormItemRule } from 'naive-ui'

interface Props {
  // 标签文本
  label?: string
  // 字段路径（用于验证和绑定）
  path?: string
  // 验证规则
  rule?: FormItemRule | FormItemRule[]
  // 是否必填
  required?: boolean
  // 是否显示必填标记
  showRequireMark?: boolean
  // 是否显示反馈信息
  showFeedback?: boolean
  // 自定义反馈信息
  feedback?: string
  // 尺寸
  size?: 'small' | 'medium' | 'large'
  // 标签宽度
  labelWidth?: string | number
  // 标签对齐方式
  labelAlign?: 'left' | 'right'
  // 标签位置
  labelPlacement?: 'left' | 'top'
  // 是否禁用
  disabled?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  label: '',
  path: '',
  rule: undefined,
  required: false,
  showRequireMark: true,
  showFeedback: true,
  feedback: '',
  size: 'medium',
  labelWidth: 'auto',
  labelAlign: 'right',
  labelPlacement: 'left',
  disabled: false
})

// 提供一些工具方法
const validate = () => {
  // 实际验证逻辑由父级Form处理
  console.log('验证字段:', props.path)
}

const clearValidation = () => {
  console.log('清除字段验证:', props.path)
}

// 暴露方法
defineExpose({
  validate,
  clearValidation
})
</script>

<style scoped>
.form-item-wrapper {
  width: 100%;
}

/* 自定义表单项样式 */
.form-item-wrapper :deep(.n-form-item-label) {
  font-weight: 500;
  color: var(--text-color);
}

.form-item-wrapper :deep(.n-form-item-label__text) {
  font-size: 14px;
}

.form-item-wrapper :deep(.n-form-item-feedback-wrapper) {
  min-height: 20px;
}

.form-item-wrapper :deep(.n-form-item-feedback__line) {
  font-size: 12px;
  margin-top: 4px;
}

/* 必填标记样式 */
.form-item-wrapper :deep(.n-form-item-label__asterisk) {
  color: var(--error-color);
  margin-right: 4px;
}

/* 禁用状态 */
.form-item-wrapper.disabled :deep(.n-form-item-label) {
  color: var(--text-color-disabled);
}

/* 错误状态 */
.form-item-wrapper.error :deep(.n-form-item-label) {
  color: var(--error-color);
}

/* 响应式设计 */
@media (max-width: 768px) {
  .form-item-wrapper {
    margin-bottom: 16px;
  }
  
  .form-item-wrapper :deep(.n-form-item-label) {
    padding-bottom: 6px;
  }
}

@media (max-width: 576px) {
  .form-item-wrapper {
    margin-bottom: 12px;
  }
}
</style>