<template>
  <NDataTable
    :data="props.data"
    :columns="internalColumns"
    :loading="props.loading"
    :pagination="internalPagination"
    :scroll-x="scrollX"
    striped
    remote
    @update:page="onPageChange"
    @update:page-size="onPageSizeChange"
  />
</template>

<script setup lang="ts">
import { computed, h, useSlots } from 'vue'
import { NDataTable, NPagination } from 'naive-ui'

interface Column {
  title: string
  key: string
  width?: number
  minWidth?: number
  fixed?: 'left' | 'right'
  slot?: string
  ellipsis?: boolean | { tooltip: boolean }
  render?: (row: any) => any
}

interface Pagination {
  page: number
  pageSize: number
  pageCount: number
  showSizePicker?: boolean
  pageSizes?: number[]
  prefix?: () => any
}

const props = defineProps<{
  data: any[]
  columns: Column[]
  loading?: boolean
  pagination?: Pagination
}>()

const emit = defineEmits<{
  (e: 'update:page', page: number): void
  (e: 'update:page-size', size: number): void
}>()

const slots = useSlots()

const internalColumns = computed(() => {
  return props.columns.map(col => {
    const base: any = {
      title: col.title,
      key: col.key,
      width: col.width,
      minWidth: col.minWidth,
      fixed: col.fixed,
      ellipsis: col.ellipsis
    }
    if (col.slot && slots[col.slot]) {
      base.render = (row: any) => slots[col.slot]!({ row })
    } else if (col.render) {
      base.render = col.render
    }
    return base
  })
})

const scrollX = computed(() => {
  return props.columns.reduce((sum, col) => sum + (col.width || 120), 0)
})

const internalPagination = computed(() => {
  if (!props.pagination) return false
  return {
    page: props.pagination.page,
    pageSize: props.pagination.pageSize,
    pageCount: props.pagination.pageCount,
    showSizePicker: props.pagination.showSizePicker ?? true,
    pageSizes: props.pagination.pageSizes ?? [10, 20, 50],
    prefix: props.pagination.prefix
  }
})

function onPageChange(page: number) {
  emit('update:page', page)
}
function onPageSizeChange(size: number) {
  emit('update:page-size', size)
}
</script>
