<template>
  <div class="file-upload">
    <!-- 文件上传区域 -->
    <div
      class="upload-area"
      :class="{
        'drag-over': isDragOver,
        'disabled': disabled,
        'has-files': files.length > 0
      }"
      @click="handleAreaClick"
      @dragover.prevent="handleDragOver"
      @dragleave.prevent="handleDragLeave"
      @drop.prevent="handleDrop"
    >
      <div class="upload-content">
        <NIcon size="48" :color="iconColor">
          <CloudUploadOutline />
        </NIcon>
        <div class="upload-text">
          <template v-if="files.length === 0">
            <p class="upload-title">{{ title }}</p>
            <p class="upload-hint">{{ hint }}</p>
          </template>
          <template v-else>
            <p class="upload-title">已选择 {{ files.length }} 个文件</p>
            <p class="upload-hint">点击或拖拽继续添加文件</p>
          </template>
        </div>
        <input
          ref="fileInputRef"
          type="file"
          :multiple="multiple"
          :accept="accept"
          :disabled="disabled"
          style="display: none;"
          @change="handleFileChange"
        />
      </div>
    </div>

    <!-- 文件列表 -->
    <div v-if="files.length > 0" class="file-list">
      <div v-for="(file, index) in files" :key="file.id" class="file-item">
        <div class="file-info">
          <NIcon size="24" class="file-icon" :color="getFileIconColor(file)">
            <component :is="getFileIcon(file)" />
          </NIcon>
          <div class="file-details">
            <div class="file-name" :title="file.name">{{ file.name }}</div>
            <div class="file-meta">
              <span class="file-size">{{ formatFileSize(file.size) }}</span>
              <span v-if="file.progress !== undefined" class="file-progress">
                <NProgress
                  type="line"
                  :percentage="file.progress"
                  :height="6"
                  :show-indicator="false"
                  :border-radius="0"
                />
                <span class="progress-text">{{ file.progress }}%</span>
              </span>
              <span v-else-if="file.error" class="file-error">
                {{ file.error }}
              </span>
            </div>
          </div>
        </div>
        <div class="file-actions">
          <NButton
            v-if="file.previewable"
            quaternary
            circle
            size="small"
            :disabled="disabled"
            @click="handlePreview(file)"
          >
            <template #icon>
              <NIcon><EyeOutline /></NIcon>
            </template>
          </NButton>
          <NButton
            quaternary
            circle
            size="small"
            :disabled="disabled"
            @click="handleDownload(file)"
          >
            <template #icon>
              <NIcon><DownloadOutline /></NIcon>
            </template>
          </NButton>
          <NButton
            quaternary
            circle
            size="small"
            :disabled="disabled"
            type="error"
            @click="handleRemove(index)"
          >
            <template #icon>
              <NIcon><TrashOutline /></NIcon>
            </template>
          </NButton>
        </div>
      </div>
    </div>

    <!-- 上传进度 -->
    <div v-if="uploading" class="upload-progress">
      <div class="progress-header">
        <span>正在上传 ({{ uploadingCount }}/{{ files.length }})</span>
        <NButton
          size="tiny"
          type="error"
          :disabled="!canCancel"
          @click="handleCancelUpload"
        >
          取消
        </NButton>
      </div>
      <NProgress
        type="line"
        :percentage="totalProgress"
        :height="8"
        :border-radius="0"
        :show-indicator="false"
      />
      <div class="progress-text">
        {{ uploadedSize }}/{{ totalSize }} ({{ totalProgress }}%)
      </div>
    </div>

    <!-- 操作按钮 -->
    <div v-if="showActions && files.length > 0" class="upload-actions">
      <NSpace>
        <NButton size="small" @click="handleClear" :disabled="disabled">
          清空列表
        </NButton>
        <NButton
          size="small"
          type="primary"
          @click="handleUpload"
          :loading="uploading"
          :disabled="disabled || files.length === 0"
        >
          {{ uploadButtonText }}
        </NButton>
      </NSpace>
    </div>

    <!-- 文件限制提示 -->
    <div v-if="showLimits" class="upload-limits">
      <NAlert type="info" :show-icon="false" size="small">
        <template #header>
          <div class="limits-header">
            <NIcon size="14"><InformationCircleOutline /></NIcon>
            <span>文件上传限制</span>
          </div>
        </template>
        <div class="limits-content">
          <p>• 支持格式: {{ acceptText || '所有格式' }}</p>
          <p>• 单文件大小: ≤ {{ formatFileSize(maxSize) }}</p>
          <p v-if="maxCount > 1">• 最多上传 {{ maxCount }} 个文件</p>
          <p v-else>• 只能上传 1 个文件</p>
        </div>
      </NAlert>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  NIcon,
  NButton,
  NProgress,
  NSpace,
  NAlert,
  useMessage
} from 'naive-ui'
import {
  CloudUploadOutline,
  EyeOutline,
  DownloadOutline,
  TrashOutline,
  InformationCircleOutline,
  DocumentOutline,
  ImageOutline,
  VideocamOutline,
  MusicalNotesOutline,
  ArchiveOutline,
  CodeOutline
} from '@vicons/ionicons5'
import { ref, reactive, computed, watch, nextTick } from 'vue'

// 全局消息
const message = useMessage()

// 类型定义
interface UploadFile {
  id: string
  name: string
  size: number
  type: string
  file: File
  url?: string
  previewable: boolean
  progress?: number
  error?: string
  uploaded?: boolean
}

// 属性定义
interface Props {
  // 基础配置
  modelValue?: File[]
  multiple?: boolean
  accept?: string
  maxSize?: number
  maxCount?: number
  disabled?: boolean
  
  // 显示配置
  title?: string
  hint?: string
  showActions?: boolean
  showLimits?: boolean
  uploadButtonText?: string
  
  // 功能配置
  autoUpload?: boolean
  chunkedUpload?: boolean
  chunkSize?: number
  maxConcurrent?: number
  
  // 验证配置
  validateFile?: (file: File) => string | null
}

// 事件定义
interface Emits {
  (e: 'update:modelValue', files: File[]): void
  (e: 'change', files: UploadFile[]): void
  (e: 'upload', files: UploadFile[]): Promise<void> | void
  (e: 'upload-success', result: any): void
  (e: 'upload-error', error: Error): void
  (e: 'file-added', file: UploadFile): void
  (e: 'file-removed', file: UploadFile): void
  (e: 'file-preview', file: UploadFile): void
  (e: 'file-download', file: UploadFile): void
}

const props = withDefaults(defineProps<Props>(), {
  modelValue: () => [],
  multiple: true,
  accept: '*/*',
  maxSize: 10 * 1024 * 1024, // 10MB
  maxCount: 10,
  disabled: false,
  title: '点击或拖拽文件到此处',
  hint: '支持单个或多个文件上传',
  showActions: true,
  showLimits: true,
  uploadButtonText: '上传文件',
  autoUpload: false,
  chunkedUpload: false,
  chunkSize: 1024 * 1024, // 1MB
  maxConcurrent: 3,
  validateFile: () => null
})

const emit = defineEmits<Emits>()

// 响应式状态
const fileInputRef = ref<HTMLInputElement>()
const isDragOver = ref(false)
const files = reactive<UploadFile[]>([])
const uploading = ref(false)
const uploadedCount = ref(0)
const cancelToken = ref<AbortController | null>(null)

// 计算属性
const iconColor = computed(() => {
  if (disabled.value) return '#d9d9d9'
  if (isDragOver.value) return 'var(--primary-color)'
  return '#666'
})

const disabled = computed(() => props.disabled || uploading.value)

const uploadingCount = computed(() => {
  return files.filter(f => f.progress !== undefined && f.progress < 100).length
})

const totalProgress = computed(() => {
  if (files.length === 0) return 0
  const total = files.reduce((sum, file) => sum + (file.progress || 0), 0)
  return Math.round(total / files.length)
})

const totalSize = computed(() => {
  return files.reduce((sum, file) => sum + file.size, 0)
})

const uploadedSize = computed(() => {
  const size = files.reduce((sum, file) => {
    const progress = file.progress || 0
    return sum + Math.round((file.size * progress) / 100)
  }, 0)
  return formatFileSize(size)
})

const canCancel = computed(() => {
  return cancelToken.value !== null
})

const acceptText = computed(() => {
  if (!props.accept || props.accept === '*/*') return ''
  
  const types = props.accept.split(',').map(type => {
    const ext = type.trim().replace('.', '')
    return ext.toUpperCase()
  })
  
  return types.join(', ')
})

// 文件类型判断
const getFileIcon = (file: UploadFile) => {
  const type = file.type.toLowerCase()
  
  if (type.startsWith('image/')) return ImageOutline
  if (type.startsWith('video/')) return VideocamOutline
  if (type.startsWith('audio/')) return MusicalNotesOutline
  if (type.includes('pdf')) return DocumentOutline
  if (type.includes('zip') || type.includes('rar') || type.includes('7z')) return ArchiveOutline
  if (type.includes('text') || type.includes('code')) return CodeOutline
  return DocumentOutline
}

const getFileIconColor = (file: UploadFile) => {
  const type = file.type.toLowerCase()
  
  if (type.startsWith('image/')) return '#52c41a'
  if (type.startsWith('video/')) return '#1890ff'
  if (type.startsWith('audio/')) return '#fa8c16'
  if (type.includes('pdf')) return '#ff4d4f'
  if (type.includes('zip') || type.includes('rar') || type.includes('7z')) return '#722ed1'
  if (type.includes('text') || type.includes('code')) return '#13c2c2'
  return '#666'
}

// 工具函数
const formatFileSize = (bytes: number) => {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`
}

const generateFileId = () => {
  return `file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

const validateFileBeforeAdd = (file: File): string | null => {
  // 检查文件大小
  if (file.size > props.maxSize) {
    return `文件大小超过限制 (${formatFileSize(props.maxSize)})`
  }
  
  // 检查文件类型
  if (props.accept !== '*/*') {
    const acceptTypes = props.accept.split(',').map(type => type.trim().toLowerCase())
    const fileType = file.type.toLowerCase()
    const fileExt = '.' + file.name.split('.').pop()?.toLowerCase()
    
    const isAccepted = acceptTypes.some(type => {
      if (type.startsWith('.')) {
        return fileExt === type
      } else if (type.includes('/')) {
        return fileType === type || fileType.startsWith(type.replace('/*', '/'))
      }
      return false
    })
    
    if (!isAccepted) {
      return '文件类型不支持'
    }
  }
  
  // 自定义验证
  if (props.validateFile) {
    return props.validateFile(file)
  }
  
  return null
}

// 事件处理
const handleAreaClick = () => {
  if (disabled.value || !fileInputRef.value) return
  fileInputRef.value.click()
}

const handleDragOver = (event: DragEvent) => {
  if (disabled.value) return
  event.preventDefault()
  isDragOver.value = true
}

const handleDragLeave = (event: DragEvent) => {
  if (disabled.value) return
  event.preventDefault()
  isDragOver.value = false
}

const handleDrop = async (event: DragEvent) => {
  if (disabled.value) return
  event.preventDefault()
  isDragOver.value = false
  
  const droppedFiles = Array.from(event.dataTransfer?.files || [])
  await addFiles(droppedFiles)
}

const handleFileChange = async (event: Event) => {
  const input = event.target as HTMLInputElement
  if (!input.files || input.files.length === 0) return
  
  const selectedFiles = Array.from(input.files)
  await addFiles(selectedFiles)
  
  // 清空input以便再次选择相同文件
  input.value = ''
}

const addFiles = async (fileList: File[]) => {
  // 检查文件数量限制
  const remainingSlots = props.maxCount - files.length
  if (remainingSlots <= 0) {
    message.warning(`最多只能上传 ${props.maxCount} 个文件`)
    return
  }
  
  const filesToAdd = fileList.slice(0, remainingSlots)
  
  for (const file of filesToAdd) {
    const error = validateFileBeforeAdd(file)
    
    if (error) {
      message.error(`${file.name}: ${error}`)
      continue
    }
    
    const uploadFile: UploadFile = {
      id: generateFileId(),
      name: file.name,
      size: file.size,
      type: file.type,
      file,
      previewable: file.type.startsWith('image/') || file.type.startsWith('video/') || file.type.includes('pdf'),
      progress: 0,
      uploaded: false
    }
    
    // 生成预览URL（仅图片和视频）
    if (uploadFile.previewable) {
      uploadFile.url = URL.createObjectURL(file)
    }
    
    files.push(uploadFile)
    emit('file-added', uploadFile)
  }
  
  emit('change', [...files])
  emit('update:modelValue', files.map(f => f.file))
  
  // 自动上传
  if (props.autoUpload && files.length > 0) {
    await handleUpload()
  }
}

const handleRemove = (index: number) => {
  if (disabled.value) return
  
  const removedFile = files[index]
  
  // 清理预览URL
  if (removedFile.url && removedFile.url.startsWith('blob:')) {
    URL.revokeObjectURL(removedFile.url)
  }
  
  files.splice(index, 1)
  emit('file-removed', removedFile)
  emit('change', [...files])
  emit('update:modelValue', files.map(f => f.file))
}

const handleClear = () => {
  if (disabled.value) return
  
  // 清理所有预览URL
  files.forEach(file => {
    if (file.url && file.url.startsWith('blob:')) {
      URL.revokeObjectURL(file.url)
    }
  })
  
  files.splice(0, files.length)
  emit('change', [])
  emit('update:modelValue', [])
}

const handlePreview = (file: UploadFile) => {
  if (disabled.value || !file.previewable) return
  emit('file-preview', file)
}

const handleDownload = (file: UploadFile) => {
  if (disabled.value) return
  emit('file-download', file)
}

// 上传处理
const handleUpload = async () => {
  if (disabled.value || files.length === 0) return
  
  uploading.value = true
  uploadedCount.value = 0
  cancelToken.value = new AbortController()
  
  try {
    await emit('upload', [...files])
    
    // 如果没有自定义上传处理，使用默认模拟上传
    if (files.some(f => f.progress === 0 || f.progress === undefined)) {
      await simulateUpload()
    }
    
    emit('upload-success', { files: [...files] })
    message.success('上传成功')
    
  } catch (error) {
    emit('upload-error', error as Error)
    message.error('上传失败')
  } finally {
    uploading.value = false
    cancelToken.value = null
  }
}

const simulateUpload = async () => {
  const promises = files.map(file => 
    simulateFileUpload(file, cancelToken.value!.signal)
  )
  
  await Promise.all(promises)
}

const simulateFileUpload = (file: UploadFile, signal: AbortSignal): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (signal.aborted) {
      reject(new Error('Upload cancelled'))
      return
    }
    
    let progress = 0
    const interval = setInterval(() => {
      if (signal.aborted) {
        clearInterval(interval)
        reject(new Error('Upload cancelled'))
        return
      }
      
      progress += Math.random() * 10
      if (progress > 100) progress = 100
      
      file.progress = progress
      
      if (progress === 100) {
        clearInterval(interval)
        file.uploaded = true
        uploadedCount.value++
        resolve()
      }
    }, 200)
  })
}

const handleCancelUpload = () => {
  if (cancelToken.value) {
    cancelToken.value.abort()
    cancelToken.value = null
    uploading.value = false
    message.info('上传已取消')
  }
}

// 监听文件变化
watch(() => props.modelValue, (newFiles) => {
  if (newFiles.length === 0 && files.length > 0) {
    handleClear()
  }
}, { deep: true })

// 清理预览URL
onUnmounted(() => {
  files.forEach(file => {
    if (file.url && file.url.startsWith('blob:')) {
      URL.revokeObjectURL(file.url)
    }
  })
})
</script>

<style scoped>
.file-upload {
  width: 100%;
}

.upload-area {
  border: 2px dashed var(--border-color);
  border-radius: 8px;
  padding: 48px 24px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s;
  background-color: var(--background-color-light);
  margin-bottom: 16px;
}

.upload-area:hover:not(.disabled) {
  border-color: var(--primary-color);
  background-color: var(--background-color-hover);
}

.upload-area.drag-over {
  border-color: var(--primary-color);
  background-color: var(--primary-color-soft);
}

.upload-area.disabled {
  cursor: not-allowed;
  opacity: 0.6;
}

.upload-area.has-files {
  padding: 32px 24px;
}

.upload-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
}

.upload-text {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.upload-title {
  font-size: 16px;
  font-weight: 500;
  margin: 0;
  color: var(--text-color);
}

.upload-hint {
  font-size: 12px;
  margin: 0;
  color: var(--text-color-secondary);
}

.file-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 16px;
}

.file-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px;
  border: 1px solid var(--border-color);
  border-radius: 6px;
  background-color: var(--background-color);
  transition: all 0.3s;
}

.file-item:hover {
  border-color: var(--primary-color);
  background-color: var(--background-color-hover);
}

.file-info {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: 1;
  min-width: 0;
}

.file-icon {
  flex-shrink: 0;
}

.file-details {
  flex: 1;
  min-width: 0;
}

.file-name {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-color);
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.file-meta {
  display: flex;
  gap: 12px;
  font-size: 12px;
  color: var(--text-color-secondary);
}

.file-progress {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  max-width: 200px;
}

.progress-text {
  font-size: 11px;
  min-width: 32px;
}

.file-error {
  color: var(--error-color);
}

.file-actions {
  display: flex;
  gap: 4px;
  flex-shrink: 0;
}

.upload-progress {
  padding: 12px;
  border: 1px solid var(--border-color);
  border-radius: 6px;
  background-color: var(--background-color-light);
  margin-bottom: 16px;
}

.progress-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  font-size: 14px;
  font-weight: 500;
  color: var(--text-color);
}

.upload-actions {
  margin-top: 16px;
}

.upload-limits {
  margin-top: 16px;
}

.limits-header {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 4px;
}

.limits-content {
  font-size: 12px;
  color: var(--text-color-secondary);
  line-height: 1.6;
}

.limits-content p {
  margin: 2px 0;
}

@media (max-width: 768px) {
  .upload-area {
    padding: 32px 16px;
  }
  
  .file-item {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }
  
  .file-actions {
    align-self: flex-end;
  }
}
</style>