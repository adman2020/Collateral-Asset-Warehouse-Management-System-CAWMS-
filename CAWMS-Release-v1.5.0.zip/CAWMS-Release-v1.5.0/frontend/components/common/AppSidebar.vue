<template>
  <NLayoutSider
    :collapsed="collapsed"
    :collapsed-width="64"
    :width="256"
    :native-scrollbar="false"
    bordered
    show-trigger
    collapse-mode="width"
    class="app-sidebar"
    @collapse="collapsed = true"
    @expand="collapsed = false"
  >
    <!-- 侧边栏头部 -->
    <div class="sidebar-header" @click="handleLogoClick">
      <div class="sidebar-logo">
        <div class="logo-icon">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="currentColor"/>
            <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2"/>
            <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2"/>
          </svg>
        </div>
        <transition name="slide-fade">
          <div v-if="!collapsed" class="logo-text">
            <h1>CAWMS</h1>
            <p>{{ t('app.title') }}</p>
          </div>
        </transition>
      </div>
    </div>

    <!-- 侧边栏内容 -->
    <div class="sidebar-content">
      <NMenu
        :key="locale"
        v-model:value="activeKey"
        :collapsed="collapsed"
        :collapsed-width="64"
        :collapsed-icon-size="20"
        :options="safeMenuOptions"
        :indent="24"
        :expanded-keys="expandedKeys"
        @update:expanded-keys="expandedKeys = $event"
        @update:value="handleMenuSelect"
      />
    </div>

    <!-- 快捷操作（展开时显示） -->
    <transition name="slide-fade">
      <div v-if="!collapsed" class="sidebar-quick-actions">
        <h3 class="quick-actions-title">{{ t('quickActions.title') }}</h3>
        <div class="quick-actions-grid">
          <NButton
            v-for="action in quickActions"
            :key="action.key"
            size="small"
            :type="action.type"
            @click="handleQuickAction(action)"
          >
            <template #icon>
              <NIcon><component :is="action.icon" /></NIcon>
            </template>
            {{ action.label }}
          </NButton>
        </div>
      </div>
    </transition>

    <!-- 侧边栏底部 -->
    <div class="sidebar-footer">
      <transition name="slide-fade">
        <div v-if="!collapsed" class="sidebar-user">
          <NAvatar round :size="32" :src="userAvatar" />
          <div class="user-details">
            <span class="user-name">{{ userFullName }}</span>
            <span class="user-role">{{ userRole }}</span>
          </div>
        </div>
      </transition>

      <div class="sidebar-collapse">
        <NButton quaternary circle size="medium" @click="$emit('toggle')">
          <template #icon>
            <NIcon>
              <component :is="collapsed ? ChevronForwardOutline : ChevronBackOutline" />
            </NIcon>
          </template>
        </NButton>
      </div>
    </div>
  </NLayoutSider>
</template>

<script setup lang="ts">
import {
  NLayoutSider,
  NMenu,
  NIcon,
  NButton,
  NAvatar
} from 'naive-ui'
import type { MenuOption, MenuGroupOption } from 'naive-ui'
import {
  HomeOutline,
  CubeOutline,
  FileTrayFullOutline,
  LogOutOutline,
  SwapHorizontalOutline,
  CashOutline,
  StatsChartOutline,
  DocumentTextOutline,
  SettingsOutline,
  ChevronForwardOutline,
  ChevronBackOutline,
  AddOutline,
  TrendingUpOutline,
  TimeOutline,
  AlertCircleOutline,
  DownloadOutline
} from '@vicons/ionicons5'
import { useAuthStore } from '@/stores/auth'
import { getRoleAvatar } from '@/composables/useRoleAvatar'
import { useI18n } from 'vue-i18n'

interface Props {
  collapsed?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  collapsed: false
})

const emit = defineEmits<{
  toggle: []
}>()

const authStore = useAuthStore()
const route = useRoute()
const router = useRouter()

const activeKey = ref(route.path)
const expandedKeys = ref<string[]>([])

const { t, locale } = useI18n()

const userFullName = computed(() => authStore.user?.fullName || authStore.user?.username || t('user.defaultName'))
const userRole = computed(() => authStore.user?.roleName || authStore.user?.role || t('user.defaultRole'))
const userAvatar = computed(() => {
  // 优先使用用户自定义头像，否则按角色显示
  if (authStore.user?.avatar) return authStore.user.avatar
  return getRoleAvatar(authStore.user?.role)
})

const menuOptions = computed<Array<MenuOption | MenuGroupOption>>(() => [
  {
    label: () => t('menu.dashboard'),
    key: '/',
    icon: () => h(NIcon, null, { default: () => h(HomeOutline) })
  },
  {
    label: () => t('menu.assetManagement'),
    key: 'asset-management',
    icon: () => h(NIcon, null, { default: () => h(CubeOutline) }),
    children: [
      {
        label: () => t('menu.warehouseIn'),
        key: '/warehouse-in',
        icon: () => h(NIcon, null, { default: () => h(FileTrayFullOutline) }),
        children: [
          { label: () => t('menu.warehouseInList'), key: '/warehouse-in' },
          { label: () => t('menu.warehouseInCreate'), key: '/warehouse-in/create' },
          { label: () => t('menu.warehouseInPending'), key: '/approval/pending' }
        ]
      },
      {
        label: () => t('menu.loanOut'),
        key: '/loan-out',
        icon: () => h(NIcon, null, { default: () => h(LogOutOutline) }),
        children: [
          { label: () => t('menu.loanOutList'), key: '/loan-out' },
          { label: () => t('menu.loanOutCreate'), key: '/loan-out/create' },
          { label: () => t('menu.loanOutReturn'), key: '/loan-out/return' },
          { label: () => t('menu.loanOutOverdue'), key: '/loan-out/overdue' }
        ]
      },
      {
        label: () => t('menu.transfer'),
        key: '/transfer',
        icon: () => h(NIcon, null, { default: () => h(SwapHorizontalOutline) }),
        children: [
          { label: () => t('menu.transferList'), key: '/transfer' },
          { label: () => t('menu.transferCreate'), key: '/transfer/create' }
        ]
      },
      {
        label: () => t('menu.warehouseOut'),
        key: '/warehouse-out',
        icon: () => h(NIcon, null, { default: () => h(CashOutline) }),
        children: [
          { label: () => t('menu.warehouseOutList'), key: '/warehouse-out' },
          { label: () => t('menu.warehouseOutCreate'), key: '/warehouse-out/create' }
        ]
      }
    ]
  },
  {
    label: () => t('menu.reports'),
    key: 'reports',
    icon: () => h(NIcon, null, { default: () => h(StatsChartOutline) }),
    children: [
      { label: () => t('menu.reportsInbound'), key: '/reports/inbound' },
      { label: () => t('menu.reportsLoanOut'), key: '/reports/loan-out' },
      { label: () => t('menu.reportsOverdue'), key: '/reports/overdue' },
      { label: () => t('menu.reportsFinancial'), key: '/reports/financial' },
      { label: () => t('menu.reportsDashboard'), key: '/reports/dashboard' }
    ]
  },
  {
    label: () => t('menu.approval'),
    key: 'approval',
    icon: () => h(NIcon, null, { default: () => h(DocumentTextOutline) }),
    children: [
      { label: () => t('menu.approvalPending'), key: '/approval/pending' },
      { label: () => t('menu.approvalCompleted'), key: '/approval/completed' },
      { label: () => t('menu.approvalHistory'), key: '/approval/history' }
    ]
  },
  {
    label: () => t('menu.system'),
    key: 'system',
    icon: () => h(NIcon, null, { default: () => h(SettingsOutline) }),
    children: [
      { label: () => t('menu.systemUsers'), key: '/system/users' },
      { label: () => t('menu.systemRoles'), key: '/system/roles' },
      { label: () => t('menu.systemPermissions'), key: '/system/permissions' },
      { label: () => t('menu.systemWarehouseZones'), key: '/system/warehouse-zones' },
      { label: () => t('menu.systemWarehouses'), key: '/system/warehouses' },
      { label: () => t('menu.systemAuditLogs'), key: '/system/audit-logs' },
      { label: () => t('menu.systemConfig'), key: '/system/config' }
    ]
  }
])

// 关键修复：如果过滤后菜单为空，直接显示全部菜单
const safeMenuOptions = computed(() => {
  const filtered = menuOptions.value.filter(option => checkMenuPermission(option))
  return filtered.length > 0 ? filtered : menuOptions.value
})

const handleLogoClick = () => router.push('/')
const handleMenuSelect = (key: string) => {
  if (key.startsWith('/')) router.push(key)
}

const quickActions = computed(() => [
  { key: 'new-inbound', label: t('quickActions.newInbound'), icon: AddOutline, type: 'primary' as const, path: '/warehouse-in/create' },
  { key: 'new-loan', label: t('quickActions.newLoan'), icon: LogOutOutline, type: 'info' as const, path: '/loan-out/create' },
  { key: 'report', label: t('quickActions.report'), icon: TrendingUpOutline, type: 'success' as const, path: '/reports/inbound' },
  { key: 'approval', label: t('quickActions.pending'), icon: TimeOutline, type: 'warning' as const, path: '/approval/pending' },
  { key: 'alert', label: t('quickActions.overdueAlert'), icon: AlertCircleOutline, type: 'error' as const, path: '/loan-out/overdue' },
  { key: 'export', label: t('quickActions.export'), icon: DownloadOutline, type: 'default' as const, path: '/reports/financial' }
])

const handleQuickAction = (action: any) => {
  if (action.path) router.push(action.path)
}

const checkMenuPermission = (option: MenuOption | MenuGroupOption): boolean => {
  const user = authStore.user
  if (!user) return false
  const role = (user.roleName || user.role || '').toLowerCase()
  if (role.includes('admin')) return true

  const key = (option.key || '') as string
  const restricted = ['system', 'audit-logs', 'permissions']
  if (restricted.some(r => key.includes(r))) {
    return role.includes('manager')
  }
  return true
}

onMounted(() => {
  activeKey.value = route.path
  const parts = route.path.split('/').filter(Boolean)
  if (parts.length > 0) expandedKeys.value = [`/${parts[0]}`]
})

watch(() => route.path, (newPath) => {
  activeKey.value = newPath
})
</script>

<style scoped>
.app-sidebar {
  height: 100vh;
  background: var(--background-color-light);
}
.sidebar-header {
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 16px;
  cursor: pointer;
  border-bottom: 1px solid var(--border-color-split);
}
.sidebar-logo {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
}
.logo-icon {
  width: 32px;
  height: 32px;
  color: var(--primary-color);
  flex-shrink: 0;
}
.logo-icon svg {
  width: 100%;
  height: 100%;
}
.logo-text h1 {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-color);
  margin: 0;
  line-height: 1.2;
  white-space: nowrap;
}
.logo-text p {
  font-size: 12px;
  color: var(--text-color-secondary);
  margin: 0;
  line-height: 1.2;
  white-space: nowrap;
}
.sidebar-content {
  flex: 1;
  overflow-y: auto;
  padding: 12px 0;
}
:deep(.n-menu) {
  background: transparent;
}
:deep(.n-menu-item-content) {
  color: var(--text-color-secondary);
}
:deep(.n-menu-item-content--selected),
:deep(.n-menu-item-content:hover) {
  color: var(--primary-color);
}
.sidebar-footer {
  border-top: 1px solid var(--border-color-split);
  padding: 12px;
}
.sidebar-user {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}
.user-details {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-width: 0;
}
.user-name {
  font-size: 14px;
  color: var(--text-color);
  font-weight: 500;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.user-role {
  font-size: 12px;
  color: var(--text-color-secondary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.sidebar-collapse {
  display: flex;
  justify-content: center;
}
.sidebar-quick-actions {
  border-top: 1px solid var(--border-color-split);
  padding: 12px 16px;
}
.quick-actions-title {
  font-size: 12px;
  color: var(--text-color-secondary);
  margin: 0 0 10px 0;
  font-weight: 500;
}
.quick-actions-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 6px;
}
.quick-actions-grid :deep(.n-button) {
  white-space: normal;
  line-height: 1.2;
  padding: 4px 6px;
  height: auto;
  min-height: 32px;
  font-size: 11px;
}
.slide-fade-enter-active,
.slide-fade-leave-active {
  transition: all 0.2s ease;
}
.slide-fade-enter-from,
.slide-fade-leave-to {
  opacity: 0;
  transform: translateX(-10px);
}
</style>
