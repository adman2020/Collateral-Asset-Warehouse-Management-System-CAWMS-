<template>
  <div class="data-table-container">
    <!-- 表格工具栏 -->
    <div v-if="showToolbar" class="table-toolbar">
      <div class="toolbar-left">
        <slot name="toolbar-left">
          <div v-if="showTitle" class="table-title">
            <h3>{{ title }}</h3>
            <p v-if="subtitle" class="table-subtitle">{{ subtitle }}</p>
          </div>
        </slot>
      </div>
      
      <div class="toolbar-center">
        <slot name="toolbar-center">
          <!-- 搜索框 -->
          <div v-if="showSearch" class="table-search">
            <NInput
              v-model:value="searchValue"
              placeholder="搜索..."
              clearable
              size="small"
              round
              @keyup.enter="handleSearch"
              @clear="handleSearchClear"
            >
              <template #prefix>
                <NIcon><SearchOutline /></NIcon>
              </template>
            </NInput>
          </div>
        </slot>
      </div>
      
      <div class="toolbar-right">
        <slot name="toolbar-right">
          <!-- 刷新按钮 -->
          <NButton
            v-if="showRefresh"
            quaternary
            circle
            size="small"
            @click="handleRefresh"
            :loading="loading"
          >
            <template #icon>
              <NIcon><RefreshOutline /></NIcon>
            </template>
          </NButton>
          
          <!-- 列设置 -->
          <NButton
            v-if="showColumnSettings"
            quaternary
            circle
            size="small"
            @click="columnSettingsVisible = true"
          >
            <template #icon>
              <NIcon><SettingsOutline /></NIcon>
            </template>
          </NButton>
          
          <!-- 导出按钮 -->
          <NButton
            v-if="showExport"
            quaternary
            circle
            size="small"
            @click="handleExport"
          >
            <template #icon>
              <NIcon><DownloadOutline /></NIcon>
            </template>
          </NButton>
          
          <!-- 新建按钮 -->
          <NButton
            v-if="showCreate"
            type="primary"
            size="small"
            @click="handleCreate"
          >
            <template #icon>
              <NIcon><AddOutline /></NIcon>
            </template>
            新建
          </NButton>
        </slot>
      </div>
    </div>
    
    <!-- 数据表格 -->
    <NDataTable
      ref="tableRef"
      :data="processedData"
      :columns="processedColumns"
      :pagination="pagination"
      :loading="loading"
      :bordered="bordered"
      :striped="striped"
      :single-line="singleLine"
      :size="size"
      :max-height="maxHeight"
      :min-height="minHeight"
      :row-key="rowKey"
      :virtual-scroll="virtualScroll"
      :scroll-x="scrollX"
      :remote="remote"
      :row-class-name="rowClassName"
      :row-props="rowProps"
      @update:sorter="handleSorterChange"
      @update:filters="handleFiltersChange"
      @update:page="handlePageChange"
      @update:page-size="handlePageSizeChange"
      @update:checked-row-keys="handleSelectionChange"
      class="data-table"
    >
      <!-- 自定义列插槽 -->
      <template v-for="(_, slotName) in $slots" #[slotName]="slotProps">
        <slot :name="slotName" v-bind="slotProps" />
      </template>
    </NDataTable>
    
    <!-- 空状态 -->
    <template v-if="!loading && (!processedData || processedData.length === 0)">
      <NEmpty v-if="customEmpty" :description="emptyDescription">
        <template v-if="$slots.empty" #default>
          <slot name="empty" />
        </template>
        <template v-if="$slots['empty-action']" #action>
          <slot name="empty-action" />
        </template>
      </NEmpty>
      <NEmpty v-else :description="emptyDescription" />
    </template>
    
    <!-- 列设置弹窗 -->
    <NModal
      v-model:show="columnSettingsVisible"
      preset="dialog"
      title="列设置"
      positive-text="确认"
      negative-text="取消"
      @positive-click="handleColumnSettingsConfirm"
      @negative-click="columnSettingsVisible = false"
    >
      <div class="column-settings">
        <NCheckboxGroup v-model:value="visibleColumns">
          <NSpace vertical>
            <NCheckbox
              v-for="column in allColumns"
              :key="column.key"
              :value="column.key"
              :label="column.title || column.key"
            />
          </NSpace>
        </NCheckboxGroup>
      </div>
    </NModal>
  </div>
</template>

<script setup lang="ts">
import { 
  NDataTable, 
  NButton, 
  NIcon, 
  NInput, 
  NEmpty, 
  NModal, 
  NCheckboxGroup, 
  NCheckbox, 
  NSpace,
  DataTableColumn,
  PaginationProps,
  DataTableRowKey
} from 'naive-ui'
import { 
  SearchOutline, 
  RefreshOutline, 
  SettingsOutline, 
  DownloadOutline, 
  AddOutline 
} from '@vicons/ionicons5'
import type { DataTableInst } from 'naive-ui'

// Props
interface Props {
  // 数据
  data?: any[]
  // 列定义
  columns?: DataTableColumn[]
  // 分页配置
  pagination?: PaginationProps | false
  // 加载状态
  loading?: boolean
  // 表格标题
  title?: string
  subtitle?: string
  // 工具栏显示
  showToolbar?: boolean
  showTitle?: boolean
  showSearch?: boolean
  showRefresh?: boolean
  showColumnSettings?: boolean
  showExport?: boolean
  showCreate?: boolean
  // 表格样式
  bordered?: boolean
  striped?: boolean
  singleLine?: boolean
  size?: 'small' | 'medium' | 'large'
  maxHeight?: string | number
  minHeight?: string | number
  // 行设置
  rowKey?: (row: any) => DataTableRowKey
  virtualScroll?: boolean
  scrollX?: string | number
  // 远程数据
  remote?: boolean
  // 空状态
  customEmpty?: boolean
  emptyDescription?: string
}

const props = withDefaults(defineProps<Props>(), {
  data: () => [],
  columns: () => [],
  pagination: () => ({
    page: 1,
    pageSize: 10,
    pageSizes: [10, 20, 50, 100],
    showSizePicker: true,
    showQuickJumper: true
  }),
  loading: false,
  title: '数据列表',
  subtitle: '',
  showToolbar: true,
  showTitle: true,
  showSearch: true,
  showRefresh: true,
  showColumnSettings: true,
  showExport: true,
  showCreate: true,
  bordered: true,
  striped: false,
  singleLine: false,
  size: 'medium',
  maxHeight: undefined,
  minHeight: undefined,
  rowKey: (row) => row.id,
  virtualScroll: false,
  scrollX: undefined,
  remote: false,
  customEmpty: false,
  emptyDescription: '暂无数据'
})

// Emits
const emit = defineEmits<{
  // 搜索
  search: [value: string]
  // 刷新
  refresh: []
  // 导出
  export: []
  // 新建
  create: []
  // 排序变化
  'sorter-change': [sorter: any]
  // 筛选变化
  'filters-change': [filters: any]
  // 分页变化
  'page-change': [page: number]
  // 页大小变化
  'page-size-change': [pageSize: number]
  // 选择变化
  'selection-change': [selectedRowKeys: any[]]
}>()

// 响应式状态
const searchValue = ref('')
const columnSettingsVisible = ref(false)
const visibleColumns = ref<string[]>([])
const tableRef = ref<DataTableInst | null>(null)

// 计算属性
const allColumns = computed(() => {
  return props.columns.map(col => ({
    key: col.key as string,
    title: col.title as string
  }))
})

const processedColumns = computed(() => {
  if (!props.showColumnSettings || visibleColumns.value.length === 0) {
    return props.columns
  }
  
  return props.columns.filter(col => {
    const key = col.key as string
    return visibleColumns.value.includes(key)
  })
})

const processedData = computed(() => {
  if (!searchValue.value.trim() || !props.showSearch) {
    return props.data
  }
  
  const keyword = searchValue.value.toLowerCase()
  return props.data.filter(item => {
    // 简单搜索实现，实际应用中可能需要更复杂的搜索逻辑
    return JSON.stringify(item).toLowerCase().includes(keyword)
  })
})

// 方法
const handleSearch = () => {
  emit('search', searchValue.value)
}

const handleSearchClear = () => {
  searchValue.value = ''
  emit('search', '')
}

const handleRefresh = () => {
  emit('refresh')
}

const handleExport = () => {
  emit('export')
}

const handleCreate = () => {
  emit('create')
}

const handleSorterChange = (sorter: any) => {
  emit('sorter-change', sorter)
}

const handleFiltersChange = (filters: any) => {
  emit('filters-change', filters)
}

const handlePageChange = (page: number) => {
  emit('page-change', page)
}

const handlePageSizeChange = (pageSize: number) => {
  emit('page-size-change', pageSize)
}

const handleSelectionChange = (selectedRowKeys: any[]) => {
  emit('selection-change', selectedRowKeys)
}

const handleColumnSettingsConfirm = () => {
  columnSettingsVisible.value = false
  // 保存列设置到本地存储
  localStorage.setItem('table-visible-columns', JSON.stringify(visibleColumns.value))
}

// 表格操作方法
const clearSelection = () => {
  if (tableRef.value) {
    tableRef.value.clearSelection()
  }
}

const scrollTo = (options: any) => {
  if (tableRef.value) {
    tableRef.value.scrollTo(options)
  }
}

// 暴露方法给父组件
defineExpose({
  clearSelection,
  scrollTo,
  tableRef
})

// 初始化
onMounted(() => {
  // 从本地存储加载列设置
  const savedColumns = localStorage.getItem('table-visible-columns')
  if (savedColumns) {
    try {
      visibleColumns.value = JSON.parse(savedColumns)
    } catch (error) {
      console.error('加载列设置失败:', error)
    }
  } else {
    // 默认显示所有列
    visibleColumns.value = allColumns.value.map(col => col.key)
  }
})
</script>

<style scoped>
.data-table-container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.table-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 0;
  margin-bottom: 16px;
  flex-wrap: wrap;
  gap: 16px;
}

.toolbar-left,
.toolbar-center,
.toolbar-right {
  display: flex;
  align-items: center;
  gap: 12px;
}

.table-title h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: var(--text-color);
}

.table-subtitle {
  margin: 4px 0 0 0;
  font-size: 12px;
  color: var(--text-color-secondary);
}

.table-search {
  min-width: 200px;
}

.data-table {
  flex: 1;
  min-height: 300px;
}

.column-settings {
  padding: 16px 0;
}

/* 空状态样式 */
.data-table-container :deep(.n-empty) {
  margin: 48px 0;
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .table-toolbar {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }
  
  .toolbar-left,
  .toolbar-center,
  .toolbar-right {
    width: 100%;
    justify-content: space-between;
  }
  
  .table-search {
    flex: 1;
  }
}

@media (max-width: 768px) {
  .table-toolbar {
    padding: 12px 0;
    margin-bottom: 12px;
  }
  
  .table-title h3 {
    font-size: 16px;
  }
  
  .toolbar-left,
  .toolbar-center,
  .toolbar-right {
    gap: 8px;
  }
}

@media (max-width: 576px) {
  .table-toolbar {
    flex-direction: column;
    gap: 8px;
  }
  
  .toolbar-right {
    flex-wrap: wrap;
    justify-content: center;
  }
  
  .data-table :deep(.n-data-table) {
    font-size: 13px;
  }
}
</style>