<template>
  <NLayoutFooter class="app-footer" bordered>
    <div class="footer-container">
      <!-- 左侧：版权信息 -->
      <div class="footer-left">
        <div class="footer-copyright">
          <p>© 2026 Southeast Asia Bank. 版权所有</p>
          <p class="version">版本: {{ appVersion }} ({{ appEnv }})</p>
        </div>
      </div>
      
      <!-- 中间：导航链接 -->
      <div class="footer-center">
        <nav class="footer-nav">
          <NuxtLink to="/about" class="footer-link">关于我们</NuxtLink>
          <span class="footer-divider">|</span>
          <NuxtLink to="/help" class="footer-link">帮助中心</NuxtLink>
          <span class="footer-divider">|</span>
          <NuxtLink to="/contact" class="footer-link">联系我们</NuxtLink>
          <span class="footer-divider">|</span>
          <NuxtLink to="/privacy" class="footer-link">隐私政策</NuxtLink>
          <span class="footer-divider">|</span>
          <NuxtLink to="/terms" class="footer-link">服务条款</NuxtLink>
        </nav>
      </div>
      
      <!-- 右侧：状态信息和快速链接 -->
      <div class="footer-right">
        <!-- 系统状态 -->
        <div class="system-status">
          <NPopover trigger="hover" placement="top">
            <template #trigger>
              <div class="status-indicator">
                <span class="status-dot" :class="systemStatusClass"></span>
                <span class="status-text">系统状态</span>
              </div>
            </template>
            <div class="status-popover">
              <div class="status-item">
                <span class="status-label">后端服务:</span>
                <span class="status-value" :class="backendStatusClass">{{ backendStatus }}</span>
              </div>
              <div class="status-item">
                <span class="status-label">数据库:</span>
                <span class="status-value" :class="databaseStatusClass">{{ databaseStatus }}</span>
              </div>
              <div class="status-item">
                <span class="status-label">API响应:</span>
                <span class="status-value">{{ apiResponseTime }}ms</span>
              </div>
              <div class="status-item">
                <span class="status-label">在线用户:</span>
                <span class="status-value">{{ onlineUsers }}</span>
              </div>
            </div>
          </NPopover>
        </div>
        
        <!-- 快速链接 -->
        <div class="footer-quick-links">
          <NDropdown trigger="hover" :options="quickLinkOptions" @select="handleQuickLinkSelect">
            <NButton text size="small">
              <template #icon>
                <NIcon><LinkOutline /></NIcon>
              </template>
              快速链接
            </NButton>
          </NDropdown>
        </div>
      </div>
    </div>
  </NLayoutFooter>
</template>

<script setup lang="ts">
import { 
  NLayoutFooter, 
  NPopover, 
  NButton, 
  NIcon, 
  NDropdown, 
  DropdownOption
} from 'naive-ui'
import { 
  LinkOutline,
  DocumentTextOutline,
  SettingsOutline,
  BugOutline,
  CodeOutline,
  ServerOutline,
  PeopleOutline,
  ShieldOutline
} from '@vicons/ionicons5'
import { useAuthStore } from '@/stores/auth'

// 状态管理
const authStore = useAuthStore()

// 响应式状态
const appVersion = ref(process.env.APP_VERSION || '1.0.0')
const appEnv = ref(process.env.APP_ENV || 'development')
const systemStatus = ref<'healthy' | 'degraded' | 'down'>('healthy')
const backendStatus = ref<'在线' | '离线' | '不稳定'>('在线')
const databaseStatus = ref<'正常' | '异常' | '维护'>('正常')
const apiResponseTime = ref(128)
const onlineUsers = ref(42)

// 计算属性
const systemStatusClass = computed(() => {
  return {
    healthy: 'status-dot-healthy',
    degraded: 'status-dot-degraded',
    down: 'status-dot-down'
  }[systemStatus.value]
})

const backendStatusClass = computed(() => {
  return backendStatus.value === '在线' ? 'status-healthy' : 
         backendStatus.value === '不稳定' ? 'status-degraded' : 'status-down'
})

const databaseStatusClass = computed(() => {
  return databaseStatus.value === '正常' ? 'status-healthy' : 
         databaseStatus.value === '维护' ? 'status-degraded' : 'status-down'
})

// 快速链接选项
const quickLinkOptions = computed<DropdownOption[]>(() => [
  {
    label: 'API文档',
    key: 'api-docs',
    icon: () => h(NIcon, null, { default: () => h(DocumentTextOutline) })
  },
  {
    label: '系统监控',
    key: 'monitoring',
    icon: () => h(NIcon, null, { default: () => h(ServerOutline) })
  },
  {
    label: '用户管理',
    key: 'user-management',
    icon: () => h(NIcon, null, { default: () => h(PeopleOutline) })
  },
  {
    label: '安全设置',
    key: 'security',
    icon: () => h(NIcon, null, { default: () => h(ShieldOutline) })
  },
  { type: 'divider' },
  {
    label: '开发工具',
    key: 'dev-tools',
    icon: () => h(NIcon, null, { default: () => h(CodeOutline) })
  },
  {
    label: '系统设置',
    key: 'settings',
    icon: () => h(NIcon, null, { default: () => h(SettingsOutline) })
  },
  {
    label: '问题反馈',
    key: 'feedback',
    icon: () => h(NIcon, null, { default: () => h(BugOutline) })
  }
])

// 方法
const handleQuickLinkSelect = (key: string | number) => {
  console.log('快速链接选择:', key)
  
  switch (key) {
    case 'api-docs':
      window.open('/api/docs', '_blank')
      break
    case 'monitoring':
      window.open('/monitoring', '_blank')
      break
    case 'user-management':
      window.open('/system/users', '_blank')
      break
    case 'security':
      window.open('/security', '_blank')
      break
    case 'dev-tools':
      window.open('/dev-tools', '_blank')
      break
    case 'settings':
      window.open('/settings', '_blank')
      break
    case 'feedback':
      window.open('/feedback', '_blank')
      break
  }
}

// 模拟系统状态检查
const checkSystemStatus = async () => {
  try {
    // 实际应用中这里会调用API检查系统状态
    // 模拟API调用
    await new Promise(resolve => setTimeout(resolve, 100))
    
    // 模拟状态更新
    const random = Math.random()
    if (random > 0.9) {
      systemStatus.value = 'down'
      backendStatus.value = '离线'
    } else if (random > 0.7) {
      systemStatus.value = 'degraded'
      backendStatus.value = '不稳定'
    } else {
      systemStatus.value = 'healthy'
      backendStatus.value = '在线'
    }
    
    // 更新API响应时间
    apiResponseTime.value = Math.floor(Math.random() * 200) + 50
    
    // 更新在线用户数
    onlineUsers.value = Math.floor(Math.random() * 50) + 30
  } catch (error) {
    console.error('系统状态检查失败:', error)
    systemStatus.value = 'down'
    backendStatus.value = '离线'
  }
}

// 定时检查系统状态
onMounted(() => {
  checkSystemStatus()
  const interval = setInterval(checkSystemStatus, 60000) // 每分钟检查一次
  
  onUnmounted(() => {
    clearInterval(interval)
  })
})
</script>

<style scoped>
.app-footer {
  height: 48px;
  background-color: var(--background-color-light);
  z-index: 100;
  box-shadow: 0 -1px 4px rgba(0, 0, 0, 0.05);
}

.footer-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
  padding: 0 24px;
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
}

.footer-left {
  flex-shrink: 0;
}

.footer-copyright {
  font-size: 12px;
  color: var(--text-color-secondary);
  line-height: 1.4;
}

.footer-copyright .version {
  font-size: 11px;
  color: var(--text-color-disabled);
  margin-top: 2px;
}

.footer-center {
  flex: 1;
  display: flex;
  justify-content: center;
}

.footer-nav {
  display: flex;
  align-items: center;
  gap: 12px;
}

.footer-link {
  font-size: 12px;
  color: var(--text-color-secondary);
  text-decoration: none;
  transition: color 0.2s;
  white-space: nowrap;
}

.footer-link:hover {
  color: var(--primary-color);
}

.footer-divider {
  color: var(--border-color);
  font-size: 10px;
  user-select: none;
}

.footer-right {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 16px;
}

.system-status {
  display: flex;
  align-items: center;
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 8px;
  border-radius: 12px;
  background-color: var(--background-color-light);
  cursor: pointer;
  transition: background-color 0.2s;
}

.status-indicator:hover {
  background-color: var(--background-color-hover);
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
}

.status-dot-healthy {
  background-color: var(--success-color);
  box-shadow: 0 0 6px rgba(82, 196, 26, 0.5);
}

.status-dot-degraded {
  background-color: var(--warning-color);
  box-shadow: 0 0 6px rgba(250, 173, 20, 0.5);
}

.status-dot-down {
  background-color: var(--error-color);
  box-shadow: 0 0 6px rgba(245, 34, 45, 0.5);
}

.status-text {
  font-size: 12px;
  color: var(--text-color-secondary);
}

.status-popover {
  padding: 8px;
  min-width: 180px;
}

.status-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 4px 0;
  font-size: 12px;
}

.status-label {
  color: var(--text-color-secondary);
  margin-right: 12px;
}

.status-value {
  font-weight: 500;
}

.status-healthy {
  color: var(--success-color);
}

.status-degraded {
  color: var(--warning-color);
}

.status-down {
  color: var(--error-color);
}

.footer-quick-links {
  display: flex;
  align-items: center;
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .footer-container {
    padding: 0 16px;
  }
  
  .footer-center {
    display: none;
  }
  
  .footer-container {
    justify-content: space-between;
  }
}

@media (max-width: 768px) {
  .app-footer {
    height: 64px;
    padding: 8px 0;
  }
  
  .footer-container {
    flex-direction: column;
    justify-content: center;
    gap: 8px;
    padding: 0 12px;
  }
  
  .footer-left,
  .footer-right {
    width: 100%;
    justify-content: center;
  }
  
  .footer-copyright {
    text-align: center;
  }
}

@media (max-width: 576px) {
  .footer-right {
    flex-direction: column;
    gap: 8px;
  }
  
  .status-indicator {
    padding: 3px 6px;
  }
}
</style>