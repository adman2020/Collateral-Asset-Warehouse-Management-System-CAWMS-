<template>
  <NLayoutHeader class="app-header" bordered>
    <div class="header-container">
      <!-- 左侧：菜单切换按钮和面包屑 -->
      <div class="header-left">
        <!-- 菜单切换按钮 -->
        <NButton 
          v-if="showSidebarToggle"
          quaternary 
          circle 
          size="large"
          @click="$emit('toggle-sidebar')"
          class="sidebar-toggle"
        >
          <template #icon>
            <NIcon v-if="sidebarCollapsed">
              <MenuOutline />
            </NIcon>
            <NIcon v-else>
              <CloseOutline />
            </NIcon>
          </template>
        </NButton>
        
        <!-- 当前页面标题 -->
        <div class="header-title">
          <h1>{{ pageTitle }}</h1>
          <p v-if="pageSubtitle" class="subtitle">{{ pageSubtitle }}</p>
        </div>
      </div>
      
      <!-- 中间：搜索框（桌面端显示） -->
      <div class="header-center">
        <div class="header-search">
          <NInput
            v-model:value="searchKeyword"
            :placeholder="t('header.searchPlaceholder')"
            clearable
            round
            size="medium"
            @keyup.enter="handleSearch"
          >
            <template #prefix>
              <NIcon><SearchOutline /></NIcon>
            </template>
          </NInput>
        </div>
      </div>
      
      <!-- 右侧：用户菜单和功能按钮 -->
      <div class="header-right">
        <!-- 通知按钮 -->
        <NDropdown
          v-model:show="notificationVisible"
          trigger="click"
          :options="notificationOptions"
          @select="handleNotificationSelect"
        >
          <NButton quaternary circle size="medium" :badge="unreadCount > 0">
            <template #icon>
              <NIcon>
                <NotificationsOutline />
              </NIcon>
            </template>
            <template #badge>
              <span v-if="unreadCount > 0" class="badge-count">{{ unreadCount > 99 ? '99+' : unreadCount }}</span>
            </template>
          </NButton>
        </NDropdown>
        
        <!-- 语言切换 -->
        <LanguageSwitcher />

        <!-- 主题切换 -->
        <NButton quaternary circle size="medium" @click="toggleTheme">
          <template #icon>
            <NIcon>
              <MoonOutline v-if="currentTheme === 'dark'" />
              <SunnyOutline v-else />
            </NIcon>
          </template>
        </NButton>
        
        <!-- 帮助按钮 -->
        <NDropdown
          trigger="click"
          :options="helpOptions"
          @select="handleHelpSelect"
        >
          <NButton quaternary circle size="medium">
            <template #icon>
              <NIcon><HelpCircleOutline /></NIcon>
            </template>
          </NButton>
        </NDropdown>
        
        <!-- 用户菜单 -->
        <NDropdown
          trigger="click"
          :options="userMenuOptions"
          @select="handleUserMenuSelect"
        >
          <div class="user-profile">
            <NAvatar
              round
              :size="36"
              :src="userAvatar"
            />
            <div class="user-info">
              <span class="user-name">{{ userFullName }}</span>
              <span class="user-role">{{ userRole }}</span>
            </div>
            <NIcon class="chevron"><ChevronDownOutline /></NIcon>
          </div>
        </NDropdown>
      </div>
    </div>
  </NLayoutHeader>
</template>

<script setup lang="ts">
import { 
  NLayoutHeader, 
  NButton, 
  NIcon, 
  NInput, 
  NDropdown, 
  DropdownOption,
  NAvatar
} from 'naive-ui'
import { 
  MenuOutline,
  CloseOutline,
  SearchOutline,
  NotificationsOutline,
  MoonOutline,
  SunnyOutline,
  HelpCircleOutline,
  ChevronDownOutline,
  PersonOutline,
  SettingsOutline,
  LogOutOutline,
  DocumentTextOutline,
  ChatbubbleOutline,
  HeadsetOutline
} from '@vicons/ionicons5'
import { storeToRefs } from 'pinia'
import { useAuthStore } from '@/stores/auth'
import { getRoleAvatar } from '@/composables/useRoleAvatar'
import { useRouter } from '#vue-router'
import { useI18n } from 'vue-i18n'
import LanguageSwitcher from '@/components/common/LanguageSwitcher.vue'
import { useThemeState } from '@/composables/useThemeState'

const colorScheme = usePreferredColorScheme()
const { setThemeMode } = useThemeState()

const { t } = useI18n()

// Props
interface Props {
  sidebarCollapsed?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  sidebarCollapsed: false
})

// Emits
const emit = defineEmits<{
  'toggle-sidebar': []
  'logout': []
}>()

// 状态管理
const authStore = useAuthStore()
const { user } = storeToRefs(authStore)
const route = useRoute()
const router = useRouter()

// 响应式状态
const searchKeyword = ref('')
const notificationVisible = ref(false)
const currentTheme = ref<'light' | 'dark'>('light')
const unreadCount = ref(3) // 模拟未读通知数量

// 计算属性
const showSidebarToggle = computed(() => {
  // 某些页面不需要显示侧边栏切换按钮
  const noToggleRoutes = ['/login', '/register']
  return !noToggleRoutes.includes(route.path)
})

const pageTitle = computed(() => {
  const titleMap: Record<string, string> = {
    '/': 'menu.dashboard',
    '/warehouse-in': 'menu.warehouseIn',
    '/warehouse-in/create': 'menu.warehouseInCreate',
    '/loan-out': 'menu.loanOut',
    '/loan-out/create': 'menu.loanOutCreate',
    '/loan-out/return': 'menu.loanOutReturn',
    '/loan-out/overdue': 'menu.loanOutOverdue',
    '/transfer': 'menu.transfer',
    '/transfer/create': 'menu.transferCreate',
    '/warehouse-out': 'menu.warehouseOut',
    '/warehouse-out/create': 'menu.warehouseOutCreate',
    '/approval/pending': 'menu.approvalPending',
    '/approval/completed': 'menu.approvalCompleted',
    '/approval/history': 'menu.approvalHistory',
    '/reports': 'menu.reports',
    '/reports/inbound': 'menu.reportsInbound',
    '/reports/loan-out': 'menu.reportsLoanOut',
    '/reports/overdue': 'menu.reportsOverdue',
    '/reports/financial': 'menu.reportsFinancial',
    '/reports/dashboard': 'menu.reportsDashboard',
    '/system/users': 'menu.systemUsers',
    '/system/roles': 'menu.systemRoles',
    '/system/permissions': 'menu.systemPermissions',
    '/system/warehouse-zones': 'menu.systemWarehouseZones',
    '/system/warehouses': 'menu.systemWarehouses',
    '/system/audit-logs': 'menu.systemAuditLogs',
    '/system/config': 'menu.systemConfig',
    '/profile': 'user.profile',
    '/settings': 'user.settings',
  }
  const key = titleMap[route.path]
  if (key) return t(key)
  return route.meta?.title as string || ''
})

const pageSubtitle = computed(() => {
  return route.meta?.description as string || ''
})

const userFullName = computed(() => {
  return user.value?.fullName || user.value?.username || t('user.defaultName')
})

const userRole = computed(() => {
  return user.value?.roleName || user.value?.role || t('user.defaultRole')
})

const userAvatar = computed(() => {
  if (user.value?.avatar) return user.value.avatar
  return getRoleAvatar(user.value?.role)
})

// 下拉菜单选项
const notificationOptions = computed<DropdownOption[]>(() => [
  {
    label: t('header.notificationCenter'),
    key: 'center',
    icon: () => h(NIcon, null, { default: () => h(NotificationsOutline) })
  },
  { type: 'divider' },
  {
    label: t('header.systemAnnouncement'),
    key: 'announcement-1',
    disabled: true,
    extra: t('header.justNow')
  },
  {
    label: t('header.approvalReminder'),
    key: 'approval-1',
    extra: t('header.minutesAgo', { n: 10 })
  },
  {
    label: t('header.alertNotification'),
    key: 'alert-1',
    extra: t('header.hoursAgo', { n: 1 })
  },
  { type: 'divider' },
  {
    label: t('header.viewAllNotifications'),
    key: 'all'
  },
  {
    label: t('header.markAllAsRead'),
    key: 'mark-read'
  }
])

const helpOptions = computed<DropdownOption[]>(() => [
  {
    label: t('header.helpDocs'),
    key: 'docs',
    icon: () => h(NIcon, null, { default: () => h(DocumentTextOutline) })
  },
  {
    label: t('header.onlineSupport'),
    key: 'support',
    icon: () => h(NIcon, null, { default: () => h(ChatbubbleOutline) })
  },
  {
    label: t('header.contactUs'),
    key: 'contact',
    icon: () => h(NIcon, null, { default: () => h(HeadsetOutline) })
  },
  { type: 'divider' },
  {
    label: t('header.aboutSystem'),
    key: 'about'
  },
  {
    label: t('header.checkUpdate'),
    key: 'update'
  }
])

const userMenuOptions = computed<DropdownOption[]>(() => [
  {
    label: t('header.profile'),
    key: 'profile',
    icon: () => h(NIcon, null, { default: () => h(PersonOutline) })
  },
  {
    label: t('header.accountSettings'),
    key: 'settings',
    icon: () => h(NIcon, null, { default: () => h(SettingsOutline) })
  },
  { type: 'divider' },
  {
    label: t('header.switchTheme'),
    key: 'theme',
    children: [
      { label: t('header.lightTheme'), key: 'light' },
      { label: t('header.darkTheme'), key: 'dark' },
      { label: t('header.followSystem'), key: 'system' }
    ]
  },
  { type: 'divider' },
  {
    label: t('header.logout'),
    key: 'logout',
    icon: () => h(NIcon, null, { default: () => h(LogOutOutline) })
  }
])

// 方法
const handleSearch = () => {
  if (searchKeyword.value.trim()) {
    console.log('搜索关键词:', searchKeyword.value)
    // 实际应用中这里会触发搜索
  }
}

const handleNotificationSelect = (key: string | number) => {
  console.log('通知选项选择:', key)
  notificationVisible.value = false
  
  switch (key) {
    case 'center':
      router.push('/notifications')
      break
    case 'all':
      router.push('/notifications/all')
      break
    case 'mark-read':
      unreadCount.value = 0
      break
  }
}

const handleHelpSelect = (key: string | number) => {
  console.log('帮助选项选择:', key)
  
  switch (key) {
    case 'docs':
      window.open('/docs', '_blank')
      break
    case 'support':
      router.push('/support')
      break
    case 'contact':
      router.push('/contact')
      break
    case 'about':
      router.push('/about')
      break
    case 'update':
      checkForUpdates()
      break
  }
}

const handleUserMenuSelect = async (key: string | number) => {
  console.log('用户菜单选择:', key)
  
  switch (key) {
    case 'profile':
      router.push('/profile')
      break
    case 'settings':
      router.push('/settings')
      break
    case 'light':
    case 'dark':
    case 'system':
      setTheme(key as string)
      break
    case 'logout':
      emit('logout')
      break
  }
}

const toggleTheme = () => {
  const next = currentTheme.value === 'light' ? 'dark' : 'light'
  currentTheme.value = next
  localStorage.setItem('theme', next)
  setThemeMode(next)
  document.documentElement.setAttribute('data-theme', next)
}

const setTheme = (theme: string) => {
  const effective = theme === 'system'
    ? (colorScheme.value === 'dark' ? 'dark' : 'light')
    : (theme as 'light' | 'dark')
  currentTheme.value = effective
  localStorage.setItem('theme', theme)
  setThemeMode(effective)
  document.documentElement.setAttribute('data-theme', effective)
}

const checkForUpdates = () => {
  console.log('检查更新...')
  // 实际应用中这里会检查版本更新
}

// 初始化
onMounted(() => {
  // 从本地存储或用户设置中读取主题
  const savedTheme = localStorage.getItem('theme')
  if (savedTheme === 'dark') {
    currentTheme.value = 'dark'
  } else if (savedTheme === 'light') {
    currentTheme.value = 'light'
  } else {
    // system or null
    currentTheme.value = colorScheme.value === 'dark' ? 'dark' : 'light'
  }
})
</script>

<style scoped>
.app-header {
  height: 64px;
  background-color: var(--background-color-light);
  z-index: 1000;
  box-shadow: var(--box-shadow-light);
}

.header-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
  padding: 0 24px;
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.sidebar-toggle {
  margin-right: 8px;
}

.header-title h1 {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
  color: var(--text-color);
}

.header-title .subtitle {
  font-size: 12px;
  color: var(--text-color-secondary);
  margin: 2px 0 0 0;
}

.header-center {
  flex: 1;
  max-width: 400px;
  margin: 0 24px;
}

.header-search {
  width: 100%;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 12px;
}

.user-profile {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 4px 12px;
  border-radius: 20px;
  cursor: pointer;
  transition: background-color 0.2s;
  user-select: none;
}

.user-profile:hover {
  background-color: var(--background-color-hover);
}

.user-info {
  display: flex;
  flex-direction: column;
  line-height: 1.2;
}

.user-name {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-color);
}

.user-role {
  font-size: 12px;
  color: var(--text-color-secondary);
}

.chevron {
  font-size: 16px;
  color: var(--text-color-secondary);
}

.badge-count {
  position: absolute;
  top: -4px;
  right: -4px;
  background-color: var(--error-color);
  color: #fff;
  font-size: 10px;
  font-weight: 600;
  min-width: 16px;
  height: 16px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 4px;
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .header-center {
    display: none;
  }
  
  .header-container {
    padding: 0 16px;
  }
}

@media (max-width: 768px) {
  .user-info {
    display: none;
  }
  
  .chevron {
    display: none;
  }
  
  .header-right {
    gap: 8px;
  }
}

@media (max-width: 576px) {
  .header-title h1 {
    font-size: 16px;
  }
  
  .header-container {
    padding: 0 12px;
  }
  
  .sidebar-toggle {
    margin-right: 4px;
  }
}
</style>