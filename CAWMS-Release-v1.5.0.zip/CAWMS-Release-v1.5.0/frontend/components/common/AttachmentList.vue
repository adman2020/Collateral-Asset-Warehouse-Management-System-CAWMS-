<template>
  <NCard :title="title" size="small">
    <NEmpty v-if="!files || files.length === 0" :description="emptyText" />
    <NList v-else>
      <NListItem v-for="file in files" :key="file.id">
        <NSpace align="center" justify="space-between">
          <NSpace align="center" :size="12">
            <NIcon size="22">
              <DocumentTextOutline />
            </NIcon>
            <NEllipsis style="max-width: 200px">
              {{ file.fileName }}
            </NEllipsis>
            <span class="file-meta">{{ formatFileSize(file.fileSize) }}</span>
            <span v-if="file.uploadUser" class="file-meta">{{ file.uploadUser }}</span>
            <span v-if="file.uploadTime" class="file-meta">{{ file.uploadTime }}</span>
          </NSpace>
          <NSpace>
            <NButton v-if="isPreviewable(file)" size="small" @click="handlePreview(file)">
              <template #icon>
                <NIcon><EyeOutline /></NIcon>
              </template>
              预览
            </NButton>
            <NButton size="small" @click="handleDownload(file.id, file.fileName)">
              <template #icon>
                <NIcon><DownloadOutline /></NIcon>
              </template>
              {{ $t('warehouseIn.download') }}
            </NButton>
          </NSpace>
        </NSpace>
      </NListItem>
    </NList>
  </NCard>

  <!-- 图片预览弹窗 -->
  <NModal
    v-model:show="imagePreviewVisible"
    preset="card"
    :title="previewTitle"
    style="width: auto; max-width: 90vw"
    :bordered="false"
  >
    <img v-if="imagePreviewUrl" :src="imagePreviewUrl" style="max-width: 100%; max-height: 80vh; display: block; margin: 0 auto;" />
  </NModal>

  <!-- PDF 预览弹窗 -->
  <NModal
    v-model:show="pdfPreviewVisible"
    preset="card"
    :title="previewTitle"
    style="width: 90vw; height: 85vh"
    :bordered="false"
  >
    <iframe v-if="pdfPreviewUrl" :src="pdfPreviewUrl" style="width: 100%; height: calc(85vh - 60px); border: none;" />
  </NModal>


</template>

<script setup lang="ts">
import { ref } from 'vue'
import { NCard, NList, NListItem, NSpace, NButton, NIcon, NEmpty, NEllipsis, NModal, useMessage } from 'naive-ui'
import { DocumentTextOutline, DownloadOutline, EyeOutline } from '@vicons/ionicons5'
import type { AttachmentFile } from '@/api/warehouse-in'

const message = useMessage()

const props = withDefaults(defineProps<{
  files: AttachmentFile[]
  title?: string
  emptyText?: string
  downloadUrl: (fileId: number) => string
}>(), {
  title: '附件列表',
  emptyText: '暂无附件'
})

// 预览状态
const imagePreviewVisible = ref(false)
const imagePreviewUrl = ref('')
const pdfPreviewVisible = ref(false)
const pdfPreviewUrl = ref('')
const previewTitle = ref('')

// 判断文件是否可预览
function isPreviewable(file: AttachmentFile): boolean {
  const mime = file.mimeType || ''
  const name = file.fileName || ''
  const ext = name.split('.').pop()?.toLowerCase() || ''
  if (mime.startsWith('image/')) return true
  if (mime === 'application/pdf' || ext === 'pdf') return true
  if (isOfficeFile(file)) return true
  return false
}

// 判断是否为 Office 文件
function isOfficeFile(file: AttachmentFile): boolean {
  const mime = file.mimeType || ''
  const name = file.fileName || ''
  const ext = name.split('.').pop()?.toLowerCase() || ''
  const officeExts = ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'odp', 'rtf', 'txt', 'csv']
  const officeMimes = [
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.oasis.opendocument.text',
    'application/vnd.oasis.opendocument.spreadsheet',
    'application/vnd.oasis.opendocument.presentation'
  ]
  return officeExts.includes(ext) || officeMimes.some(m => mime.includes(m))
}

// 获取文件扩展名（用于 OnlyOffice）
function getFileExtension(fileName: string): string {
  return (fileName.split('.').pop()?.toLowerCase() || '')
}

// 获取 OnlyOffice 的 fileType
function getOnlyOfficeFileType(fileName: string): string {
  const ext = getFileExtension(fileName)
  const typeMap: Record<string, string> = {
    doc: 'doc', docx: 'docx', odt: 'odt', rtf: 'rtf', txt: 'txt',
    xls: 'xls', xlsx: 'xlsx', ods: 'ods', csv: 'csv',
    ppt: 'ppt', pptx: 'pptx', odp: 'odp'
  }
  return typeMap[ext] || ext
}

// 获取 OnlyOffice 的 documentType
function getOnlyOfficeDocumentType(fileName: string): string {
  const ext = getFileExtension(fileName)
  if (['doc', 'docx', 'odt', 'rtf', 'txt'].includes(ext)) return 'word'
  if (['xls', 'xlsx', 'ods', 'csv'].includes(ext)) return 'cell'
  if (['ppt', 'pptx', 'odp'].includes(ext)) return 'slide'
  return 'word'
}

// 预览处理
async function handlePreview(file: AttachmentFile) {
  previewTitle.value = file.fileName || '预览'
  const mime = file.mimeType || ''
  const name = file.fileName || ''

  if (mime.startsWith('image/')) {
    await previewImage(file)
  } else if (mime === 'application/pdf' || name.endsWith('.pdf')) {
    await previewPdf(file)
  } else if (isOfficeFile(file)) {
    message.info('暂不支持 Office 文档在线预览，请下载后查看')
  }
}

// 图片预览
async function previewImage(file: AttachmentFile) {
  const blob = await fetchFileBlob(file.id)
  if (!blob) return
  imagePreviewUrl.value = URL.createObjectURL(blob)
  imagePreviewVisible.value = true
}

// PDF 预览
async function previewPdf(file: AttachmentFile) {
  const blob = await fetchFileBlob(file.id)
  if (!blob) return
  pdfPreviewUrl.value = URL.createObjectURL(blob)
  pdfPreviewVisible.value = true
}

// Office 预览
async function previewOffice(file: AttachmentFile) {
  officePreviewVisible.value = true
  await nextTick()
  await loadOnlyOfficeScript()

  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : ''
  const fileUrl = props.downloadUrl(file.id) + (token ? `?token=${token}` : '')

  const container = document.getElementById('onlyoffice-preview-container')
  if (!container) return

  // 销毁之前的编辑器
  if (officeEditor) {
    officeEditor.destroyEditor()
    officeEditor = null
  }

  const config = {
    document: {
      fileType: getOnlyOfficeFileType(file.fileName),
      key: 'preview-' + file.id + '-' + Date.now(),
      url: fileUrl,
      title: file.fileName
    },
    documentType: getOnlyOfficeDocumentType(file.fileName),
    editorConfig: {
      mode: 'view',
      lang: 'zh-CN',
      customization: {
        chat: false,
        comments: false,
        download: true,
        header: false
      }
    },
    height: '100%',
    width: '100%'
  }

  // @ts-ignore
  officeEditor = new DocsAPI.DocEditor('onlyoffice-preview-container', config)
}

// 加载 OnlyOffice JS API
let onlyOfficeScriptLoaded = false
function loadOnlyOfficeScript(): Promise<void> {
  if (onlyOfficeScriptLoaded) return Promise.resolve()
  return new Promise((resolve, reject) => {
    const script = document.createElement('script')
    script.src = '/onlyoffice/web-apps/apps/api/documents/api.js'
    script.onload = () => {
      onlyOfficeScriptLoaded = true
      resolve()
    }
    script.onerror = reject
    document.head.appendChild(script)
  })
}

// 通用文件获取
async function fetchFileBlob(fileId: number): Promise<Blob | null> {
  const url = props.downloadUrl(fileId)
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null
  try {
    const response = await fetch(url, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    })
    if (!response.ok) {
      throw new Error(`获取文件失败: ${response.status}`)
    }
    return await response.blob()
  } catch (e: any) {
    alert(e.message || '预览失败')
    return null
  }
}

// 下载处理
async function handleDownload(fileId: number, fileName?: string) {
  const url = props.downloadUrl(fileId)
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null
  try {
    const response = await fetch(url, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    })
    if (!response.ok) {
      const err = await response.json().catch(() => ({}))
      throw new Error(err.message || `下载失败: ${response.status}`)
    }
    const blob = await response.blob()
    const blobUrl = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = blobUrl
    a.download = fileName || 'download'
    document.body.appendChild(a)
    a.click()
    window.URL.revokeObjectURL(blobUrl)
    document.body.removeChild(a)
  } catch (e: any) {
    alert(e.message || '下载失败')
  }
}

function formatFileSize(bytes?: number): string {
  if (bytes === undefined || bytes === null) return '-'
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB'
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB'
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
}
</script>

<style scoped>
.file-meta {
  color: #888;
  font-size: 12px;
}
</style>
