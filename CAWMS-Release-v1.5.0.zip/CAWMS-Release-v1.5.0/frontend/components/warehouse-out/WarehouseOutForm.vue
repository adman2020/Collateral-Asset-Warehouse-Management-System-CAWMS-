<template>
  <div class="warehouse-out-form">
    <n-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-placement="left"
      label-width="100"
    >
      <n-grid :cols="2" :x-gap="24">
        <n-gi>
          <n-form-item label="入库编号" path="warehouseInId">
            <n-select
              v-model:value="formData.warehouseInId"
              placeholder="请选择入库记录"
              :options="warehouseOptions"
              filterable
              @update:value="onWarehouseChange"
            />
          </n-form-item>
        </n-gi>
        <n-gi>
          <n-form-item label="抵押物名称" path="collateralName">
            <n-input v-model:value="formData.collateralName" disabled />
          </n-form-item>
        </n-gi>
        <n-gi>
          <n-form-item label="释放类型" path="releaseType">
            <n-select
              v-model:value="formData.releaseType"
              placeholder="请选择释放类型"
              :options="releaseTypeOptions"
            />
          </n-form-item>
        </n-gi>
        <n-gi v-if="formData.releaseType === 'PARTIAL'">
          <n-form-item label="释放比例" path="releasePercentage">
            <n-input-number
              v-model:value="formData.releasePercentage"
              placeholder="请输入释放比例"
              :min="1"
              :max="100"
              style="width: 100%"
              suffix="%"
              @update:value="onReleasePercentageChange"
            />
          </n-form-item>
        </n-gi>
        <n-gi v-if="formData.releaseType === 'PARTIAL'">
          <n-form-item label="释放金额">
            <n-input :value="`¥${releaseAmount / 10000}万`" disabled />
          </n-form-item>
        </n-gi>
        <n-gi>
          <n-form-item label="释放原因类型" path="releaseReasonType">
            <n-select
              v-model:value="formData.releaseReasonType"
              placeholder="请选择释放原因类型"
              :options="releaseReasonTypeOptions"
            />
          </n-form-item>
        </n-gi>
        <n-gi :span="2">
          <n-form-item label="释放原因" path="releaseReason">
            <n-input
              v-model:value="formData.releaseReason"
              type="textarea"
              placeholder="请输入释放原因"
              :rows="3"
            />
          </n-form-item>
        </n-gi>
        <n-gi :span="2">
          <n-form-item label="备注" path="remarks">
            <n-input
              v-model:value="formData.remarks"
              type="textarea"
              placeholder="请输入备注信息"
              :rows="2"
            />
          </n-form-item>
        </n-gi>
      </n-grid>

      <div class="form-actions">
        <n-button @click="handleClose">取消</n-button>
        <n-button type="primary" :loading="submitting" @click="handleSubmit">
          {{ isEdit ? '保存' : '创建' }}
        </n-button>
      </div>
    </n-form>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { useMessage } from 'naive-ui'
import type { FormInst, FormRules } from 'naive-ui'
import {
  createWarehouseOut,
  updateWarehouseOut,
  getWarehouseOutDetail,
  calculateReleaseAmount,
  type WarehouseOutCreateRequest
} from '~/api/warehouse-out'

const props = defineProps<{
  warehouseOutId: number | null
}>()

const emit = defineEmits<{
  success: []
  close: []
}>()

const message = useMessage()
const formRef = ref<FormInst | null>(null)
const submitting = ref(false)
const releaseAmount = ref(0)

const isEdit = computed(() => props.warehouseOutId !== null)

// 表单数据
const formData = reactive<WarehouseOutCreateRequest & {
  collateralName: string
  remarks?: string
}>({
  warehouseInId: 0,
  releaseType: 'FULL',
  releaseReasonType: 'LOAN_REPAYMENT',
  releaseReason: '',
  releaseAmount: 0,
  releasePercentage: 100,
  collateralName: '',
  remarks: ''
})

// 表单规则
const formRules: FormRules = {
  warehouseInId: {
    required: true,
    message: '请选择入库记录',
    trigger: 'change'
  },
  releaseType: {
    required: true,
    message: '请选择释放类型',
    trigger: 'change'
  },
  releaseReasonType: {
    required: true,
    message: '请选择释放原因类型',
    trigger: 'change'
  },
  releaseReason: {
    required: true,
    message: '请输入释放原因',
    trigger: 'blur'
  }
}

// 部分释放时验证释放比例
const validateReleasePercentage = () => {
  if (formData.releaseType === 'PARTIAL') {
    if (!formData.releasePercentage || formData.releasePercentage < 1 || formData.releasePercentage > 100) {
      formRules.releasePercentage = {
        required: true,
        message: '请输入有效的释放比例 (1-100)',
        trigger: 'change'
      }
    }
  }
}

// 仓库选项（模拟数据）
const warehouseOptions = ref([
  { label: '上海分行仓库 A', value: 1 },
  { label: '上海分行仓库 B', value: 2 },
  { label: '北京分行仓库', value: 3 },
  { label: '广州分行仓库', value: 4 },
  { label: '深圳分行仓库', value: 5 }
])

// 释放类型选项
const releaseTypeOptions = [
  { label: '部分释放', value: 'PARTIAL' },
  { label: '完全释放', value: 'FULL' }
]

// 释放原因类型选项
const releaseReasonTypeOptions = [
  { label: '贷款还款', value: 'LOAN_REPAYMENT' },
  { label: '授信额度减少', value: 'CREDIT_LINE_REDUCTION' },
  { label: '抵押物替换', value: 'COLLATERAL_REPLACEMENT' },
  { label: '其他', value: 'OTHER' }
]

// 仓库变化
const onWarehouseChange = (value: number) => {
  const warehouse = warehouseOptions.value.find(w => w.value === value)
  if (warehouse) {
    formData.collateralName = `${warehouse.label} - 抵押物`
    // 模拟：假设抵押物原值为 100 万
    if (formData.releaseType === 'PARTIAL' && formData.releasePercentage) {
      releaseAmount.value = 1000000 * (formData.releasePercentage / 100)
    } else if (formData.releaseType === 'FULL') {
      releaseAmount.value = 1000000
    }
  }
}

// 释放比例变化
const onReleasePercentageChange = async (value: number | null) => {
  if (value && formData.warehouseInId) {
    try {
      const res = await calculateReleaseAmount(formData.warehouseInId, value)
      if (res.data.code === 0) {
        releaseAmount.value = res.data.data.releaseAmount
      }
    } catch (error) {
      // 使用模拟值
      releaseAmount.value = 1000000 * (value / 100)
    }
  }
}

// 加载详情
const loadDetail = async () => {
  if (!props.warehouseOutId) return
  try {
    const res = await getWarehouseOutDetail(props.warehouseOutId)
    if (res.data.code === 0) {
      const data = res.data.data
      formData.warehouseInId = data.warehouseInId
      formData.releaseType = data.releaseType
      formData.releasePercentage = data.releasePercentage
      formData.releaseReasonType = data.releaseReasonType
      formData.releaseReason = data.releaseReason
      formData.collateralName = data.collateralName
      formData.remarks = data.remarks
      releaseAmount.value = data.releaseAmount
    }
  } catch (error) {
    message.error('加载详情失败')
  }
}

// 提交表单
const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    submitting.value = true

    const submitData = {
      warehouseInId: formData.warehouseInId,
      releaseType: formData.releaseType,
      releaseAmount: formData.releaseType === 'PARTIAL' ? releaseAmount.value : undefined,
      releasePercentage: formData.releaseType === 'PARTIAL' ? formData.releasePercentage : undefined,
      releaseReasonType: formData.releaseReasonType,
      releaseReason: formData.releaseReason,
      remarks: formData.remarks
    }

    let res
    if (isEdit.value) {
      res = await updateWarehouseOut(props.warehouseOutId!, submitData)
    } else {
      res = await createWarehouseOut(submitData)
    }

    if (res.data.code === 0) {
      message.success(isEdit.value ? '保存成功' : '创建成功')
      emit('success')
    }
  } catch (error: any) {
    if (error?.message !== 'validation failed') {
      message.error(isEdit.value ? '保存失败' : '创建失败')
    }
  } finally {
    submitting.value = false
  }
}

// 关闭
const handleClose = () => {
  emit('close')
}

// 初始化
onMounted(() => {
  if (props.warehouseOutId) {
    loadDetail()
  }
})

// 监听 warehouseOutId 变化（模态框复用时重新加载）
watch(() => props.warehouseOutId, (newId) => {
  if (newId) {
    loadDetail()
  }
})
</script>

<style scoped>
.warehouse-out-form {
  padding: 16px 0;
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 24px;
  padding-top: 24px;
  border-top: 1px solid #f0f0f0;
}
</style>
