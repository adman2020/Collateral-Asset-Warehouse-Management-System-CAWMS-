<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <p>This is a sample component using Naive UI</p>
    <n-button type="primary" @click="handleClick">
      Click me
    </n-button>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { NButton } from 'naive-ui'

defineProps<{
  msg: string
}>()

const handleClick = () => {
  console.log('Button clicked')
}
</script>

<style scoped>
.hello {
  text-align: center;
  padding: 2rem;
}
</style>