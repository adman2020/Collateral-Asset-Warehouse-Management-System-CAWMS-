<template>
  <div class="warehouse-in-table">
    <div class="table-header">
      <div class="header-left">
        <h3 class="table-title">入库申请列表</h3>
        <NTag v-if="total" type="info" size="small">共 {{ total }} 条记录</NTag>
      </div>
      <div class="header-right">
        <NSpace>
          <NButton size="small" @click="handleRefresh">
            <template #icon>
              <NIcon><RefreshOutline /></NIcon>
            </template>
            刷新
          </NButton>
          <NButton size="small" @click="handleExport">
            <template #icon>
              <NIcon><DownloadOutline /></NIcon>
            </template>
            导出
          </NButton>
          <NButton size="small" type="primary" @click="handleCreate">
            <template #icon>
              <NIcon><AddOutline /></NIcon>
            </template>
            新建申请
          </NButton>
        </NSpace>
      </div>
    </div>

    <!-- 筛选条件 -->
    <div class="filter-section">
      <NForm inline label-placement="left" label-width="80px">
        <NFormItem label="申请状态">
          <NSelect
            v-model:value="filterParams.status"
            :options="statusOptions"
            placeholder="全部状态"
            clearable
            style="width: 120px;"
          />
        </NFormItem>
        <NFormItem label="申请部门">
          <NSelect
            v-model:value="filterParams.department"
            :options="departmentOptions"
            placeholder="全部部门"
            clearable
            style="width: 150px;"
          />
        </NFormItem>
        <NFormItem label="申请时间">
          <NDatePicker
            v-model:value="filterParams.dateRange"
            type="daterange"
            clearable
            placeholder="选择日期范围"
          />
        </NFormItem>
        <NFormItem>
          <NButton type="primary" @click="handleSearch">查询</NButton>
          <NButton @click="handleReset" style="margin-left: 8px;">重置</NButton>
        </NFormItem>
      </NForm>
    </div>

    <!-- 数据表格 -->
    <NDataTable
      :columns="columns"
      :data="tableData"
      :pagination="pagination"
      :loading="loading"
      :row-key="(row) => row.id"
      @update:page="handlePageChange"
      @update:page-size="handlePageSizeChange"
      striped
      bordered
    />

    <!-- 批量操作 -->
    <div v-if="selectedRows.length > 0" class="batch-actions">
      <NSpace align="center">
        <span>已选择 {{ selectedRows.length }} 条记录</span>
        <NButton size="small" @click="handleBatchApprove" :disabled="!canBatchApprove">
          <template #icon>
            <NIcon><CheckmarkDoneOutline /></NIcon>
          </template>
          批量审批
        </NButton>
        <NButton size="small" @click="handleBatchDelete" type="error" ghost>
          <template #icon>
            <NIcon><TrashOutline /></NIcon>
          </template>
          批量删除
        </NButton>
        <NButton size="small" @click="clearSelection">
          取消选择
        </NButton>
      </NSpace>
    </div>

    <!-- 统计卡片 -->
    <div class="stat-cards">
      <NCard size="small" class="stat-card">
        <div class="stat-content">
          <div class="stat-icon pending">
            <NIcon><TimeOutline /></NIcon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.pending || 0 }}</div>
            <div class="stat-label">待审批</div>
          </div>
        </div>
      </NCard>
      <NCard size="small" class="stat-card">
        <div class="stat-content">
          <div class="stat-icon approved">
            <NIcon><CheckmarkCircleOutline /></NIcon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.approved || 0 }}</div>
            <div class="stat-label">已批准</div>
          </div>
        </div>
      </NCard>
      <NCard size="small" class="stat-card">
        <div class="stat-content">
          <div class="stat-icon rejected">
            <NIcon><CloseCircleOutline /></NIcon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.rejected || 0 }}</div>
            <div class="stat-label">已拒绝</div>
          </div>
        </div>
      </NCard>
      <NCard size="small" class="stat-card">
        <div class="stat-content">
          <div class="stat-icon total">
            <NIcon><BarChartOutline /></NIcon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.total || 0 }}</div>
            <div class="stat-label">总计</div>
          </div>
        </div>
      </NCard>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  NDataTable,
  NButton,
  NIcon,
  NTag,
  NSpace,
  NForm,
  NFormItem,
  NSelect,
  NDatePicker,
  NCard,
  useMessage,
  useDialog,
  DataTableColumn,
  PaginationProps
} from 'naive-ui'
import {
  RefreshOutline,
  DownloadOutline,
  AddOutline,
  CheckmarkDoneOutline,
  TrashOutline,
  TimeOutline,
  CheckmarkCircleOutline,
  CloseCircleOutline,
  BarChartOutline,
  EyeOutline,
  PencilOutline,
  DocumentTextOutline
} from '@vicons/ionicons5'
import { ref, reactive, computed, onMounted } from 'vue'

// 类型定义
interface WarehouseInItem {
  id: string
  code: string
  assetName: string
  assetType: string
  quantity: number
  unit: string
  applicant: string
  department: string
  applyDate: string
  status: string
  priority: string
  createdAt: string
}

interface FilterParams {
  status: string | null
  department: string | null
  dateRange: [number, number] | null
  keyword: string
}

interface Stats {
  pending: number
  approved: number
  rejected: number
  total: number
}

// 响应式状态
const loading = ref(false)
const tableData = ref<WarehouseInItem[]>([])
const selectedRows = ref<WarehouseInItem[]>([])
const total = ref(0)
const stats = reactive<Stats>({
  pending: 0,
  approved: 0,
  rejected: 0,
  total: 0
})

const filterParams = reactive<FilterParams>({
  status: null,
  department: null,
  dateRange: null,
  keyword: ''
})

// 分页配置
const pagination = reactive<PaginationProps>({
  page: 1,
  pageSize: 10,
  pageSizes: [10, 20, 50, 100],
  showSizePicker: true,
  showQuickJumper: true,
  itemCount: 0,
  prefix: (info) => `共 ${info.itemCount} 条记录`
})

// 工具
const message = useMessage()
const dialog = useDialog()

// 选项数据
const statusOptions = [
  { label: '草稿', value: 'DRAFT' },
  { label: '待审批', value: 'PENDING' },
  { label: '审批中', value: 'IN_REVIEW' },
  { label: '已批准', value: 'APPROVED' },
  { label: '已拒绝', value: 'REJECTED' },
  { label: '已完成', value: 'COMPLETED' }
]

const departmentOptions = [
  { label: '信贷部', value: 'CREDIT' },
  { label: '风险管理部', value: 'RISK_MANAGEMENT' },
  { label: '运营部', value: 'OPERATIONS' },
  { label: '科技部', value: 'TECHNOLOGY' },
  { label: '财务部', value: 'FINANCE' },
  { label: '行政部', value: 'ADMINISTRATION' }
]

// 表格列定义
const columns = ref<DataTableColumn<WarehouseInItem>[]>([
  {
    type: 'selection',
    width: 50
  },
  {
    title: '申请单号',
    key: 'code',
    width: 140,
    sorter: true
  },
  {
    title: '资产名称',
    key: 'assetName',
    width: 180
  },
  {
    title: '资产类别',
    key: 'assetType',
    width: 100,
    render: (row) => {
      const typeMap: Record<string, string> = {
        'ELECTRONIC': '电子设备',
        'OFFICE': '办公设备',
        'TRANSPORT': '运输设备',
        'MACHINERY': '机械设备',
        'FURNITURE': '家具设备',
        'OTHER': '其他设备'
      }
      return typeMap[row.assetType] || row.assetType
    }
  },
  {
    title: '数量',
    key: 'quantity',
    width: 80,
    align: 'center'
  },
  {
    title: '申请人',
    key: 'applicant',
    width: 100
  },
  {
    title: '申请部门',
    key: 'department',
    width: 120,
    render: (row) => {
      const deptMap: Record<string, string> = {
        'CREDIT': '信贷部',
        'RISK_MANAGEMENT': '风险管理部',
        'OPERATIONS': '运营部',
        'TECHNOLOGY': '科技部',
        'FINANCE': '财务部',
        'ADMINISTRATION': '行政部'
      }
      return deptMap[row.department] || row.department
    }
  },
  {
    title: '申请时间',
    key: 'applyDate',
    width: 120,
    sorter: true
  },
  {
    title: '状态',
    key: 'status',
    width: 100,
    render: (row) => {
      const statusConfig: Record<string, { type: any, text: string }> = {
        'DRAFT': { type: 'default', text: '草稿' },
        'PENDING': { type: 'warning', text: '待审批' },
        'IN_REVIEW': { type: 'info', text: '审批中' },
        'APPROVED': { type: 'success', text: '已批准' },
        'REJECTED': { type: 'error', text: '已拒绝' },
        'COMPLETED': { type: 'success', text: '已完成' }
      }
      const config = statusConfig[row.status] || { type: 'default', text: row.status }
      return h(NTag, { type: config.type, size: 'small' }, { default: () => config.text })
    }
  },
  {
    title: '优先级',
    key: 'priority',
    width: 80,
    render: (row) => {
      const priorityConfig: Record<string, { type: any, text: string }> = {
        'LOW': { type: 'default', text: '低' },
        'MEDIUM': { type: 'info', text: '中' },
        'HIGH': { type: 'warning', text: '高' },
        'URGENT': { type: 'error', text: '紧急' }
      }
      const config = priorityConfig[row.priority] || { type: 'default', text: row.priority }
      return h(NTag, { type: config.type, size: 'small' }, { default: () => config.text })
    }
  },
  {
    title: '操作',
    key: 'actions',
    width: 180,
    fixed: 'right',
    render: (row) => {
      return h('div', { class: 'action-buttons' }, [
        h(NButton, {
          size: 'small',
          type: 'info',
          ghost: true,
          onClick: () => handleView(row)
        }, {
          icon: () => h(NIcon, null, { default: () => h(EyeOutline) }),
          default: () => '查看'
        }),
        h(NButton, {
          size: 'small',
          type: 'primary',
          ghost: true,
          onClick: () => handleEdit(row),
          disabled: !canEdit(row)
        }, {
          icon: () => h(NIcon, null, { default: () => h(PencilOutline) }),
          default: () => '编辑'
        }),
        h(NButton, {
          size: 'small',
          type: 'warning',
          ghost: true,
          onClick: () => handleApprove(row),
          disabled: !canApprove(row)
        }, {
          icon: () => h(NIcon, null, { default: () => h(DocumentTextOutline) }),
          default: () => row.status === 'PENDING' ? '审批' : '继续审批'
        })
      ])
    }
  }
])

// 计算属性
const canBatchApprove = computed(() => {
  return selectedRows.value.some(row => 
    row.status === 'PENDING' || row.status === 'IN_REVIEW'
  )
})

// 方法
const canEdit = (row: WarehouseInItem) => {
  return row.status === 'DRAFT' || row.status === 'REJECTED'
}

const canApprove = (row: WarehouseInItem) => {
  return row.status === 'PENDING' || row.status === 'IN_REVIEW'
}

const handleRefresh = async () => {
  loading.value = true
  try {
    // 模拟API调用
    await new Promise(resolve => setTimeout(resolve, 800))
    loadMockData()
    message.success('数据刷新成功')
  } catch (error) {
    message.error('刷新失败')
  } finally {
    loading.value = false
  }
}

const handleSearch = () => {
  pagination.page = 1
  loadMockData()
}

const handleReset = () => {
  filterParams.status = null
  filterParams.department = null
  filterParams.dateRange = null
  filterParams.keyword = ''
  pagination.page = 1
  loadMockData()
}

const handlePageChange = (page: number) => {
  pagination.page = page
  loadMockData()
}

const handlePageSizeChange = (pageSize: number) => {
  pagination.pageSize = pageSize
  pagination.page = 1
  loadMockData()
}

const handleCreate = () => {
  message.info('跳转到创建页面')
  // router.push('/warehouse-in/create')
}

const handleExport = () => {
  message.success('导出功能开发中...')
}

const handleView = (row: WarehouseInItem) => {
  message.info(`查看申请: ${row.code}`)
  // router.push(`/warehouse-in/${row.id}`)
}

const handleEdit = (row: WarehouseInItem) => {
  if (!canEdit(row)) {
    message.warning('当前状态不允许编辑')
    return
  }
  message.info(`编辑申请: ${row.code}`)
  // router.push(`/warehouse-in/${row.id}/edit`)
}

const handleApprove = (row: WarehouseInItem) => {
  if (!canApprove(row)) {
    message.warning('当前状态不允许审批')
    return
  }
  message.info(`审批申请: ${row.code}`)
  // router.push(`/warehouse-in/${row.id}/approval`)
}

const handleBatchApprove = () => {
  if (!canBatchApprove.value) {
    message.warning('没有可审批的记录')
    return
  }
  const codes = selectedRows.value
    .filter(row => canApprove(row))
    .map(row => row.code)
    .join(', ')
  dialog.info({
    title: '批量审批',
    content: `确定要批量审批选中的 ${codes} 吗？`,
    positiveText: '确认审批',
    negativeText: '取消',
    onPositiveClick: () => {
      message.success('批量审批请求已提交')
      clearSelection()
    }
  })
}

const handleBatchDelete = () => {
  const codes = selectedRows.value.map(row => row.code).join(', ')
  dialog.warning({
    title: '批量删除',
    content: `确定要批量删除选中的 ${codes} 吗？此操作不可恢复。`,
    positiveText: '确认删除',
    negativeText: '取消',
    onPositiveClick: () => {
      message.success('批量删除成功')
      clearSelection()
      loadMockData()
    }
  })
}

const clearSelection = () => {
  selectedRows.value = []
}

// 加载模拟数据
const loadMockData = () => {
  loading.value = true
  
  // 模拟数据
  const mockData: WarehouseInItem[] = [
    {
      id: '1',
      code: 'IN20240328001',
      assetName: '笔记本电脑',
      assetType: 'ELECTRONIC',
      quantity: 5,
      unit: '台',
      applicant: '张三',
      department: 'TECHNOLOGY',
      applyDate: '2026-04-01',
      status: 'APPROVED',
      priority: 'HIGH',
      createdAt: '2026-04-01 10:30:00'
    },
    {
      id: '2',
      code: 'IN20240328002',
      assetName: '服务器',
      assetType: 'ELECTRONIC',
      quantity: 3,
      unit: '台',
      applicant: '李四',
      department: 'TECHNOLOGY',
      applyDate: '2026-04-02',
      status: 'PENDING',
      priority: 'URGENT',
      createdAt: '2026-04-02 14:20:00'
    },
    {
      id: '3',
      code: 'IN20240328003',
      assetName: '办公桌椅',
      assetType: 'FURNITURE',
      quantity: 20,
      unit: '套',
      applicant: '王五',
      department: 'ADMINISTRATION',
      applyDate: '2026-04-03',
      status: 'IN_REVIEW',
      priority: 'MEDIUM',
      createdAt: '2026-04-03 09:15:00'
    },
    {
      id: '4',
      code: 'IN20240328004',
      assetName: '投影仪',
      assetType: 'OFFICE',
      quantity: 2,
      unit: '台',
      applicant: '赵六',
      department: 'OPERATIONS',
      applyDate: '2026-04-01',
      status: 'DRAFT',
      priority: 'LOW',
      createdAt: '2026-04-01 16:45:00'
    },
    {
      id: '5',
      code: 'IN20240328005',
      assetName: '打印机',
      assetType: 'OFFICE',
      quantity: 8,
      unit: '台',
      applicant: '钱七',
      department: 'FINANCE',
      applyDate: '2026-04-02',
      status: 'REJECTED',
      priority: 'MEDIUM',
      createdAt: '2026-04-02 11:30:00'
    }
  ]

  // 应用筛选条件
  let filteredData = [...mockData]
  
  if (filterParams.status) {
    filteredData = filteredData.filter(item => item.status === filterParams.status)
  }
  
  if (filterParams.department) {
    filteredData = filteredData.filter(item => item.department === filterParams.department)
  }

  // 模拟分页
  const startIndex = (pagination.page - 1) * pagination.pageSize
  const endIndex = startIndex + pagination.pageSize
  const pageData = filteredData.slice(startIndex, endIndex)
  
  tableData.value = pageData
  total.value = filteredData.length
  pagination.itemCount = filteredData.length
  
  // 更新统计
  stats.total = filteredData.length
  stats.pending = filteredData.filter(item => item.status === 'PENDING').length
  stats.approved = filteredData.filter(item => item.status === 'APPROVED').length
  stats.rejected = filteredData.filter(item => item.status === 'REJECTED').length
  
  loading.value = false
}

// 生命周期
onMounted(() => {
  loadMockData()
})
</script>

<style scoped>
.warehouse-in-table {
  padding: 16px;
}

.table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.table-title {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
  color: var(--text-color);
}

.filter-section {
  padding: 16px;
  background-color: var(--background-color-light);
  border-radius: 8px;
  margin-bottom: 16px;
}

.batch-actions {
  padding: 12px 16px;
  background-color: var(--primary-color-soft);
  border: 1px solid var(--primary-color);
  border-radius: 6px;
  margin: 16px 0;
}

.stat-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-top: 24px;
}

.stat-card {
  transition: all 0.3s;
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.stat-content {
  display: flex;
  align-items: center;
  gap: 16px;
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.stat-icon.pending {
  background-color: var(--warning-color-soft);
  color: var(--warning-color);
}

.stat-icon.approved {
  background-color: var(--success-color-soft);
  color: var(--success-color);
}

.stat-icon.rejected {
  background-color: var(--error-color-soft);
  color: var(--error-color);
}

.stat-icon.total {
  background-color: var(--info-color-soft);
  color: var(--info-color);
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: 700;
  line-height: 1;
  margin-bottom: 4px;
  color: var(--text-color);
}

.stat-label {
  font-size: 12px;
  color: var(--text-color-secondary);
}

.action-buttons {
  display: flex;
  gap: 4px;
}

@media (max-width: 1200px) {
  .stat-cards {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .table-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }
  
  .header-right {
    width: 100%;
  }
  
  .filter-section {
    padding: 12px;
  }
  
  .stat-cards {
    grid-template-columns: 1fr;
  }
}
</style>