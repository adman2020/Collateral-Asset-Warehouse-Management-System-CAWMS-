<template>
  <div class="asset-selection">
    <div class="selection-header">
      <h3 class="title">{{ title }}</h3>
      <div class="header-actions">
        <NButton size="small" @click="handleRefresh">
          <template #icon>
            <NIcon><RefreshOutline /></NIcon>
          </template>
          刷新
        </NButton>
        <NButton size="small" type="primary" @click="handleAddNew">
          <template #icon>
            <NIcon><AddOutline /></NIcon>
          </template>
          新增资产
        </NButton>
      </div>
    </div>

    <!-- 搜索和筛选 -->
    <div class="filter-section">
      <NInput
        v-model:value="searchKeyword"
        placeholder="搜索资产名称、编号、规格..."
        clearable
        @clear="handleClearSearch"
        style="margin-bottom: 16px;"
      >
        <template #prefix>
          <NIcon><SearchOutline /></NIcon>
        </template>
      </NInput>
      
      <div class="filter-row">
        <NSelect
          v-model:value="assetTypeFilter"
          :options="assetTypeOptions"
          placeholder="资产类型"
          clearable
          style="width: 150px;"
        />
        
        <NSelect
          v-model:value="departmentFilter"
          :options="departmentOptions"
          placeholder="使用部门"
          clearable
          style="width: 150px;"
        />
        
        <NSelect
          v-model:value="conditionFilter"
          :options="conditionOptions"
          placeholder="资产状况"
          clearable
          style="width: 150px;"
        />
        
        <NButton type="primary" @click="handleSearch">
          搜索
        </NButton>
        
        <NButton @click="handleResetFilters">
          重置
        </NButton>
      </div>
    </div>

    <!-- 资产列表 -->
    <div class="asset-list">
      <div v-if="loading" class="loading-state">
        <NSpin size="large" />
        <p class="loading-text">加载资产列表中...</p>
      </div>
      
      <div v-else-if="filteredAssets.length === 0" class="empty-state">
        <NEmpty description="暂无可用资产">
          <template #icon>
            <NIcon size="48" color="#d9d9d9">
              <CubeOutline />
            </NIcon>
          </template>
          <template #action>
            <NButton type="primary" @click="handleAddNew">
              新增资产
            </NButton>
          </template>
        </NEmpty>
      </div>
      
      <div v-else class="assets-grid">
        <div
          v-for="asset in paginatedAssets"
          :key="asset.id"
          class="asset-card"
          :class="{ selected: selectedAssetIds.includes(asset.id) }"
          @click="handleAssetClick(asset)"
        >
          <div class="asset-card-header">
            <div class="asset-badge">
              <NTag :type="getAssetTypeTagType(asset.assetType)" size="small">
                {{ getAssetTypeText(asset.assetType) }}
              </NTag>
            </div>
            <div class="asset-checkbox">
              <NCheckbox 
                :checked="selectedAssetIds.includes(asset.id)"
                @update:checked="checked => handleCheckboxChange(checked, asset)"
              />
            </div>
          </div>
          
          <div class="asset-card-body">
            <div class="asset-name">{{ asset.assetName }}</div>
            <div class="asset-code">编号: {{ asset.assetCode }}</div>
            <div class="asset-spec">规格: {{ asset.specification || '暂无' }}</div>
            <div class="asset-quantity">数量: {{ asset.quantity }} {{ getUnitText(asset.unit) }}</div>
            <div class="asset-condition">
              状况: <NTag :type="getConditionTagType(asset.condition)" size="tiny">
                {{ getConditionText(asset.condition) }}
              </NTag>
            </div>
            <div class="asset-location">位置: {{ asset.storageLocation || '未指定' }}</div>
            <div class="asset-department">部门: {{ getDepartmentText(asset.usingDepartment) }}</div>
          </div>
          
          <div class="asset-card-footer">
            <div class="asset-actions">
              <NButton size="tiny" quaternary @click.stop="handleViewDetail(asset)">
                详情
              </NButton>
              <NButton size="tiny" quaternary @click.stop="handleQuickSelect(asset)">
                选择
              </NButton>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 分页 -->
    <div v-if="filteredAssets.length > 0" class="pagination-section">
      <NPagination
        v-model:page="currentPage"
        :page-count="totalPages"
        :page-size="pageSize"
        :item-count="filteredAssets.length"
        show-size-picker
        :page-sizes="[12, 24, 48, 96]"
        @update:page="handlePageChange"
        @update:page-size="handlePageSizeChange"
      />
    </div>

    <!-- 已选资产汇总 -->
    <div v-if="selectedAssets.length > 0" class="selected-summary">
      <div class="summary-header">
        <h4 class="summary-title">已选资产 ({{ selectedAssets.length }}项)</h4>
        <NButton size="small" @click="handleClearSelection">
          清空选择
        </NButton>
      </div>
      
      <div class="selected-list">
        <div v-for="asset in selectedAssets" :key="asset.id" class="selected-item">
          <div class="selected-info">
            <div class="selected-name">{{ asset.assetName }}</div>
            <div class="selected-details">
              <span class="detail-item">编号: {{ asset.assetCode }}</span>
              <span class="detail-item">数量: {{ asset.quantity }}</span>
              <span class="detail-item">规格: {{ asset.specification || '无' }}</span>
            </div>
          </div>
          <div class="selected-actions">
            <NButton size="tiny" quaternary circle @click="handleRemoveSelection(asset)">
              <template #icon>
                <NIcon><CloseOutline /></NIcon>
              </template>
            </NButton>
          </div>
        </div>
      </div>
      
      <div class="summary-actions">
        <NSpace>
          <NButton @click="handleConfirmSelection">
            确认选择
          </NButton>
          <NButton type="primary" @click="handleConfirmSelectionAndClose">
            选择并关闭
          </NButton>
        </NSpace>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  NButton,
  NIcon,
  NInput,
  NSelect,
  NTag,
  NCheckbox,
  NPagination,
  NSpace,
  NSpin,
  NEmpty,
  useMessage
} from 'naive-ui'
import {
  RefreshOutline,
  AddOutline,
  SearchOutline,
  CubeOutline,
  CloseOutline
} from '@vicons/ionicons5'

// 属性定义
interface Props {
  title?: string
  multiple?: boolean
  maxSelection?: number
  initialSelection?: any[]
}

const props = withDefaults(defineProps<Props>(), {
  title: '选择资产',
  multiple: true,
  maxSelection: 10,
  initialSelection: () => []
})

// 事件定义
const emit = defineEmits<{
  select: [assets: any[]]
  cancel: []
  confirm: [assets: any[]]
}>()

// 工具
const message = useMessage()

// 响应式状态
const searchKeyword = ref('')
const assetTypeFilter = ref('')
const departmentFilter = ref('')
const conditionFilter = ref('')
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(12)

// 资产数据
const allAssets = ref<any[]>([])
const filteredAssets = computed(() => {
  let result = [...allAssets.value]
  
  // 关键字搜索
  if (searchKeyword.value) {
    const keyword = searchKeyword.value.toLowerCase()
    result = result.filter(asset => 
      asset.assetName.toLowerCase().includes(keyword) ||
      asset.assetCode.toLowerCase().includes(keyword) ||
      (asset.specification && asset.specification.toLowerCase().includes(keyword))
    )
  }
  
  // 类型筛选
  if (assetTypeFilter.value) {
    result = result.filter(asset => asset.assetType === assetTypeFilter.value)
  }
  
  // 部门筛选
  if (departmentFilter.value) {
    result = result.filter(asset => asset.usingDepartment === departmentFilter.value)
  }
  
  // 状况筛选
  if (conditionFilter.value) {
    result = result.filter(asset => asset.condition === conditionFilter.value)
  }
  
  return result
})

// 分页资产
const paginatedAssets = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  const end = start + pageSize.value
  return filteredAssets.value.slice(start, end)
})

// 分页信息
const totalPages = computed(() => {
  return Math.ceil(filteredAssets.value.length / pageSize.value)
})

// 选中的资产
const selectedAssetIds = ref<number[]>([])
const selectedAssets = computed(() => {
  return allAssets.value.filter(asset => selectedAssetIds.value.includes(asset.id))
})

// 选项数据
const assetTypeOptions = [
  { label: '电子设备', value: 'ELECTRONIC' },
  { label: '办公设备', value: 'OFFICE' },
  { label: '运输设备', value: 'TRANSPORT' },
  { label: '机械设备', value: 'MACHINERY' },
  { label: '家具设备', value: 'FURNITURE' },
  { label: '其他设备', value: 'OTHER' }
]

const departmentOptions = [
  { label: '信贷部', value: 'CREDIT' },
  { label: '风险管理部', value: 'RISK_MANAGEMENT' },
  { label: '运营部', value: 'OPERATIONS' },
  { label: '科技部', value: 'TECHNOLOGY' },
  { label: '财务部', value: 'FINANCE' },
  { label: '行政部', value: 'ADMINISTRATION' }
]

const conditionOptions = [
  { label: '全新', value: 'NEW' },
  { label: '良好', value: 'GOOD' },
  { label: '一般', value: 'NORMAL' },
  { label: '较差', value: 'POOR' },
  { label: '待维修', value: 'NEED_REPAIR' }
]

// 工具方法
const getAssetTypeTagType = (type: string) => {
  const types: Record<string, string> = {
    ELECTRONIC: 'info',
    OFFICE: 'success',
    TRANSPORT: 'warning',
    MACHINERY: 'error',
    FURNITURE: 'default',
    OTHER: 'default'
  }
  return types[type] || 'default'
}

const getAssetTypeText = (type: string) => {
  const texts: Record<string, string> = {
    ELECTRONIC: '电子',
    OFFICE: '办公',
    TRANSPORT: '运输',
    MACHINERY: '机械',
    FURNITURE: '家具',
    OTHER: '其他'
  }
  return texts[type] || type
}

const getUnitText = (unit: string) => {
  const texts: Record<string, string> = {
    UNIT: '台',
    PIECE: '件',
    SET: '套',
    BATCH: '批',
    KG: '千克',
    METER: '米'
  }
  return texts[unit] || unit
}

const getConditionTagType = (condition: string) => {
  const types: Record<string, string> = {
    NEW: 'success',
    GOOD: 'info',
    NORMAL: 'default',
    POOR: 'warning',
    NEED_REPAIR: 'error'
  }
  return types[condition] || 'default'
}

const getConditionText = (condition: string) => {
  const texts: Record<string, string> = {
    NEW: '全新',
    GOOD: '良好',
    NORMAL: '一般',
    POOR: '较差',
    NEED_REPAIR: '待维修'
  }
  return texts[condition] || condition
}

const getDepartmentText = (department: string) => {
  const texts: Record<string, string> = {
    CREDIT: '信贷部',
    RISK_MANAGEMENT: '风险管理部',
    OPERATIONS: '运营部',
    TECHNOLOGY: '科技部',
    FINANCE: '财务部',
    ADMINISTRATION: '行政部'
  }
  return texts[department] || department
}

// 事件处理
const handleRefresh = async () => {
  loading.value = true
  try {
    // 模拟API调用
    await new Promise(resolve => setTimeout(resolve, 800))
    
    // 模拟数据
    allAssets.value = [
      {
        id: 1,
        assetName: '笔记本电脑',
        assetType: 'ELECTRONIC',
        assetCode: 'AST00123',
        specification: 'ThinkPad X1 Carbon Gen 11',
        quantity: 5,
        unit: 'UNIT',
        condition: 'NEW',
        storageLocation: '科技部仓库-A区-3号货架',
        usingDepartment: 'TECHNOLOGY',
        purchaseDate: '2024-03-15',
        purchaseAmount: 45000,
        supplier: '联想集团',
        remark: '新采购设备'
      },
      {
        id: 2,
        assetName: '投影仪',
        assetType: 'OFFICE',
        assetCode: 'AST00245',
        specification: 'EPSON CB-1485Fi',
        quantity: 2,
        unit: 'UNIT',
        condition: 'NEW',
        storageLocation: '行政部仓库-B区',
        usingDepartment: 'OPERATIONS',
        purchaseDate: '2024-03-18',
        purchaseAmount: 12000,
        supplier: 'EPSON',
        remark: '会议室设备'
      },
      {
        id: 3,
        assetName: '打印机',
        assetType: 'OFFICE',
        assetCode: 'AST00367',
        specification: 'HP LaserJet Pro MFP',
        quantity: 3,
        unit: 'UNIT',
        condition: 'GOOD',
        storageLocation: '财务部仓库',
        usingDepartment: 'FINANCE',
        purchaseDate: '2023-11-20',
        purchaseAmount: 8000,
        supplier: 'HP',
        remark: '日常办公使用'
      },
      {
        id: 4,
        assetName: '数码相机',
        assetType: 'ELECTRONIC',
        assetCode: 'AST00489',
        specification: 'Canon EOS R5',
        quantity: 1,
        unit: 'UNIT',
        condition: 'GOOD',
        storageLocation: '市场部仓库',
        usingDepartment: 'MARKETING',
        purchaseDate: '2023-12-05',
        purchaseAmount: 25000,
        supplier: 'Canon',
        remark: '活动拍摄使用'
      },
      {
        id: 5,
        assetName: '扫描仪',
        assetType: 'OFFICE',
        assetCode: 'AST00501',
        specification: 'Fujitsu fi-8170',
        quantity: 2,
        unit: 'UNIT',
        condition: 'NORMAL',
        storageLocation: '档案室',
        usingDepartment: 'ADMINISTRATION',
        purchaseDate: '2023-09-10',
        purchaseAmount: 15000,
        supplier: 'Fujitsu',
        remark: '档案数字化'
      }
    ]
    
    message.success('资产列表已刷新')
  } catch (error) {
    message.error('加载失败')
  } finally {
    loading.value = false
  }
}

const handleSearch = () => {
  currentPage.value = 1
  message.info('搜索完成')
}

const handleResetFilters = () => {
  searchKeyword.value = ''
  assetTypeFilter.value = ''
  departmentFilter.value = ''
  conditionFilter.value = ''
  currentPage.value = 1
  message.success('筛选条件已重置')
}

const handleClearSearch = () => {
  searchKeyword.value = ''
  currentPage.value = 1
}

const handleAssetClick = (asset: any) => {
  if (selectedAssetIds.value.includes(asset.id)) {
    // 取消选择
    const index = selectedAssetIds.value.indexOf(asset.id)
    selectedAssetIds.value.splice(index, 1)
  } else {
    // 检查是否超过最大选择数
    if (!props.multiple && selectedAssetIds.value.length >= 1) {
      message.warning('只能选择一个资产')
      return
    }
    
    if (props.multiple && selectedAssetIds.value.length >= props.maxSelection) {
      message.warning(`最多选择${props.maxSelection}个资产`)
      return
    }
    
    selectedAssetIds.value.push(asset.id)
    emit('select', selectedAssets.value)
  }
}

const handleCheckboxChange = (checked: boolean, asset: any) => {
  if (checked) {
    // 检查限制
    if (!props.multiple && selectedAssetIds.value.length >= 1) {
      message.warning('只能选择一个资产')
      return
    }
    
    if (props.multiple && selectedAssetIds.value.length >= props.maxSelection) {
      message.warning(`最多选择${props.maxSelection}个资产`)
      return
    }
    
    if (!selectedAssetIds.value.includes(asset.id)) {
      selectedAssetIds.value.push(asset.id)
      emit('select', selectedAssets.value)
    }
  } else {
    const index = selectedAssetIds.value.indexOf(asset.id)
    if (index !== -1) {
      selectedAssetIds.value.splice(index, 1)
      emit('select', selectedAssets.value)
    }
  }
}

const handleQuickSelect = (asset: any) => {
  if (!props.multiple) {
    selectedAssetIds.value = [asset.id]
    emit('select', selectedAssets.value)
    message.success('已选择资产')
  } else {
    handleAssetClick(asset)
  }
}

const handleViewDetail = (asset: any) => {
  message.info(`查看资产详情: ${asset.assetName}`)
}

const handlePageChange = (page: number) => {
  currentPage.value = page
}

const handlePageSizeChange = (size: number) => {
  pageSize.value = size
  currentPage.value = 1
}

const handleClearSelection = () => {
  selectedAssetIds.value = []
  emit('select', [])
  message.success('已清空选择')
}

const handleRemoveSelection = (asset: any) => {
  const index = selectedAssetIds.value.indexOf(asset.id)
  if (index !== -1) {
    selectedAssetIds.value.splice(index, 1)
    emit('select', selectedAssets.value)
    message.success('已移除选择')
  }
}

const handleConfirmSelection = () => {
  if (selectedAssets.value.length === 0) {
    message.warning('请至少选择一个资产')
    return
  }
  
  emit('confirm', selectedAssets.value)
  message.success('资产选择确认')
}

const handleConfirmSelectionAndClose = () => {
  if (selectedAssets.value.length === 0) {
    message.warning('请至少选择一个资产')
    return
  }
  
  emit('confirm', selectedAssets.value)
  message.success('资产选择确认')
  // 在实际使用中，这里可能会触发关闭模态框等操作
}

const handleAddNew = () => {
  message.info('新增资产功能开发中...')
}

// 初始化
onMounted(() => {
  handleRefresh()
  
  // 初始化选中项
  if (props.initialSelection && props.initialSelection.length > 0) {
    selectedAssetIds.value = props.initialSelection.map(asset => asset.id)
  }
})

// 监听选中项变化
watch(selectedAssets, (newValue) => {
  if (!props.multiple && newValue.length > 1) {
    // 单选模式下只保留最后一个
    selectedAssetIds.value = [newValue[newValue.length - 1].id]
  }
})
</script>

<style scoped>
.asset-selection {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.selection-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.title {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
  color: var(--text-color);
}

.header-actions {
  display: flex;
  gap: 8px;
}

.filter-section {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.filter-row {
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}

.asset-list {
  min-height: 400px;
  position: relative;
}

.loading-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 0;
}

.loading-text {
  margin-top: 16px;
  font-size: 14px;
  color: var(--text-color-secondary);
}

.empty-state {
  padding: 60px 0;
  text-align: center;
}

.assets-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 16px;
}

.asset-card {
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 16px;
  background-color: var(--background-color);
  cursor: pointer;
  transition: all 0.3s;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.asset-card:hover {
  border-color: var(--primary-color);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.asset-card.selected {
  border-color: var(--primary-color);
  background-color: var(--primary-color-soft);
}

.asset-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.asset-badge {
  flex: 1;
}

.asset-checkbox {
  margin-left: 8px;
}

.asset-card-body {
  display: flex;
  flex-direction: column;
  gap: 6px;
  flex: 1;
}

.asset-name {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-color);
  margin-bottom: 4px;
}

.asset-code,
.asset-spec,
.asset-quantity,
.asset-condition,
.asset-location,
.asset-department {
  font-size: 12px;
  color: var(--text-color-secondary);
  display: flex;
  align-items: center;
  gap: 4px;
}

.asset-card-footer {
  border-top: 1px solid var(--border-color);
  padding-top: 12px;
  margin-top: 4px;
}

.asset-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}

.pagination-section {
  display: flex;
  justify-content: center;
  margin-top: 16px;
}

.selected-summary {
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 16px;
  background-color: var(--background-color-light);
}

.summary-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.summary-title {
  font-size: 16px;
  font-weight: 600;
  margin: 0;
  color: var(--text-color);
}

.selected-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 16px;
  max-height: 200px;
  overflow-y: auto;
}

.selected-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  border: 1px solid var(--border-color);
  border-radius: 6px;
  background-color: var(--background-color);
}

.selected-info {
  flex: 1;
}

.selected-name {
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 4px;
  color: var(--text-color);
}

.selected-details {
  display: flex;
  gap: 12px;
  font-size: 12px;
  color: var(--text-color-secondary);
}

.detail-item {
  display: inline-block;
}

.selected-actions {
  margin-left: 12px;
}

.summary-actions {
  display: flex;
  justify-content: center;
  margin-top: 16px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .assets-grid {
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  }
  
  .filter-row {
    flex-direction: column;
    align-items: stretch;
  }
  
  .filter-row .n-select {
    width: 100% !important;
  }
  
  .selection-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }
  
  .header-actions {
    width: 100%;
    justify-content: flex-start;
  }
}

@media (max-width: 576px) {
  .assets-grid {
    grid-template-columns: 1fr;
  }
  
  .selected-details {
    flex-direction: column;
    gap: 4px;
  }
}
</style>