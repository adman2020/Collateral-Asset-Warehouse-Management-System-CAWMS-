<template>
  <div class="transfer-form">
    <n-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-placement="left"
      label-width="100"
    >
      <n-grid :cols="2" :x-gap="24">
        <n-gi>
          <n-form-item label="入库编号" path="warehouseInId">
            <n-select
              v-model:value="formData.warehouseInId"
              placeholder="请选择入库记录"
              :options="warehouseOptions"
              filterable
              @update:value="onWarehouseChange"
            />
          </n-form-item>
        </n-gi>
        <n-gi>
          <n-form-item label="抵押物名称" path="collateralName">
            <n-input v-model:value="formData.collateralName" disabled />
          </n-form-item>
        </n-gi>
        <n-gi>
          <n-form-item label="转移类型" path="transferType">
            <n-select
              v-model:value="formData.transferType"
              placeholder="请选择转移类型"
              :options="transferTypeOptions"
            />
          </n-form-item>
        </n-gi>
        <n-gi>
          <n-form-item label="目标仓库" path="targetWarehouseId">
            <n-select
              v-model:value="formData.targetWarehouseId"
              placeholder="请选择目标仓库"
              :options="warehouseOptions"
              filterable
            />
          </n-form-item>
        </n-gi>
        <n-gi :span="2">
          <n-form-item label="转移原因" path="transferReason">
            <n-input
              v-model:value="formData.transferReason"
              type="textarea"
              placeholder="请输入转移原因"
              :rows="3"
            />
          </n-form-item>
        </n-gi>
        <n-gi :span="2">
          <n-form-item label="备注" path="remarks">
            <n-input
              v-model:value="formData.remarks"
              type="textarea"
              placeholder="请输入备注信息"
              :rows="2"
            />
          </n-form-item>
        </n-gi>
      </n-grid>

      <div class="form-actions">
        <n-button @click="handleClose">取消</n-button>
        <n-button type="primary" :loading="submitting" @click="handleSubmit">
          {{ isEdit ? '保存' : '创建' }}
        </n-button>
      </div>
    </n-form>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { useMessage } from 'naive-ui'
import type { FormInst, FormRules } from 'naive-ui'
import {
  createTransfer,
  updateTransfer,
  getTransferDetail,
  type TransferCreateRequest
} from '~/api/transfer'

const props = defineProps<{
  transferId: number | null
}>()

const emit = defineEmits<{
  success: []
  close: []
}>()

const message = useMessage()
const formRef = ref<FormInst | null>(null)
const submitting = ref(false)

const isEdit = computed(() => props.transferId !== null)

// 表单数据
const formData = reactive<TransferCreateRequest & {
  collateralName: string
  remarks?: string
}>({
  warehouseInId: null as any,
  targetWarehouseId: null as any,
  transferType: 'INTERNAL',
  transferReason: '',
  collateralName: '',
  remarks: ''
})

// 表单规则
const formRules: FormRules = {
  warehouseInId: {
    required: true,
    message: '请选择入库记录',
    trigger: 'change'
  },
  targetWarehouseId: {
    required: true,
    message: '请选择目标仓库',
    trigger: 'change'
  },
  transferType: {
    required: true,
    message: '请选择转移类型',
    trigger: 'change'
  },
  transferReason: {
    required: true,
    message: '请输入转移原因',
    trigger: 'blur'
  }
}

// 仓库选项（模拟数据）
const warehouseOptions = ref([
  { label: '上海分行仓库 A', value: 1 },
  { label: '上海分行仓库 B', value: 2 },
  { label: '北京分行仓库', value: 3 },
  { label: '广州分行仓库', value: 4 },
  { label: '深圳分行仓库', value: 5 }
])

// 转移类型选项
const transferTypeOptions = [
  { label: '库内转移', value: 'INTERNAL' },
  { label: '跨库转移', value: 'CROSS_BRANCH' }
]

// 仓库变化
const onWarehouseChange = (value: number) => {
  // 根据选择的仓库更新抵押物名称（模拟）
  const warehouse = warehouseOptions.value.find(w => w.value === value)
  if (warehouse) {
    formData.collateralName = `${warehouse.label} - 抵押物`
  }
}

// 加载详情
const loadDetail = async () => {
  if (!props.transferId) return
  try {
    const res = await getTransferDetail(props.transferId)
    if (res.data.code === 0) {
      const data = res.data.data
      formData.warehouseInId = data.warehouseInId
      formData.targetWarehouseId = data.targetWarehouseId
      formData.transferType = data.transferType
      formData.transferReason = data.transferReason
      formData.collateralName = data.collateralName
      formData.remarks = data.remarks
    }
  } catch (error) {
    message.error('加载详情失败')
  }
}

// 提交表单
const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    submitting.value = true

    const submitData = {
      warehouseInId: formData.warehouseInId,
      targetWarehouseId: formData.targetWarehouseId,
      transferType: formData.transferType,
      transferReason: formData.transferReason,
      remarks: formData.remarks
    }

    let res
    if (isEdit.value) {
      res = await updateTransfer(props.transferId!, submitData)
    } else {
      res = await createTransfer(submitData)
    }

    if (res.data.code === 0) {
      message.success(isEdit.value ? '保存成功' : '创建成功')
      emit('success')
    }
  } catch (error: any) {
    if (error?.message === 'validation failed') return
    const backendMsg = error?.response?.data?.message
    const msg = backendMsg || error?.message || '未知错误'
    console.error(isEdit.value ? '保存转移失败:' : '创建转移失败:', error?.response?.data || error)
    message.error((isEdit.value ? '保存失败: ' : '创建失败: ') + msg)
  } finally {
    submitting.value = false
  }
}

// 关闭
const handleClose = () => {
  emit('close')
}

// 初始化
onMounted(() => {
  if (props.transferId) {
    loadDetail()
  }
})

// 监听 transferId 变化（模态框复用时重新加载）
watch(() => props.transferId, (newId) => {
  if (newId) {
    loadDetail()
  }
})
</script>

<style scoped>
.transfer-form {
  padding: 16px 0;
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 24px;
  padding-top: 24px;
  border-top: 1px solid #f0f0f0;
}
</style>
