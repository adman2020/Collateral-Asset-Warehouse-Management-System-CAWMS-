# CAWMS测试服务器启动脚本
Write-Host "=== CAWMS测试服务器启动 ===" -ForegroundColor Cyan
Write-Host "生成时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor White
Write-Host ""

# 检查可选功能
$hasNode = Get-Command node -ErrorAction SilentlyContinue
$hasPython = Get-Command python -ErrorAction SilentlyContinue

Write-Host "检测到以下服务器选项:" -ForegroundColor Yellow
if ($hasNode) {
    Write-Host "✅ Node.js可用" -ForegroundColor Green
}
if ($hasPython) {
    Write-Host "✅ Python可用" -ForegroundColor Green
}
Write-Host "✅ 可以直接打开HTML文件" -ForegroundColor Green
Write-Host ""

# 显示测试选项
Write-Host "测试选项:" -ForegroundColor Cyan
Write-Host "1. 直接打开演示页面 (推荐)" -ForegroundColor White
Write-Host "2. 使用Python启动HTTP服务器" -ForegroundColor White
Write-Host "3. 启动Vue开发服务器 (需要Node.js)" -ForegroundColor White
Write-Host "4. 打开所有测试文档" -ForegroundColor White
Write-Host ""

$choice = Read-Host "请选择 (1-4)"

if ($choice -eq "1") {
    Write-Host "正在打开完整工作流演示..." -ForegroundColor Green
    Start-Process "complete_workflow_demo.html"
    Write-Host ""
    Write-Host "✅ 演示页面已打开！" -ForegroundColor Green
    Write-Host ""
    Write-Host "测试说明:" -ForegroundColor Yellow
    Write-Host "- 这是一个交互式演示，展示从申请到审批的完整流程" -ForegroundColor White
    Write-Host "- 点击'下一步'逐步执行每个工作流步骤" -ForegroundColor White
    Write-Host "- 可以点击'自动完成审批'快速查看完整流程" -ForegroundColor White
    Write-Host "- API调用日志会显示在页面底部" -ForegroundColor White
}

if ($choice -eq "2" -and $hasPython) {
    Write-Host "正在启动Python HTTP服务器..." -ForegroundColor Green
    Write-Host "服务器将在 http://localhost:8000 运行" -ForegroundColor White
    Write-Host "按 Ctrl+C 停止服务器" -ForegroundColor Yellow
    Write-Host ""
    
    # 尝试Python 3
    try {
        python -m http.server 8000
    }
    catch {
        # 尝试Python 2
        try {
            python -m SimpleHTTPServer 8000
        }
        catch {
            Write-Host "❌ Python服务器启动失败" -ForegroundColor Red
        }
    }
}

if ($choice -eq "3" -and $hasNode) {
    Write-Host "正在启动Vue开发服务器..." -ForegroundColor Green
    Write-Host "请稍等，这可能需要一些时间..." -ForegroundColor Yellow
    Write-Host ""
    
    # 检查node_modules
    if (Test-Path "node_modules") {
        Write-Host "✅ 检测到node_modules目录" -ForegroundColor Green
        npm run dev
    }
    else {
        Write-Host "❌ 未找到node_modules目录" -ForegroundColor Red
        Write-Host "请先运行: npm install" -ForegroundColor Yellow
        Write-Host "或选择其他测试选项" -ForegroundColor White
    }
}

if ($choice -eq "4") {
    Write-Host "正在打开所有测试文档..." -ForegroundColor Green
    Start-Process "complete_workflow_demo.html"
    Start-Process "test_navigation.html"
    Start-Process "dashboard.html"
    Start-Process "FINAL_TEST_GUIDE.txt"
    Start-Process "COMPLETE_WORKFLOW_TEST_GUIDE.md"
    
    Write-Host ""
    Write-Host "✅ 所有测试文档已打开！" -ForegroundColor Green
    Write-Host ""
    Write-Host "文档说明:" -ForegroundColor Yellow
    Write-Host "1. complete_workflow_demo.html - 交互式完整工作流演示" -ForegroundColor White
    Write-Host "2. test_navigation.html - 页面导航和功能测试" -ForegroundColor White
    Write-Host "3. dashboard.html - 系统仪表板" -ForegroundColor White
    Write-Host "4. FINAL_TEST_GUIDE.txt - 最终测试指南" -ForegroundColor White
    Write-Host "5. COMPLETE_WORKFLOW_TEST_GUIDE.md - 完整工作流测试指南" -ForegroundColor White
}

if ($choice -notin @("1","2","3","4")) {
    Write-Host "❌ 无效的选择" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== 测试资源汇总 ===" -ForegroundColor Cyan
Write-Host "📁 工作目录: $PWD" -ForegroundColor White
Write-Host ""
Write-Host "📄 主要测试文件:" -ForegroundColor Yellow
Write-Host "- complete_workflow_demo.html (完整工作流交互演示)" -ForegroundColor White
Write-Host "- test_navigation.html (页面导航测试)" -ForegroundColor White
Write-Host "- dashboard.html (系统仪表板)" -ForegroundColor White
Write-Host "- RUN_COMPLETE_TEST.bat (测试启动脚本)" -ForegroundColor White
Write-Host "- start_test_server.ps1 (本脚本)" -ForegroundColor White
Write-Host ""
Write-Host "📋 测试文档:" -ForegroundColor Yellow
Write-Host "- FINAL_TEST_GUIDE.txt (最终测试指南)" -ForegroundColor White
Write-Host "- COMPLETE_WORKFLOW_TEST_GUIDE.md (完整工作流测试指南)" -ForegroundColor White
Write-Host ""
Write-Host "💡 提示: 双击 RUN_COMPLETE_TEST.bat 快速开始测试" -ForegroundColor Green

Write-Host ""
Read-Host "按Enter键退出"