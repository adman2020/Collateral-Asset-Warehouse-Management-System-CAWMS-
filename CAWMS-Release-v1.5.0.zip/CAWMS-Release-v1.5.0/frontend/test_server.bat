@echo off
cd /d "D:\frontend"
echo Starting HTTP server on port 8080...
echo Open http://localhost:8080/dashboard.html in your browser
echo Press Ctrl+C to stop
python -m http.server 8080