@echo off
echo ========================================
echo SeABank CAWMS 前端演示启动脚本
echo ========================================
echo.

REM 检查Node.js和npm
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [错误] 未找到Node.js，请先安装Node.js
    pause
    exit /b 1
)

where npm >nul 2>nul
if %errorlevel% neq 0 (
    echo [错误] 未找到npm，请先安装npm
    pause
    exit /b 1
)

echo [信息] 检测到Node.js版本:
node --version
echo [信息] 检测到npm版本:
npm --version
echo.

REM 检查前端项目依赖
if not exist "node_modules" (
    echo [信息] node_modules目录不存在，正在安装依赖...
    call npm install
    if %errorlevel% neq 0 (
        echo [错误] 依赖安装失败
        pause
        exit /b 1
    )
    echo [成功] 依赖安装完成
) else (
    echo [信息] 依赖已安装，跳过安装步骤
)

echo.
echo ========================================
echo 启动前端开发服务器
echo ========================================
echo.

echo [信息] 将在 http://localhost:3000 启动开发服务器
echo [提示] 按 Ctrl+C 停止服务器
echo.

REM 启动开发服务器
call npm run dev

REM 如果用户停止服务器，显示提示
echo.
echo [信息] 开发服务器已停止
echo [提示] 按任意键退出...
pause >nul