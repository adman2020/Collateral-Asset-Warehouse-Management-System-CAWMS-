@echo off
chcp 65001 >nul
color 0A
mode con: cols=80 lines=25

echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║                   CAWMS 前端系统测试                    ║
echo ╠══════════════════════════════════════════════════════════╣
echo ║                                                          ║
echo ║  任务状态: Task13.8 和 Task14.7 已完成! (04:15)         ║
echo ║                                                          ║
echo ║  登录凭证:                                               ║
echo ║    用户名: admin    密码: admin123                      ║
echo ║    用户名: user     密码: user123                       ║
echo ║                                                          ║
echo ║  请按任意键打开系统进行测试...                          ║
echo ║                                                          ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
pause >nul

start "" "dashboard.html"
echo.
echo 系统已打开，请使用上述凭证登录并测试功能。
echo.
echo 测试内容:
echo   1. 入库管理页面 (搜索、筛选、操作按钮)
echo   2. 借出管理页面 (逾期预警、归还操作)
echo   3. 页面导航 (仪表板到各页面链接)
echo.
echo 按任意键退出本窗口...
pause >nul