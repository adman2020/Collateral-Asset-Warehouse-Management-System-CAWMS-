import { test, expect } from '@playwright/test';

async function login(page: any, username: string, password: string) {
  await page.goto('/');
  await page.locator('input[type="text"], input[name="username"]').first().fill(username);
  await page.locator('input[type="password"]').first().fill(password);
  await page.locator('button[type="submit"], button:has-text("登录"), button:has-text("Login"), button:has-text("Sign in")').first().click();
  await expect(page).toHaveURL(/^(?!.*login).*$/);
}

test.describe('Warehouse In E2E', () => {
  test('TC-02: should create warehouse-in application via API and verify', async ({ request }) => {
    // Step 1: Login and get token via API
    const loginRes = await request.post('http://localhost:8080/api/auth/login', {
      data: { username: 'admin', password: 'admin123' }
    });
    
    // If auth endpoint doesn't exist, skip API test gracefully
    if (!loginRes.ok()) {
      test.skip('Auth API not available');
      return;
    }
    
    const loginBody = await loginRes.json().catch(() => ({}));
    const token = loginBody.data?.token || loginBody.token;
    
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
    
    // Step 2: Create warehouse-in draft
    const createRes = await request.post('http://localhost:8080/api/warehouse-in/draft', {
      headers,
      multipart: {
        buCode: 'HN',
        buName: 'Hanoi Branch',
        customerId: 'CUST-E2E-001',
        customerName: 'E2E Test Corp',
        collateralType: 'REAL_ESTATE',
        collateralValue: '1000000000',
        creditAgreementNo: 'LOAN-E2E-001',
        intakeType: 'NEW',
        remarks: 'E2E automated test',
        uploader: 'admin'
      }
    });
    
    expect(createRes.status()).toBeLessThan(500);
    const createBody = await createRes.json().catch(() => ({}));
    expect(createBody.code === 200 || createBody.success === true || typeof createBody.data === 'number').toBeTruthy();
  });

  test('TC-02a: should navigate to warehouse-in page after login', async ({ page }) => {
    await login(page, 'admin', 'admin123');
    
    // Try to navigate to warehouse-in module (URL patterns may vary)
    await page.goto('/warehouse-in');
    await expect(page.locator('body')).toBeVisible();
    
    // Check that page contains some warehouse-in related text or form elements
    const bodyText = await page.locator('body').innerText();
    const hasWarehouseInContent = /入库|Warehouse|wh_code|抵押|collateral/i.test(bodyText);
    expect(hasWarehouseInContent).toBeTruthy();
  });
});
