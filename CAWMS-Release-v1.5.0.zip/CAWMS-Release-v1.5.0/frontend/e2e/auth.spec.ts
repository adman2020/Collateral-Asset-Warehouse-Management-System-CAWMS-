import { test, expect } from '@playwright/test';

test.describe('Authentication', () => {
  test('TC-01: should login with admin credentials', async ({ page }) => {
    await page.goto('/');
    
    // Wait for login form
    await expect(page.locator('input[type="text"], input[name="username"], input[placeholder*="用户名"], input[placeholder*="username"]').first()).toBeVisible({ timeout: 10000 });
    
    // Fill login form (use generic selectors to accommodate any UI framework)
    const usernameInput = page.locator('input[type="text"], input[name="username"]').first();
    const passwordInput = page.locator('input[type="password"]').first();
    const submitButton = page.locator('button[type="submit"], button:has-text("登录"), button:has-text("Login"), button:has-text("Sign in")').first();
    
    await usernameInput.fill('admin');
    await passwordInput.fill('admin123');
    await submitButton.click();
    
    // Expect redirect to dashboard or home page
    await expect(page).toHaveURL(/^(?!.*login).*$/);
    
    // Verify token stored
    const token = await page.evaluate(() => localStorage.getItem('token') || sessionStorage.getItem('token'));
    expect(token).toBeTruthy();
  });

  test('TC-01a: should reject invalid credentials', async ({ page }) => {
    await page.goto('/');
    
    const usernameInput = page.locator('input[type="text"], input[name="username"]').first();
    const passwordInput = page.locator('input[type="password"]').first();
    const submitButton = page.locator('button[type="submit"], button:has-text("登录"), button:has-text("Login"), button:has-text("Sign in")').first();
    
    await usernameInput.fill('admin');
    await passwordInput.fill('wrongpassword');
    await submitButton.click();
    
    // Should stay on login page or show error message
    await expect(page.locator('body')).toContainText(/错误|失败|error|fail|invalid/i, { timeout: 5000 });
  });
});
