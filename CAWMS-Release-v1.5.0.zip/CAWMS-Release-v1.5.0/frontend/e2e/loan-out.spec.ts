import { test, expect } from '@playwright/test';

async function login(page: any, username: string, password: string) {
  await page.goto('/');
  await page.locator('input[type="text"], input[name="username"]').first().fill(username);
  await page.locator('input[type="password"]').first().fill(password);
  await page.locator('button[type="submit"], button:has-text("登录"), button:has-text("Login"), button:has-text("Sign in")').first().click();
  await expect(page).toHaveURL(/^(?!.*login).*$/);
}

test.describe('Loan Out E2E', () => {
  test('TC-03: should create loan-out draft via API', async ({ request }) => {
    const loginRes = await request.post('http://localhost:8080/api/auth/login', {
      data: { username: 'admin', password: 'admin123' }
    });
    
    if (!loginRes.ok()) {
      test.skip('Auth API not available');
      return;
    }
    
    const loginBody = await loginRes.json().catch(() => ({}));
    const token = loginBody.data?.token || loginBody.token;
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
    
    const createRes = await request.post('http://localhost:8080/api/loan-out/drafts', {
      headers,
      data: {
        whCode: 'WH-HN-20240402001',
        loanPurpose: 'E2E Test Purpose',
        loanDuration: 30,
        expectedReturnDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
        borrower: 'E2E Borrower',
        borrowerDepartment: 'Legal',
        createdBy: 'admin'
      }
    });
    
    expect(createRes.status()).toBeLessThan(500);
    const body = await createRes.json().catch(() => ({}));
    expect(body.code === 200 || body.success === true).toBeTruthy();
  });

  test('TC-03a: should access loan-out module', async ({ page }) => {
    await login(page, 'admin', 'admin123');
    await page.goto('/loan-out');
    await expect(page.locator('body')).toBeVisible();
    const bodyText = await page.locator('body').innerText();
    const hasLoanOutContent = /借出|Loan|loan-out|borrow/i.test(bodyText);
    expect(hasLoanOutContent).toBeTruthy();
  });
});
