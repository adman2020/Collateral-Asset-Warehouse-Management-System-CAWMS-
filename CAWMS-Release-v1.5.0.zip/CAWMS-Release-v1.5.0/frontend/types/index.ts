export interface User {
  id: number
  name: string
  email: string
  avatar?: string
}

// Re-export from request utils to avoid duplicated definitions
export type { ApiResponse, PaginatedResponse } from '~/utils/request'

// Alias for API files using Response / PageResult naming
export type Response<T> = import('~/utils/request').ApiResponse<T>
export type PageResult<T> = import('~/utils/request').PaginatedResponse<T>

export interface CounterState {
  value: number
}
