#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简单的数据库结构比较
"""

import re
import subprocess
import sys

def get_current_tables():
    """获取当前数据库的所有表名"""
    cmd = ['mysql', '-u', 'root', '-pG-;fnxjV4Ck(', '-D', 'cawms', '-e', 'SHOW TABLES']
    result = subprocess.run(cmd, capture_output=True, text=True, shell=True)
    
    tables = []
    for line in result.stdout.strip().split('\n')[1:]:
        if line.strip():
            tables.append(line.strip())
    
    return tables

def get_table_structure(table_name):
    """获取指定表的结构"""
    cmd = ['mysql', '-u', 'root', '-pG-;fnxjV4Ck(', '-D', 'cawms', '-e', f'SHOW CREATE TABLE `{table_name}`']
    result = subprocess.run(cmd, capture_output=True, text=True, shell=True)
    
    if result.returncode == 0:
        lines = result.stdout.strip().split('\n')
        if len(lines) > 1:
            # 第一行是列标题，第二行开始是数据
            for line in lines[1:]:
                if 'CREATE TABLE' in line:
                    return line
    return None

def parse_old_sql(file_path):
    """解析旧版本SQL文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 提取所有CREATE TABLE语句
    tables = {}
    
    # 使用正则表达式匹配CREATE TABLE语句
    pattern = r'CREATE TABLE IF NOT EXISTS (\w+)\s*\(([^;]+?)\)[^)]*?ENGINE=(\w+)'
    matches = re.findall(pattern, content, re.DOTALL | re.IGNORECASE)
    
    for match in matches:
        table_name = match[0]
        table_def = match[1].strip()
        engine = match[2]
        
        # 清理表定义
        lines = []
        for line in table_def.split('\n'):
            line = line.strip()
            if line and not line.startswith('--'):
                lines.append(line)
        
        tables[table_name] = {
            'definition': ' '.join(lines),
            'engine': engine,
            'columns': extract_columns(table_def)
        }
    
    return tables

def extract_columns(table_def):
    """从表定义中提取列信息"""
    columns = {}
    
    # 分割列定义
    lines = table_def.split(',')
    for line in lines:
        line = line.strip()
        if not line or line.startswith('PRIMARY KEY') or line.startswith('KEY') or line.startswith('INDEX') or line.startswith('UNIQUE') or line.startswith('FOREIGN'):
            continue
        
        # 提取列名和类型
        # 格式: `column_name` type [options]
        match = re.match(r'`?(\w+)`?\s+([^(]+)', line)
        if match:
            col_name = match.group(1)
            col_type = match.group(2).strip()
            columns[col_name] = {
                'full_def': line,
                'type': col_type
            }
    
    return columns

def compare_tables(old_tables, current_tables):
    """比较表结构"""
    old_names = set(old_tables.keys())
    current_names = set(current_tables)
    
    added = current_names - old_names
    removed = old_names - current_names
    common = old_names & current_names
    
    return {
        'added_tables': sorted(list(added)),
        'removed_tables': sorted(list(removed)),
        'common_tables': sorted(list(common))
    }

def generate_simple_report(old_file, current_tables, comparison):
    """生成简单的报告"""
    report = []
    
    report.append("=" * 60)
    report.append("数据库结构比较报告")
    report.append("=" * 60)
    report.append(f"旧版本: {old_file}")
    report.append(f"当前数据库: cawms")
    report.append("")
    
    # 表数量统计
    report.append("1. 表数量统计")
    report.append("-" * 40)
    report.append(f"旧版本表数: {len(comparison['common_tables']) + len(comparison['removed_tables'])}")
    report.append(f"当前表数: {len(comparison['common_tables']) + len(comparison['added_tables'])}")
    report.append("")
    
    # 新增的表
    if comparison['added_tables']:
        report.append("2. 新增的表")
        report.append("-" * 40)
        for table in comparison['added_tables']:
            report.append(f"  + {table}")
        report.append("")
    
    # 删除的表（理论上不应有）
    if comparison['removed_tables']:
        report.append("3. 已删除的表（旧版本有，当前无）")
        report.append("-" * 40)
        for table in comparison['removed_tables']:
            report.append(f"  - {table}")
        report.append("")
    
    # 共同的表
    report.append("4. 共同的表")
    report.append("-" * 40)
    for table in comparison['common_tables']:
        report.append(f"  • {table}")
    
    return "\n".join(report)

def main():
    if len(sys.argv) != 3:
        print("用法: python simple_compare.py <旧版本SQL> <输出报告>")
        sys.exit(1)
    
    old_file = sys.argv[1]
    report_file = sys.argv[2]
    
    print("获取当前数据库表...")
    current_tables = get_current_tables()
    print(f"当前数据库有 {len(current_tables)} 个表")
    
    print("解析旧版本SQL文件...")
    old_tables = parse_old_sql(old_file)
    print(f"旧版本有 {len(old_tables)} 个表")
    
    print("比较表结构...")
    comparison = compare_tables(old_tables, current_tables)
    
    print("生成报告...")
    report = generate_simple_report(old_file, current_tables, comparison)
    
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(f"报告已生成: {report_file}")
    
    # 控制台输出摘要
    print("\n" + "=" * 60)
    print("摘要:")
    print(f"新增表: {len(comparison['added_tables'])} 个")
    if comparison['added_tables']:
        print(f"  具体: {', '.join(comparison['added_tables'])}")
    
    print(f"删除表: {len(comparison['removed_tables'])} 个")
    if comparison['removed_tables']:
        print(f"  具体: {', '.join(comparison['removed_tables'])}")
    
    print(f"共同表: {len(comparison['common_tables'])} 个")

if __name__ == '__main__':
    main()