#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
修复MySQL导出文件中的中文乱码
"""

import re
import sys

def fix_comment_encoding(match):
    """修复单个COMMENT中的乱码"""
    comment = match.group(1)
    # 尝试常见乱码修复
    # 如果包含'�'，可能是UTF-8解码失败
    if '�' in comment:
        # 尝试从GBK重新编码
        try:
            # 假设乱码是UTF-8字节被当作GBK读取的结果
            # 将当前字符串编码为GBK，然后解码为UTF-8
            fixed = comment.encode('gbk', errors='ignore').decode('utf-8', errors='ignore')
            if fixed and len(fixed) > 0:
                return fixed
        except:
            pass
    
    # 常见乱码映射（基于观察）
    mapping = {
        '??ID': 'ID',
        '???': '名称',
        '????': '操作',
        '????': '资源类型',
        '??': '旧值',
        '??': '新值',
        'IP??': 'IP地址',
        '????': '用户代理',
        '??URL': '请求URL',
        '????': '请求方法',
        '????(ms)': '执行时间(ms)',
        '????: SUCCESS, FAILED': '状态: SUCCESS, FAILED',
        '????': '错误消息',
        '?????': '审计日志表',
        '???????': '入库记录ID',
        '????': '借用目的',
        '????(?)': '借用期限(天)',
        '??????': '预计归还日期',
        '??????': '实际归还日期',
        '??: DRAFT, LOANED, RETURNED, OVERDUE': '状态: DRAFT, LOANED, RETURNED, OVERDUE',
        'T24????: PENDING, SYNCED, FAILED': 'T24同步状态: PENDING, SYNCED, FAILED',
        'T24????': 'T24同步时间',
        '???': '创建人',
        '更新�?': '更新人',
        '逻辑删除标志': '逻辑删除标志',
        '????': '仓库编码',
        '??????': '业务单位名称',
        '??????': '业务单位代码',
        '????': '客户名称',
        '??ID': '客户ID',
        '??????': '抵押物类型',
    }
    
    if comment in mapping:
        return mapping[comment]
    
    return comment

def fix_sql_file(input_file, output_file):
    """修复SQL文件中的乱码注释"""
    # 尝试多种编码
    for encoding in ['utf-8-sig', 'utf-8', 'gbk', 'latin-1']:
        try:
            with open(input_file, 'r', encoding=encoding) as f:
                content = f.read()
            print(f"使用编码 {encoding} 成功读取文件")
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ValueError(f"无法解码文件 {input_file}")
    
    # 修复 COMMENT '...' 中的乱码
    pattern = r"COMMENT '([^']*)'"
    
    def replace_func(match):
        original = match.group(0)
        comment = match.group(1)
        # 如果注释已经是中文（不包含?和�），则保留
        if not ('?' in comment or '�' in comment):
            return original
        
        fixed = fix_comment_encoding(match)
        if fixed != comment:
            print(f"修复: {comment} -> {fixed}")
            return f"COMMENT '{fixed}'"
        return original
    
    fixed_content = re.sub(pattern, replace_func, content)
    
    # 修复表注释 TABLE_COMMENT='...'
    table_pattern = r"TABLE_COMMENT='([^']*)'"
    fixed_content = re.sub(table_pattern, replace_func, fixed_content)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(fixed_content)
    
    print(f"修复完成，输出文件: {output_file}")
    print(f"原始文件大小: {len(content)} 字节")
    print(f"修复后大小: {len(fixed_content)} 字节")

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("用法: python fix_encoding.py <输入文件> <输出文件>")
        sys.exit(1)
    
    fix_sql_file(sys.argv[1], sys.argv[2])