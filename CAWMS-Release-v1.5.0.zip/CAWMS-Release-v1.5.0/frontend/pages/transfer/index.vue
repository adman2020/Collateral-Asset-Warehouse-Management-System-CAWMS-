<template>
  <div class="transfer-page">
    <!-- 页面标题 -->
    <div class="page-header">
      <h1 class="page-title">{{ $t('transfer.title') }}</h1>
      <n-button type="primary" @click="handleCreate">
        <template #icon>
          <n-icon><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg></n-icon>
        </template>
        {{ $t('transfer.createBtn') }}
      </n-button>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #e6f7ff;">📦</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.total || 0 }}</div>
          <div class="stat-label">{{ $t('transfer.total') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #fff7e6;">⏳</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.pendingApprovals || 0 }}</div>
          <div class="stat-label">{{ $t('transfer.pendingApproval') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #f6ffed;">✅</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.completedToday || 0 }}</div>
          <div class="stat-label">{{ $t('transfer.completedToday') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #fff1f0;">🔄</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.byStatus?.SUBMITTED || 0 }}</div>
          <div class="stat-label">{{ $t('transfer.inReview') }}</div>
        </div>
      </n-card>
    </div>

    <!-- 搜索栏 -->
    <n-card class="search-card">
      <n-grid :cols="4" :x-gap="16" :y-gap="12">
        <n-gi>
          <n-input v-model:value="searchForm.collateralName" :placeholder="$t('transfer.collateralName')" clearable />
        </n-gi>
        <n-gi>
          <n-input v-model:value="searchForm.warehouseInNo" :placeholder="$t('transfer.warehouseInNo')" clearable />
        </n-gi>
        <n-gi>
          <n-select
            v-model:value="searchForm.status"
            :placeholder="$t('transfer.status')"
            :options="statusOptions"
            clearable
          />
        </n-gi>
        <n-gi>
          <n-select
            v-model:value="searchForm.transferType"
            :placeholder="$t('transfer.transferType')"
            :options="transferTypeOptions"
            clearable
          />
        </n-gi>
        <n-gi>
          <n-date-picker
            v-model:value="searchForm.startDate"
            type="date"
            :placeholder="$t('transfer.startDate')"
            style="width: 100%"
          />
        </n-gi>
        <n-gi>
          <n-date-picker
            v-model:value="searchForm.endDate"
            type="date"
            :placeholder="$t('transfer.endDate')"
            style="width: 100%"
          />
        </n-gi>
        <n-gi>
          <n-button type="primary" block @click="handleSearch">
            <template #icon>
              <n-icon><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg></n-icon>
            </template>
            {{ $t('transfer.search') }}
          </n-button>
        </n-gi>
        <n-gi>
          <n-button block @click="handleReset">{{ $t('transfer.reset') }}</n-button>
        </n-gi>
      </n-grid>
    </n-card>

    <!-- 表格 -->
    <n-card class="table-card">
      <n-data-table
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :pagination="pagination"
        :row-key="(row) => row.id"
        @update:checked-row-keys="onChecked"
      />
    </n-card>

    <!-- 新建/详情模态框 -->
    <n-modal
      v-model:show="showModal"
      :title="modalTitle"
      preset="card"
      style="width: 800px"
    >
      <transfer-form
        v-if="showModal"
        :transfer-id="currentTransferId"
        @success="handleModalSuccess"
        @close="showModal = false"
      />
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useMessage, NButton } from 'naive-ui'
import type { DataTableColumns } from 'naive-ui'
import {
  getTransferList,
  getTransferStatistics,
  type Transfer,
  type TransferStatistics
} from '~/api/transfer'
import { useAuthStore } from '@/stores/auth'
import { useI18n } from 'vue-i18n'
import TransferForm from '~/components/transfer/TransferForm.vue'

const router = useRouter()
const message = useMessage()
const authStore = useAuthStore()
const { t } = useI18n()

// 加载状态
const loading = ref(false)

// 统计数据
const statistics = ref<TransferStatistics>()

// 搜索表单
const searchForm = reactive({
  collateralName: '',
  warehouseInNo: '',
  status: '',
  transferType: '',
  startDate: null as number | null,
  endDate: null as number | null
})

// 表格数据
const tableData = ref<Transfer[]>([])

// 分页
const pagination = reactive({
  page: 1,
  pageSize: 10,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  itemCount: 0,
  onChange: (page: number) => {
    pagination.page = page
    loadTableData()
  },
  onUpdatePageSize: (pageSize: number) => {
    pagination.pageSize = pageSize
    pagination.page = 1
    loadTableData()
  }
})

// 模态框
const showModal = ref(false)
const modalTitle = ref('')
const currentTransferId = ref<number | null>(null)

// 选项
const statusOptions = [
  { label: t('status.draft'), value: 'DRAFT' },
  { label: t('status.submitted'), value: 'SUBMITTED' },
  { label: t('status.approved'), value: 'APPROVED' },
  { label: t('status.completed'), value: 'COMPLETED' },
  { label: t('status.cancelled'), value: 'CANCELLED' }
]

const transferTypeOptions = [
  { label: t('transfer.typeInternal'), value: 'INTERNAL' },
  { label: t('transfer.typeCross'), value: 'CROSS_BRANCH' }
]

// 表格列定义
const columns: DataTableColumns<Transfer> = [
  {
    type: 'selection',
    fixed: 'left'
  },
  {
    title: t('transfer.transferNo'),
    key: 'transferNo',
    width: 150,
    fixed: 'left'
  },
  {
    title: t('transfer.warehouseInNo'),
    key: 'warehouseInNo',
    width: 120
  },
  {
    title: t('transfer.collateralName'),
    key: 'collateralName',
    width: 150
  },
  {
    title: t('transfer.transferType'),
    key: 'transferType',
    width: 100,
    render: (row) => {
      const typeMap: Record<string, string> = {
        INTERNAL: t('transfer.typeInternal'),
        CROSS_BRANCH: t('transfer.typeCross')
      }
      return typeMap[row.transferType] || row.transferType
    }
  },
  {
    title: t('transfer.sourceWarehouse'),
    key: 'sourceWarehouseName',
    width: 120
  },
  {
    title: t('transfer.targetWarehouse'),
    key: 'targetWarehouseName',
    width: 120
  },
  {
    title: t('transfer.status'),
    key: 'status',
    width: 100,
    render: (row) => {
      const statusMap: Record<string, { type: string; label: string }> = {
        DRAFT: { type: 'default', label: t('status.draft') },
        SUBMITTED: { type: 'warning', label: t('status.inReview') },
        APPROVED: { type: 'info', label: t('status.approved') },
        COMPLETED: { type: 'success', label: t('status.completed') },
        CANCELLED: { type: 'error', label: t('status.cancelled') }
      }
      const status = statusMap[row.status] || { type: 'default', label: row.status }
      return h('n-tag', { type: status.type as any }, { default: () => status.label })
    }
  },
  {
    title: t('transfer.applicant'),
    key: 'applicantName',
    width: 100
  },
  {
    title: t('transfer.applyTime'),
    key: 'applyTime',
    width: 160,
    render: (row) => row.applyTime?.slice(0, 16).replace('T', ' ')
  },
  {
    title: t('common.operation'),
    key: 'actions',
    width: 320,
    fixed: 'right',
    render: (row) => {
      return h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } }, [
        h(NButton, { size: 'small', onClick: () => handleView(row.id) }, { default: () => t('common.view') }),
        h(NButton, { size: 'small', disabled: !canEdit(row), onClick: () => handleEdit(row.id) }, { default: () => t('common.edit') }),
        h(NButton, { size: 'small', type: 'primary', disabled: !canSubmit(row), onClick: () => handleSubmit(row.id) }, { default: () => t('common.submit') }),
        h(NButton, { size: 'small', type: 'warning', disabled: !canApprove(row), onClick: () => handleGoApprove(row.id) }, { default: () => t('common.approve') }),
        h(NButton, { size: 'small', type: 'error', disabled: !canReject(row), onClick: () => handleReject(row.id) }, { default: () => t('common.reject') }),
        h(NButton, { size: 'small', type: 'info', disabled: !canComplete(row), onClick: () => handleComplete(row.id) }, { default: () => t('common.completed') })
      ])
    }
  }
]

// 加载表格数据
const loadTableData = async () => {
  loading.value = true
  try {
    const res = await getTransferList({
      page: pagination.page,
      size: pagination.pageSize,
      ...searchForm
    })
    if (res.data.code === 0) {
      tableData.value = res.data.data.records
      pagination.itemCount = res.data.data.total
    }
  } catch (error) {
    message.error(t('transfer.loadDataFailed'))
  } finally {
    loading.value = false
  }
}

// 加载统计数据
const loadStatistics = async () => {
  try {
    const res = await getTransferStatistics()
    if (res.data.code === 0) {
      statistics.value = res.data.data
    }
  } catch (error) {
    console.error(t('transfer.loadStatisticsFailed'), error)
  }
}

// 搜索
const handleSearch = () => {
  pagination.page = 1
  loadTableData()
}

// 重置
const handleReset = () => {
  searchForm.collateralName = ''
  searchForm.warehouseInNo = ''
  searchForm.status = ''
  searchForm.transferType = ''
  searchForm.startDate = null
  searchForm.endDate = null
  handleSearch()
}

// 新建
const handleCreate = () => {
  router.push('/transfer/create')
}

// 查看
const handleView = (id: number) => {
  router.push(`/transfer/${id}`)
}

// 编辑
const handleEdit = (id: number) => {
  modalTitle.value = t('transfer.editModalTitle')
  currentTransferId.value = id
  showModal.value = true
}

// 提交
const handleSubmit = async (id: number) => {
  try {
    const { submitTransfer } = await import('~/api/transfer')
    const res = await submitTransfer({ id })
    if (res.data.code === 0) {
      message.success(t('transfer.submitSuccess'))
      loadTableData()
      loadStatistics()
    } else {
      message.error(res.data.message || t('transfer.submitFailed'))
    }
  } catch (error: any) {
    message.error(t('transfer.submitFailed') + ': ' + (error?.response?.data?.message || error?.message))
  }
}

// 审批
const handleApprove = async (id: number) => {
  try {
    const { approveTransfer } = await import('~/api/transfer')
    const res = await approveTransfer({ id, step: 1, approvalStatus: 'APPROVED', approvalOpinion: t('common.agree') })
    if (res.data.code === 0) {
      message.success(t('transfer.approveSuccess'))
      loadTableData()
      loadStatistics()
    } else {
      message.error(res.data.message || t('transfer.approveFailed'))
    }
  } catch (error: any) {
    message.error(t('transfer.approveFailed') + ': ' + (error?.response?.data?.message || error?.message))
  }
}

// 拒绝（取消）
const handleReject = async (id: number) => {
  try {
    const { cancelTransfer } = await import('~/api/transfer')
    const res = await cancelTransfer(id)
    if (res.data.code === 0) {
      message.success(t('transfer.rejectSuccess'))
      loadTableData()
      loadStatistics()
    } else {
      message.error(res.data.message || t('transfer.operationFailed'))
    }
  } catch (error: any) {
    message.error(t('transfer.operationFailed') + ': ' + (error?.response?.data?.message || error?.message))
  }
}

// 完成
const handleComplete = async (id: number) => {
  try {
    const { completeTransfer } = await import('~/api/transfer')
    const res = await completeTransfer(id)
    if (res.data.code === 0) {
      message.success(t('transfer.completeSuccess'))
      loadTableData()
      loadStatistics()
    } else {
      message.error(res.data.message || t('transfer.operationFailed'))
    }
  } catch (error: any) {
    message.error(t('transfer.operationFailed') + ': ' + (error?.response?.data?.message || error?.message))
  }
}

// 模态框成功
const handleModalSuccess = () => {
  showModal.value = false
  loadTableData()
  loadStatistics()
}

// 选择行
const onChecked = (rowKeys: (string | number)[]) => {
  console.log(t('transfer.selectedRows'), rowKeys)
}

// 权限判断
function canEdit(row: Transfer) {
  if (authStore.isAdmin) return true
  const isCreator = authStore.user?.username === row.applicantName || authStore.user?.id === row.applicantId
  return isCreator && row.status === 'DRAFT'
}
function canSubmit(row: Transfer) {
  if (authStore.isAdmin) return true
  const isCreator = authStore.user?.username === row.applicantName || authStore.user?.id === row.applicantId
  return isCreator && row.status === 'DRAFT'
}
function canApprove(row: Transfer) {
  if (!['SUBMITTED'].includes(row.status)) return false
  const pending = row.approvals?.find((a: any) => a.approvalStatus === 'PENDING')
  if (!pending) return false
  return authStore.isAdmin || authStore.user?.role === pending.approverRole
}
function canReject(row: Transfer) {
  return ['SUBMITTED'].includes(row.status) && (authStore.isAdmin || authStore.user?.role === 'WAREHOUSE_MANAGER')
}
function canComplete(row: Transfer) {
  return row.status === 'APPROVED'
}

// 跳转到审批页面
function handleGoApprove(id: number) {
  router.push(`/transfer/approval?id=${id}`)
}

// 初始化
onMounted(() => {
  loadTableData()
  loadStatistics()
})
</script>

<style scoped>
.transfer-page {
  padding: 24px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.page-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: 600;
  color: #333;
}

.stat-label {
  font-size: 14px;
  color: #666;
  margin-top: 4px;
}

.search-card {
  margin-bottom: 24px;
}

.table-card {
  min-height: 400px;
}
</style>
