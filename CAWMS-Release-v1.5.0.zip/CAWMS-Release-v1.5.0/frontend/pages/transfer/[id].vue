<template>
  <div class="transfer-detail-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('transfer.detailTitle') }}</h1>
        <p class="page-subtitle">{{ $t('transfer.transferNo') }}: {{ detail.transferNo || detail.id }} | {{ $t('transfer.status') }}: {{ formatStatus(detail.status) }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="router.back()">{{ $t('common.back') }}</NButton>
        <NButton :disabled="!canEdit" @click="handleEdit">{{ $t('common.edit') }}</NButton>
        <NButton type="primary" :disabled="!canSubmit" @click="handleSubmit">{{ $t('common.submit') }}</NButton>
        <NButton type="warning" :disabled="!canApprove" @click="handleApprove">{{ $t('common.approve') }}</NButton>
        <NButton type="info" :disabled="!canComplete" @click="handleComplete">{{ $t('common.completed') }}</NButton>
        <NButton type="error" :disabled="!canCancel" @click="handleCancel">{{ $t('common.cancel') }}</NButton>
      </div>
    </div>

    <NGrid :cols="3" :x-gap="16" :y-gap="16">
      <NGi :span="2">
        <NCard :title="$t('transfer.basicInfo')" size="small">
          <NDescriptions :column="2" bordered size="small">
            <NDescriptionsItem :label="$t('transfer.transferNo')">{{ detail.transferNo || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.warehouseInNo')">{{ detail.warehouseInNo || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.collateralName')">{{ detail.collateralName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.collateralType')">{{ detail.collateralType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.sourceWarehouse')">{{ detail.sourceWarehouseName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.targetWarehouse')">{{ detail.targetWarehouseName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.transferType')">{{ formatTransferType(detail.transferType) }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.transferReason')">{{ detail.transferReason || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.applicant')">{{ detail.applicantName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.applyTime')">{{ detail.applyTime ? detail.applyTime.slice(0, 16).replace('T', ' ') : '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.status')">
              <NTag :type="getStatusType(detail.status)">{{ formatStatus(detail.status) }}</NTag>
            </NDescriptionsItem>
            <NDescriptionsItem :label="$t('common.remark')" :span="2">{{ detail.remarks || '-' }}</NDescriptionsItem>
          </NDescriptions>
        </NCard>

        <NCard :title="$t('transfer.approvalHistory')" size="small" class="history-card">
          <NEmpty v-if="!detail.approvals || detail.approvals.length === 0" :description="$t('transfer.noApprovalRecords')" />
          <NTimeline v-else>
            <NTimelineItem
              v-for="item in detail.approvals"
              :key="item.id"
              :type="getApprovalTimelineType(item.approvalStatus)"
              :title="item.stepName || getApprovalStepName(item.step)"
              :content="formatApprovalContent(item)"
              :time="item.approvalTime ? item.approvalTime.slice(0, 16).replace('T', ' ') : $t('transfer.pendingApproval')"
            />
          </NTimeline>
        </NCard>
      </NGi>

      <NGi>
        <NCard :title="$t('transfer.quickActions')" size="small">
          <NSpace vertical>
            <NButton block type="primary" :disabled="!canSubmit" @click="handleSubmit">{{ $t('transfer.submitApproval') }}</NButton>
            <NButton block type="warning" :disabled="!canApprove" @click="handleApprove">{{ $t('transfer.approvePass') }}</NButton>
            <NButton block type="error" :disabled="!canApprove" @click="handleReject">{{ $t('transfer.rejectApplication') }}</NButton>
            <NButton block type="info" :disabled="!canComplete" @click="handleComplete">{{ $t('transfer.completeTransfer') }}</NButton>
          </NSpace>
        </NCard>
      </NGi>
    </NGrid>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { NCard, NButton, NGrid, NGi, NDescriptions, NDescriptionsItem, NTag, NSpace, NTimeline, NTimelineItem, NEmpty, useMessage } from 'naive-ui'
import { getTransferDetail, submitTransfer, approveTransfer, completeTransfer, cancelTransfer, type Transfer, type TransferApproval } from '~/api/transfer'

const router = useRouter()
const route = useRoute()
const message = useMessage()
const { t } = useI18n()

const id = computed(() => route.params.id as string)
const detail = ref<Partial<Transfer>>({})

const canEdit = computed(() => detail.value.status === 'DRAFT')
const canSubmit = computed(() => detail.value.status === 'DRAFT')
const canApprove = computed(() => detail.value.status === 'SUBMITTED')
const canComplete = computed(() => detail.value.status === 'APPROVED')
const canCancel = computed(() => detail.value.status !== 'COMPLETED')

function formatTransferType(type?: string) {
  const map: Record<string, string> = { INTERNAL: t('transfer.typeInternal'), CROSS_BRANCH: t('transfer.typeCross') }
  return map[type || ''] || type || '-'
}
function formatStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), SUBMITTED: t('status.submitted'), APPROVED: t('status.approved'), COMPLETED: t('status.completed'), CANCELLED: t('status.cancelled') }
  return map[status || ''] || status || '-'
}
function getStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', SUBMITTED: 'warning', APPROVED: 'success', COMPLETED: 'success', CANCELLED: 'error' }
  return map[status || ''] || 'default'
}

function getApprovalTimelineType(status?: string) {
  const map: Record<string, any> = { PENDING: 'default', APPROVED: 'success', REJECTED: 'error', RETURNED: 'warning', CANCELLED: 'error' }
  return map[status || ''] || 'default'
}
function getApprovalStepName(step?: number) {
  const map: Record<number, string> = { 1: t('transfer.stepSourceApprove'), 2: t('transfer.stepTargetConfirm') }
  return map[step || 0] || `${t('transfer.step')} ${step}`
}
function formatApprovalContent(item: TransferApproval) {
  let content = `${t('transfer.approver')}：${item.approverName || item.approverRole || t('common.pending')}`
  if (item.approvalOpinion) {
    content += ` | ${t('transfer.opinionLabel')}：${item.approvalOpinion}`
  }
  if (item.approvalStatus) {
    content += ` | ${t('transfer.resultLabel')}：${formatApprovalStatus(item.approvalStatus)}`
  }
  return content
}
function formatApprovalStatus(status?: string) {
  const map: Record<string, string> = { PENDING: t('status.pending'), APPROVED: t('transfer.statusPassed'), REJECTED: t('status.rejected'), RETURNED: t('transfer.statusReturned') }
  return map[status || ''] || status || '-'
}

async function loadData() {
  try {
    const res = await getTransferDetail(Number(id.value))
    console.log('[Transfer Detail] API Response:', res.data)
    if (res.data.code === 0) {
      detail.value = res.data.data
      console.log('[Transfer Detail] approvals:', detail.value.approvals)
    } else {
      throw new Error(res.data.message)
    }
  } catch (e: any) {
    console.error('[Transfer Detail] Load error:', e)
    message.error(e.message || t('transfer.loadDetailFailed'))
    detail.value = { id: Number(id.value), status: 'DRAFT', transferNo: `TRF-${id.value}`, collateralName: t('transfer.testCollateral'), sourceWarehouseName: t('transfer.testSourceWarehouse'), targetWarehouseName: t('transfer.testTargetWarehouse') }
  }
}

function handleEdit() {
  router.push(`/transfer/${id.value}?mode=edit`)
}
async function handleSubmit() {
  try {
    const res = await submitTransfer({ id: Number(id.value) })
    if (res.data.code === 0) {
      message.success(t('transfer.submitSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('transfer.submitFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('transfer.submitFailed'))
  }
}
async function handleApprove() {
  try {
    const res = await approveTransfer({ id: Number(id.value), step: 1, approvalStatus: 'APPROVED', approvalOpinion: t('common.agree') })
    if (res.data.code === 0) {
      message.success(t('transfer.approveSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('transfer.approveFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('transfer.approveFailed'))
  }
}
async function handleReject() {
  try {
    const res = await cancelTransfer(Number(id.value))
    if (res.data.code === 0) {
      message.success(t('transfer.rejectSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('transfer.operationFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('transfer.operationFailed'))
  }
}
async function handleComplete() {
  try {
    const res = await completeTransfer(Number(id.value))
    if (res.data.code === 0) {
      message.success(t('transfer.completeSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('transfer.operationFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('transfer.operationFailed'))
  }
}
async function handleCancel() {
  try {
    const res = await cancelTransfer(Number(id.value))
    if (res.data.code === 0) {
      message.success(t('transfer.cancelSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('transfer.operationFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('transfer.operationFailed'))
  }
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.transfer-detail-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.page-subtitle {
  margin: 4px 0 0;
  color: #666;
}
.header-actions {
  display: flex;
  gap: 8px;
}
</style>
