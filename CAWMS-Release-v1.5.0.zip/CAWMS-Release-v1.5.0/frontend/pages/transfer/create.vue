<template>
  <div class="create-transfer-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('transfer.createTitle') }}</h1>
        <p class="page-subtitle">{{ $t('transfer.createSubtitle') }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="handleCancel">{{ $t('common.cancel') }}</NButton>
        <NButton type="primary" :loading="submitting" @click="handleSubmit">{{ $t('transfer.submitApplication') }}</NButton>
      </div>
    </div>

    <NForm ref="formRef" :model="form" :rules="rules" label-placement="left" label-width="140px">
      <NCard :title="$t('transfer.selectAsset')" size="small" class="form-section">
        <NFormItem :label="$t('transfer.warehouseInRecord')" path="warehouseInId">
          <NSelect
            v-model:value="form.warehouseInId"
            :options="warehouseInOptions"
            filterable
            :loading="whInLoading"
            :placeholder="$t('transfer.pleaseSelectAsset')"
            clearable
            @focus="loadWarehouseInOptions"
            @update:value="onWarehouseInChange"
          />
        </NFormItem>
        <NDescriptions v-if="selectedWarehouseIn" label-placement="left" :column="3" bordered size="small" class="asset-preview">
          <NDescriptionsItem :label="$t('transfer.warehouseInNo')">{{ selectedWarehouseIn.whCode || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('transfer.businessDepartment')">{{ selectedWarehouseIn.buName || selectedWarehouseIn.buCode || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('transfer.customerId')">{{ selectedWarehouseIn.customerId || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('transfer.customerName')">{{ selectedWarehouseIn.customerName || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('transfer.collateralType')">{{ selectedWarehouseIn.collateralType || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('transfer.collateralValue')">{{ formatCurrency(selectedWarehouseIn.collateralValue) }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('transfer.creditAgreementNo')">{{ selectedWarehouseIn.creditAgreementNo || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('transfer.intakeType')">{{ selectedWarehouseIn.intakeType || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('common.status')"><NTag type="success">COMPLETED</NTag></NDescriptionsItem>
          <NDescriptionsItem :label="$t('transfer.warehouse')">{{ selectedWarehouseIn.warehouseName || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('transfer.zone')">{{ selectedWarehouseIn.zoneName || '-' }}</NDescriptionsItem>
        </NDescriptions>
      </NCard>

      <NCard :title="$t('transfer.transferInfo')" size="small" class="form-section">
        <div class="form-row">
          <NFormItem :label="$t('transfer.transferType')" path="transferType" style="flex: 1;">
            <NSelect
              v-model:value="form.transferType"
              :options="transferTypeOptions"
              :placeholder="$t('transfer.pleaseSelectTransferType')"
            />
          </NFormItem>
          <NFormItem :label="$t('transfer.targetWarehouse')" path="targetWarehouseId" style="flex: 1;">
            <NSelect
              v-model:value="form.targetWarehouseId"
              :options="warehouseOptions"
              filterable
              :placeholder="$t('transfer.pleaseSelectTargetWarehouse')"
              clearable
            />
          </NFormItem>
        </div>
        <NFormItem :label="$t('transfer.transferReason')" path="transferReason">
          <NInput
            v-model:value="form.transferReason"
            type="textarea"
            :rows="3"
            :placeholder="$t('transfer.pleaseInputTransferReason')"
          />
        </NFormItem>
        <NFormItem :label="$t('common.remark')" path="remarks">
          <NInput
            v-model:value="form.remarks"
            type="textarea"
            :rows="2"
            :placeholder="$t('transfer.pleaseInputRemarks')"
          />
        </NFormItem>
      </NCard>
    </NForm>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { NCard, NButton, NForm, NFormItem, NSelect, NInput, NDescriptions, NDescriptionsItem, NTag, useMessage, type FormInst, type FormRules } from 'naive-ui'
import warehouseInApi from '@/api/warehouse-in'
import warehouseApi from '@/api/warehouse'
import warehouseZoneApi from '@/api/warehouse-zone'
import { useI18n } from 'vue-i18n'
import { createTransfer } from '~/api/transfer'

const router = useRouter()
const message = useMessage()
const { t } = useI18n()

const formRef = ref<FormInst | null>(null)
const submitting = ref(false)
const whInLoading = ref(false)

const form = reactive({
  warehouseInId: null as number | null,
  targetWarehouseId: null as number | null,
  transferType: 'INTERNAL' as 'INTERNAL' | 'CROSS_BRANCH',
  transferReason: '',
  remarks: ''
})

const rules: FormRules = {
  warehouseInId: { required: true, message: t('transfer.pleaseSelectWarehouseIn'), trigger: 'change', type: 'number' },
  targetWarehouseId: { required: true, message: t('transfer.pleaseSelectTargetWarehouse'), trigger: 'change', type: 'number' },
  transferType: { required: true, message: t('transfer.pleaseSelectTransferType'), trigger: 'change' },
  transferReason: { required: true, message: t('transfer.pleaseInputTransferReason'), trigger: 'blur' }
}

const transferTypeOptions = [
  { label: t('transfer.typeInternal'), value: 'INTERNAL' },
  { label: t('transfer.typeCross'), value: 'CROSS_BRANCH' }
]

const warehouseInOptions = ref<{ label: string; value: number; whCode?: string; customerId?: string; customerName: string; collateralType: string; collateralValue: number; creditAgreementNo?: string; intakeType?: string; buName?: string; buCode?: string; warehouseId?: number; zoneId?: number }[]>([])
const warehouseOptions = ref<{ label: string; value: number }[]>([])
const selectedWarehouseIn = ref<any>(null)

const loadWarehouseInOptions = async () => {
  if (warehouseInOptions.value.length > 0) return
  whInLoading.value = true
  try {
    const res = await warehouseInApi.getList({ pageNum: 1, pageSize: 100, status: 'COMPLETED' })
    warehouseInOptions.value = (res.records || []).map((item: any) => ({
      label: `${item.whCode || item.id} - ${item.customerName}`,
      value: Number(item.id),
      whCode: item.whCode,
      customerId: item.customerId,
      customerName: item.customerName,
      collateralType: item.collateralType,
      collateralValue: item.collateralValue,
      creditAgreementNo: item.creditAgreementNo,
      intakeType: item.intakeType,
      buName: item.buName,
      buCode: item.buCode,
      warehouseId: item.warehouseId,
      zoneId: item.zoneId
    }))
  } catch (error) {
    message.error(t('transfer.loadWarehouseInFailed'))
  } finally {
    whInLoading.value = false
  }
}

const loadWarehouseOptions = async () => {
  try {
    const list = await warehouseApi.getAllActive()
    warehouseOptions.value = list.map((item: any) => ({
      label: `${item.warehouseName} (${item.warehouseCode})`,
      value: Number(item.id)
    }))
  } catch (error) {
    message.error(t('transfer.loadWarehouseListFailed'))
  }
}

const onWarehouseInChange = async (value: number) => {
  const option = warehouseInOptions.value.find(o => o.value === value) || null
  if (!option) {
    selectedWarehouseIn.value = null
    return
  }
  selectedWarehouseIn.value = { ...option }
  if (option.warehouseId) {
    try {
      const wh = await warehouseApi.getById(option.warehouseId)
      selectedWarehouseIn.value.warehouseName = wh.warehouseName || '-'
    } catch (e) {
      selectedWarehouseIn.value.warehouseName = '-'
    }
  } else {
    selectedWarehouseIn.value.warehouseName = '-'
  }
  if (option.zoneId) {
    try {
      const zone = await warehouseZoneApi.getById(option.zoneId)
      selectedWarehouseIn.value.zoneName = zone.zoneName || '-'
    } catch (e) {
      selectedWarehouseIn.value.zoneName = '-'
    }
  } else {
    selectedWarehouseIn.value.zoneName = '-'
  }
}

const formatCurrency = (value?: number) => {
  if (value == null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

const handleCancel = () => {
  router.push('/transfer')
}

const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    submitting.value = true
    console.log('[Transfer Create] submitting with data:', {
      warehouseInId: form.warehouseInId,
      targetWarehouseId: form.targetWarehouseId,
      transferType: form.transferType
    })

    const res = await createTransfer({
      warehouseInId: form.warehouseInId!,
      targetWarehouseId: form.targetWarehouseId!,
      transferType: form.transferType,
      transferReason: form.transferReason,
      remarks: form.remarks
    })

    console.log('[Transfer Create] response:', res.data)

    if (res.data.code === 0) {
      message.success(t('transfer.createSuccess'))
      router.push('/transfer')
    } else {
      message.error(res.data.message || t('transfer.createFailed'))
    }
  } catch (error: any) {
    if (error?.message === 'validation failed') {
      console.warn('[Transfer Create] validation failed')
      return
    }
    const backendMsg = error?.response?.data?.message
    const msg = backendMsg || error?.message || t('common.unknownError')
    console.error('[Transfer Create] error:', error?.response?.data || error)
    message.error(t('transfer.createFailed') + ': ' + msg)
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  loadWarehouseInOptions()
  loadWarehouseOptions()
})
</script>

<style scoped>
.create-transfer-page {
  padding: 24px;
  max-width: 1200px;
  margin: 0 auto;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.header-content {
  flex: 1;
}

.page-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
  margin: 0;
}

.page-subtitle {
  color: #666;
  margin-top: 4px;
  margin-bottom: 0;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.form-section {
  margin-bottom: 24px;
}

.form-row {
  display: flex;
  gap: 24px;
}

.asset-preview {
  margin-top: 12px;
}

:deep(.n-descriptions-table-content) {
  font-size: 14px;
}

:deep(.n-descriptions-header) {
  font-weight: 600;
}
</style>
