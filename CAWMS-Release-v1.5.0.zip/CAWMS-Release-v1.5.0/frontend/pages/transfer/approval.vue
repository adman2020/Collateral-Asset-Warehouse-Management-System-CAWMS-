<template>
  <div class="transfer-approval-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('transfer.approvalTitle') }}</h1>
        <p class="page-subtitle">
          {{ $t('transfer.transferNo') }}: {{ detail.transferCode || detail.id }} | {{ $t('transfer.collateralName') }}: {{ detail.collateralName }} | {{ $t('transfer.status') }}: {{ formatStatus(detail.status) }}
        </p>
      </div>
      <div class="header-actions">
        <NButton @click="router.back()">{{ $t('common.back') }}</NButton>
        <NButton type="info" @click="router.push(`/transfer/${id}`)">{{ $t('transfer.viewDetail') }}</NButton>
      </div>
    </div>

    <NGrid :cols="3" :x-gap="16" :y-gap="16">
      <NGi :span="2">
        <NCard :title="$t('transfer.approvalProgress')" size="small" class="progress-card">
          <NSteps :current="currentStep" status="process">
            <NStep :title="$t('transfer.stepSubmit')" :description="submitDesc" />
            <NStep :title="$t('transfer.stepSourceApprove')" :description="stepDesc($t('transfer.stepSourceApprove'))" />
            <NStep :title="$t('transfer.stepTargetConfirm')" :description="stepDesc($t('transfer.stepTargetConfirm'))" />
          </NSteps>
        </NCard>

        <NCard :title="$t('transfer.approvalAction')" size="small" class="approval-card">
          <NForm ref="formRef" :model="form" :rules="rules" label-placement="left" label-width="100px">
            <NFormItem :label="$t('transfer.approvalResult')" path="result">
              <NRadioGroup v-model:value="form.result">
                <NSpace>
                  <NRadio value="APPROVE">
                    <NTag type="success" size="small">{{ $t('common.agree') }}</NTag>
                  </NRadio>
                  <NRadio value="REJECT">
                    <NTag type="error" size="small">{{ $t('common.reject') }}</NTag>
                  </NRadio>
                </NSpace>
              </NRadioGroup>
            </NFormItem>
            <NFormItem :label="$t('transfer.approvalComment')" path="comment">
              <NInput v-model:value="form.comment" type="textarea" :rows="3" :placeholder="$t('transfer.pleaseInputApprovalComment')" />
            </NFormItem>
          </NForm>
          <NSpace justify="end">
            <NButton :loading="submitting" type="primary" @click="handleSubmit">{{ $t('transfer.submitApproval') }}</NButton>
          </NSpace>
        </NCard>
      </NGi>

      <NGi>
        <NCard :title="$t('transfer.applicationInfo')" size="small">
          <NDescriptions :column="1" bordered size="small">
            <NDescriptionsItem :label="$t('transfer.warehouseInNo')">{{ detail.warehouseInCode || detail.id || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.collateralName')">{{ detail.collateralName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.collateralType')">{{ detail.collateralType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.sourceWarehouse')">{{ detail.sourceWarehouse || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.targetWarehouse')">{{ detail.targetWarehouse || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.transferType')">{{ detail.transferType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('transfer.status')">
              <NTag :type="getStatusType(detail.status)">{{ formatStatus(detail.status) }}</NTag>
            </NDescriptionsItem>
          </NDescriptions>
        </NCard>

        <NCard :title="$t('transfer.approvalHistory')" size="small" class="history-card">
          <NEmpty v-if="history.length === 0" :description="$t('transfer.noRecords')" />
          <NTimeline v-else>
            <NTimelineItem
              v-for="h in history"
              :key="h.id"
              :title="h.operationType"
              :content="`${h.operatorName || $t('common.system')}：${h.operationDesc || $t('transfer.noOpinion')}`"
              :time="h.operationTime"
            />
          </NTimeline>
        </NCard>
      </NGi>
    </NGrid>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, reactive } from 'vue'
import {
  NCard, NButton, NGrid, NGi, NForm, NFormItem, NInput,
  NRadioGroup, NRadio, NTag, NSpace, NSteps, NStep,
  NDescriptions, NDescriptionsItem, NTimeline, NTimelineItem,
  NEmpty, useMessage, type FormInst, type FormRules
} from 'naive-ui'
import {
  getTransferDetail, getTransferHistory, approveTransfer, cancelTransfer,
  type Transfer, type TransferHistory
} from '~/api/transfer'
import { useAuthStore } from '@/stores/auth'
import { useI18n } from 'vue-i18n'

const router = useRouter()
const route = useRoute()
const message = useMessage()
const authStore = useAuthStore()
const { t } = useI18n()

const id = computed(() => (route.query.id || route.params.id) as string)
const detail = ref<Partial<Transfer>>({})
const history = ref<TransferHistory[]>([])
const submitting = ref(false)

const formRef = ref<FormInst | null>(null)
const form = reactive({
  result: 'APPROVE',
  comment: t('common.agree')
})

const rules: FormRules = {
  result: [{ required: true, message: t('transfer.pleaseSelectApprovalResult'), trigger: 'change' }],
  comment: [{ required: true, message: t('transfer.pleaseInputApprovalComment'), trigger: 'blur' }]
}

const currentStep = computed(() => {
  if (detail.value.status === 'APPROVED' || detail.value.status === 'COMPLETED') {
    return 3
  }
  if (detail.value.status === 'SUBMITTED' && Array.isArray((detail.value as any).approvals) && (detail.value as any).approvals.length > 0) {
    const pending = (detail.value as any).approvals.find((a: any) => a.status === 'PENDING' || a.approvalStatus === 'PENDING')
    if (pending && typeof pending.step === 'number') {
      return pending.step + 1
    }
  }
  return 1
})

const submitDesc = computed(() => {
  const d = detail.value as any
  return d.submittedAt || d.createdAt ? `${t('transfer.submittedAt')} ${d.submittedAt || d.createdAt}` : t('transfer.pendingSubmit')
})

function stepDesc(stepName: string) {
  const rec = history.value.find(h => h.operationDesc?.includes(stepName))
  return rec ? `${rec.operatorName || t('common.system')}: ${rec.operationDesc || t('transfer.noOpinion')}` : t('transfer.pendingApproval')
}

function formatStatus(status?: string) {
  const map: Record<string, string> = {
    DRAFT: t('status.draft'),
    SUBMITTED: t('status.submitted'),
    IN_REVIEW: t('status.inReview'),
    APPROVED: t('transfer.statusPassed'),
    REJECTED: t('status.rejected'),
    COMPLETED: t('status.completed')
  }
  return map[status || ''] || status || '-'
}

function getStatusType(status?: string) {
  const map: Record<string, any> = {
    DRAFT: 'default',
    SUBMITTED: 'info',
    IN_REVIEW: 'warning',
    APPROVED: 'success',
    REJECTED: 'error',
    COMPLETED: 'success'
  }
  return map[status || ''] || 'default'
}

async function loadData() {
  if (!id.value || id.value === 'undefined') {
    message.error(t('transfer.missingApprovalId'))
    router.push('/transfer')
    return
  }
  try {
    const detailRes = await getTransferDetail(Number(id.value))
    const historyRes = await getTransferHistory(Number(id.value))
    detail.value = detailRes.data.data
    history.value = historyRes.data.data || []
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
    detail.value = {
      id: id.value,
      transferCode: id.value,
      collateralName: t('transfer.testCollateral'),
      collateralType: t('transfer.movableProperty'),
      sourceWarehouse: t('transfer.testSourceWarehouse'),
      targetWarehouse: t('transfer.testTargetWarehouse'),
      transferType: t('transfer.normalTransfer'),
      status: 'SUBMITTED',
      approvals: [{ step: 1, status: 'PENDING' }]
    } as any
    history.value = []
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    if (form.result === 'APPROVE') {
      const res = await approveTransfer({
        id: Number(id.value),
        step: 1,
        approvalStatus: 'APPROVED',
        approvalOpinion: form.comment
      })
      if (res.data.code !== 0) throw new Error(res.data.message)
      message.success(t('transfer.approveSuccess'))
    } else if (form.result === 'REJECT') {
      const res = await cancelTransfer(Number(id.value))
      if (res.data.code !== 0) throw new Error(res.data.message)
      message.success(t('transfer.rejectSuccess'))
    }
    router.push('/transfer')
  } catch (e: any) {
    message.error(e.message || t('transfer.submitFailed'))
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.transfer-approval-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.progress-card,
.approval-card,
.history-card {
  margin-bottom: 16px;
}
</style>
