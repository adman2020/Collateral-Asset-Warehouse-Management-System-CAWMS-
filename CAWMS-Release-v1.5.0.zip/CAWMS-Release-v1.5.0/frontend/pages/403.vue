<template>
  <div class="forbidden-page">
    <div class="forbidden-content">
      <div class="forbidden-icon">
        <NIcon size="120" color="#f5222d"><LockClosedOutline /></NIcon>
      </div>
      <h1>403 无权访问</h1>
      <p>抱歉，您没有权限访问此页面。如需帮助，请联系管理员。</p>
      <NButton type="primary" size="large" @click="navigateTo('/')">返回首页</NButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { NButton, NIcon } from 'naive-ui'
import { LockClosedOutline } from '@vicons/ionicons5'

definePageMeta({
  layout: 'auth'
})
</script>

<style scoped>
.forbidden-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  padding: 24px;
}

.forbidden-content {
  text-align: center;
  max-width: 400px;
}

.forbidden-content h1 {
  font-size: 28px;
  margin: 16px 0 8px;
  color: #1f2937;
}

.forbidden-content p {
  color: #6b7280;
  margin-bottom: 24px;
}
</style>
