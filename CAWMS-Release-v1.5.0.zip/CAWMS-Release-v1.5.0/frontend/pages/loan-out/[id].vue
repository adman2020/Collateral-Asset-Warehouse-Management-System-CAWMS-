<template>
  <div class="loan-out-detail-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('loanOut.detailTitle') }}</h1>
        <p class="page-subtitle">{{ $t('loanOut.detailSubtitle') }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="router.back()">{{ $t('common.back') }}</NButton>
        <NButton :disabled="!canEdit" @click="handleEdit">{{ $t('loanOut.edit') }}</NButton>
        <NButton type="primary" :disabled="!canSubmit" @click="handleSubmit">{{ $t('loanOut.submit') }}</NButton>
        <NButton type="warning" :disabled="!canApprove" @click="showApproveDialog = true">{{ $t('loanOut.approve') }}</NButton>
        <NButton type="info" :disabled="!canConfirm" @click="handleConfirm">{{ $t('loanOut.confirmLoan') }}</NButton>
        <NButton type="success" :disabled="!canReturn" @click="showReturnDialog = true">{{ $t('loanOut.return') }}</NButton>
        <NButton type="error" :disabled="!canDelete" @click="handleDelete">{{ $t('loanOut.delete') }}</NButton>
      </div>
    </div>

    <NGrid :cols="3" :x-gap="16" :y-gap="16">
      <NGi :span="2">
        <NCard :title="$t('loanOut.basicInfo')" size="small">
          <NDescriptions :column="2" bordered size="small">
            <NDescriptionsItem :label="$t('loanOut.loanCode')">{{ detail.loanCode || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.whCode')">{{ detail.whCode || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.customerName')">{{ detail.customerName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.collateralType')">{{ detail.collateralType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.collateralValue')">{{ formatCurrency(detail.collateralValue) }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.deptLabel')">{{ detail.buName || detail.buCode || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.loanPurpose')">{{ detail.loanPurpose || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.loanDurationLabel')">{{ detail.loanDuration ? detail.loanDuration + ' ' + $t('loanOut.monthSuffix') : '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.expectedReturnDate')">{{ detail.expectedReturnDate || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.actualReturnDate')">{{ detail.actualReturnDate || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.status')">
              <NTag :type="getStatusType(detail.status)">{{ formatStatus(detail.status) }}</NTag>
            </NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.t24Sync')">{{ detail.t24SyncStatus || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.overdueStatus')">
              <NTag v-if="detail.overdue" type="error">{{ $t('loanOut.overdue') }}</NTag>
              <span v-else-if="detail.remainingDays !== undefined && detail.remainingDays !== null">{{ $t('loanOut.remainingDays', { n: detail.remainingDays }) }}</span>
              <span v-else>-</span>
            </NDescriptionsItem>
            <NDescriptionsItem :label="$t('loanOut.remark')" :span="2">{{ detail.remarks || '-' }}</NDescriptionsItem>
          </NDescriptions>
        </NCard>

        <NCard :title="$t('loanOut.loanApprovalHistory')" size="small" class="history-card">
          <NEmpty v-if="!detail.approvals?.length" :description="$t('loanOut.noLoanApprovalRecords')" />
          <NTimeline v-else>
            <NTimelineItem
              v-for="item in detail.approvals"
              :key="item.id"
              :type="getApprovalTimelineType(item.status)"
              :title="item.stepName || getApprovalStepName(item.stepNumber)"
              :content="formatApprovalContent(item)"
              :time="formatApprovalTime(item.approvedAt)"
            />
          </NTimeline>
        </NCard>

        <NCard :title="$t('loanOut.returnApprovalHistory')" size="small" class="history-card">
          <NEmpty v-if="!detail.returnApprovals?.length" :description="$t('loanOut.noReturnApprovalRecords')" />
          <NTimeline v-else>
            <NTimelineItem
              v-for="item in detail.returnApprovals"
              :key="item.id"
              :type="getApprovalTimelineType(item.status)"
              :title="item.stepName || getReturnStepName(item.stepNumber)"
              :content="formatReturnApprovalContent(item)"
              :time="formatApprovalTime(item.approvedAt)"
            />
          </NTimeline>
        </NCard>
      </NGi>

      <NGi>
        <NCard :title="$t('loanOut.quickActions')" size="small">
          <NSpace vertical>
            <NButton block type="primary" :disabled="!canSubmit" @click="handleSubmit">{{ $t('loanOut.submitApprovalBtn') }}</NButton>
            <NButton block type="warning" :disabled="!canApprove" @click="showApproveDialog = true">{{ $t('loanOut.approvePass') }}</NButton>
            <NButton block type="error" :disabled="!canApprove" @click="handleReject">{{ $t('loanOut.rejectApply') }}</NButton>
            <NButton block type="info" :disabled="!canConfirm" @click="handleConfirm">{{ $t('loanOut.confirmLoan') }}</NButton>
            <NButton block type="success" :disabled="!canReturn" @click="showReturnDialog = true">{{ $t('loanOut.returnAsset') }}</NButton>
            <NButton block :disabled="detail.status !== 'LOANED'" @click="handleSyncT24">{{ $t('loanOut.syncT24') }}</NButton>
          </NSpace>
        </NCard>
      </NGi>
    </NGrid>

    <NModal v-model:show="showApproveDialog" :title="$t('loanOut.approveTitle')" preset="dialog" :positive-text="approving ? $t('loanOut.submitting') : $t('loanOut.confirm')" :negative-text="$t('loanOut.cancel')" :positive-button-props="{ loading: approving }" @positive-click="doApprove">
      <NInput v-model:value="approveComments" type="textarea" :placeholder="$t('loanOut.pleaseInputApproveComment')" />
    </NModal>

    <NModal v-model:show="showReturnDialog" :title="$t('loanOut.returnAssetTitle')" preset="dialog" :positive-text="$t('loanOut.confirmReturn')" :negative-text="$t('loanOut.cancel')" @positive-click="doReturn">
      <NDatePicker v-model:formatted-value="returnDate" value-format="yyyy-MM-dd" type="date" :placeholder="$t('loanOut.pleaseSelectActualReturnDate')" style="width: 100%; margin-bottom: 12px" />
      <NInput v-model:value="returnRemarks" type="textarea" :placeholder="$t('loanOut.pleaseInputReturnRemark')" />
    </NModal>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { NCard, NButton, NGrid, NGi, NDescriptions, NDescriptionsItem, NTag, NSpace, NModal, NInput, NDatePicker, NTimeline, NTimelineItem, NEmpty, useMessage, useDialog } from 'naive-ui'
import loanOutApi, { type LoanOutItem } from '@/api/loan-out'

const { t } = useI18n()
const router = useRouter()
const route = useRoute()
const message = useMessage()
const dialog = useDialog()

const id = computed(() => route.params.id as string)
const detail = ref<Partial<LoanOutItem>>({})

const showApproveDialog = ref(false)
const showReturnDialog = ref(false)
const approving = ref(false)
const approveComments = ref(t('loanOut.approveCommentsDefault'))
const returnDate = ref(new Date().toISOString().split('T')[0])
const returnRemarks = ref(t('loanOut.normalReturn'))

const canEdit = computed(() => ['DRAFT', 'REJECTED'].includes(detail.value.status || ''))
const canSubmit = computed(() => detail.value.status === 'DRAFT')
const canApprove = computed(() => ['PENDING'].includes(detail.value.status || ''))
const canConfirm = computed(() => detail.value.status === 'APPROVED')
const canReturn = computed(() => detail.value.status === 'LOANED')
const canDelete = computed(() => ['DRAFT', 'REJECTED'].includes(detail.value.status || ''))

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}
function formatStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), PENDING: t('status.pending'), APPROVED: t('status.approved'), LOANED: t('status.loaned'), RETURNED: t('status.returned'), REJECTED: t('status.rejected') }
  return map[status || ''] || status || '-'
}
function getStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', PENDING: 'warning', APPROVED: 'success', LOANED: 'info', RETURNED: 'success', REJECTED: 'error' }
  return map[status || ''] || 'default'
}

function getApprovalTimelineType(status?: string) {
  const map: Record<string, any> = { PENDING: 'default', APPROVED: 'success', REJECTED: 'error', RETURNED: 'warning', CANCELLED: 'error', WAITING: 'info' }
  return map[status || ''] || 'default'
}
function getApprovalStepName(step?: number) {
  const map: Record<number, string> = { 1: t('loanOut.stepSubmitApproval'), 2: t('loanOut.stepApprovalProcess'), 3: t('loanOut.stepConfirmLoan') }
  return map[step || 0] || t('loanOut.stepN', { n: step })
}
function getReturnStepName(step?: number) {
  const map: Record<number, string> = { 1: t('loanOut.stepApplyReturn'), 2: t('loanOut.stepWarehouseConfirm'), 3: t('loanOut.stepFinanceSettlement'), 4: t('loanOut.stepCompleteReturn') }
  return map[step || 0] || t('loanOut.stepN', { n: step })
}
function formatApprovalContent(item: any) {
  let content = `${t('loanOut.approver')}：${item.approverName || item.approverUser || item.approverRole || t('loanOut.pendingApprover')}`
  if (item.comments) {
    content += ` | ${t('loanOut.comment')}：${item.comments}`
  }
  if (item.status) {
    const statusMap: Record<string, string> = { PENDING: t('loanOut.pendingApproval'), APPROVED: t('loanOut.approvedStatus'), REJECTED: t('loanOut.rejectedStatus'), RETURNED: t('loanOut.returnedStatus'), CANCELLED: t('loanOut.cancelled'), WAITING: t('loanOut.waiting') }
    content += ` | ${t('loanOut.statusLabel')}：${statusMap[item.status] || item.status}`
  }
  return content
}
function formatReturnApprovalContent(item: any) {
  let content = `${t('loanOut.approver')}：${item.approverName || item.approverUser || item.approverRole || t('loanOut.pendingApprover')}`
  if (item.comments) {
    content += ` | ${t('loanOut.comment')}：${item.comments}`
  }
  if (item.assetCondition) {
    content += ` | ${t('loanOut.assetCondition')}：${item.assetCondition}`
  }
  if (item.settlementAmount) {
    content += ` | ${t('loanOut.settlementAmount')}：${item.settlementAmount}`
  }
  if (item.status) {
    const statusMap: Record<string, string> = { PENDING: t('loanOut.pendingApproval'), APPROVED: t('loanOut.approvedStatus'), REJECTED: t('loanOut.rejectedStatus'), RETURNED: t('loanOut.returnedStatus'), CANCELLED: t('loanOut.cancelled'), WAITING: t('loanOut.waiting') }
    content += ` | ${t('loanOut.statusLabel')}：${statusMap[item.status] || item.status}`
  }
  return content
}
function formatApprovalTime(time?: string) {
  if (!time) return t('loanOut.pendingApproval')
  return time.slice(0, 16).replace('T', ' ')
}

async function loadData() {
  try {
    detail.value = await loanOutApi.getDetail(id.value)
  } catch (e: any) {
    message.error(e.message || t('loanOut.loadDetailFailed'))
    detail.value = { id: id.value, status: 'DRAFT', loanCode: `LO-MOCK-${id.value}`, customerName: t('loanOut.testCustomer'), collateralType: 'REAL_ESTATE', collateralValue: 800000, loanPurpose: t('loanOut.purposeBusiness'), loanDuration: 12, whCode: 'WH-001' }
  }
}

function handleEdit() {
  router.push(`/loan-out/${id.value}?mode=edit`)
}
async function handleSubmit() {
  try {
    await loanOutApi.submit(id.value, { comments: t('loanOut.submitApproval') })
    message.success(t('loanOut.submitSuccess'))
    loadData()
  } catch (e: any) {
    message.error(e.message || t('loanOut.submitFailed'))
  }
}
async function doApprove() {
  approving.value = true
  try {
    await loanOutApi.approve(id.value, approveComments.value)
    message.success(t('loanOut.approveSuccess'))
    showApproveDialog.value = false
    await loadData()
  } catch (e: any) {
    message.error(e.message || t('loanOut.approveFailed'))
  } finally {
    approving.value = false
  }
}
async function handleReject() {
  dialog.create({
    title: t('loanOut.rejectTitle'),
    content: () => h('div', {}, t('loanOut.rejectConfirmContent')),
    positiveText: t('loanOut.confirmReject'),
    negativeText: t('loanOut.cancel'),
    onPositiveClick: async () => {
      try {
        await loanOutApi.reject(id.value, t('loanOut.rejectReason'))
        message.success(t('loanOut.rejected'))
        loadData()
      } catch (e: any) {
        message.error(e.message || t('loanOut.operationFailed'))
      }
    }
  })
}
async function handleConfirm() {
  try {
    await loanOutApi.confirm(id.value)
    message.success(t('loanOut.confirmLoanSuccess'))
    loadData()
  } catch (e: any) {
    message.error(e.message || t('loanOut.confirmFailed'))
  }
}
async function doReturn() {
  try {
    await loanOutApi.returnCollateral(id.value, returnDate.value || new Date().toISOString().split('T')[0], returnRemarks.value)
    message.success(t('loanOut.returnSuccess'))
    showReturnDialog.value = false
    loadData()
  } catch (e: any) {
    message.error(e.message || t('loanOut.returnFailed'))
  }
}
async function handleSyncT24() {
  try {
    await loanOutApi.syncT24(id.value)
    message.success(t('loanOut.t24SyncTriggered'))
    loadData()
  } catch (e: any) {
    message.error(e.message || t('loanOut.syncFailed'))
  }
}
function handleDelete() {
  dialog.warning({
    title: t('loanOut.deleteTitle'),
    content: t('loanOut.deleteConfirmContentDetail'),
    positiveText: t('loanOut.delete'),
    negativeText: t('loanOut.cancel'),
    onPositiveClick: async () => {
      try {
        await loanOutApi.delete(id.value)
        message.success(t('loanOut.deleteSuccess'))
        router.push('/loan-out')
      } catch (e: any) {
        message.error(e.message || t('loanOut.deleteFailed'))
      }
    }
  })
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.loan-out-detail-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.history-card {
  margin-top: 16px;
}
</style>
