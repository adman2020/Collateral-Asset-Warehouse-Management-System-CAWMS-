<template>
  <div class="loan-out-overdue-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('loanOut.overdueQuery') }}</h1>
        <p class="page-subtitle">{{ $t('loanOut.overdueSubtitle') }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="loadData">{{ $t('loanOut.refreshBtn') }}</NButton>
        <NButton type="primary" @click="handleBatchAlert">{{ $t('loanOut.batchAlert') }}</NButton>
      </div>
    </div>

    <NCard size="small">
      <DataTable
        :data="tableData"
        :columns="tableColumns"
        :loading="loading"
        :pagination="pagination"
        @update:page="handlePageChange"
        @update:page-size="handlePageSizeChange"
      >
        <template #status="{ row }">
          <NTag :type="getStatusType(row.status)">{{ formatStatus(row.status) }}</NTag>
        </template>
        <template #overdue="{ row }">
          <NTag type="error">{{ $t('loanOut.overdueDays', { n: row.remainingDays ? Math.abs(row.remainingDays) : '' }) }}</NTag>
        </template>
        <template #actions="{ row }">
          <NSpace size="small">
            <NButton size="small" @click="handleView(row)">{{ $t('loanOut.view') }}</NButton>
            <NButton size="small" type="primary" @click="handleAlert(row)">{{ $t('loanOut.sendReminder') }}</NButton>
          </NSpace>
        </template>
      </DataTable>
    </NCard>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, h, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { NCard, NButton, NTag, NSpace, useMessage } from 'naive-ui'
import DataTable from '@/components/common/DataTable.vue'
import loanOutApi, { type LoanOutItem, type LoanOutPageResult } from '@/api/loan-out'

const { t } = useI18n()
const router = useRouter()
const message = useMessage()

const loading = ref(false)
const tableData = ref<LoanOutItem[]>([])
const totalCount = ref(0)

const pagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  prefix: () => h('span', {}, t('loanOut.totalRecords', { n: totalCount.value }))
})

const tableColumns = computed(() => [
  { title: t('loanOut.loanCode'), key: 'loanCode', width: 140 },
  { title: t('loanOut.customerName'), key: 'customerName', minWidth: 140 },
  { title: t('loanOut.collateralType'), key: 'collateralType', width: 120 },
  { title: t('loanOut.collateralValue'), key: 'collateralValue', width: 140, render: (row: LoanOutItem) => formatCurrency(row.collateralValue) },
  { title: t('loanOut.loanPurpose'), key: 'loanPurpose', width: 120 },
  { title: t('loanOut.expectedReturnDate'), key: 'expectedReturnDate', width: 120 },
  { title: t('loanOut.status'), key: 'status', width: 100, slot: 'status' },
  { title: t('loanOut.overdueDaysLabel'), key: 'overdue', width: 120, slot: 'overdue' },
  { title: t('loanOut.actions'), key: 'actions', width: 180, fixed: 'right', slot: 'actions' }
])

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}
function formatStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), PENDING: t('status.pending'), APPROVED: t('status.approved'), LOANED: t('status.loaned'), RETURNED: t('status.returned'), REJECTED: t('status.rejected') }
  return map[status || ''] || status || '-'
}
function getStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', PENDING: 'warning', APPROVED: 'success', LOANED: 'info', RETURNED: 'success', REJECTED: 'error' }
  return map[status || ''] || 'default'
}

async function loadData() {
  loading.value = true
  try {
    const result: LoanOutPageResult = await loanOutApi.getOverdueList({
      pageNum: pagination.page,
      pageSize: pagination.pageSize
    })
    tableData.value = result.records || []
    totalCount.value = result.total || 0
    pagination.pageCount = result.pages || 1
  } catch (e: any) {
    message.error(e.message || t('loanOut.loadFailed'))
    tableData.value = []
    totalCount.value = 0
  } finally {
    loading.value = false
  }
}

function handlePageChange(page: number) {
  pagination.page = page
  loadData()
}
function handlePageSizeChange(size: number) {
  pagination.pageSize = size
  pagination.page = 1
  loadData()
}
function handleView(row: LoanOutItem) {
  router.push(`/loan-out/${row.id}`)
}
function handleAlert(row: LoanOutItem) {
  message.info(t('loanOut.reminderSentTo', { name: row.customerName }))
}
function handleBatchAlert() {
  message.info(t('loanOut.batchAlertDeveloping'))
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.loan-out-overdue-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
</style>
