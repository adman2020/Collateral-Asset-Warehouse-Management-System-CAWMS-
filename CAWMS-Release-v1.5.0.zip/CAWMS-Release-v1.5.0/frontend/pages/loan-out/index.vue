<template>
  <div class="loan-out-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('loanOut.title') }}</h1>
        <p class="page-subtitle">{{ $t('loanOut.subtitle') }}</p>
      </div>
      <div class="header-actions">
        <NButton type="primary" @click="handleCreate">
          <template #icon><NIcon><AddOutline /></NIcon></template>
          {{ $t('loanOut.createBtn') }}
        </NButton>
        <NButton @click="handleRefresh">
          <template #icon><NIcon><RefreshOutline /></NIcon></template>
          {{ $t('loanOut.refreshBtn') }}
        </NButton>
      </div>
    </div>

    <NCard class="filter-card" size="small">
      <NGrid :cols="4" :x-gap="12" :y-gap="12">
        <NGi>
          <NInput v-model:value="filterParams.customerName" :placeholder="$t('loanOut.customerName')" clearable />
        </NGi>
        <NGi>
          <NSelect v-model:value="filterParams.status" :options="statusOptions" :placeholder="$t('loanOut.status')" clearable />
        </NGi>
        <NGi>
          <NSelect v-model:value="filterParams.buCode" :options="buOptions" :placeholder="$t('loanOut.buCode')" clearable />
        </NGi>
        <NGi>
          <NSelect v-model:value="filterParams.t24SyncStatus" :options="t24Options" :placeholder="$t('loanOut.t24SyncStatus')" clearable />
        </NGi>
        <NGi :span="2">
          <NDatePicker v-model:value="dateRange" type="daterange" clearable :placeholder="$t('loanOut.dateRange')" />
        </NGi>
        <NGi>
          <NSpace>
            <NButton type="primary" @click="loadData">{{ $t('loanOut.search') }}</NButton>
            <NButton @click="handleReset">{{ $t('loanOut.reset') }}</NButton>
          </NSpace>
        </NGi>
      </NGrid>
    </NCard>

    <div class="stats-grid">
      <NCard v-for="s in statCards" :key="s.key" size="small" class="stat-card">
        <div class="stat-value">{{ s.value }}</div>
        <div class="stat-label">{{ s.label }}</div>
      </NCard>
    </div>

    <DataTable
      :data="tableData"
      :columns="tableColumns"
      :loading="loading"
      :pagination="pagination"
      @update:page="handlePageChange"
      @update:page-size="handlePageSizeChange"
    >
      <template #status="{ row }">
        <NTag :type="getStatusType(row.status)">{{ formatStatus(row.status) }}</NTag>
      </template>
      <template #overdue="{ row }">
        <NTag v-if="row.overdue" type="error">{{ $t('loanOut.overdueDays', { n: row.remainingDays ? Math.abs(row.remainingDays) : '' }) }}</NTag>
        <span v-else-if="row.remainingDays !== undefined && row.remainingDays !== null">{{ $t('loanOut.remainingDays', { n: row.remainingDays }) }}</span>
        <span v-else>-</span>
      </template>
      <template #actions="{ row }">
        <NSpace size="small">
          <NButton size="small" @click="handleView(row)">{{ $t('loanOut.view') }}</NButton>
          <NButton size="small" :disabled="!canEdit(row)" @click="handleEdit(row)">{{ $t('loanOut.edit') }}</NButton>
          <NButton size="small" type="primary" :disabled="!canSubmit(row)" @click="handleSubmit(row)">{{ $t('loanOut.submit') }}</NButton>
          <NButton size="small" type="warning" :disabled="!canApprove(row)" :loading="approvingId === row.id" @click="handleApprove(row)">{{ $t('loanOut.approve') }}</NButton>
          <NButton size="small" type="info" :disabled="!canConfirm(row)" @click="handleConfirm(row)">{{ $t('loanOut.confirmLoan') }}</NButton>
          <NButton size="small" type="success" :disabled="!canReturn(row)" @click="handleReturn(row)">{{ $t('loanOut.return') }}</NButton>
          <NButton size="small" type="error" :disabled="!canDelete(row)" @click="handleDelete(row)">{{ $t('loanOut.delete') }}</NButton>
        </NSpace>
      </template>
    </DataTable>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, h } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  NCard, NButton, NIcon, NTag, NInput, NSelect, NDatePicker, NGrid, NGi, NSpace, useMessage, useDialog
} from 'naive-ui'
import { AddOutline, RefreshOutline } from '@vicons/ionicons5'
import DataTable from '@/components/common/DataTable.vue'
import loanOutApi, { type LoanOutItem, type LoanOutPageResult, type LoanOutStats } from '@/api/loan-out'
import { useAuthStore } from '@/stores/auth'

const { t } = useI18n()
const router = useRouter()
const message = useMessage()
const dialog = useDialog()
const authStore = useAuthStore()

definePageMeta({
  middleware: ['auth'],
  layout: 'default',
  meta: { title: '抵押资产借出管理', requiresAuth: true }
})

const filterParams = reactive({
  customerName: '',
  status: null as string | null,
  buCode: null as string | null,
  t24SyncStatus: null as string | null,
  pageNum: 1,
  pageSize: 10
})

const dateRange = ref<[number, number] | null>(null)

const statusOptions = computed(() => [
  { label: t('status.draft'), value: 'DRAFT' },
  { label: t('status.pending'), value: 'PENDING' },
  { label: t('status.approved'), value: 'APPROVED' },
  { label: t('status.loaned'), value: 'LOANED' },
  { label: t('status.returned'), value: 'RETURNED' },
  { label: t('status.rejected'), value: 'REJECTED' }
])

const buOptions = computed(() => [
  { label: t('loanOut.deptRBU'), value: 'RBU' },
  { label: t('loanOut.deptCBU'), value: 'CBU' },
  { label: t('loanOut.deptFMU'), value: 'FMU' },
  { label: t('loanOut.deptRMU'), value: 'RMU' }
])

const t24Options = computed(() => [
  { label: t('loanOut.t24NotSynced'), value: 'NOT_SYNCED' },
  { label: t('loanOut.t24Syncing'), value: 'SYNCING' },
  { label: t('loanOut.t24Synced'), value: 'SYNCED' },
  { label: t('loanOut.t24Failed'), value: 'FAILED' }
])

const loading = ref(false)
const tableData = ref<LoanOutItem[]>([])
const totalCount = ref(0)
const approvingId = ref<string | number | null>(null)

const pagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  prefix: () => h('span', {}, t('loanOut.totalRecords', { n: totalCount.value }))
})

const tableColumns = computed(() => [
  { title: t('loanOut.id'), key: 'id', width: 80 },
  { title: t('loanOut.whCode'), key: 'whCode', width: 140 },
  { title: t('loanOut.customerName'), key: 'customerName', minWidth: 140 },
  { title: t('loanOut.collateralType'), key: 'collateralType', width: 120 },
  { title: t('loanOut.collateralValue'), key: 'collateralValue', width: 140, render: (row: LoanOutItem) => formatCurrency(row.collateralValue) },
  { title: t('loanOut.loanPurpose'), key: 'loanPurpose', width: 120 },
  { title: t('loanOut.loanDuration'), key: 'loanDuration', width: 110 },
  { title: t('loanOut.expectedReturnDate'), key: 'expectedReturnDate', width: 120 },
  { title: t('loanOut.status'), key: 'status', width: 100, slot: 'status' },
  { title: t('loanOut.overdueRemaining'), key: 'overdue', width: 120, slot: 'overdue' },
  { title: t('loanOut.actions'), key: 'actions', width: 360, fixed: 'right', slot: 'actions' }
])

const stats = reactive<Partial<LoanOutStats>>({})
const statCards = computed(() => [
  { key: 'total', label: t('loanOut.statTotal'), value: stats.totalCount || 0 },
  { key: 'loaned', label: t('loanOut.statLoaned'), value: stats.loanedCount || 0 },
  { key: 'overdue', label: t('loanOut.statOverdue'), value: stats.overdueCount || 0 },
  { key: 'expiring', label: t('loanOut.statExpiring'), value: stats.expiringLoans || 0 }
])

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

function formatStatus(status?: string) {
  const map: Record<string, string> = {
    DRAFT: t('status.draft'),
    PENDING: t('status.pending'),
    APPROVED: t('status.approved'),
    LOANED: t('status.loaned'),
    RETURNED: t('status.returned'),
    REJECTED: t('status.rejected')
  }
  return map[status || ''] || status || '-'
}

function getStatusType(status?: string) {
  const map: Record<string, any> = {
    DRAFT: 'default',
    PENDING: 'warning',
    APPROVED: 'success',
    LOANED: 'info',
    RETURNED: 'success',
    REJECTED: 'error'
  }
  return map[status || ''] || 'default'
}

function canEdit(row: LoanOutItem) {
  return ['DRAFT', 'REJECTED'].includes(row.status)
}
function canSubmit(row: LoanOutItem) {
  return row.status === 'DRAFT'
}
function canApprove(row: LoanOutItem) {
  return ['PENDING'].includes(row.status) && approvingId.value !== row.id
}
function canConfirm(row: LoanOutItem) {
  return row.status === 'APPROVED'
}
function canReturn(row: LoanOutItem) {
  return row.status === 'LOANED'
}
function canDelete(row: LoanOutItem) {
  return ['DRAFT', 'REJECTED'].includes(row.status)
}

async function loadData() {
  loading.value = true
  try {
    const params: any = {
      ...filterParams,
      pageNum: pagination.page,
      pageSize: pagination.pageSize
    }
    if (dateRange.value) {
      params.startDate = new Date(dateRange.value[0]).toISOString().split('T')[0]
      params.endDate = new Date(dateRange.value[1]).toISOString().split('T')[0]
    }
    const result: LoanOutPageResult = await loanOutApi.getList(params)
    tableData.value = result.records || []
    totalCount.value = result.total || 0
    pagination.pageCount = result.pages || 1

    const statResult = await loanOutApi.getStatistics()
    Object.assign(stats, statResult)
  } catch (e: any) {
    console.warn(t('loanOut.apiLoadFailed'), e)
    const mock = generateMockData()
    tableData.value = mock
    totalCount.value = mock.length
    pagination.pageCount = 1
    Object.assign(stats, { totalCount: 86, loanedCount: 42, overdueCount: 5, expiringLoans: 8 })
  } finally {
    loading.value = false
  }
}

function generateMockData(): LoanOutItem[] {
  return Array.from({ length: 12 }).map((_, i) => ({
    id: i + 1,
    loanCode: `LO-2024-${String(i + 1).padStart(4, '0')}`,
    whInId: 100 + i,
    whCode: `WH-2024-${String(i + 1).padStart(4, '0')}`,
    customerName: t('loanOut.mockCustomer', { letter: String.fromCharCode(65 + i) }),
    collateralType: ['REAL_ESTATE', 'MOVABLE', 'RIGHTS', 'MARGIN'][i % 4],
    collateralValue: 800000 + i * 30000,
    loanPurpose: [t('loanOut.purposeBusiness'), t('loanOut.purposeProject'), t('loanOut.purposeConsumer'), t('loanOut.purposeSupplyChain')][i % 4],
    loanDuration: [6, 12, 24, 36][i % 4],
    expectedReturnDate: new Date(Date.now() + (30 - i) * 86400000).toISOString().split('T')[0],
    status: ['DRAFT', 'PENDING', 'APPROVED', 'LOANED', 'RETURNED'][i % 5],
    overdue: i % 5 === 3 && i > 8,
    remainingDays: i % 5 === 3 ? (i > 8 ? -3 : 15) : 30 - i,
    t24SyncStatus: ['NOT_SYNCED', 'SYNCED'][i % 2]
  }))
}

function handlePageChange(page: number) {
  pagination.page = page
  loadData()
}
function handlePageSizeChange(size: number) {
  pagination.pageSize = size
  pagination.page = 1
  loadData()
}
function handleReset() {
  filterParams.customerName = ''
  filterParams.status = null
  filterParams.buCode = null
  filterParams.t24SyncStatus = null
  dateRange.value = null
  pagination.page = 1
  loadData()
}
function handleRefresh() {
  loadData()
}
function handleCreate() {
  router.push('/loan-out/create')
}
function handleView(row: LoanOutItem) {
  router.push(`/loan-out/${row.id}`)
}
function handleEdit(row: LoanOutItem) {
  router.push(`/loan-out/${row.id}?mode=edit`)
}
async function handleSubmit(row: LoanOutItem) {
  try {
    await loanOutApi.submit(row.id, { comments: t('loanOut.submitApproval') })
    message.success(t('loanOut.submitSuccess'))
    loadData()
  } catch (e: any) {
    message.error(e.message || t('loanOut.submitFailed'))
  }
}
function handleApprove(row: LoanOutItem) {
  dialog.create({
    title: t('loanOut.approveTitle'),
    content: () => h('div', {}, t('loanOut.approveConfirmContent', { code: row.loanCode || row.id })),
    positiveText: t('loanOut.confirm'),
    negativeText: t('loanOut.cancel'),
    onPositiveClick: async () => {
      approvingId.value = row.id
      try {
        await loanOutApi.approve(row.id, t('loanOut.approveCommentsDefault'))
        message.success(t('loanOut.approveSuccess'))
        await loadData()
      } catch (e: any) {
        message.error(e.message || t('loanOut.approveFailed'))
      } finally {
        approvingId.value = null
      }
    }
  })
}
async function handleConfirm(row: LoanOutItem) {
  try {
    await loanOutApi.confirm(row.id)
    message.success(t('loanOut.confirmLoanSuccess'))
    loadData()
  } catch (e: any) {
    message.error(e.message || t('loanOut.confirmFailed'))
  }
}
function handleReturn(row: LoanOutItem) {
  dialog.create({
    title: t('loanOut.returnTitle'),
    content: () => h('div', {}, t('loanOut.returnConfirmContent', { code: row.loanCode || row.id })),
    positiveText: t('loanOut.confirmReturn'),
    negativeText: t('loanOut.cancel'),
    onPositiveClick: async () => {
      try {
        const today = new Date().toISOString().split('T')[0]
        await loanOutApi.returnCollateral(row.id, today, t('loanOut.normalReturn'))
        message.success(t('loanOut.returnSuccess'))
        loadData()
      } catch (e: any) {
        message.error(e.message || t('loanOut.returnFailed'))
      }
    }
  })
}
function handleDelete(row: LoanOutItem) {
  dialog.warning({
    title: t('loanOut.deleteTitle'),
    content: t('loanOut.deleteConfirmContent', { code: row.loanCode || row.id }),
    positiveText: t('loanOut.delete'),
    negativeText: t('loanOut.cancel'),
    onPositiveClick: async () => {
      try {
        await loanOutApi.delete(row.id)
        message.success(t('loanOut.deleteSuccess'))
        loadData()
      } catch (e: any) {
        message.error(e.message || t('loanOut.deleteFailed'))
      }
    }
  })
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.loan-out-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.page-subtitle {
  font-size: 14px;
  color: var(--text-color-secondary);
  margin: 4px 0 0;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.filter-card {
  margin-bottom: 16px;
}
.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 16px;
}
.stat-card {
  text-align: center;
}
.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #722ed1;
}
.stat-label {
  font-size: 13px;
  color: var(--text-color-secondary);
  margin-top: 4px;
}
@media (max-width: 1200px) {
  .stats-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 768px) {
  .stats-grid { grid-template-columns: 1fr; }
  .page-header { flex-direction: column; align-items: flex-start; gap: 12px; }
}
</style>
