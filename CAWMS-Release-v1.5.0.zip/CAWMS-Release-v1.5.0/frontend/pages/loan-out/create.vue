<template>
  <div class="create-loan-out-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ isEdit ? $t('loanOut.editTitle') : $t('loanOut.newTitle') }}</h1>
        <p class="page-subtitle">{{ $t('loanOut.createSubtitle') }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="handleCancel">{{ $t('common.cancel') }}</NButton>
        <NButton type="info" :loading="saving" @click="handleSaveDraft">{{ $t('loanOut.saveDraft') }}</NButton>
        <NButton type="primary" :loading="submitting" @click="handleSubmit">{{ $t('loanOut.submitApply') }}</NButton>
      </div>
    </div>

    <NCard :title="$t('loanOut.selectWarehouseAsset')" size="small" class="form-section">
      <NFormItem :label="$t('loanOut.warehouseRecord')" :required="true">
        <NSelect
          v-model:value="form.whInId"
          :options="warehouseInOptions"
          filterable
          :loading="whInLoading"
          :render-label="renderWhInLabel"
          :placeholder="$t('loanOut.pleaseSelectWarehouseAsset')"
          clearable
          @focus="loadWarehouseInOptions()"
        />
      </NFormItem>
      <div class="options-hint">
        {{ $t('loanOut.availableRecords') }}: {{ warehouseInOptions.length }}
        <NButton text type="primary" size="tiny" @click="loadWarehouseInOptions()">{{ $t('common.refresh') }}</NButton>
      </div>
      <div v-if="selectedWarehouseIn" class="selected-preview">
        <NTag>{{ $t('loanOut.customerLabel') }}: {{ selectedWarehouseIn.customerName }}</NTag>
        <NTag>{{ $t('loanOut.collateralTypeLabel') }}: {{ selectedWarehouseIn.collateralType }}</NTag>
        <NTag>{{ $t('loanOut.collateralValueLabel') }}: {{ formatCurrency(selectedWarehouseIn.collateralValue) }}</NTag>
        <NTag>{{ $t('loanOut.deptLabel') }}: {{ selectedWarehouseIn.buName || selectedWarehouseIn.buCode }}</NTag>
      </div>
    </NCard>

    <NCard :title="$t('loanOut.loanInfo')" size="small" class="form-section">
      <NForm ref="formRef" :model="form" :rules="rules" label-placement="left" label-width="140px">
        <div class="form-row">
          <NFormItem :label="$t('loanOut.loanPurpose')" path="loanPurpose" style="flex: 1;">
            <NSelect v-model:value="form.loanPurpose" :options="loanPurposeOptions" :placeholder="$t('loanOut.pleaseSelectLoanPurpose')" />
          </NFormItem>
          <NFormItem :label="$t('loanOut.loanDurationMonth')" path="loanDuration" style="flex: 1;">
            <NInputNumber v-model:value="form.loanDuration" :min="1" :max="360" :placeholder="$t('loanOut.pleaseInputLoanDuration')" style="width: 100%" />
          </NFormItem>
        </div>
        <div class="form-row">
          <NFormItem :label="$t('loanOut.expectedReturnDate')" path="expectedReturnDate" style="flex: 1;">
            <NInput v-model:value="form.expectedReturnDate" placeholder="YYYY-MM-DD" />
          </NFormItem>
          <div style="flex: 1;"></div>
        </div>
        <NFormItem :label="$t('loanOut.remark')" path="remarks">
          <NInput v-model:value="form.remarks" type="textarea" :rows="3" :placeholder="$t('loanOut.pleaseInputRemark')" />
        </NFormItem>
      </NForm>
    </NCard>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, h, watch, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { NCard, NButton, NForm, NFormItem, NSelect, NInput, NInputNumber, NTag, useMessage, type FormInst, type FormRules, type SelectOption } from 'naive-ui'
import loanOutApi from '@/api/loan-out'
import warehouseInApi from '@/api/warehouse-in'

const { t } = useI18n()
const router = useRouter()
const route = useRoute()
const message = useMessage()

const isEdit = ref(false)
const editId = ref<string | number>('')

onMounted(() => {
  loadWarehouseInOptions()
  if (route.query.mode === 'edit' && route.params.id) {
    isEdit.value = true
    editId.value = route.params.id as string
    loadDetail(editId.value)
  }
})

async function loadDetail(id: string | number) {
  try {
    const detail = await loanOutApi.getDetail(id)
    Object.assign(form, {
      whInId: detail.whInId,
      loanPurpose: detail.loanPurpose || '',
      loanDuration: detail.loanDuration || 12,
      expectedReturnDate: detail.expectedReturnDate || '',
      remarks: detail.remarks || ''
    })
    if (detail.whInId) {
      const wh = await warehouseInApi.getDetail(detail.whInId)
      selectedWarehouseIn.value = wh.warehouseIn || wh
    }
  } catch (e: any) {
    message.error(e.message || t('loanOut.loadDetailFailed'))
  }
}

const formRef = ref<FormInst | null>(null)
const form = reactive({
  whInId: null as number | null,
  loanPurpose: '',
  loanDuration: 12,
  expectedReturnDate: '',
  remarks: ''
})

const saving = ref(false)
const submitting = ref(false)
const whInLoading = ref(false)
const warehouseInOptions = ref<SelectOption[]>([])
const selectedWarehouseIn = ref<any | null>(null)

const loanPurposeOptions = computed(() => [
  { label: t('loanOut.purposeBusiness'), value: t('loanOut.purposeBusiness') },
  { label: t('loanOut.purposeProject'), value: t('loanOut.purposeProject') },
  { label: t('loanOut.purposeConsumer'), value: t('loanOut.purposeConsumer') },
  { label: t('loanOut.purposeSupplyChain'), value: t('loanOut.purposeSupplyChain') },
  { label: t('loanOut.purposeOther'), value: t('loanOut.purposeOther') }
])

const rules: FormRules = {
  whInId: [{ required: true, type: 'number', message: t('loanOut.pleaseSelectWarehouseAsset'), trigger: 'change' }],
  loanPurpose: [{ required: true, message: t('loanOut.pleaseSelectLoanPurpose'), trigger: 'change' }],
  loanDuration: [{ required: true, type: 'number', min: 1, message: t('loanOut.loanDurationMustGreaterThan0'), trigger: 'blur' }],
  expectedReturnDate: [{ required: true, message: t('loanOut.pleaseSelectExpectedReturnDate'), trigger: 'blur' }]
}

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

function normalizeDate(dateStr: string): string {
  if (!dateStr) return dateStr
  if (/^\d{8}$/.test(dateStr)) {
    return `${dateStr.slice(0, 4)}-${dateStr.slice(4, 6)}-${dateStr.slice(6, 8)}`
  }
  return dateStr
}

async function loadWarehouseInOptions(query?: string) {
  whInLoading.value = true
  try {
    const result = await warehouseInApi.getList({
      keyword: query || undefined,
      status: 'COMPLETED',
      pageNum: 1,
      pageSize: 20
    })
    const records = (result as any).records || (result as any).data?.records || []
    console.log('[loan-out]', t('loanOut.consoleApiRecords'), ':', records.length, t('loanOut.consoleOriginalResult'), ':', result)
    warehouseInOptions.value = records.map((item: any) => ({
      label: `${item.whCode || item.id} - ${item.customerName} - ${item.collateralType}`,
      value: Number(item.id),
      wh: item
    }))
  } catch (e: any) {
    console.error('[loan-out]', t('loanOut.consoleLoadWarehouseFailed'), ':', e)
    message.error(t('loanOut.loadWarehouseRecordsFailed') + ': ' + (e.message || t('loanOut.unknownError')))
  } finally {
    whInLoading.value = false
  }
}

function renderWhInLabel(option: any) {
  return h('div', {}, [
    h('div', { style: { fontWeight: 500 } }, option.wh?.whCode || option.label),
    h('div', { style: { fontSize: '12px', color: '#888' } }, `${option.wh?.customerName} | ${option.wh?.collateralType} | ${formatCurrency(option.wh?.collateralValue)}`)
  ])
}

function handleCancel() {
  router.back()
}

async function handleSaveDraft() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  if (!form.whInId) {
    message.warning(t('loanOut.pleaseSelectWarehouseAsset'))
    return
  }

  saving.value = true
  try {
    if (isEdit.value) {
      await loanOutApi.update(editId.value, { ...form })
      message.success(t('loanOut.updateSuccess'))
    } else {
      await loanOutApi.createDraft({ ...form, whInId: form.whInId, expectedReturnDate: normalizeDate(form.expectedReturnDate) })
      message.success(t('loanOut.draftSaveSuccess'))
    }
    router.push('/loan-out')
  } catch (e: any) {
    message.error(e.message || t('loanOut.saveFailed'))
  } finally {
    saving.value = false
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  if (!form.whInId) {
    message.warning(t('loanOut.pleaseSelectWarehouseAsset'))
    return
  }

  submitting.value = true
  try {
    if (isEdit.value) {
      await loanOutApi.update(editId.value, { ...form })
      await loanOutApi.submit(editId.value, { comments: t('loanOut.submitApproval') })
    } else {
      const created = await loanOutApi.createDraft({ ...form, whInId: form.whInId, expectedReturnDate: normalizeDate(form.expectedReturnDate) })
      await loanOutApi.submit(created.id, { comments: t('loanOut.submitApproval') })
    }
    message.success(t('loanOut.submitSuccessApproval'))
    router.push('/loan-out')
  } catch (e: any) {
    message.error(e.message || t('loanOut.submitFailed'))
  } finally {
    submitting.value = false
  }
}

watch(() => form.whInId, async (id) => {
  if (!id) {
    selectedWarehouseIn.value = null
    return
  }
  try {
    const wh = await warehouseInApi.getDetail(id)
    selectedWarehouseIn.value = wh.warehouseIn || wh
  } catch (e) {
    selectedWarehouseIn.value = null
  }
})
</script>

<style scoped>
.create-loan-out-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.page-subtitle {
  font-size: 14px;
  color: var(--text-color-secondary);
  margin: 4px 0 0;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.form-section {
  margin-bottom: 16px;
}
.form-row {
  display: flex;
  gap: 24px;
}
.options-hint {
  margin-top: 8px;
  font-size: 12px;
  color: #888;
}
.selected-preview {
  margin-top: 12px;
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
</style>
