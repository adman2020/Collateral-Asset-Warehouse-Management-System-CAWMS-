<template>
  <div class="audit-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('system.auditLogs.title') }}</h1>
      <n-button @click="handleExport">{{ $t('system.auditLogs.exportBtn') }}</n-button>
    </div>

    <n-card class="search-card">
      <n-grid :cols="4" :x-gap="16" :y-gap="12">
        <n-gi><n-input v-model:value="searchForm.operation" :placeholder="$t('system.auditLogs.operationPlaceholder')" clearable /></n-gi>
        <n-gi><n-input v-model:value="searchForm.module" :placeholder="$t('system.auditLogs.modulePlaceholder')" clearable /></n-gi>
        <n-gi><n-select v-model:value="searchForm.status" :placeholder="$t('system.auditLogs.statusPlaceholder')" :options="statusOptions" clearable /></n-gi>
        <n-gi><n-button type="primary" block @click="handleSearch">{{ $t('system.auditLogs.search') }}</n-button></n-gi>
      </n-grid>
    </n-card>

    <n-card class="table-card">
      <n-data-table :columns="columns" :data="tableData" :loading="loading" :pagination="pagination" :row-key="(row) => row.id" />
    </n-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, computed, h } from 'vue'
import { useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { DataTableColumns } from 'naive-ui'
import { getAuditLogList, type AuditLog } from '~/api/system'

const { t } = useI18n()
const message = useMessage()
const loading = ref(false)
const tableData = ref<AuditLog[]>([])

const searchForm = reactive({ operation: '', module: '', status: '' })

const pagination = reactive({
  page: 1, pageSize: 10, showSizePicker: true, pageSizes: [10, 20, 50], itemCount: 0,
  onChange: (page: number) => { pagination.page = page; loadTableData() },
  onUpdatePageSize: (pageSize: number) => { pagination.pageSize = pageSize; pagination.page = 1; loadTableData() }
})

const statusOptions = computed(() => [
  { label: t('system.auditLogs.statusSuccess'), value: 'SUCCESS' },
  { label: t('system.auditLogs.statusFailure'), value: 'FAILURE' }
])

const columns = computed<DataTableColumns<AuditLog>>(() => [
  { title: t('system.auditLogs.user'), key: 'userName', width: 100 },
  { title: t('system.auditLogs.operation'), key: 'operation', width: 150 },
  { title: t('system.auditLogs.module'), key: 'module', width: 120 },
  { title: t('system.auditLogs.method'), key: 'method', width: 120 },
  { title: t('system.auditLogs.ipAddress'), key: 'ipAddress', width: 140 },
  { title: t('system.auditLogs.executionTime'), key: 'executionTime', width: 100, render: (row) => `${row.executionTime}ms` },
  {
    title: t('system.auditLogs.status'), key: 'status', width: 100,
    render: (row) => {
      const map: Record<string, any> = { SUCCESS: { type: 'success', label: t('system.auditLogs.statusSuccess') }, FAILURE: { type: 'error', label: t('system.auditLogs.statusFailure') } }
      const s = map[row.status] || { type: 'default', label: row.status }
      return h('n-tag', { type: s.type }, { default: () => s.label })
    }
  },
  { title: t('system.auditLogs.time'), key: 'createTime', width: 160, render: (row) => row.createTime?.slice(0, 16).replace('T', ' ') }
])

const loadTableData = async () => {
  loading.value = true
  try {
    const res = await getAuditLogList({ page: pagination.page, size: pagination.pageSize, ...searchForm })
    tableData.value = res.records || []
    pagination.itemCount = res.total || 0
  } catch (error) { message.error(t('system.auditLogs.loadFailed')) } finally { loading.value = false }
}

const handleSearch = () => { pagination.page = 1; loadTableData() }
const handleExport = () => { message.success(t('system.auditLogs.exportSuccess')) }

onMounted(() => { loadTableData() })
</script>

<style scoped>
.audit-page { padding: 24px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
.page-title { font-size: 24px; font-weight: 600; color: #333; }
.search-card { margin-bottom: 24px; }
.table-card { min-height: 400px; }
</style>
