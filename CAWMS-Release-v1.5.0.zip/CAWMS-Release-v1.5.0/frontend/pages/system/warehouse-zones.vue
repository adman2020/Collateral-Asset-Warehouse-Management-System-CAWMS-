<template>
  <div class="system-page">
    <div class="page-header">
      <h1 class="page-title">{{ t('system.warehouseZone.title') }}</h1>
      <NButton type="primary" @click="handleCreate">{{ t('system.warehouseZone.create') }}</NButton>
    </div>

    <NCard class="search-card" size="small">
      <NGrid :cols="4" :x-gap="12" :y-gap="12">
        <NGi>
          <NInput v-model:value="searchKeyword" :placeholder="t('system.warehouseZone.zoneCode') + '/' + t('system.warehouseZone.zoneName')" clearable />
        </NGi>
        <NGi>
          <NButton type="primary" @click="loadData">{{ t('common.search') }}</NButton>
          <NButton style="margin-left: 8px" @click="searchKeyword = ''; loadData()">{{ t('common.reset') }}</NButton>
        </NGi>
      </NGrid>
    </NCard>

    <NCard class="table-card" size="small">
      <NDataTable
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :pagination="pagination"
        :row-key="(row: any) => row.id"
      />
    </NCard>

    <NModal v-model:show="showModal" :title="isEdit ? t('system.warehouseZone.edit') : t('system.warehouseZone.create')" preset="card" style="width: 600px">
      <NForm ref="formRef" :model="form" :rules="rules" label-placement="left" label-width="100px">
        <NFormItem :label="t('system.warehouseZone.zoneCode')" path="zoneCode">
          <NInput v-model:value="form.zoneCode" :placeholder="t('common.pleaseInput') + t('system.warehouseZone.zoneCode')" />
        </NFormItem>
        <NFormItem :label="t('system.warehouseZone.zoneName')" path="zoneName">
          <NInput v-model:value="form.zoneName" :placeholder="t('common.pleaseInput') + t('system.warehouseZone.zoneName')" />
        </NFormItem>
        <NFormItem :label="t('system.warehouseZone.zoneType')" path="zoneType">
          <NSelect v-model:value="form.zoneType" :options="zoneTypeOptions" :placeholder="t('common.pleaseSelect') + t('system.warehouseZone.zoneType')" />
        </NFormItem>
        <NFormItem :label="t('system.warehouseZone.address')" path="address">
          <NInput v-model:value="form.address" :placeholder="t('common.pleaseInput') + t('system.warehouseZone.address')" />
        </NFormItem>
        <NFormItem :label="t('system.warehouseZone.contactPerson')" path="contactPerson">
          <NInput v-model:value="form.contactPerson" :placeholder="t('common.pleaseInput') + t('system.warehouseZone.contactPerson')" />
        </NFormItem>
        <NFormItem :label="t('system.warehouseZone.contactPhone')" path="contactPhone">
          <NInput v-model:value="form.contactPhone" :placeholder="t('common.pleaseInput') + t('system.warehouseZone.contactPhone')" />
        </NFormItem>
        <NFormItem :label="t('common.status')" path="status">
          <NSelect v-model:value="form.status" :options="statusOptions" :placeholder="t('common.pleaseSelect') + t('common.status')" />
        </NFormItem>
      </NForm>
      <template #footer>
        <NSpace justify="end">
          <NButton @click="showModal = false">{{ t('common.cancel') }}</NButton>
          <NButton type="primary" :loading="saving" @click="handleSave">{{ t('common.save') }}</NButton>
        </NSpace>
      </template>
    </NModal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, h, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  NButton, NCard, NDataTable, NForm, NFormItem, NInput, NModal, NSelect, NSpace, useMessage, type FormInst, type FormRules
} from 'naive-ui'
import type { DataTableColumns } from 'naive-ui'
import warehouseZoneApi, { type WarehouseZoneItem } from '@/api/warehouse-zone'

const { t } = useI18n()

const message = useMessage()
const loading = ref(false)
const tableData = ref<WarehouseZoneItem[]>([])
const searchKeyword = ref('')

const pagination = reactive({
  page: 1,
  pageSize: 10,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  itemCount: 0,
  onChange: (page: number) => { pagination.page = page; loadData() },
  onUpdatePageSize: (pageSize: number) => { pagination.pageSize = pageSize; pagination.page = 1; loadData() }
})

const showModal = ref(false)
const isEdit = ref(false)
const editId = ref<string | number>('')
const formRef = ref<FormInst | null>(null)
const saving = ref(false)
const form = reactive({
  zoneCode: '',
  zoneName: '',
  zoneType: 'SUPERVISED',
  address: '',
  contactPerson: '',
  contactPhone: '',
  status: 'ACTIVE'
})

const zoneTypeOptions = [
  { label: t('system.warehouseZone.zoneTypes.supervised'), value: 'SUPERVISED' },
  { label: t('system.warehouseZone.zoneTypes.selfManaged'), value: 'SELF_MANAGED' }
]

const statusOptions = [
  { label: t('status.active'), value: 'ACTIVE' },
  { label: t('status.inactive'), value: 'INACTIVE' }
]

const rules: FormRules = {
  zoneCode: [{ required: true, message: t('common.pleaseInput') + t('system.warehouseZone.zoneCode'), trigger: 'blur' }],
  zoneName: [{ required: true, message: t('common.pleaseInput') + t('system.warehouseZone.zoneName'), trigger: 'blur' }],
  zoneType: [{ required: true, message: t('common.pleaseSelect') + t('system.warehouseZone.zoneType'), trigger: 'change' }]
}

const columns: DataTableColumns<WarehouseZoneItem> = [
  { title: t('system.warehouseZone.zoneCode'), key: 'zoneCode', width: 140 },
  { title: t('system.warehouseZone.zoneName'), key: 'zoneName', minWidth: 140 },
  {
    title: t('system.warehouseZone.zoneType'),
    key: 'zoneType',
    width: 120,
    render(row) {
      return row.zoneType === 'SUPERVISED' ? t('system.warehouseZone.zoneTypes.supervised') : t('system.warehouseZone.zoneTypes.selfManaged')
    }
  },
  { title: t('system.warehouseZone.address'), key: 'address', minWidth: 180, ellipsis: { tooltip: true } },
  { title: t('system.warehouseZone.contactPerson'), key: 'contactPerson', width: 100 },
  { title: t('system.warehouseZone.contactPhone'), key: 'contactPhone', width: 120 },
  {
    title: t('common.status'),
    key: 'status',
    width: 80,
    render(row) {
      return row.status === 'ACTIVE' ? t('status.active') : t('status.inactive')
    }
  },
  {
    title: t('common.operation'),
    key: 'actions',
    width: 140,
    fixed: 'right',
    render(row) {
      return h(NSpace, { size: 'small' }, () => [
        h(NButton, { size: 'small', onClick: () => handleEdit(row) }, () => t('common.edit')),
        h(NButton, { size: 'small', type: 'error', onClick: () => handleDelete(row) }, () => t('common.delete'))
      ])
    }
  }
]

async function loadData() {
  loading.value = true
  try {
    const result = await warehouseZoneApi.getList({
      keyword: searchKeyword.value || undefined,
      pageNum: pagination.page,
      pageSize: pagination.pageSize
    })
    tableData.value = result.records || []
    pagination.itemCount = result.total || 0
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
  } finally {
    loading.value = false
  }
}

function handleCreate() {
  isEdit.value = false
  editId.value = ''
  Object.assign(form, {
    zoneCode: '',
    zoneName: '',
    zoneType: 'SUPERVISED',
    address: '',
    contactPerson: '',
    contactPhone: '',
    status: 'ACTIVE'
  })
  showModal.value = true
}

function handleEdit(row: WarehouseZoneItem) {
  isEdit.value = true
  editId.value = row.id
  Object.assign(form, {
    zoneCode: row.zoneCode,
    zoneName: row.zoneName,
    zoneType: row.zoneType,
    address: row.address || '',
    contactPerson: row.contactPerson || '',
    contactPhone: row.contactPhone || '',
    status: row.status
  })
  showModal.value = true
}

async function handleDelete(row: WarehouseZoneItem) {
  try {
    await warehouseZoneApi.delete(row.id)
    message.success(t('message.deleteSuccess'))
    loadData()
  } catch (e: any) {
    message.error(e.message || t('message.deleteFailed'))
  }
}

async function handleSave() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    if (isEdit.value) {
      await warehouseZoneApi.update(editId.value, { ...form })
      message.success(t('message.updateSuccess'))
    } else {
      await warehouseZoneApi.create({ ...form } as any)
      message.success(t('message.createSuccess'))
    }
    showModal.value = false
    loadData()
  } catch (e: any) {
    message.error(e.message || t('message.saveFailed'))
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.system-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.search-card {
  margin-bottom: 16px;
}
</style>
