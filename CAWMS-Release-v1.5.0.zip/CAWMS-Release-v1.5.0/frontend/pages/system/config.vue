<template>
  <div class="config-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('system.config.title') }}</h1>
    </div>

    <n-card class="table-card">
      <n-data-table
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :row-key="(row) => row.id"
      />
    </n-card>

    <n-modal v-model:show="showModal" :title="$t('system.config.editModalTitle')" preset="card" style="width: 500px">
      <n-form v-if="currentRow" label-width="100">
        <n-form-item :label="$t('system.config.configKey')">
          <n-input :value="currentRow.configKey" disabled />
        </n-form-item>
        <n-form-item :label="$t('system.config.description')">
          <n-input :value="currentRow.description" type="textarea" :rows="2" disabled />
        </n-form-item>
        <n-form-item :label="$t('system.config.configValue')">
          <n-input v-model:value="editValue" />
        </n-form-item>
      </n-form>
      <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px;">
        <n-button @click="showModal = false">{{ $t('system.config.cancel') }}</n-button>
        <n-button type="primary" :loading="saving" @click="handleSave">{{ $t('system.config.save') }}</n-button>
      </div>
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed, h } from 'vue'
import { useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { DataTableColumns } from 'naive-ui'
import { getConfigList, updateConfig, type SystemConfig } from '~/api/system'

const { t } = useI18n()
const message = useMessage()
const loading = ref(false)
const tableData = ref<SystemConfig[]>([])
const showModal = ref(false)
const currentRow = ref<SystemConfig | null>(null)
const editValue = ref('')
const saving = ref(false)

const columns = computed<DataTableColumns<SystemConfig>>(() => [
  { title: t('system.config.configKey'), key: 'configKey', width: 200 },
  { title: t('system.config.configValue'), key: 'configValue', width: 250 },
  { title: t('system.config.configType'), key: 'configType', width: 100 },
  { title: t('system.config.description'), key: 'description' },
  {
    title: t('system.config.editable'), key: 'editable', width: 90,
    render: (row) => row.editable === 1 ? t('system.config.yes') : t('system.config.no')
  },
  {
    title: t('system.config.operation'), key: 'actions', width: 120,
    render: (row) => {
      if (row.editable !== 1) return null
      return h('n-button', { size: 'small', type: 'primary', onClick: () => handleEdit(row) }, { default: () => t('system.config.edit') })
    }
  }
])

const loadData = async () => {
  loading.value = true
  try {
    const res = await getConfigList()
    tableData.value = res || []
  } catch (error: any) {
    message.error(error?.message || t('system.config.loadFailed'))
  } finally {
    loading.value = false
  }
}

const handleEdit = (row: SystemConfig) => {
  currentRow.value = row
  editValue.value = row.configValue
  showModal.value = true
}

const handleSave = async () => {
  if (!currentRow.value) return
  saving.value = true
  try {
    await updateConfig(currentRow.value.id, { configValue: editValue.value })
    message.success(t('message.saveSuccess'))
    showModal.value = false
    loadData()
  } catch (error: any) {
    message.error(error?.message || t('message.saveFailed'))
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.config-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
}
.table-card {
  min-height: 400px;
}
</style>
