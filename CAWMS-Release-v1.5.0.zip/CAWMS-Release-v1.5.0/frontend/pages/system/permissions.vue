<template>
  <div class="permissions-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('system.permissions.title') }}</h1>
    </div>

    <div class="permissions-layout">
      <n-card :title="$t('system.permissions.roleList')" class="role-list-card">
        <n-spin :show="roleLoading">
          <n-empty v-if="!roleLoading && roleList.length === 0" :description="$t('system.permissions.emptyRoleData')" />
          <n-menu
            v-else
            :value="selectedKey"
            :options="roleMenuOptions"
            :collapsed-width="0"
            @update:value="handleSelectRole"
          />
        </n-spin>
      </n-card>

      <n-card :title="$t('system.permissions.permissionAssign')" class="permission-tree-card">
        <n-spin :show="saving">
          <n-empty v-if="!selectedRoleId" :description="$t('system.permissions.selectRoleFirst')" />
          <div v-else>
            <n-tree
              block-line
              checkable
              cascade
              :data="permissionTree"
              :checked-keys="checkedKeys"
              :expanded-keys="expandedKeys"
              @update:checked-keys="handleCheck"
              @update:expanded-keys="expandedKeys = $event"
            />
            <div class="permission-actions">
              <n-button @click="resetChecked">{{ $t('common.reset') }}</n-button>
              <n-button type="primary" :loading="saving" @click="savePermissions">{{ $t('system.permissions.savePermissions') }}</n-button>
            </div>
          </div>
        </n-spin>
      </n-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { TreeOption, MenuOption } from 'naive-ui'
import { getRoleList, updateRole, type SystemRole } from '~/api/system'

const message = useMessage()
const { t } = useI18n()
const roleList = ref<SystemRole[]>([])
const roleLoading = ref(false)
const saving = ref(false)
const selectedRoleId = ref<number | null>(null)
const checkedKeys = ref<string[]>([])
const expandedKeys = ref<string[]>(['warehouse', 'loan', 'system'])

const selectedKey = computed(() => selectedRoleId.value?.toString() || '')

const roleMenuOptions = computed<MenuOption[]>(() =>
  roleList.value.map(role => ({
    label: `${role.roleName} (${role.roleCode})`,
    key: role.id.toString()
  }))
)

const permissionTree = computed<TreeOption[]>(() => [
  {
    key: 'warehouse',
    label: t('system.permissions.permissionTree.warehouse'),
    children: [
      { key: 'warehouse:list', label: t('system.permissions.permissionTree.warehouseList') },
      { key: 'warehouse:create', label: t('system.permissions.permissionTree.warehouseCreate') },
      { key: 'warehouse:edit', label: t('system.permissions.permissionTree.warehouseEdit') },
      { key: 'warehouse:delete', label: t('system.permissions.permissionTree.warehouseDelete') },
      { key: 'warehouse:approve', label: t('system.permissions.permissionTree.warehouseApprove') },
      { key: 'warehouse:export', label: t('system.permissions.permissionTree.warehouseExport') }
    ]
  },
  {
    key: 'loan',
    label: t('system.permissions.permissionTree.loan'),
    children: [
      { key: 'loan:list', label: t('system.permissions.permissionTree.loanList') },
      { key: 'loan:create', label: t('system.permissions.permissionTree.loanCreate') },
      { key: 'loan:edit', label: t('system.permissions.permissionTree.loanEdit') },
      { key: 'loan:delete', label: t('system.permissions.permissionTree.loanDelete') },
      { key: 'loan:approve', label: t('system.permissions.permissionTree.loanApprove') },
      { key: 'loan:return', label: t('system.permissions.permissionTree.loanReturn') }
    ]
  },
  {
    key: 'transfer',
    label: t('system.permissions.permissionTree.transfer'),
    children: [
      { key: 'transfer:list', label: t('system.permissions.permissionTree.transferList') },
      { key: 'transfer:create', label: t('system.permissions.permissionTree.transferCreate') },
      { key: 'transfer:edit', label: t('system.permissions.permissionTree.transferEdit') },
      { key: 'transfer:delete', label: t('system.permissions.permissionTree.transferDelete') }
    ]
  },
  {
    key: 'reports',
    label: t('system.permissions.permissionTree.reports'),
    children: [
      { key: 'reports:inbound', label: t('system.permissions.permissionTree.reportsInbound') },
      { key: 'reports:loan', label: t('system.permissions.permissionTree.reportsLoanOut') },
      { key: 'reports:overdue', label: t('system.permissions.permissionTree.reportsOverdue') },
      { key: 'reports:financial', label: t('system.permissions.permissionTree.reportsFinancial') }
    ]
  },
  {
    key: 'approval',
    label: t('system.permissions.permissionTree.approval'),
    children: [
      { key: 'approval:pending', label: t('system.permissions.permissionTree.approvalPending') },
      { key: 'approval:completed', label: t('system.permissions.permissionTree.approvalCompleted') },
      { key: 'approval:history', label: t('system.permissions.permissionTree.approvalHistory') }
    ]
  },
  {
    key: 'system',
    label: t('system.permissions.permissionTree.system'),
    children: [
      { key: 'system:users', label: t('system.permissions.permissionTree.systemUsers') },
      { key: 'system:roles', label: t('system.permissions.permissionTree.systemRoles') },
      { key: 'system:permissions', label: t('system.permissions.permissionTree.systemPermissions') },
      { key: 'system:audit-logs', label: t('system.permissions.permissionTree.systemAuditLogs') },
      { key: 'system:config', label: t('system.permissions.permissionTree.systemConfig') }
    ]
  }
])

const loadRoles = async () => {
  roleLoading.value = true
  try {
    const res = await getRoleList({ page: 1, size: 100 })
    roleList.value = res.records || []
  } catch (error: any) {
    message.error(error.message || t('system.permissions.loadRoleListFailed'))
  } finally {
    roleLoading.value = false
  }
}

const handleSelectRole = (key: string) => {
  const id = Number(key)
  selectedRoleId.value = id
  const role = roleList.value.find(r => r.id === id)
  if (role && role.permissions) {
    try {
      const perms = JSON.parse(role.permissions)
      checkedKeys.value = Array.isArray(perms) ? perms : []
    } catch {
      checkedKeys.value = []
    }
  } else if (role && role.description) {
    // 兼容旧数据：如果 permissions 为空但 description 有逗号分隔的权限
    const perms = role.description.split(',').map(s => s.trim()).filter(Boolean)
    checkedKeys.value = perms.length > 0 ? perms : []
  } else {
    checkedKeys.value = []
  }
}

const handleCheck = (keys: string[]) => {
  checkedKeys.value = keys
}

const resetChecked = () => {
  checkedKeys.value = []
}

const savePermissions = async () => {
  if (!selectedRoleId.value) return
  saving.value = true
  try {
    await updateRole(selectedRoleId.value, {
      permissions: JSON.stringify(checkedKeys.value)
    })
    message.success(t('system.permissions.saveSuccess'))
    loadRoles()
  } catch (error: any) {
    message.error(error.message || t('message.saveFailed'))
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadRoles()
})
</script>

<style scoped>
.permissions-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
}
.permissions-layout {
  display: grid;
  grid-template-columns: 320px 1fr;
  gap: 16px;
}
@media (max-width: 900px) {
  .permissions-layout {
    grid-template-columns: 1fr;
  }
}
.role-list-card {
  min-height: 500px;
}
.permission-tree-card {
  min-height: 500px;
}
.permission-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 24px;
}
</style>
