<template>
  <div class="roles-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('system.roles.title') }}</h1>
      <n-button type="primary" @click="handleCreate">{{ $t('system.roles.createBtn') }}</n-button>
    </div>

    <n-card class="table-card">
      <n-data-table :columns="columns" :data="tableData" :loading="loading" :pagination="pagination" :row-key="(row) => row.id" />
    </n-card>

    <n-modal v-model:show="showModal" :title="modalTitle" preset="card" style="width: 700px">
      <role-form v-if="showModal" :role-id="currentRoleId" @success="handleModalSuccess" @close="showModal = false" />
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { DataTableColumns } from 'naive-ui'
import { getRoleList, deleteRole, type SystemRole } from '~/api/system'
import RoleForm from '~/components/system/RoleForm.vue'

const message = useMessage()
const { t } = useI18n()
const loading = ref(false)
const tableData = ref<SystemRole[]>([])

const pagination = reactive({
  page: 1, pageSize: 10, showSizePicker: true, pageSizes: [10, 20, 50], itemCount: 0,
  onChange: (page: number) => { pagination.page = page; loadTableData() },
  onUpdatePageSize: (pageSize: number) => { pagination.pageSize = pageSize; pagination.page = 1; loadTableData() }
})

const showModal = ref(false)
const modalTitle = ref('')
const currentRoleId = ref<number | null>(null)

const columns = computed<DataTableColumns<SystemRole>>(() => [
  { type: 'selection', fixed: 'left' },
  { title: t('system.roles.roleName'), key: 'roleName', width: 150, fixed: 'left' },
  { title: t('system.roles.roleCode'), key: 'roleCode', width: 150 },
  { title: t('system.roles.description'), key: 'description', width: 200 },
  {
    title: t('system.roles.status'), key: 'status', width: 100,
    render: (row) => {
      const map: Record<string, any> = { ACTIVE: { type: 'success', label: t('system.roles.statusActive') }, INACTIVE: { type: 'default', label: t('system.roles.statusInactive') } }
      const s = map[row.status] || { type: 'default', label: row.status }
      return h('n-tag', { type: s.type }, { default: () => s.label })
    }
  },
  { title: t('system.roles.createdAt'), key: 'createTime', width: 160, render: (row) => row.createTime?.slice(0, 16).replace('T', ' ') },
  {
    title: t('system.roles.actions'), key: 'actions', width: 180, fixed: 'right',
    render: (row) => h('div', { style: { display: 'flex', gap: '8px' } }, [
      h('n-button', { size: 'small', onClick: () => handleView(row.id) }, { default: () => t('system.roles.view') }),
      h('n-button', { size: 'small', type: 'primary', onClick: () => handleEdit(row.id) }, { default: () => t('system.roles.edit') }),
      h('n-button', { size: 'small', type: 'error', onClick: () => handleDelete(row.id) }, { default: () => t('system.roles.delete') })
    ])
  }
])

const loadTableData = async () => {
  loading.value = true
  try {
    const res = await getRoleList({ page: pagination.page, size: pagination.pageSize })
    tableData.value = res.records || []
    pagination.itemCount = res.total || 0
  } catch (error) {
    message.error(t('system.roles.loadFailed'))
  } finally {
    loading.value = false
  }
}

const handleCreate = () => { modalTitle.value = t('system.roles.createModalTitle'); currentRoleId.value = null; showModal.value = true }
const handleView = (id: number) => { modalTitle.value = t('system.roles.viewModalTitle'); currentRoleId.value = id; showModal.value = true }
const handleEdit = (id: number) => { modalTitle.value = t('system.roles.editModalTitle'); currentRoleId.value = id; showModal.value = true }
const handleDelete = async (id: number) => {
  if (!confirm(t('system.roles.deleteConfirm'))) return
  try {
    await deleteRole(id)
    message.success(t('message.deleteSuccess'))
    loadTableData()
  } catch (error: any) {
    message.error(error.message || t('message.deleteFailed'))
  }
}
const handleModalSuccess = () => { showModal.value = false; loadTableData() }

onMounted(() => { loadTableData() })
</script>

<style scoped>
.roles-page { padding: 24px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
.page-title { font-size: 24px; font-weight: 600; color: #333; }
.table-card { min-height: 400px; }
</style>
