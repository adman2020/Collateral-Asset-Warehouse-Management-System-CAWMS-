<template>
  <div class="system-page">
    <div class="page-header">
      <h1 class="page-title">{{ t('system.warehouse.title') }}</h1>
      <NButton type="primary" @click="handleCreate">{{ t('system.warehouse.create') }}</NButton>
    </div>

    <NCard class="search-card" size="small">
      <NGrid :cols="4" :x-gap="12" :y-gap="12">
        <NGi>
          <NSelect v-model:value="searchZoneId" :options="zoneOptions" clearable :placeholder="t('system.warehouse.zone')" @update:value="loadData" />
        </NGi>
        <NGi>
          <NInput v-model:value="searchKeyword" :placeholder="t('system.warehouse.warehouseCode') + '/' + t('system.warehouse.warehouseName')" clearable />
        </NGi>
        <NGi>
          <NButton type="primary" @click="loadData">{{ t('common.search') }}</NButton>
          <NButton style="margin-left: 8px" @click="searchKeyword = ''; searchZoneId = null; loadData()">{{ t('common.reset') }}</NButton>
        </NGi>
      </NGrid>
    </NCard>

    <NCard class="table-card" size="small">
      <NDataTable
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :pagination="pagination"
        :row-key="(row: any) => row.id"
      />
    </NCard>

    <NModal v-model:show="showModal" :title="isEdit ? t('system.warehouse.edit') : t('system.warehouse.create')" preset="card" style="width: 600px">
      <NForm ref="formRef" :model="form" :rules="rules" label-placement="left" label-width="100px">
        <NFormItem :label="t('system.warehouse.warehouseCode')" path="warehouseCode">
          <NInput v-model:value="form.warehouseCode" :placeholder="t('common.pleaseInput') + t('system.warehouse.warehouseCode')" />
        </NFormItem>
        <NFormItem :label="t('system.warehouse.warehouseName')" path="warehouseName">
          <NInput v-model:value="form.warehouseName" :placeholder="t('common.pleaseInput') + t('system.warehouse.warehouseName')" />
        </NFormItem>
        <NFormItem :label="t('system.warehouse.zone')" path="zoneId">
          <NSelect v-model:value="form.zoneId" :options="zoneOptions" :placeholder="t('common.pleaseSelect') + t('system.warehouse.zone')" />
        </NFormItem>
        <NFormItem :label="t('system.warehouse.manager')" path="manager">
          <NInput v-model:value="form.manager" :placeholder="t('common.pleaseInput') + t('system.warehouse.manager')" />
        </NFormItem>
        <NFormItem :label="t('system.warehouse.capacity')" path="capacity">
          <NInputNumber v-model:value="form.capacity" :min="0" :placeholder="t('common.pleaseInput') + t('system.warehouse.capacity')" style="width: 100%" />
        </NFormItem>
        <NFormItem :label="t('common.status')" path="status">
          <NSelect v-model:value="form.status" :options="statusOptions" :placeholder="t('common.pleaseSelect') + t('common.status')" />
        </NFormItem>
      </NForm>
      <template #footer>
        <NSpace justify="end">
          <NButton @click="showModal = false">{{ t('common.cancel') }}</NButton>
          <NButton type="primary" :loading="saving" @click="handleSave">{{ t('common.save') }}</NButton>
        </NSpace>
      </template>
    </NModal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, h, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  NButton, NCard, NDataTable, NForm, NFormItem, NInput, NInputNumber, NModal, NSelect, NSpace, useMessage, type FormInst, type FormRules
} from 'naive-ui'
import type { DataTableColumns } from 'naive-ui'
import warehouseApi, { type WarehouseItem } from '@/api/warehouse'
import warehouseZoneApi, { type WarehouseZoneItem } from '@/api/warehouse-zone'

const { t } = useI18n()

const message = useMessage()
const loading = ref(false)
const tableData = ref<WarehouseItem[]>([])
const searchKeyword = ref('')
const searchZoneId = ref<string | number | null>(null)
const zoneList = ref<WarehouseZoneItem[]>([])
const zoneOptions = ref<{ label: string; value: string | number }[]>([])

const pagination = reactive({
  page: 1,
  pageSize: 10,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  itemCount: 0,
  onChange: (page: number) => { pagination.page = page; loadData() },
  onUpdatePageSize: (pageSize: number) => { pagination.pageSize = pageSize; pagination.page = 1; loadData() }
})

const showModal = ref(false)
const isEdit = ref(false)
const editId = ref<string | number>('')
const formRef = ref<FormInst | null>(null)
const saving = ref(false)
const form = reactive({
  warehouseCode: '',
  warehouseName: '',
  zoneId: null as string | number | null,
  manager: '',
  capacity: null as number | null,
  status: 'ACTIVE'
})

const statusOptions = [
  { label: t('status.active'), value: 'ACTIVE' },
  { label: t('status.inactive'), value: 'INACTIVE' }
]

const rules: FormRules = {
  warehouseCode: [{ required: true, message: t('common.pleaseInput') + t('system.warehouse.warehouseCode'), trigger: 'blur' }],
  warehouseName: [{ required: true, message: t('common.pleaseInput') + t('system.warehouse.warehouseName'), trigger: 'blur' }],
  zoneId: [{ required: true, type: 'number', message: t('common.pleaseSelect') + t('system.warehouse.zone'), trigger: 'change' }]
}

function getZoneName(zoneId?: string | number) {
  const z = zoneList.value.find(item => String(item.id) === String(zoneId))
  return z ? z.zoneName : '-'
}

const columns: DataTableColumns<WarehouseItem> = [
  { title: t('system.warehouse.warehouseCode'), key: 'warehouseCode', width: 140 },
  { title: t('system.warehouse.warehouseName'), key: 'warehouseName', minWidth: 140 },
  {
    title: t('system.warehouse.zone'),
    key: 'zoneId',
    width: 150,
    render(row) {
      return getZoneName(row.zoneId)
    }
  },
  { title: t('system.warehouse.manager'), key: 'manager', width: 100 },
  { title: t('system.warehouse.capacity'), key: 'capacity', width: 100 },
  {
    title: t('common.status'),
    key: 'status',
    width: 80,
    render(row) {
      return row.status === 'ACTIVE' ? t('status.active') : t('status.inactive')
    }
  },
  {
    title: t('common.operation'),
    key: 'actions',
    width: 140,
    fixed: 'right',
    render(row) {
      return h(NSpace, { size: 'small' }, () => [
        h(NButton, { size: 'small', onClick: () => handleEdit(row) }, () => t('common.edit')),
        h(NButton, { size: 'small', type: 'error', onClick: () => handleDelete(row) }, () => t('common.delete'))
      ])
    }
  }
]

async function loadZones() {
  try {
    const list = await warehouseZoneApi.getAllActive()
    zoneList.value = list || []
    zoneOptions.value = (list || []).map(z => ({ label: z.zoneName, value: z.id }))
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
  }
}

async function loadData() {
  loading.value = true
  try {
    const result = await warehouseApi.getList({
      zoneId: searchZoneId.value || undefined,
      keyword: searchKeyword.value || undefined,
      pageNum: pagination.page,
      pageSize: pagination.pageSize
    })
    tableData.value = result.records || []
    pagination.itemCount = result.total || 0
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
  } finally {
    loading.value = false
  }
}

function handleCreate() {
  isEdit.value = false
  editId.value = ''
  Object.assign(form, {
    warehouseCode: '',
    warehouseName: '',
    zoneId: null,
    manager: '',
    capacity: null,
    status: 'ACTIVE'
  })
  showModal.value = true
}

function handleEdit(row: WarehouseItem) {
  isEdit.value = true
  editId.value = row.id
  Object.assign(form, {
    warehouseCode: row.warehouseCode,
    warehouseName: row.warehouseName,
    zoneId: row.zoneId,
    manager: row.manager || '',
    capacity: row.capacity ?? null,
    status: row.status
  })
  showModal.value = true
}

async function handleDelete(row: WarehouseItem) {
  try {
    await warehouseApi.delete(row.id)
    message.success(t('message.deleteSuccess'))
    loadData()
  } catch (e: any) {
    message.error(e.message || t('message.deleteFailed'))
  }
}

async function handleSave() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    const payload = { ...form, zoneId: form.zoneId }
    if (isEdit.value) {
      await warehouseApi.update(editId.value, payload)
      message.success(t('message.updateSuccess'))
    } else {
      await warehouseApi.create(payload as any)
      message.success(t('message.createSuccess'))
    }
    showModal.value = false
    loadData()
  } catch (e: any) {
    message.error(e.message || t('message.saveFailed'))
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadZones()
  loadData()
})
</script>

<style scoped>
.system-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.search-card {
  margin-bottom: 16px;
}
</style>
