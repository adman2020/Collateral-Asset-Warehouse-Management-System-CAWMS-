<template>
  <div class="system-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('system.users.title') }}</h1>
      <n-button type="primary" @click="handleCreate">
        <template #icon>
          <n-icon><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg></n-icon>
        </template>
        {{ $t('system.users.createBtn') }}
      </n-button>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #e6f7ff;">👥</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.totalUsers || 0 }}</div>
          <div class="stat-label">{{ $t('system.users.totalUsers') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #f6ffed;">✅</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.activeUsers || 0 }}</div>
          <div class="stat-label">{{ $t('system.users.activeUsers') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #fff7e6;">🔐</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.totalRoles || 0 }}</div>
          <div class="stat-label">{{ $t('system.users.roleCount') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #f0f5ff;">📊</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.auditLogsToday || 0 }}</div>
          <div class="stat-label">{{ $t('system.users.todayOps') }}</div>
        </div>
      </n-card>
    </div>

    <!-- 搜索�?-->
    <n-card class="search-card">
      <n-grid :cols="4" :x-gap="16" :y-gap="12">
        <n-grid-item>
          <n-input v-model:value="searchForm.username" :placeholder="$t('system.users.usernamePlaceholder')" clearable />
        </n-grid-item>
        <n-grid-item>
          <n-input v-model:value="searchForm.realName" :placeholder="$t('system.users.realNamePlaceholder')" clearable />
        </n-grid-item>
        <n-grid-item>
          <n-select v-model:value="searchForm.status" :placeholder="$t('system.users.statusPlaceholder')" :options="statusOptions" clearable />
        </n-grid-item>
        <n-grid-item>
          <n-button type="primary" block @click="handleSearch">{{ $t('system.users.search') }}</n-button>
        </n-grid-item>
        <n-grid-item>
          <n-button block @click="handleReset">{{ $t('system.users.reset') }}</n-button>
        </n-grid-item>
      </n-grid>
    </n-card>

    <!-- 表格 -->
    <n-card class="table-card">
      <n-data-table
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :pagination="pagination"
        :row-key="(row) => row.id"
      />
    </n-card>

    <!-- 创建/编辑用户弹窗 -->
    <n-modal
      v-model:show="showModal"
      :title="modalTitle"
      preset="card"
      style="width: 700px"
      :mask-closable="false"
    >
      <user-form
        v-if="showModal"
        :user-id="currentUserId"
        @success="handleModalSuccess"
        @close="showModal = false"
      />
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { DataTableColumns } from 'naive-ui'
import { getUserList, getSystemStatistics, type SystemUser, type SystemStatistics } from '~/api/system'
import UserForm from '~/components/system/UserForm.vue'

const message = useMessage()
const { t } = useI18n()
const loading = ref(false)
const statistics = ref<SystemStatistics>()
const tableData = ref<SystemUser[]>([])

const searchForm = reactive({
  username: '',
  realName: '',
  status: ''
})

const pagination = reactive({
  page: 1,
  pageSize: 10,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  itemCount: 0,
  onChange: (page: number) => { pagination.page = page; loadTableData() },
  onUpdatePageSize: (pageSize: number) => { pagination.pageSize = pageSize; pagination.page = 1; loadTableData() }
})

const showModal = ref(false)
const modalTitle = ref('')
const currentUserId = ref<number | null>(null)

const statusOptions = [
  { label: t('system.users.statusActive'), value: 'ACTIVE' },
  { label: t('system.users.statusInactive'), value: 'INACTIVE' },
  { label: t('system.users.statusLocked'), value: 'LOCKED' }
]

const columns = computed<DataTableColumns<SystemUser>>(() => [
  { type: 'selection', fixed: 'left' },
  { title: t('system.users.username'), key: 'username', width: 120, fixed: 'left' },
  { title: t('system.users.realName'), key: 'realName', width: 100 },
  { title: t('system.users.email'), key: 'email', width: 180 },
  { title: t('system.users.department'), key: 'departmentName', width: 120 },
  { title: t('system.users.roles'), key: 'roleNames', width: 150, render: (row) => row.roleNames?.join(', ') },
  {
    title: t('system.users.status'), key: 'status', width: 100,
    render: (row) => {
      const map: Record<string, any> = {
        ACTIVE: { type: 'success', label: t('system.users.statusActive') },
        INACTIVE: { type: 'default', label: t('system.users.statusInactive') },
        LOCKED: { type: 'error', label: t('system.users.statusLocked') }
      }
      const s = map[row.status] || { type: 'default', label: row.status }
      return h('n-tag', { type: s.type }, { default: () => s.label })
    }
  },
  { title: t('system.users.lastLogin'), key: 'lastLoginTime', width: 160, render: (row) => row.lastLoginTime?.slice(0, 16).replace('T', ' ') || t('system.users.neverLoggedIn') },
  {
    title: t('system.users.actions'), key: 'actions', width: 180, fixed: 'right',
    render: (row) => h('div', { style: { display: 'flex', gap: '8px' } }, [
      h('n-button', { size: 'small', onClick: () => handleView(row.id) }, { default: () => t('system.users.view') }),
      h('n-button', { size: 'small', type: 'primary', onClick: () => handleEdit(row.id) }, { default: () => t('system.users.edit') }),
      h('n-button', { size: 'small', type: 'error', onClick: () => handleDelete(row.id) }, { default: () => t('system.users.delete') })
    ])
  }
])

const loadTableData = async () => {
  loading.value = true
  try {
    const res = await getUserList({ page: pagination.page, size: pagination.pageSize, ...searchForm })
    tableData.value = res.records
    pagination.itemCount = res.total
  } catch (error) {
    message.error(t('system.users.loadFailed'))
  } finally {
    loading.value = false
  }
}

const loadStatistics = async () => {
  try {
    statistics.value = await getSystemStatistics()
  } catch (error) {
    console.error(t('system.users.loadStatisticsFailed'), error)
  }
}

const handleSearch = () => { pagination.page = 1; loadTableData() }
const handleReset = () => {
  searchForm.username = ''
  searchForm.realName = ''
  searchForm.status = ''
  handleSearch()
}
const handleCreate = () => { modalTitle.value = t('system.users.createModalTitle'); currentUserId.value = null; showModal.value = true }
const handleView = (id: number) => { modalTitle.value = t('system.users.viewModalTitle'); currentUserId.value = id; showModal.value = true }
const handleEdit = (id: number) => { modalTitle.value = t('system.users.editModalTitle'); currentUserId.value = id; showModal.value = true }
const handleDelete = async (id: number) => {
  if (!confirm(t('system.users.deleteConfirm'))) return
  try {
    const { deleteUser } = await import('~/api/system')
    await deleteUser(id)
    message.success(t('message.deleteSuccess'))
    loadTableData()
    loadStatistics()
  } catch (error) {
    message.error(t('message.deleteFailed'))
  }
}
const handleModalSuccess = () => { showModal.value = false; loadTableData(); loadStatistics() }

onMounted(() => { loadTableData(); loadStatistics() })
</script>

<style scoped>
.system-page { padding: 24px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
.page-title { font-size: 24px; font-weight: 600; color: #333; }
.stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
.stat-card { display: flex; align-items: center; gap: 16px; }
.stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; }
.stat-content { flex: 1; }
.stat-value { font-size: 24px; font-weight: 600; color: #333; }
.stat-label { font-size: 14px; color: #666; margin-top: 4px; }
.search-card { margin-bottom: 24px; }
.table-card { min-height: 400px; }
</style>

