<template>
  <div class="profile-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('profile.title') }}</h1>
    </div>

    <div class="profile-layout">
      <!-- 左侧：基本信息 -->
      <n-card :title="$t('profile.basicInfo')" class="info-card">
        <div class="avatar-section">
          <n-avatar round :size="80" :src="userAvatar" />
          <div class="avatar-meta">
            <h3>{{ authStore.userFullName }}</h3>
            <p>{{ authStore.user?.username }}</p>
            <n-tag type="success" size="small">{{ userRoleLabel }}</n-tag>
          </div>
        </div>

        <n-form label-width="100">
          <n-form-item :label="$t('profile.username')">
            <n-input :value="authStore.user?.username" disabled />
          </n-form-item>
          <n-form-item :label="$t('profile.fullName')">
            <n-input v-model:value="formData.fullName" :placeholder="$t('profile.fullNamePlaceholder')" />
          </n-form-item>
          <n-form-item :label="$t('profile.email')">
            <n-input v-model:value="formData.email" :placeholder="$t('profile.emailPlaceholder')" />
          </n-form-item>
          <n-form-item :label="$t('profile.phone')">
            <n-input v-model:value="formData.phone" :placeholder="$t('profile.phonePlaceholder')" />
          </n-form-item>
          <n-form-item :label="$t('profile.department')">
            <n-input v-model:value="formData.department" :placeholder="$t('profile.departmentPlaceholder')" />
          </n-form-item>
        </n-form>

        <div class="form-actions">
          <n-button type="primary" :loading="savingInfo" @click="handleSaveInfo">{{ $t('profile.saveInfo') }}</n-button>
        </div>
      </n-card>

      <!-- 右侧：修改密码 -->
      <n-card :title="$t('profile.changePassword')" class="password-card">
        <n-form label-width="100">
          <n-form-item :label="$t('profile.currentPassword')">
            <n-input v-model:value="passwordForm.oldPassword" type="password" :placeholder="$t('profile.currentPasswordPlaceholder')" />
          </n-form-item>
          <n-form-item :label="$t('profile.newPassword')">
            <n-input v-model:value="passwordForm.newPassword" type="password" :placeholder="$t('profile.newPasswordPlaceholder')" />
          </n-form-item>
          <n-form-item :label="$t('profile.confirmPassword')">
            <n-input v-model:value="passwordForm.confirmPassword" type="password" :placeholder="$t('profile.confirmPasswordPlaceholder')" />
          </n-form-item>
        </n-form>

        <div class="form-actions">
          <n-button type="primary" :loading="savingPassword" @click="handleChangePassword">{{ $t('profile.changePassword') }}</n-button>
        </div>
      </n-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { storeToRefs } from 'pinia'
import { useAuthStore } from '@/stores/auth'
import { updateUser } from '~/api/system'
import { getRoleAvatar } from '@/composables/useRoleAvatar'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

definePageMeta({
  middleware: ['auth'],
  layout: 'default',
  meta: { title: '个人资料', requiresAuth: true }
})

const message = useMessage()
const authStore = useAuthStore()
const { user } = storeToRefs(authStore)

const userAvatar = computed(() => {
  if (user.value?.avatar) return user.value.avatar
  return getRoleAvatar(user.value?.role)
})
const userRoleLabel = computed(() => {
  const map: Record<string, string> = {
    SUPER_ADMIN: t('profile.roleMap.SUPER_ADMIN'),
    SYSTEM_ADMIN: t('profile.roleMap.SYSTEM_ADMIN'),
    BUSINESS_MANAGER: t('profile.roleMap.BUSINESS_MANAGER'),
    RISK_OFFICER: t('profile.roleMap.RISK_OFFICER'),
    COMPLIANCE_OFFICER: t('profile.roleMap.COMPLIANCE_OFFICER'),
    WAREHOUSE_MANAGER: t('profile.roleMap.WAREHOUSE_MANAGER'),
    CREDIT_OFFICER: t('profile.roleMap.CREDIT_OFFICER'),
    BU_OFFICER: t('profile.roleMap.BU_OFFICER')
  }
  const role = user.value?.role || user.value?.roleName || ''
  return map[role] || role || t('profile.defaultRole')
})

const formData = reactive({
  fullName: '',
  email: '',
  phone: '',
  department: ''
})

const passwordForm = reactive({
  oldPassword: '',
  newPassword: '',
  confirmPassword: ''
})

const savingInfo = ref(false)
const savingPassword = ref(false)

// 使用 storeToRefs 解构出的 ref 进行监听，确保可靠触发
watch(user, (userValue) => {
  if (userValue) {
    formData.fullName = userValue.fullName || ''
    formData.email = userValue.email || ''
    formData.phone = userValue.phone || ''
    formData.department = userValue.department || ''
  }
}, { immediate: true, deep: true })

onMounted(async () => {
  // 如果用户信息缺失，强制拉取
  if (!user.value?.username) {
    await authStore.fetchUserInfo()
  }
})

const handleSaveInfo = async () => {
  const userId = authStore.user?.id
  if (!userId) {
    message.error(t('profile.notLoggedIn'))
    return
  }
  savingInfo.value = true
  try {
    await updateUser(userId, {
      realName: formData.fullName,
      email: formData.email,
      phone: formData.phone,
      departmentName: formData.department
    })
    // 更新本地状态
    authStore.updateUserInfo({
      fullName: formData.fullName,
      email: formData.email,
      phone: formData.phone,
      department: formData.department
    })
    message.success(t('profile.saveSuccess'))
  } catch (error: any) {
    message.error(error?.message || t('profile.saveFailed'))
  } finally {
    savingInfo.value = false
  }
}

const handleChangePassword = async () => {
  if (!passwordForm.oldPassword || !passwordForm.newPassword) {
    message.error(t('profile.pleaseFillPassword'))
    return
  }
  if (passwordForm.newPassword !== passwordForm.confirmPassword) {
    message.error(t('profile.passwordMismatch'))
    return
  }
  savingPassword.value = true
  try {
    const success = await authStore.changePassword(passwordForm.oldPassword, passwordForm.newPassword)
    if (success) {
      message.success(t('profile.passwordChangeSuccess'))
      passwordForm.oldPassword = ''
      passwordForm.newPassword = ''
      passwordForm.confirmPassword = ''
    } else {
      message.error(t('profile.passwordChangeFailed'))
    }
  } catch (error: any) {
    message.error(error?.message || t('profile.passwordChangeFailed'))
  } finally {
    savingPassword.value = false
  }
}
</script>

<style scoped>
.profile-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
  margin: 0;
}
.profile-layout {
  display: grid;
  grid-template-columns: 1.2fr 0.8fr;
  gap: 24px;
}
@media (max-width: 900px) {
  .profile-layout {
    grid-template-columns: 1fr;
  }
}
.avatar-section {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 24px;
}
.avatar-meta h3 {
  margin: 0 0 4px 0;
  font-size: 18px;
  font-weight: 600;
}
.avatar-meta p {
  margin: 0 0 8px 0;
  color: #666;
  font-size: 14px;
}
.form-actions {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}
</style>
