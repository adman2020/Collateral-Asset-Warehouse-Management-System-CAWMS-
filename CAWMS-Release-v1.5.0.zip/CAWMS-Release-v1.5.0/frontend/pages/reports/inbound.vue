<template>
  <div class="reports-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('reports.inboundTitle') }}</h1>
    </div>

    <!-- 工具栏 -->
    <NCard size="small" class="toolbar-card">
      <NSpace align="center">
        <NDatePicker
          v-model:value="dateRange"
          type="daterange"
          clearable
          :shortcuts="dateShortcuts"
          :placeholder="$t('reports.dateRangePlaceholder')"
          @update:value="handleDateChange"
        />
        <NButton type="primary" @click="loadData">
          <template #icon><NIcon><SearchOutline /></NIcon></template>
          {{ $t('reports.search') }}
        </NButton>
        <NButton @click="handleExport">
          <template #icon><NIcon><DownloadOutline /></NIcon></template>
          {{ $t('reports.exportExcel') }}
        </NButton>
      </NSpace>
    </NCard>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <NCard v-for="s in statCards" :key="s.key" size="small" class="stat-card">
        <div class="stat-value">{{ s.value }}</div>
        <div class="stat-label">{{ s.label }}</div>
      </NCard>
    </div>

    <!-- 图表 -->
    <NGrid :cols="2" :x-gap="16" class="chart-row">
      <NGi>
        <NCard :title="$t('reports.statusDistribution')" size="small">
          <v-chart :option="statusPieOption" style="height: 300px;" />
        </NCard>
      </NGi>
      <NGi>
        <NCard :title="$t('reports.collateralTypeDistribution')" size="small">
          <v-chart :option="typeBarOption" style="height: 300px;" />
        </NCard>
      </NGi>
    </NGrid>

    <!-- 明细表格 -->
    <NCard :title="$t('reports.inboundDetail')" size="small" class="table-card">
      <NDataTable
        :columns="tableColumns"
        :data="tableData"
        :loading="tableLoading"
        :pagination="pagination"
        remote
        @update:page="handlePageChange"
        @update:page-size="handlePageSizeChange"
      />
    </NCard>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import {
  NCard, NGrid, NGi, NSpace, NButton, NIcon, NDatePicker, NDataTable, useMessage
} from 'naive-ui'
import { SearchOutline, DownloadOutline } from '@vicons/ionicons5'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { PieChart, BarChart } from 'echarts/charts'
import {
  TitleComponent, TooltipComponent, LegendComponent, GridComponent
} from 'echarts/components'
import VChart from 'vue-echarts'
import { useI18n } from 'vue-i18n'
import warehouseInApi from '@/api/warehouse-in'
import type { WarehouseInItem } from '@/api/warehouse-in'

use([CanvasRenderer, PieChart, BarChart, TitleComponent, TooltipComponent, LegendComponent, GridComponent])

const message = useMessage()
const { t } = useI18n()

const stats = reactive<Record<string, any>>({})
const dateRange = ref<[number, number] | null>(null)
const tableLoading = ref(false)
const tableData = ref<WarehouseInItem[]>([])
const pagination = reactive({
  page: 1,
  pageSize: 10,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  itemCount: 0,
  onChange: (page: number) => { pagination.page = page; loadTableData() },
  onUpdatePageSize: (pageSize: number) => { pagination.pageSize = pageSize; pagination.page = 1; loadTableData() }
})

const dateShortcuts = computed(() => ({
  [t('reports.last7Days')]: () => { const end = new Date(); const start = new Date(); start.setDate(end.getDate() - 6); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.last30Days')]: () => { const end = new Date(); const start = new Date(); start.setDate(end.getDate() - 29); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.thisMonth')]: () => { const end = new Date(); const start = new Date(end.getFullYear(), end.getMonth(), 1); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.lastMonth')]: () => { const end = new Date(); const start = new Date(end.getFullYear(), end.getMonth() - 1, 1); end.setDate(0); return [start.getTime(), end.getTime()] as [number, number] }
}))

const statCards = computed(() => [
  { key: 'total', label: t('reports.inboundTotal'), value: stats.totalApplications || 0 },
  { key: 'completed', label: t('status.completed'), value: stats.approvedApplications || 0 },
  { key: 'pending', label: t('status.inReview'), value: stats.pendingApplications || 0 },
  { key: 'rejected', label: t('status.rejected'), value: stats.rejectedApplications || 0 },
  { key: 'value', label: t('reports.collateralValue'), value: formatCurrency(stats.totalCollateralValue) }
])

const statusMap = computed(() => ({
  DRAFT: t('status.draft'),
  SUBMITTED: t('status.submitted'),
  IN_REVIEW: t('status.inReview'),
  APPROVED: t('status.approved'),
  REJECTED: t('status.rejected'),
  COMPLETED: t('status.completed')
}))

const collateralTypeMap = computed(() => ({
  REAL_ESTATE: t('warehouseIn.collateralTypes.realEstate'),
  MOVABLE: t('warehouseIn.collateralTypes.movable'),
  RIGHTS: t('warehouseIn.collateralTypes.rights'),
  MARGIN: t('warehouseIn.collateralTypes.margin'),
  OTHER: t('warehouseIn.collateralTypes.other')
}))

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

function formatDate(ts?: string) {
  if (!ts) return '-'
  return new Date(ts).toLocaleDateString('zh-CN')
}

const statusPieOption = computed(() => {
  const data = Object.entries(stats.applicationsByStatus || {}).map(([k, v]) => ({
    name: statusMap.value[k] || k,
    value: v
  }))
  return {
    tooltip: { trigger: 'item' },
    legend: { orient: 'vertical', left: 'left' },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 10, borderColor: '#fff', borderWidth: 2 },
      label: { show: false },
      emphasis: { label: { show: true, fontSize: 16, fontWeight: 'bold' } },
      data
    }]
  }
})

const typeBarOption = computed(() => {
  const entries = Object.entries(stats.valueByCollateralType || {})
  return {
    tooltip: { trigger: 'axis' },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: { type: 'category', data: entries.map(([k]) => collateralTypeMap.value[k] || k) },
    yAxis: { type: 'value' },
    series: [{
      data: entries.map(([, v]) => v),
      type: 'bar',
      itemStyle: { borderRadius: [4, 4, 0, 0] }
    }]
  }
})

const tableColumns = computed(() => [
  { title: t('table.whCode'), key: 'whCode', width: 140 },
  { title: t('table.customerName'), key: 'customerName', ellipsis: { tooltip: true } },
  { title: t('table.collateralType'), key: 'collateralType', width: 120, render: (row: WarehouseInItem) => collateralTypeMap.value[row.collateralType] || row.collateralType },
  { title: t('table.collateralValue'), key: 'collateralValue', width: 140, render: (row: WarehouseInItem) => formatCurrency(row.collateralValue) },
  { title: t('table.status'), key: 'status', width: 100, render: (row: WarehouseInItem) => statusMap.value[row.status] || row.status },
  { title: t('table.createdAt'), key: 'createdAt', width: 160, render: (row: WarehouseInItem) => formatDate(row.createdAt) }
])

function getDateParams() {
  if (!dateRange.value) return {}
  const start = new Date(dateRange.value[0]).toISOString().split('T')[0]
  const end = new Date(dateRange.value[1]).toISOString().split('T')[0]
  return { startTime: `${start}T00:00:00`, endTime: `${end}T23:59:59` }
}

async function loadData() {
  await loadStats()
  await loadTableData()
}

async function loadStats() {
  try {
    const params = getDateParams()
    const data = await warehouseInApi.getStatistics(params)
    Object.assign(stats, data)
  } catch (e: any) {
    message.error(e.message || t('reports.loadStatsFailed'))
  }
}

async function loadTableData() {
  tableLoading.value = true
  try {
    const params = {
      ...getDateParams(),
      pageNum: pagination.page,
      pageSize: pagination.pageSize
    }
    const res = await warehouseInApi.getList(params)
    tableData.value = res.records || []
    pagination.itemCount = res.total || 0
  } catch (e: any) {
    message.error(e.message || t('reports.loadDetailFailed'))
  } finally {
    tableLoading.value = false
  }
}

function handleDateChange() {
  loadData()
}

function handlePageChange(page: number) {
  pagination.page = page
  loadTableData()
}

function handlePageSizeChange(pageSize: number) {
  pagination.pageSize = pageSize
  pagination.page = 1
  loadTableData()
}

function handleExport() {
  const rows = tableData.value.map(row => ({
    [t('table.whCode')]: row.whCode || '',
    [t('table.customerName')]: row.customerName || '',
    [t('table.buCode')]: row.buCode || '',
    [t('table.collateralType')]: collateralTypeMap.value[row.collateralType] || row.collateralType || '',
    [t('table.collateralValue')]: row.collateralValue || '',
    [t('table.status')]: statusMap.value[row.status] || row.status || '',
    [t('table.createdAt')]: row.createdAt || ''
  }))
  exportToCSV(rows, t('reports.inboundStats'))
}

function exportToCSV(rows: Record<string, any>[], filename: string) {
  if (!rows.length) { message.warning(t('reports.noDataToExport')); return }
  const headers = Object.keys(rows[0])
  const csv = [headers.join(','), ...rows.map(r => headers.map(h => `"${String(r[h]).replace(/"/g, '""')}"`).join(','))].join('\n')
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `${filename}_${new Date().toLocaleDateString('zh-CN')}.csv`
  link.click()
  message.success(t('reports.exportSuccess'))
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.reports-page { padding: 24px; }
.page-title { font-size: 22px; font-weight: 700; margin: 0 0 16px 0; }
.toolbar-card { margin-bottom: 16px; }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px; margin-bottom: 16px; }
.stat-value { font-size: 24px; font-weight: 600; color: #262626; }
.stat-label { font-size: 14px; color: #8c8c8c; margin-top: 4px; }
.chart-row { margin-bottom: 16px; }
.table-card { margin-top: 16px; }
</style>
