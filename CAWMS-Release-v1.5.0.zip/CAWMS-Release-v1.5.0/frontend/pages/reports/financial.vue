<template>
  <div class="reports-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('reports.financial.title') }}</h1>
    </div>

    <!-- 工具栏 -->
    <NCard size="small" class="toolbar-card">
      <NSpace align="center">
        <NDatePicker
          v-model:value="dateRange"
          type="daterange"
          clearable
          :shortcuts="dateShortcuts"
          :placeholder="$t('reports.dateRangePlaceholder')"
          @update:value="handleDateChange"
        />
        <NButton type="primary" @click="loadData">
          <template #icon><NIcon><SearchOutline /></NIcon></template>
          {{ $t('reports.search') }}
        </NButton>
        <NButton @click="handleExport">
          <template #icon><NIcon><DownloadOutline /></NIcon></template>
          {{ $t('reports.exportExcel') }}
        </NButton>
      </NSpace>
    </NCard>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <NCard v-for="s in statCards" :key="s.key" size="small" class="stat-card">
        <div class="stat-value">{{ s.value }}</div>
        <div class="stat-label">{{ s.label }}</div>
      </NCard>
    </div>

    <!-- 图表 -->
    <NGrid :cols="2" :x-gap="16" class="chart-row">
      <NGi>
        <NCard :title="$t('reports.inboundVsLoanOutCount')" size="small">
          <v-chart :option="countCompareOption" style="height: 300px;" />
        </NCard>
      </NGi>
      <NGi>
        <NCard :title="$t('reports.inboundVsLoanOutValue')" size="small">
          <v-chart :option="valueCompareOption" style="height: 300px;" />
        </NCard>
      </NGi>
    </NGrid>

    <!-- 汇总表格 -->
    <NCard :title="$t('reports.financialSummary')" size="small" class="table-card">
      <NDataTable :columns="summaryColumns" :data="summaryData" />
    </NCard>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import {
  NCard, NGrid, NGi, NSpace, NButton, NIcon, NDatePicker, NDataTable, useMessage
} from 'naive-ui'
import { SearchOutline, DownloadOutline } from '@vicons/ionicons5'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { BarChart } from 'echarts/charts'
import {
  TitleComponent, TooltipComponent, LegendComponent, GridComponent
} from 'echarts/components'
import VChart from 'vue-echarts'
import { useI18n } from 'vue-i18n'
import warehouseInApi from '@/api/warehouse-in'
import loanOutApi from '@/api/loan-out'

use([CanvasRenderer, BarChart, TitleComponent, TooltipComponent, LegendComponent, GridComponent])

const message = useMessage()
const { t } = useI18n()

const inboundStats = reactive<Record<string, any>>({})
const loanOutStats = reactive<Record<string, any>>({})
const dateRange = ref<[number, number] | null>(null)

const dateShortcuts = computed(() => ({
  [t('reports.last7Days')]: () => { const end = new Date(); const start = new Date(); start.setDate(end.getDate() - 6); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.last30Days')]: () => { const end = new Date(); const start = new Date(); start.setDate(end.getDate() - 29); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.thisMonth')]: () => { const end = new Date(); const start = new Date(end.getFullYear(), end.getMonth(), 1); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.lastMonth')]: () => { const end = new Date(); const start = new Date(end.getFullYear(), end.getMonth() - 1, 1); end.setDate(0); return [start.getTime(), end.getTime()] as [number, number] }
}))

const statCards = computed(() => [
  { key: 'inbound', label: t('reports.inboundTotal'), value: inboundStats.totalApplications || 0 },
  { key: 'loan', label: t('reports.loanOutTotal'), value: loanOutStats.totalCount || 0 },
  { key: 'returned', label: t('reports.returned'), value: loanOutStats.returnedCount || 0 },
  { key: 'overdue', label: t('reports.totalOverdue'), value: loanOutStats.overdueCount || 0 },
  { key: 'inboundValue', label: t('reports.totalInboundValue'), value: formatCurrency(inboundStats.totalCollateralValue) },
  { key: 'loanValue', label: t('reports.totalLoanOutValue'), value: formatCurrency(loanOutStats.totalLoanValue) },
  { key: 'totalValue', label: t('reports.totalAssetValue'), value: formatCurrency((inboundStats.totalCollateralValue || 0) + (loanOutStats.totalLoanValue || 0)) }
])

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

const countCompareOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  legend: { data: [t('reports.inbound'), t('reports.loanOut'), t('reports.returned')], top: 8 },
  grid: { left: '3%', right: '4%', top: 50, bottom: '3%', containLabel: true },
  xAxis: { type: 'category', data: [t('reports.quantityComparison')] },
  yAxis: { type: 'value' },
  series: [
    { name: t('reports.inbound'), type: 'bar', data: [inboundStats.totalApplications || 0] },
    { name: t('reports.loanOut'), type: 'bar', data: [loanOutStats.totalCount || 0] },
    { name: t('reports.returned'), type: 'bar', data: [loanOutStats.returnedCount || 0] }
  ]
}))

const valueCompareOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  legend: { data: [t('reports.inboundValue'), t('reports.loanOutValue')], top: 8 },
  grid: { left: '3%', right: '4%', top: 50, bottom: '3%', containLabel: true },
  xAxis: { type: 'category', data: [t('reports.valueComparison')] },
  yAxis: { type: 'value' },
  series: [
    { name: t('reports.inboundValue'), type: 'bar', data: [inboundStats.totalCollateralValue || 0] },
    { name: t('reports.loanOutValue'), type: 'bar', data: [loanOutStats.totalLoanValue || 0] }
  ]
}))

const summaryColumns = computed(() => [
  { title: t('reports.item'), key: 'item' },
  { title: t('reports.inbound'), key: 'inbound' },
  { title: t('reports.loanOut'), key: 'loanOut' },
  { title: t('reports.total'), key: 'total' }
])

const summaryData = computed(() => [
  { item: t('reports.quantityCount'), inbound: inboundStats.totalApplications || 0, loanOut: loanOutStats.totalCount || 0, total: (inboundStats.totalApplications || 0) + (loanOutStats.totalCount || 0) },
  { item: t('reports.completedLoaned'), inbound: inboundStats.approvedApplications || 0, loanOut: loanOutStats.loanedCount || 0, total: (inboundStats.approvedApplications || 0) + (loanOutStats.loanedCount || 0) },
  { item: t('reports.inReviewPending'), inbound: inboundStats.pendingApplications || 0, loanOut: loanOutStats.pendingCount || 0, total: (inboundStats.pendingApplications || 0) + (loanOutStats.pendingCount || 0) },
  { item: t('reports.rejected'), inbound: inboundStats.rejectedApplications || 0, loanOut: loanOutStats.rejectedCount || 0, total: (inboundStats.rejectedApplications || 0) + (loanOutStats.rejectedCount || 0) },
  { item: t('reports.valueYuan'), inbound: formatCurrency(inboundStats.totalCollateralValue), loanOut: formatCurrency(loanOutStats.totalLoanValue), total: formatCurrency((inboundStats.totalCollateralValue || 0) + (loanOutStats.totalLoanValue || 0)) }
])

function getDateParams() {
  if (!dateRange.value) return {}
  const start = new Date(dateRange.value[0]).toISOString().split('T')[0]
  const end = new Date(dateRange.value[1]).toISOString().split('T')[0]
  return { startDate: start, endDate: end }
}

async function loadData() {
  try {
    const params = getDateParams()
    const [inData, loData] = await Promise.all([
      warehouseInApi.getStatistics({ startTime: params.startDate ? `${params.startDate}T00:00:00` : undefined, endTime: params.endDate ? `${params.endDate}T23:59:59` : undefined }),
      loanOutApi.getStatistics(params)
    ])
    Object.assign(inboundStats, inData)
    Object.assign(loanOutStats, loData)
  } catch (e: any) {
    message.error(e.message || t('reports.loadFailed'))
  }
}

function handleDateChange() {
  loadData()
}

function handleExport() {
  const rows = summaryData.value.map(r => ({
    [t('reports.item')]: r.item,
    [t('reports.inbound')]: r.inbound,
    [t('reports.loanOut')]: r.loanOut,
    [t('reports.total')]: r.total
  }))
  if (!rows.length) { message.warning(t('reports.noDataToExport')); return }
  const headers = Object.keys(rows[0])
  const csv = [headers.join(','), ...rows.map(r => headers.map(h => `"${String(r[h]).replace(/"/g, '""')}"`).join(','))].join('\n')
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `${t('reports.financialExportFilename')}_${new Date().toLocaleDateString('zh-CN')}.csv`
  link.click()
  message.success(t('reports.exportSuccess'))
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.reports-page { padding: 24px; }
.page-title { font-size: 22px; font-weight: 700; margin: 0 0 16px 0; }
.toolbar-card { margin-bottom: 16px; }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px; margin-bottom: 16px; }
.stat-value { font-size: 24px; font-weight: 600; color: #262626; }
.stat-label { font-size: 14px; color: #8c8c8c; margin-top: 4px; }
.chart-row { margin-bottom: 16px; }
.table-card { margin-top: 16px; }
</style>
