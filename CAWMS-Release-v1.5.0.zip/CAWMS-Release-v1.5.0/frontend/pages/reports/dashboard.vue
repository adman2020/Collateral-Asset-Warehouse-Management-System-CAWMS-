<template>
  <div class="reports-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('reports.dashboard.title') }}</h1>
    </div>

    <!-- 工具栏 -->
    <NCard size="small" class="toolbar-card">
      <NSpace align="center">
        <NDatePicker
          v-model:value="dateRange"
          type="daterange"
          clearable
          :shortcuts="dateShortcuts"
          :placeholder="$t('reports.dateRangePlaceholder')"
          @update:value="handleDateChange"
        />
        <NButton type="primary" @click="loadData">
          <template #icon><NIcon><SearchOutline /></NIcon></template>
          {{ $t('reports.search') }}
        </NButton>
      </NSpace>
    </NCard>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <NCard v-for="s in statCards" :key="s.key" size="small" class="stat-card" @click="navigateTo(s.path)">
        <div class="stat-value">{{ s.value }}</div>
        <div class="stat-label">{{ s.label }}</div>
      </NCard>
    </div>

    <!-- 图表 -->
    <NGrid :cols="2" :x-gap="16" class="chart-row">
      <NGi>
        <NCard :title="$t('reports.assetDistribution')" size="small">
          <v-chart :option="assetPieOption" style="height: 300px;" />
        </NCard>
      </NGi>
      <NGi>
        <NCard :title="$t('reports.statusOverview')" size="small">
          <v-chart :option="statusBarOption" style="height: 300px;" />
        </NCard>
      </NGi>
    </NGrid>

    <!-- 快捷入口 -->
    <NCard :title="$t('reports.quickAccess')" size="small" class="table-card">
      <NSpace>
        <NButton type="info" @click="navigateTo('/reports/inbound')">📦 {{ $t('reports.inboundStatsBtn') }}</NButton>
        <NButton type="success" @click="navigateTo('/reports/loan-out')">📤 {{ $t('reports.loanOutStatsBtn') }}</NButton>
        <NButton type="warning" @click="navigateTo('/reports/overdue')">⚠️ {{ $t('reports.overdueStatsBtn') }}</NButton>
        <NButton type="primary" @click="navigateTo('/reports/financial')">💰 {{ $t('reports.financialReportBtn') }}</NButton>
      </NSpace>
    </NCard>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import {
  NCard, NGrid, NGi, NSpace, NButton, NIcon, NDatePicker, useMessage
} from 'naive-ui'
import { SearchOutline } from '@vicons/ionicons5'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { PieChart, BarChart } from 'echarts/charts'
import {
  TitleComponent, TooltipComponent, LegendComponent, GridComponent
} from 'echarts/components'
import VChart from 'vue-echarts'
import { useI18n } from 'vue-i18n'
import warehouseInApi from '@/api/warehouse-in'
import loanOutApi from '@/api/loan-out'

use([CanvasRenderer, PieChart, BarChart, TitleComponent, TooltipComponent, LegendComponent, GridComponent])

const message = useMessage()
const { t } = useI18n()
const router = useRouter()

const inboundStats = reactive<Record<string, any>>({})
const loanOutStats = reactive<Record<string, any>>({})
const dateRange = ref<[number, number] | null>(null)

const dateShortcuts = computed(() => ({
  [t('reports.last7Days')]: () => { const end = new Date(); const start = new Date(); start.setDate(end.getDate() - 6); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.last30Days')]: () => { const end = new Date(); const start = new Date(); start.setDate(end.getDate() - 29); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.thisMonth')]: () => { const end = new Date(); const start = new Date(end.getFullYear(), end.getMonth(), 1); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.lastMonth')]: () => { const end = new Date(); const start = new Date(end.getFullYear(), end.getMonth() - 1, 1); end.setDate(0); return [start.getTime(), end.getTime()] as [number, number] }
}))

const statCards = computed(() => [
  { key: 'inbound', label: t('reports.inboundTotal'), value: inboundStats.totalApplications || 0, path: '/reports/inbound' },
  { key: 'loan', label: t('reports.loanOutTotal'), value: loanOutStats.totalCount || 0, path: '/reports/loan-out' },
  { key: 'returned', label: t('reports.returned'), value: loanOutStats.returnedCount || 0, path: '/reports/loan-out' },
  { key: 'overdue', label: t('reports.overdueCount'), value: loanOutStats.overdueCount || 0, path: '/reports/overdue' },
  { key: 'totalValue', label: t('reports.collateralValue'), value: formatCurrency((inboundStats.totalCollateralValue || 0) + (loanOutStats.totalLoanValue || 0)), path: '/reports/financial' }
])

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

const assetPieOption = computed(() => {
  const inboundValue = inboundStats.totalCollateralValue || 0
  const loanValue = loanOutStats.totalLoanValue || 0
  return {
    tooltip: { trigger: 'item', formatter: (params: any) => `${params.name}: ${params.value}${t('reports.currencyUnit')} (${params.percent}%)` },
    legend: { orient: 'vertical', left: 'left' },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 10, borderColor: '#fff', borderWidth: 2 },
      label: { show: false },
      emphasis: { label: { show: true, fontSize: 16, fontWeight: 'bold' } },
      data: [
        { name: t('reports.inboundAssets'), value: inboundValue },
        { name: t('reports.loanOutAssets'), value: loanValue }
      ]
    }]
  }
})

const statusBarOption = computed(() => {
  const inbound = inboundStats.applicationsByStatus || {}
  const loan = loanOutStats.statusDistribution || {}
  return {
    tooltip: { trigger: 'axis' },
    legend: { data: [t('reports.inboundLabel'), t('reports.loanOutLabel')] },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: { type: 'category', data: [t('reports.completedLoaned'), t('reports.inReviewPending'), t('status.rejected')] },
    yAxis: { type: 'value' },
    series: [
      { name: t('reports.inboundLabel'), type: 'bar', data: [inbound.APPROVED || 0, inbound.IN_REVIEW || inbound.SUBMITTED || 0, inbound.REJECTED || 0] },
      { name: t('reports.loanOutLabel'), type: 'bar', data: [loan.LOANED || 0, loan.PENDING || 0, loan.REJECTED || 0] }
    ]
  }
})

function getDateParams() {
  if (!dateRange.value) return {}
  const start = new Date(dateRange.value[0]).toISOString().split('T')[0]
  const end = new Date(dateRange.value[1]).toISOString().split('T')[0]
  return { startDate: start, endDate: end }
}

function navigateTo(path: string) {
  router.push(path)
}

async function loadData() {
  try {
    const params = getDateParams()
    const [inData, loData] = await Promise.all([
      warehouseInApi.getStatistics({ startTime: params.startDate ? `${params.startDate}T00:00:00` : undefined, endTime: params.endDate ? `${params.endDate}T23:59:59` : undefined }),
      loanOutApi.getStatistics(params)
    ])
    Object.assign(inboundStats, inData)
    Object.assign(loanOutStats, loData)
  } catch (e: any) {
    message.error(e.message || t('reports.loadFailed'))
  }
}

function handleDateChange() {
  loadData()
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.reports-page { padding: 24px; }
.page-title { font-size: 22px; font-weight: 700; margin: 0 0 16px 0; }
.toolbar-card { margin-bottom: 16px; }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px; margin-bottom: 16px; }
.stat-card { cursor: pointer; transition: transform 0.2s; }
.stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
.stat-value { font-size: 24px; font-weight: 600; color: #262626; }
.stat-label { font-size: 14px; color: #8c8c8c; margin-top: 4px; }
.chart-row { margin-bottom: 16px; }
.table-card { margin-top: 16px; }
</style>
