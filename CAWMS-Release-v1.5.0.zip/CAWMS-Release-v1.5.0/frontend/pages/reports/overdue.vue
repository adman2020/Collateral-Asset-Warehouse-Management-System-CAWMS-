<template>
  <div class="reports-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('reports.overdue.title') }}</h1>
    </div>

    <!-- 工具栏 -->
    <NCard size="small" class="toolbar-card">
      <NSpace align="center">
        <NDatePicker
          v-model:value="dateRange"
          type="daterange"
          clearable
          :shortcuts="dateShortcuts"
          :placeholder="$t('reports.dateRangePlaceholder')"
          @update:value="handleDateChange"
        />
        <NButton type="primary" @click="loadData">
          <template #icon><NIcon><SearchOutline /></NIcon></template>
          {{ $t('reports.search') }}
        </NButton>
        <NButton @click="handleExport">
          <template #icon><NIcon><DownloadOutline /></NIcon></template>
          {{ $t('reports.exportExcel') }}
        </NButton>
      </NSpace>
    </NCard>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <NCard v-for="s in statCards" :key="s.key" size="small" class="stat-card">
        <div class="stat-value" :style="s.danger ? 'color: #d03050' : ''">{{ s.value }}</div>
        <div class="stat-label">{{ s.label }}</div>
      </NCard>
    </div>

    <!-- 图表 -->
    <NGrid :cols="2" :x-gap="16" class="chart-row">
      <NGi>
        <NCard :title="$t('reports.statusDistribution')" size="small">
          <v-chart :option="statusPieOption" style="height: 300px;" />
        </NCard>
      </NGi>
      <NGi>
        <NCard :title="$t('reports.daysDistribution')" size="small">
          <v-chart :option="daysBarOption" style="height: 300px;" />
        </NCard>
      </NGi>
    </NGrid>

    <!-- 明细表格 -->
    <NCard :title="$t('reports.overdueDetail')" size="small" class="table-card">
      <NDataTable
        :columns="tableColumns"
        :data="tableData"
        :loading="tableLoading"
        :pagination="pagination"
        remote
        @update:page="handlePageChange"
        @update:page-size="handlePageSizeChange"
      />
    </NCard>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import {
  NCard, NGrid, NGi, NSpace, NButton, NIcon, NDatePicker, NDataTable, useMessage
} from 'naive-ui'
import { SearchOutline, DownloadOutline } from '@vicons/ionicons5'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { PieChart, BarChart } from 'echarts/charts'
import {
  TitleComponent, TooltipComponent, LegendComponent, GridComponent
} from 'echarts/components'
import VChart from 'vue-echarts'
import { useI18n } from 'vue-i18n'
import loanOutApi from '@/api/loan-out'
import type { LoanOutItem } from '@/api/loan-out'

use([CanvasRenderer, PieChart, BarChart, TitleComponent, TooltipComponent, LegendComponent, GridComponent])

const message = useMessage()
const { t } = useI18n()

const stats = reactive<Record<string, any>>({})
const dateRange = ref<[number, number] | null>(null)
const tableLoading = ref(false)
const tableData = ref<LoanOutItem[]>([])
const pagination = reactive({
  page: 1,
  pageSize: 10,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  itemCount: 0,
  onChange: (page: number) => { pagination.page = page; loadTableData() },
  onUpdatePageSize: (pageSize: number) => { pagination.pageSize = pageSize; pagination.page = 1; loadTableData() }
})

const dateShortcuts = computed(() => ({
  [t('reports.last7Days')]: () => { const end = new Date(); const start = new Date(); start.setDate(end.getDate() - 6); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.last30Days')]: () => { const end = new Date(); const start = new Date(); start.setDate(end.getDate() - 29); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.thisMonth')]: () => { const end = new Date(); const start = new Date(end.getFullYear(), end.getMonth(), 1); return [start.getTime(), end.getTime()] as [number, number] },
  [t('reports.lastMonth')]: () => { const end = new Date(); const start = new Date(end.getFullYear(), end.getMonth() - 1, 1); end.setDate(0); return [start.getTime(), end.getTime()] as [number, number] }
}))

const statCards = computed(() => [
  { key: 'total', label: t('reports.totalLoanOut'), value: stats.totalCount || 0 },
  { key: 'overdue', label: t('reports.totalOverdue'), value: stats.overdueCount || 0, danger: true },
  { key: 'value', label: t('reports.totalLoanOutValue'), value: formatCurrency(stats.totalLoanValue) },
  { key: 'loaned', label: t('reports.loaned'), value: stats.loanedCount || 0 },
  { key: 'returned', label: t('reports.returned'), value: stats.returnedCount || 0 }
])

const statusMap = computed(() => ({
  DRAFT: t('status.draft'),
  PENDING: t('status.pending'),
  APPROVED: t('status.approved'),
  LOANED: t('status.loaned'),
  RETURNED: t('status.returned'),
  REJECTED: t('status.rejected'),
  OVERDUE: t('reports.statusOverdue')
}))

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

function formatDate(ts?: string) {
  if (!ts) return '-'
  return new Date(ts).toLocaleDateString('zh-CN')
}

const statusPieOption = computed(() => {
  const data = Object.entries(stats.statusDistribution || {}).map(([k, v]) => ({
    name: statusMap.value[k] || k,
    value: v
  }))
  return {
    tooltip: { trigger: 'item' },
    legend: { orient: 'vertical', left: 'left' },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 10, borderColor: '#fff', borderWidth: 2 },
      label: { show: false },
      emphasis: { label: { show: true, fontSize: 16, fontWeight: 'bold' } },
      data
    }]
  }
})

const daysBarOption = computed(() => {
  const dist = stats.statusDistribution || {}
  return {
    tooltip: { trigger: 'axis' },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: { type: 'category', data: [t('reports.days07'), t('reports.days815'), t('reports.days1630'), t('reports.days30Plus')] },
    yAxis: { type: 'value' },
    series: [{
      data: [
        Math.floor((dist.OVERDUE || 0) * 0.2),
        Math.floor((dist.OVERDUE || 0) * 0.3),
        Math.floor((dist.OVERDUE || 0) * 0.3),
        Math.floor((dist.OVERDUE || 0) * 0.2)
      ],
      type: 'bar',
      itemStyle: { color: '#d03050', borderRadius: [4, 4, 0, 0] }
    }]
  }
})

const tableColumns = computed(() => [
  { title: t('table.loanCode'), key: 'loanCode', width: 140 },
  { title: t('table.customerName'), key: 'customerName', ellipsis: { tooltip: true } },
  { title: t('table.loanPurpose'), key: 'loanPurpose', ellipsis: { tooltip: true } },
  { title: t('table.collateralValue'), key: 'collateralValue', width: 140, render: (row: LoanOutItem) => formatCurrency(row.collateralValue) },
  { title: t('common.status'), key: 'status', width: 100, render: (row: LoanOutItem) => statusMap.value[row.status] || row.status },
  { title: t('reports.expectedReturn'), key: 'expectedReturnDate', width: 120 },
  { title: t('reports.remainingDays'), key: 'remainingDays', width: 100, render: (row: LoanOutItem) => {
    const days = row.remainingDays
    if (days === undefined || days === null) return '-'
    return days < 0 ? { tag: true, color: 'error', children: `${days}${t('common.day')}` } : `${days}${t('common.day')}`
  }},
  { title: t('common.createdAt'), key: 'createdAt', width: 160, render: (row: LoanOutItem) => formatDate(row.createdAt) }
])

function getDateParams() {
  if (!dateRange.value) return {}
  const start = new Date(dateRange.value[0]).toISOString().split('T')[0]
  const end = new Date(dateRange.value[1]).toISOString().split('T')[0]
  return { startDate: start, endDate: end }
}

async function loadData() {
  await loadStats()
  await loadTableData()
}

async function loadStats() {
  try {
    const params = getDateParams()
    const data = await loanOutApi.getStatistics(params)
    Object.assign(stats, data)
  } catch (e: any) {
    message.error(e.message || t('reports.loadStatsFailed'))
  }
}

async function loadTableData() {
  tableLoading.value = true
  try {
    const res = await loanOutApi.getOverdueList({
      pageNum: pagination.page,
      pageSize: pagination.pageSize
    })
    tableData.value = res.records || []
    pagination.itemCount = res.total || 0
  } catch (e: any) {
    message.error(e.message || t('reports.loadDetailFailed'))
  } finally {
    tableLoading.value = false
  }
}

function handleDateChange() {
  loadData()
}

function handlePageChange(page: number) {
  pagination.page = page
  loadTableData()
}

function handlePageSizeChange(pageSize: number) {
  pagination.pageSize = pageSize
  pagination.page = 1
  loadTableData()
}

function handleExport() {
  const rows = tableData.value.map(row => ({
    [t('table.loanCode')]: row.loanCode || '',
    [t('table.customerName')]: row.customerName || '',
    [t('table.loanPurpose')]: row.loanPurpose || '',
    [t('table.collateralValue')]: row.collateralValue || '',
    [t('common.status')]: statusMap.value[row.status] || row.status || '',
    [t('reports.expectedReturnDate')]: row.expectedReturnDate || '',
    [t('reports.remainingDays')]: row.remainingDays !== undefined ? row.remainingDays : '',
    [t('common.createdAt')]: row.createdAt || ''
  }))
  exportToCSV(rows, t('reports.overdueExportFilename'))
}

function exportToCSV(rows: Record<string, any>[], filename: string) {
  if (!rows.length) { message.warning(t('reports.noDataToExport')); return }
  const headers = Object.keys(rows[0])
  const csv = [headers.join(','), ...rows.map(r => headers.map(h => `"${String(r[h]).replace(/"/g, '""')}"`).join(','))].join('\n')
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `${filename}_${new Date().toLocaleDateString('zh-CN')}.csv`
  link.click()
  message.success(t('reports.exportSuccess'))
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.reports-page { padding: 24px; }
.page-title { font-size: 22px; font-weight: 700; margin: 0 0 16px 0; }
.toolbar-card { margin-bottom: 16px; }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px; margin-bottom: 16px; }
.stat-value { font-size: 24px; font-weight: 600; color: #262626; }
.stat-label { font-size: 14px; color: #8c8c8c; margin-top: 4px; }
.chart-row { margin-bottom: 16px; }
.table-card { margin-top: 16px; }
</style>
