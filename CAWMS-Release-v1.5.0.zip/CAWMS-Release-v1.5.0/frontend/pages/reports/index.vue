<template>
  <div class="reports-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('reports.index.title') }}</h1>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #e6f7ff;">📦</div>
        <div class="stat-content">
          <div class="stat-value">{{ stats?.inboundTotal || 0 }}</div>
          <div class="stat-label">{{ $t('reports.inboundTotal') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #f6ffed;">📤</div>
        <div class="stat-content">
          <div class="stat-value">{{ stats?.loanOutTotal || 0 }}</div>
          <div class="stat-label">{{ $t('reports.loanOutTotal') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #fff7e6;">⚠️</div>
        <div class="stat-content">
          <div class="stat-value">{{ stats?.overdueCount || 0 }}</div>
          <div class="stat-label">{{ $t('reports.overdueCount') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #f0f5ff;">⏳</div>
        <div class="stat-content">
          <div class="stat-value">{{ stats?.pendingApprovals || 0 }}</div>
          <div class="stat-label">{{ $t('reports.pendingApprovals') }}</div>
        </div>
      </n-card>
    </div>

    <!-- 报表列表 -->
    <n-grid :cols="2" :x-gap="24" :y-gap="16">
      <n-gi v-for="report in reports" :key="report.id">
        <n-card :title="report.reportName" hoverable>
          <template #header-extra>
            <n-tag :type="getReportTypeColor(report.reportType)">{{ getReportTypeName(report.reportType) }}</n-tag>
          </template>
          <p>{{ report.description || $t('reports.noDescription') }}</p>
          <div class="card-actions">
            <n-button size="small" @click="handleView(report)">{{ $t('common.view') }}</n-button>
            <n-button size="small" type="primary" @click="handleExport(report)">{{ $t('reports.exportExcel') }}</n-button>
            <n-button size="small" @click="handleExportPDF(report)">{{ $t('reports.exportPDF') }}</n-button>
          </div>
        </n-card>
      </n-gi>
    </n-grid>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { getReportDefinitions, getDashboardStats, type ReportDefinition, type DashboardStat } from '~/api/reports'

const message = useMessage()
const { t } = useI18n()
const reports = ref<ReportDefinition[]>([])
const stats = ref<DashboardStat>()

const getReportTypeName = (type: string) => {
  const map: Record<string, string> = {
    INBOUND: t('reports.reportTypes.inbound'),
    LOAN_OUT: t('reports.reportTypes.loanOut'),
    TRANSFER: t('reports.reportTypes.transfer'),
    WAREHOUSE_OUT: t('reports.reportTypes.warehouseOut'),
    OVERDUE: t('reports.reportTypes.overdue'),
    CUSTOM: t('reports.reportTypes.custom')
  }
  return map[type] || type
}

const getReportTypeColor = (type: string) => {
  const map: Record<string, any> = {
    INBOUND: 'info',
    LOAN_OUT: 'success',
    TRANSFER: 'warning',
    WAREHOUSE_OUT: 'error',
    OVERDUE: 'error',
    CUSTOM: 'default'
  }
  return map[type] || 'default'
}

const loadReports = async () => {
  try {
    const res = await getReportDefinitions()
    if (res.data.code === 0) reports.value = res.data.data
  } catch (error) {
    message.error(t('reports.loadReportDefFailed'))
  }
}

const loadStats = async () => {
  try {
    const res = await getDashboardStats()
    if (res.data.code === 0) stats.value = res.data.data
  } catch (error) {
    console.error(t('reports.loadStatsFailed'), error)
  }
}

const handleView = (report: ReportDefinition) => {
  message.info(`${t('reports.viewReport')}: ${report.reportName}`)
}

const handleExport = (report: ReportDefinition) => {
  message.success(`${t('reports.exportExcel')}: ${report.reportName}`)
}

const handleExportPDF = (report: ReportDefinition) => {
  message.success(`${t('reports.exportPDF')}: ${report.reportName}`)
}

onMounted(() => {
  loadReports()
  loadStats()
})
</script>

<style scoped>
.reports-page { padding: 24px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
.page-title { font-size: 24px; font-weight: 600; color: #333; }
.stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
.stat-card { display: flex; align-items: center; gap: 16px; }
.stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; }
.stat-content { flex: 1; }
.stat-value { font-size: 24px; font-weight: 600; color: #333; }
.stat-label { font-size: 14px; color: #666; margin-top: 4px; }
.card-actions { display: flex; gap: 8px; margin-top: 16px; }
</style>
