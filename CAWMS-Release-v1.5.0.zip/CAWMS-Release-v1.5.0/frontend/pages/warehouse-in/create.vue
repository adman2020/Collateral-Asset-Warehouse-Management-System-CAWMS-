<template>
  <div class="create-warehouse-in-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ isEdit ? $t('warehouseIn.editTitle') : $t('warehouseIn.createTitle') }}</h1>
        <p class="page-subtitle">{{ $t('warehouseIn.createSubtitle') }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="handleCancel">{{ $t('common.cancel') }}</NButton>
        <NButton type="info" :loading="saving" @click="handleSaveDraft">{{ $t('warehouseIn.saveDraft') }}</NButton>
        <NButton type="primary" :loading="submitting" @click="handleSubmit">{{ $t('warehouseIn.submitApplication') }}</NButton>
      </div>
    </div>

    <NCard :title="$t('warehouseIn.basicInfo')" size="small" class="form-section">
      <NForm ref="formRef" :model="form" :rules="rules" label-placement="left" label-width="140px">
        <NGrid :cols="2" :x-gap="24">
          <NGi>
            <NFormItem :label="$t('warehouseIn.buCode')" path="buCode">
              <NSelect v-model:value="form.buCode" :options="buOptions" :placeholder="$t('warehouseIn.pleaseSelectBuCode')" />
            </NFormItem>
          </NGi>
          <NGi>
            <NFormItem :label="$t('warehouseIn.buName')" path="buName">
              <NInput v-model:value="form.buName" :placeholder="$t('warehouseIn.buNamePlaceholder')" />
            </NFormItem>
          </NGi>
          <NGi>
            <NFormItem :label="$t('warehouseIn.customerId')" path="customerId">
              <NInput v-model:value="form.customerId" :placeholder="$t('warehouseIn.pleaseInputCustomerId')" />
            </NFormItem>
          </NGi>
          <NGi>
            <NFormItem :label="$t('warehouseIn.customerName')" path="customerName">
              <NInput v-model:value="form.customerName" :placeholder="$t('warehouseIn.pleaseInputCustomerName')" />
            </NFormItem>
          </NGi>
          <NGi>
            <NFormItem :label="$t('warehouseIn.collateralType')" path="collateralType">
              <NSelect v-model:value="form.collateralType" :options="collateralTypeOptions" :placeholder="$t('warehouseIn.pleaseSelectCollateralType')" />
            </NFormItem>
          </NGi>
          <NGi>
            <NFormItem :label="$t('warehouseIn.collateralValue')" path="collateralValue">
              <NInputNumber v-model:value="form.collateralValue" :min="0" :precision="2" :placeholder="$t('warehouseIn.pleaseInputCollateralValue')" style="width: 100%" />
            </NFormItem>
          </NGi>
          <NGi>
            <NFormItem :label="$t('warehouseIn.creditAgreementNo')" path="creditAgreementNo">
              <NInput v-model:value="form.creditAgreementNo" :placeholder="$t('warehouseIn.pleaseInputCreditAgreementNo')" />
            </NFormItem>
          </NGi>
          <NGi>
            <NFormItem :label="$t('warehouseIn.intakeType')" path="intakeType">
              <NSelect v-model:value="form.intakeType" :options="intakeTypeOptions" :placeholder="$t('warehouseIn.pleaseSelectIntakeType')" />
            </NFormItem>
          </NGi>
          <NGi>
            <NFormItem :label="$t('warehouseIn.zone')" path="zoneId">
              <NSelect v-model:value="form.zoneId" :options="zoneOptions" :placeholder="$t('warehouseIn.pleaseSelectZone')" clearable @update:value="handleZoneChange" />
            </NFormItem>
          </NGi>
          <NGi>
            <NFormItem :label="$t('warehouseIn.warehouse')" path="warehouseId">
              <NSelect v-model:value="form.warehouseId" :options="warehouseOptions" :placeholder="$t('warehouseIn.pleaseSelectWarehouse')" clearable :disabled="!form.zoneId" />
            </NFormItem>
          </NGi>
          <NGi v-if="selectedZoneType">
            <NFormItem :label="$t('warehouseIn.warehouseType')">
              <NTag :type="selectedZoneType === 'SUPERVISED' ? 'warning' : 'info'">
                {{ selectedZoneType === 'SUPERVISED' ? $t('system.warehouseZone.zoneTypes.supervised') : $t('system.warehouseZone.zoneTypes.selfManaged') }}
              </NTag>
            </NFormItem>
          </NGi>
          <NGi :span="2">
            <NFormItem :label="$t('warehouseIn.remarks')" path="remarks">
              <NInput v-model:value="form.remarks" type="textarea" :rows="3" :placeholder="$t('warehouseIn.pleaseInputRemarks')" />
            </NFormItem>
          </NGi>
        </NGrid>
      </NForm>
    </NCard>

    <NCard :title="$t('warehouseIn.attachmentUpload')" size="small" class="form-section">
      <FileUpload v-model="uploadedFiles" accept="*/*" multiple :max-size="20 * 1024 * 1024" />
    </NCard>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { NCard, NButton, NForm, NFormItem, NInput, NSelect, NInputNumber, NGrid, NGi, useMessage, type FormInst, type FormRules } from 'naive-ui'
import FileUpload from '@/components/common/FileUpload.vue'
import warehouseInApi, { type WarehouseInCreateParams, type WarehouseInUpdateParams } from '@/api/warehouse-in'
import warehouseZoneApi, { type WarehouseZoneItem } from '@/api/warehouse-zone'
import warehouseApi, { type WarehouseItem } from '@/api/warehouse'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const route = useRoute()
const message = useMessage()
const authStore = useAuthStore()
const { t } = useI18n()

const isEdit = ref(false)
const editId = ref<string | number>('')

onMounted(() => {
  loadZones()
  const editIdFromQuery = route.query.editId as string
  const editIdFromParams = route.params.id as string
  if (editIdFromQuery) {
    isEdit.value = true
    editId.value = editIdFromQuery
    loadDetail(editId.value)
  } else if (route.query.mode === 'edit' && editIdFromParams && editIdFromParams !== 'create') {
    isEdit.value = true
    editId.value = editIdFromParams
    loadDetail(editId.value)
  }
})

async function loadDetail(id: string | number) {
  try {
    const detail = await warehouseInApi.getDetail(id)
    // 后端返回的是 WarehouseInDetail，实际数据在 warehouseIn 字段中
    const entity = (detail as any).warehouseIn || detail
    Object.assign(form, {
      buCode: entity.buCode,
      buName: entity.buName || '',
      customerId: entity.customerId || '',
      customerName: entity.customerName,
      collateralType: entity.collateralType,
      collateralValue: entity.collateralValue,
      creditAgreementNo: entity.creditAgreementNo || '',
      intakeType: entity.intakeType,
      zoneId: entity.zoneId || null,
      warehouseId: entity.warehouseId || null,
      remarks: entity.remarks || ''
    })
    if (form.zoneId) {
      await loadWarehousesByZone(form.zoneId as string | number)
    }
    // 如有附件数据也一并回填
    if ((detail as any).files && Array.isArray((detail as any).files)) {
      uploadedFiles.value = (detail as any).files
    }
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.loadDetailFailed'))
  }
}

const formRef = ref<FormInst | null>(null)
const form = reactive({
  buCode: '',
  buName: '',
  customerId: '',
  customerName: '',
  collateralType: '',
  collateralValue: 0,
  creditAgreementNo: '',
  intakeType: '',
  zoneId: null as string | number | null,
  warehouseId: null as string | number | null,
  remarks: ''
})

const uploadedFiles = ref<File[]>([])
const saving = ref(false)
const submitting = ref(false)
const zoneOptions = ref<{ label: string; value: string | number }[]>([])
const warehouseOptions = ref<{ label: string; value: string | number }[]>([])
const zoneList = ref<WarehouseZoneItem[]>([])
const selectedZoneType = computed(() => {
  if (!form.zoneId) return null
  const z = zoneList.value.find(item => String(item.id) === String(form.zoneId))
  return z ? z.zoneType : null
})

async function loadZones() {
  try {
    const list = await warehouseZoneApi.getAllActive()
    zoneList.value = list || []
    zoneOptions.value = (list || []).map(z => ({ label: `${z.zoneName} (${z.zoneType === 'SUPERVISED' ? t('system.warehouseZone.zoneTypes.supervised') : t('system.warehouseZone.zoneTypes.selfManaged')})`, value: z.id }))
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.loadZoneFailed'))
  }
}

async function loadWarehousesByZone(zoneId: string | number) {
  try {
    const list = await warehouseApi.getByZoneId(zoneId)
    warehouseOptions.value = (list || []).map(w => ({ label: w.warehouseName, value: w.id }))
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.loadWarehouseFailed'))
  }
}

function handleZoneChange(val: string | number | null) {
  form.warehouseId = null
  warehouseOptions.value = []
  if (val) {
    loadWarehousesByZone(val)
  }
}

const buOptions = computed(() => [
  { label: t('warehouseIn.buOptions.RBU'), value: 'RBU' },
  { label: t('warehouseIn.buOptions.CBU'), value: 'CBU' },
  { label: t('warehouseIn.buOptions.FMU'), value: 'FMU' },
  { label: t('warehouseIn.buOptions.RMU'), value: 'RMU' }
])

const collateralTypeOptions = computed(() => [
  { label: t('warehouseIn.collateralTypes.realEstate'), value: 'REAL_ESTATE' },
  { label: t('warehouseIn.collateralTypes.movable'), value: 'MOVABLE' },
  { label: t('warehouseIn.collateralTypes.rights'), value: 'RIGHTS' },
  { label: t('warehouseIn.collateralTypes.margin'), value: 'MARGIN' },
  { label: t('warehouseIn.collateralTypes.other'), value: 'OTHER' }
])

const intakeTypeOptions = computed(() => [
  { label: t('warehouseIn.intakeTypes.new'), value: 'NEW' },
  { label: t('warehouseIn.intakeTypes.reintake'), value: 'REINTAKE' },
  { label: t('warehouseIn.intakeTypes.transfer'), value: 'TRANSFER' },
  { label: t('warehouseIn.intakeTypes.buyback'), value: 'BUYBACK' }
])

const rules: FormRules = {
  buCode: [{ required: true, message: t('warehouseIn.pleaseSelectBuCode'), trigger: 'change' }],
  customerName: [{ required: true, message: t('warehouseIn.pleaseInputCustomerName'), trigger: 'blur' }],
  collateralType: [{ required: true, message: t('warehouseIn.pleaseSelectCollateralType'), trigger: 'change' }],
  collateralValue: [{ required: true, type: 'number', min: 0.01, message: t('warehouseIn.collateralValueMinError'), trigger: 'blur' }],
  intakeType: [{ required: true, message: t('warehouseIn.pleaseSelectIntakeType'), trigger: 'change' }],
  zoneId: [{ required: true, type: 'number', message: t('warehouseIn.pleaseSelectZone'), trigger: 'change' }],
  warehouseId: [{ required: true, type: 'number', message: t('warehouseIn.pleaseSelectWarehouse'), trigger: 'change' }]
}

function handleCancel() {
  router.back()
}

async function handleSaveDraft() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  saving.value = true
  try {
    const payload: WarehouseInCreateParams = {
      ...form,
      uploader: authStore.userFullName || 'system',
      files: uploadedFiles.value.length > 0 ? uploadedFiles.value : undefined
    }
    if (isEdit.value) {
      await warehouseInApi.update(editId.value, { ...payload, updater: payload.uploader })
      message.success(t('message.updateSuccess'))
    } else {
      await warehouseInApi.createDraft(payload)
      message.success(t('warehouseIn.draftSaved'))
    }
    router.push('/warehouse-in')
  } catch (e: any) {
    message.error(e.message || t('message.saveFailed'))
  } finally {
    saving.value = false
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  submitting.value = true
  try {
    if (isEdit.value) {
      await warehouseInApi.update(editId.value, {
        ...form,
        updater: authStore.userFullName || 'system',
        files: uploadedFiles.value.length > 0 ? uploadedFiles.value : undefined
      })
      await warehouseInApi.submit(editId.value, authStore.userFullName || 'system')
    } else {
      const id = await warehouseInApi.createDraft({
        ...form,
        uploader: authStore.userFullName || 'system',
        files: uploadedFiles.value.length > 0 ? uploadedFiles.value : undefined
      })
      await warehouseInApi.submit(id, authStore.userFullName || 'system')
    }
    message.success(t('warehouseIn.submitSuccessWithFlow'))
    router.push('/warehouse-in')
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.submitFailed'))
  } finally {
    submitting.value = false
  }
}
</script>

<style scoped>
.create-warehouse-in-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.page-subtitle {
  font-size: 14px;
  color: var(--text-color-secondary);
  margin: 4px 0 0;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.form-section {
  margin-bottom: 16px;
}
</style>
