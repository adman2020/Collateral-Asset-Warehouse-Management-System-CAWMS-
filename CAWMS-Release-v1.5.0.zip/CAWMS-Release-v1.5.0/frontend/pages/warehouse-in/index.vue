<template>
  <div class="warehouse-in-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('warehouseIn.title') }}</h1>
        <p class="page-subtitle">{{ $t('warehouseIn.subtitle') }}</p>
      </div>
      <div class="header-actions">
        <NButton type="primary" @click="handleCreate">
          <template #icon><NIcon><AddOutline /></NIcon></template>
          {{ $t('warehouseIn.createBtn') }}
        </NButton>
        <NButton @click="handleRefresh">
          <template #icon><NIcon><RefreshOutline /></NIcon></template>
          {{ $t('common.refresh') }}
        </NButton>
      </div>
    </div>

    <NCard class="filter-card" size="small">
      <NGrid :cols="4" :x-gap="12" :y-gap="12">
        <NGi>
          <NInput v-model:value="filterParams.keyword" :placeholder="$t('warehouseIn.searchPlaceholder')" clearable />
        </NGi>
        <NGi>
          <NSelect v-model:value="filterParams.buCode" :options="buOptions" :placeholder="$t('warehouseIn.buCode')" clearable />
        </NGi>
        <NGi>
          <NSelect v-model:value="filterParams.collateralType" :options="collateralTypeOptions" :placeholder="$t('warehouseIn.collateralType')" clearable />
        </NGi>
        <NGi>
          <NSelect v-model:value="filterParams.intakeType" :options="intakeTypeOptions" :placeholder="$t('warehouseIn.intakeType')" clearable />
        </NGi>
        <NGi>
          <NSelect v-model:value="filterParams.status" :options="statusOptions" :placeholder="$t('common.status')" clearable />
        </NGi>
        <NGi :span="2">
          <NDatePicker v-model:value="dateRange" type="datetimerange" clearable :placeholder="$t('warehouseIn.dateRange')" />
        </NGi>
        <NGi>
          <NSpace>
            <NButton type="primary" @click="loadData">{{ $t('common.search') }}</NButton>
            <NButton @click="handleReset">{{ $t('common.reset') }}</NButton>
          </NSpace>
        </NGi>
      </NGrid>
    </NCard>

    <!-- DEPLOY_VER: 2026-04-15-02 -->
    <div class="stats-grid">
      <NCard v-for="s in statCards" :key="s.key" size="small" class="stat-card">
        <div class="stat-value">{{ s.value }}</div>
        <div class="stat-label">{{ s.label }}</div>
      </NCard>
    </div>

    <DataTable
      :data="tableData"
      :columns="tableColumns"
      :loading="loading"
      :pagination="pagination"
      @update:page="handlePageChange"
      @update:page-size="handlePageSizeChange"
    >
      <template #status="{ row }">
        <NTag :type="getStatusType(row.status)">{{ formatStatus(row.status) }}</NTag>
      </template>
      <template #actions="{ row }">
        <NSpace size="small">
          <NButton size="small" @click="handleView(row)">{{ $t('common.view') }}</NButton>
          <NButton size="small" :disabled="!canEdit(row)" @click="handleEdit(row)">{{ $t('common.edit') }}</NButton>
          <NButton size="small" type="primary" :disabled="!canSubmit(row)" @click="handleSubmit(row)">{{ $t('common.submit') }}</NButton>
          <NButton size="small" type="warning" :disabled="!canApprove(row)" @click="handleApprove(row)">{{ $t('common.approve') }}</NButton>
          <NButton size="small" type="error" :disabled="!canDelete(row)" @click="handleDelete(row)">{{ $t('common.delete') }}</NButton>
        </NSpace>
      </template>
    </DataTable>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, h, watch, onActivated, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  NCard, NButton, NIcon, NTag, NInput, NSelect, NDatePicker, NGrid, NGi, NSpace, useMessage, useDialog, NPopconfirm
} from 'naive-ui'
import { AddOutline, RefreshOutline } from '@vicons/ionicons5'
import DataTable from '@/components/common/DataTable.vue'
import warehouseInApi, { type WarehouseInItem, type WarehouseInPageResult, type WarehouseInStats } from '@/api/warehouse-in'
import warehouseZoneApi, { type WarehouseZoneItem } from '@/api/warehouse-zone'
import warehouseApi, { type WarehouseItem } from '@/api/warehouse'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const route = useRoute()
const message = useMessage()
const dialog = useDialog()
const authStore = useAuthStore()
const { t } = useI18n()

// 页面元信息
definePageMeta({
  middleware: ['auth'],
  layout: 'default',
  meta: { title: '抵押资产入库管理', requiresAuth: true }
})

// 筛选条件
const filterParams = reactive({
  keyword: '',
  buCode: null as string | null,
  collateralType: null as string | null,
  intakeType: null as string | null,
  status: null as string | null,
  currentStep: undefined as number | undefined,
  pageNum: 1,
  pageSize: 10
})

const dateRange = ref<[number, number] | null>(null)

const buOptions = computed(() => [
  { label: t('warehouseIn.buOptions.RBU'), value: 'RBU' },
  { label: t('warehouseIn.buOptions.CBU'), value: 'CBU' },
  { label: t('warehouseIn.buOptions.FMU'), value: 'FMU' },
  { label: t('warehouseIn.buOptions.RMU'), value: 'RMU' }
])

const collateralTypeOptions = computed(() => [
  { label: t('warehouseIn.collateralTypes.realEstate'), value: 'REAL_ESTATE' },
  { label: t('warehouseIn.collateralTypes.movable'), value: 'MOVABLE' },
  { label: t('warehouseIn.collateralTypes.rights'), value: 'RIGHTS' },
  { label: t('warehouseIn.collateralTypes.margin'), value: 'MARGIN' },
  { label: t('warehouseIn.collateralTypes.other'), value: 'OTHER' }
])

const intakeTypeOptions = computed(() => [
  { label: t('warehouseIn.intakeTypes.new'), value: 'NEW' },
  { label: t('warehouseIn.intakeTypes.reintake'), value: 'REINTAKE' },
  { label: t('warehouseIn.intakeTypes.transfer'), value: 'TRANSFER' },
  { label: t('warehouseIn.intakeTypes.buyback'), value: 'BUYBACK' }
])

const statusOptions = computed(() => [
  { label: t('status.draft'), value: 'DRAFT' },
  { label: t('status.submitted'), value: 'SUBMITTED' },
  { label: t('status.inReview'), value: 'IN_REVIEW' },
  { label: t('status.approved'), value: 'APPROVED' },
  { label: t('status.rejected'), value: 'REJECTED' },
  { label: t('status.completed'), value: 'COMPLETED' }
])

// 表格数据
const loading = ref(false)
const tableData = ref<WarehouseInItem[]>([])
const totalCount = ref(0)

const pagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  prefix: () => h('span', {}, t('warehouseIn.paginationTotal', { count: totalCount.value }))
})

const zoneMap = ref<Record<string, WarehouseZoneItem>>({})
const warehouseMap = ref<Record<string, WarehouseItem>>({})

const tableColumns = computed(() => [
  { title: t('table.whCode'), key: 'whCode', width: 140 },
  { title: t('table.buCode'), key: 'buName', width: 120 },
  { title: t('table.customerName'), key: 'customerName', minWidth: 160, ellipsis: { tooltip: true } },
  { title: t('table.collateralType'), key: 'collateralType', width: 120 },
  { title: t('table.collateralValue'), key: 'collateralValue', width: 140,
    render: (row: WarehouseInItem) => formatCurrency(row.collateralValue) },
  { title: t('table.intakeType'), key: 'intakeType', width: 120 },
  {
    title: t('warehouseIn.zone'),
    key: 'zoneId',
    width: 120,
    render: (row: WarehouseInItem) => zoneMap.value[String(row.zoneId)]?.zoneName || '-'
  },
  {
    title: t('warehouseIn.warehouse'),
    key: 'warehouseId',
    width: 120,
    render: (row: WarehouseInItem) => warehouseMap.value[String(row.warehouseId)]?.warehouseName || '-'
  },
  {
    title: t('warehouseIn.warehouseType'),
    key: 'zoneType',
    width: 100,
    render: (row: WarehouseInItem) => {
      const type = zoneMap.value[String(row.zoneId)]?.zoneType
      return type === 'SUPERVISED' ? t('system.warehouseZone.zoneTypes.supervised') : type === 'SELF_MANAGED' ? t('system.warehouseZone.zoneTypes.selfManaged') : '-'
    }
  },
  { title: t('common.status'), key: 'status', width: 100, slot: 'status' },
  { title: t('table.currentStep'), key: 'currentStep', width: 90 },
  { title: t('table.submittedAt'), key: 'submittedAt', width: 160 },
  { title: t('table.operation'), key: 'actions', width: 280, fixed: 'right', slot: 'actions' }
])

// 统计
const stats = reactive<Partial<WarehouseInStats>>({})
const statCards = computed(() => [
  { key: 'drafts', label: t('status.draft'), value: stats.totalDrafts || 0 },
  { key: 'submitted', label: t('status.submitted'), value: stats.totalSubmitted || 0 },
  { key: 'inReview', label: t('status.inReview'), value: stats.totalInReview || 0 },
  { key: 'approved', label: t('status.approved'), value: stats.totalApproved || 0 },
  { key: 'completed', label: t('status.completed'), value: stats.totalCompleted || 0 }
])

// 格式化
function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

function formatStatus(status?: string) {
  const map: Record<string, string> = {
    DRAFT: t('status.draft'),
    SUBMITTED: t('status.submitted'),
    IN_REVIEW: t('status.inReview'),
    APPROVED: t('status.approved'),
    REJECTED: t('status.rejected'),
    COMPLETED: t('status.completed')
  }
  return map[status || ''] || status || '-'
}

function getStatusType(status?: string) {
  const map: Record<string, any> = {
    DRAFT: 'default',
    SUBMITTED: 'info',
    IN_REVIEW: 'warning',
    APPROVED: 'success',
    REJECTED: 'error',
    COMPLETED: 'success'
  }
  return map[status || ''] || 'default'
}

// 权限判断
function canEdit(row: WarehouseInItem) {
  if (authStore.isAdmin) return true
  return ['DRAFT', 'REJECTED'].includes(row.status)
}
function canSubmit(row: WarehouseInItem) {
  return row.status === 'DRAFT'
}
function canApprove(row: WarehouseInItem) {
  if (!['SUBMITTED', 'IN_REVIEW'].includes(row.status)) return false
  const userRole = authStore.user?.role || ''
  const step = row.currentStep || 1
  const stepRoleMap: Record<number, string> = {
    1: 'BUSINESS_MANAGER',
    2: 'RISK_OFFICER',
    3: 'COMPLIANCE_OFFICER',
    4: 'WAREHOUSE_MANAGER'
  }
  const requiredRole = stepRoleMap[step]
  if (!requiredRole) return false
  return authStore.isAdmin || userRole === requiredRole
}
function canDelete(row: WarehouseInItem) {
  return ['DRAFT', 'REJECTED'].includes(row.status)
}

// 数据加载
async function loadData() {
  loading.value = true
  try {
    const params: any = {
      ...filterParams,
      pageNum: pagination.page,
      pageSize: pagination.pageSize
    }
    if (dateRange.value) {
      params.startTime = new Date(dateRange.value[0]).toISOString()
      params.endTime = new Date(dateRange.value[1]).toISOString()
    }

    const [result, zones, warehouses] = await Promise.all([
      warehouseInApi.getList(params) as Promise<WarehouseInPageResult>,
      warehouseZoneApi.getAllActive().catch(() => []),
      warehouseApi.getAllActive().catch(() => [])
    ])
    tableData.value = result.records || []
    totalCount.value = result.total || 0
    pagination.pageCount = result.pages || 1

    zoneMap.value = {}
    for (const z of zones) {
      zoneMap.value[String(z.id)] = z
    }
    warehouseMap.value = {}
    for (const w of warehouses) {
      warehouseMap.value[String(w.id)] = w
    }

    const statResult = await warehouseInApi.getStatistics({})
    const byStatus = (statResult as any).applicationsByStatus || statResult.byStatus || {}
    stats.totalDrafts = byStatus.DRAFT || 0
    stats.totalSubmitted = byStatus.SUBMITTED || 0
    stats.totalInReview = byStatus.IN_REVIEW || 0
    stats.totalApproved = byStatus.APPROVED || 0
    stats.totalCompleted = byStatus.COMPLETED || 0
    Object.assign(stats, statResult)
  } catch (e: any) {
    console.error(t('warehouseIn.apiLoadFailed'), e)
    message.error(e.message || t('warehouseIn.listLoadFailed'))
    tableData.value = []
    totalCount.value = 0
    pagination.pageCount = 1
  } finally {
    loading.value = false
  }
}

function generateMockData(): WarehouseInItem[] {
  return Array.from({ length: 15 }).map((_, i) => ({
    id: i + 1,
    whCode: `WH-2024-${String(i + 1).padStart(4, '0')}`,
    buCode: 'RBU',
    buName: t('warehouseIn.buOptions.RBU'),
    customerId: `CUST-${1000 + i}`,
    customerName: `${t('warehouseIn.customerLabel')} ${String.fromCharCode(65 + i)}`,
    collateralType: ['REAL_ESTATE', 'MOVABLE', 'RIGHTS', 'MARGIN'][i % 4],
    collateralValue: 1000000 + i * 50000,
    creditAgreementNo: `AGR-${2024000 + i}`,
    intakeType: ['NEW', 'REINTAKE', 'TRANSFER'][i % 3],
    status: ['DRAFT', 'SUBMITTED', 'APPROVED', 'COMPLETED'][i % 4],
    currentStep: i % 4 === 0 ? 0 : i % 4 === 1 ? 1 : i % 4 === 2 ? 3 : 4,
    submittedAt: new Date(Date.now() - i * 86400000).toISOString(),
    remarks: ''
  }))
}

function handlePageChange(page: number) {
  pagination.page = page
  loadData()
}
function handlePageSizeChange(size: number) {
  pagination.pageSize = size
  pagination.page = 1
  loadData()
}
function handleReset() {
  filterParams.keyword = ''
  filterParams.buCode = null
  filterParams.collateralType = null
  filterParams.intakeType = null
  filterParams.status = null
  dateRange.value = null
  pagination.page = 1
  loadData()
}
function handleRefresh() {
  loadData()
}
function handleCreate() {
  router.push('/warehouse-in/create')
}
function handleView(row: WarehouseInItem) {
  router.push(`/warehouse-in/${row.id}`)
}
function handleEdit(row: WarehouseInItem) {
  router.push(`/warehouse-in/create?editId=${row.id}`)
}
async function handleSubmit(row: WarehouseInItem) {
  try {
    await warehouseInApi.submit(row.id, authStore.userFullName || 'system')
    message.success(t('warehouseIn.submitSuccess'))
    loadData()
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.submitFailed'))
  }
}
function handleApprove(row: WarehouseInItem) {
  dialog.create({
    title: t('warehouseIn.approveTitle'),
    content: () => h('div', {}, t('warehouseIn.approveConfirm', { code: row.whCode || row.id })),
    positiveText: t('common.confirm'),
    negativeText: t('common.cancel'),
    onPositiveClick: async () => {
      try {
        await warehouseInApi.approve(row.id, row.currentStep || 1, {
          approverUser: authStore.user?.username || 'system',
          approverRole: authStore.user?.role || '',
          comments: t('warehouseIn.agree')
        })
        message.success(t('warehouseIn.approveSuccess'))
        loadData()
      } catch (e: any) {
        message.error(e.message || t('warehouseIn.approveFailed'))
      }
    }
  })
}
function handleDelete(row: WarehouseInItem) {
  dialog.warning({
    title: t('warehouseIn.deleteTitle'),
    content: t('warehouseIn.deleteConfirm', { code: row.whCode || row.id }),
    positiveText: t('common.delete'),
    negativeText: t('common.cancel'),
    onPositiveClick: async () => {
      try {
        await warehouseInApi.delete(row.id)
        message.success(t('warehouseIn.deleteSuccess'))
        loadData()
      } catch (e: any) {
        message.error(e.message || t('warehouseIn.deleteFailed'))
      }
    }
  })
}

onMounted(() => {
  // 从 URL query 读取初始筛选状态
  if (route.query.status) {
    filterParams.status = route.query.status as string
  }
  loadData()
})

// 监听路由 query 变化（例如从 /warehouse-in?status=SUBMITTED 回到 /warehouse-in）
watch(() => route.query, (newQuery) => {
  if (newQuery.status) {
    filterParams.status = newQuery.status as string
  } else {
    filterParams.status = null
  }
  pagination.page = 1
  loadData()
}, { deep: true })

onActivated(() => {
  // 从 keep-alive 恢复时刷新数据
  loadData()
})
</script>

<style scoped>
.warehouse-in-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.page-subtitle {
  font-size: 14px;
  color: var(--text-color-secondary);
  margin: 4px 0 0;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.filter-card {
  margin-bottom: 16px;
}
.stats-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 12px;
  margin-bottom: 16px;
}
.stat-card {
  text-align: center;
  padding: 8px 4px;
}
.stat-value {
  font-size: 22px;
  font-weight: 700;
  color: #1890ff;
}
.stat-label {
  font-size: 12px;
  color: var(--text-color-secondary);
  margin-top: 2px;
}
@media (max-width: 1200px) {
  .stats-grid { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 768px) {
  .stats-grid { grid-template-columns: repeat(2, 1fr); }
  .page-header { flex-direction: column; align-items: flex-start; gap: 12px; }
}
</style>
