<template>
  <div class="warehouse-in-approval-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('warehouseIn.approvalTitle') }}</h1>
        <p class="page-subtitle">
          {{ $t('warehouseIn.whCodeLabel') }}: {{ detail.whCode || detail.id }} | {{ $t('warehouseIn.customerLabel') }}: {{ detail.customerName }} | {{ $t('common.status') }}: {{ formatStatus(detail.status) }}
        </p>
      </div>
      <div class="header-actions">
        <NButton @click="router.back()">{{ $t('common.back') }}</NButton>
        <NButton type="info" @click="router.push(`/warehouse-in/${id}`)">{{ $t('warehouseIn.viewDetail') }}</NButton>
      </div>
    </div>

    <NGrid :cols="3" :x-gap="16" :y-gap="16">
      <NGi :span="2">
        <NCard :title="$t('warehouseIn.approvalProgress')" size="small" class="progress-card">
          <NSteps :current="currentStep" status="process">
            <NStep :title="$t('warehouseIn.stepSubmit')" :description="submitDesc" />
            <NStep :title="$t('warehouseIn.stepBusinessReview')" :description="stepDesc(1)" />
            <NStep :title="$t('warehouseIn.stepRiskReview')" :description="stepDesc(2)" />
            <NStep :title="$t('warehouseIn.stepComplianceReview')" :description="stepDesc(3)" />
            <NStep :title="$t('warehouseIn.stepWarehouseConfirm')" :description="stepDesc(4)" />
          </NSteps>
        </NCard>

        <NCard :title="$t('warehouseIn.approvalOperation')" size="small" class="approval-card">
          <NForm ref="formRef" :model="form" :rules="rules" label-placement="left" label-width="100px">
            <NFormItem :label="$t('warehouseIn.approvalResult')" path="result">
              <NRadioGroup v-model:value="form.result">
                <NSpace>
                  <NRadio value="APPROVE"><NTag type="success" size="small">{{ $t('warehouseIn.agree') }}</NTag></NRadio>
                  <NRadio value="REJECT"><NTag type="error" size="small">{{ $t('common.reject') }}</NTag></NRadio>
                  <NRadio value="RETURN"><NTag type="warning" size="small">{{ $t('warehouseIn.returnForModify') }}</NTag></NRadio>
                </NSpace>
              </NRadioGroup>
            </NFormItem>
            <NFormItem :label="$t('warehouseIn.approvalComment')" path="comment">
              <NInput v-model:value="form.comment" type="textarea" :rows="3" :placeholder="$t('warehouseIn.pleaseInputApprovalComment')" />
            </NFormItem>
            <NFormItem v-if="form.result === 'RETURN'" :label="$t('warehouseIn.returnStep')" path="returnToStep">
              <NInputNumber v-model:value="form.returnToStep" :min="1" :max="detail.currentStep || 1" :placeholder="$t('warehouseIn.returnStepPlaceholder')" />
            </NFormItem>
          </NForm>
          <NSpace justify="end">
            <NButton :loading="submitting" type="primary" @click="handleSubmit">{{ $t('warehouseIn.submitApproval') }}</NButton>
          </NSpace>
        </NCard>
      </NGi>

      <NGi>
        <NCard :title="$t('warehouseIn.applicationInfo')" size="small">
          <NDescriptions :column="1" bordered size="small">
            <NDescriptionsItem :label="$t('warehouseIn.customerName')">{{ detail.customerName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.collateralType')">{{ detail.collateralType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.collateralValue')">{{ formatCurrency(detail.collateralValue) }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.buCode')">{{ detail.buName || detail.buCode || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.intakeType')">{{ detail.intakeType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.currentStep')">{{ detail.currentStep ?? '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('common.status')">
              <NTag :type="getStatusType(detail.status)">{{ formatStatus(detail.status) }}</NTag>
            </NDescriptionsItem>
          </NDescriptions>
        </NCard>

        <NCard :title="$t('warehouseIn.approvalHistory')" size="small" class="history-card">
          <NEmpty v-if="history.length === 0" :description="$t('warehouseIn.noRecords')" />
          <NTimeline v-else>
            <NTimelineItem
              v-for="h in history"
              :key="h.id"
              :title="h.action"
              :content="`${h.user || h.operator || $t('warehouseIn.system')}：${h.comment || h.description || $t('warehouseIn.noComment')}`"
              :time="h.timestamp || h.operatedAt"
            />
          </NTimeline>
        </NCard>
        <AttachmentList
          :files="files"
          :title="$t('warehouseIn.attachmentList')"
          :empty-text="$t('warehouseIn.noAttachments')"
          :download-url="warehouseInApi.downloadFile"
          class="attachment-card"
        />
      </NGi>
    </NGrid>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { NCard, NButton, NGrid, NGi, NForm, NFormItem, NInput, NInputNumber, NRadioGroup, NRadio, NTag, NSpace, NSteps, NStep, NDescriptions, NDescriptionsItem, NTimeline, NTimelineItem, NEmpty, useMessage, type FormInst, type FormRules } from 'naive-ui'
import warehouseInApi, { type WarehouseInItem, type HistoryRecord, type AttachmentFile } from '@/api/warehouse-in'
import AttachmentList from '@/components/common/AttachmentList.vue'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const route = useRoute()
const message = useMessage()
const authStore = useAuthStore()
const { t } = useI18n()

const id = computed(() => (route.query.id || route.params.id) as string)
const detail = ref<Partial<WarehouseInItem>>({})
const history = ref<HistoryRecord[]>([])
const files = ref<AttachmentFile[]>([])
const submitting = ref(false)

const formRef = ref<FormInst | null>(null)
const form = reactive({
  result: 'APPROVE',
  comment: t('warehouseIn.agree'),
  returnToStep: 1 as number | null
})

const rules: FormRules = {
  result: [{ required: true, message: t('warehouseIn.pleaseSelectApprovalResult'), trigger: 'change' }],
  comment: [{ required: true, message: t('warehouseIn.pleaseInputApprovalComment'), trigger: 'blur' }]
}

const currentStep = computed(() => {
  const s = detail.value.currentStep || 0
  return s + 1
})

const submitDesc = computed(() => {
  return detail.value.submittedAt ? t('warehouseIn.submittedAtTime', { time: detail.value.submittedAt }) : t('warehouseIn.pendingSubmit')
})

function stepDesc(step: number) {
  // 根据 details.stepNumber 匹配审批记录（history 按时间倒序，find 取最新）
  const rec = history.value.find(h => h.details?.stepNumber === step)
  return rec ? t('warehouseIn.stepDesc', { user: rec.user || rec.operator || t('warehouseIn.system'), comment: rec.comment || rec.description || t('warehouseIn.noComment') }) : t('warehouseIn.pendingApproval')
}

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}
function formatStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), SUBMITTED: t('status.submitted'), IN_REVIEW: t('status.inReview'), APPROVED: t('status.approved'), REJECTED: t('status.rejected'), COMPLETED: t('status.completed') }
  return map[status || ''] || status || '-'
}
function getStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', SUBMITTED: 'info', IN_REVIEW: 'warning', APPROVED: 'success', REJECTED: 'error', COMPLETED: 'success' }
  return map[status || ''] || 'default'
}

async function loadData() {
  if (!id.value || id.value === 'undefined') {
    message.error(t('warehouseIn.missingApprovalId'))
    router.push('/warehouse-in')
    return
  }
  try {
    const res = await warehouseInApi.getDetail(id.value)
    detail.value = res.warehouseIn || {}
    files.value = res.files || []
    history.value = res.approvals || []
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
    detail.value = { id: id.value, status: 'SUBMITTED', whCode: `WH-${id.value}`, customerName: t('warehouseIn.testCustomer'), collateralType: 'REAL_ESTATE', collateralValue: 1000000, intakeType: 'NEW', currentStep: 1 }
    files.value = []
    history.value = []
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  submitting.value = true
  try {
    const step = detail.value.currentStep || 1
    if (form.result === 'APPROVE') {
      await warehouseInApi.approve(id.value, step, {
        approverUser: authStore.user?.username || 'system',
        approverRole: authStore.user?.role || '',
        comments: form.comment
      })
      message.success(t('warehouseIn.approvedSuccess'))
    } else if (form.result === 'REJECT') {
      await warehouseInApi.reject(id.value, step, {
        approverUser: authStore.user?.username || 'system',
        approverRole: authStore.user?.role || '',
        reason: form.comment,
        comments: form.comment
      })
      message.success(t('warehouseIn.rejectedSuccess'))
    } else if (form.result === 'RETURN') {
      await warehouseInApi.returnApplication(id.value, step, {
        approverUser: authStore.user?.username || 'system',
        approverRole: authStore.user?.role || '',
        reason: form.comment,
        comments: form.comment,
        returnToStep: form.returnToStep || 1
      })
      message.success(t('warehouseIn.returnedSuccess'))
    }
    router.push('/warehouse-in')
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.submitFailed'))
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.warehouse-in-approval-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.progress-card, .approval-card, .history-card {
  margin-bottom: 16px;
}
.attachment-card {
  margin-top: 16px;
}
</style>
