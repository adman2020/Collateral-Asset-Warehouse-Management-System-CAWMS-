<template>
  <div class="warehouse-in-detail-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('warehouseIn.detailTitle') }}</h1>
        <p class="page-subtitle">{{ $t('warehouseIn.whCodeLabel') }}: {{ detail.whCode || detail.id }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="router.back()">{{ $t('common.back') }}</NButton>
        <NButton :disabled="!canEdit" @click="handleEdit">{{ $t('common.edit') }}</NButton>
        <NButton type="primary" :disabled="!canSubmit" @click="handleSubmit">{{ $t('common.submit') }}</NButton>
        <NButton type="warning" :disabled="!canApprove" @click="showApproveDialog = true">{{ $t('common.approve') }}</NButton>
        <NButton type="error" :disabled="!canDelete" @click="handleDelete">{{ $t('common.delete') }}</NButton>
      </div>
    </div>

    <NGrid :cols="3" :x-gap="16" :y-gap="16">
      <NGi :span="2">
        <NCard :title="$t('warehouseIn.basicInfo')" size="small">
          <NDescriptions :column="2" bordered size="small">
            <NDescriptionsItem :label="$t('warehouseIn.whCodeLabel')">{{ detail.whCode || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.buCode')">{{ detail.buName || detail.buCode || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.customerId')">{{ detail.customerId || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.customerName')">{{ detail.customerName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.collateralType')">{{ detail.collateralType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.collateralValue')">{{ formatCurrency(detail.collateralValue) }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.creditAgreementNo')">{{ detail.creditAgreementNo || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.intakeType')">{{ detail.intakeType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('common.status')">
              <NTag :type="getStatusType(detail.status)">{{ formatStatus(detail.status) }}</NTag>
            </NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.currentStep')">{{ detail.currentStep ?? '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.submittedAt')">{{ detail.submittedAt || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.completedAt')">{{ detail.completedAt || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.createdBy')">{{ detail.createdBy || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseIn.updatedBy')">{{ detail.updatedBy || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('common.remark')" :span="2">{{ detail.remarks || '-' }}</NDescriptionsItem>
          </NDescriptions>
        </NCard>

        <NCard :title="$t('warehouseIn.approvalHistory')" size="small" class="history-card">
          <NEmpty v-if="history.length === 0" :description="$t('warehouseIn.noApprovalRecords')" />
          <NTimeline v-else>
            <NTimelineItem
              v-for="h in history"
              :key="h.id"
              :title="h.stepName || h.action || `${$t('warehouseIn.step')} ${h.stepNumber}`"
              :content="`${h.approverName || h.approverUser || h.user || h.operator || $t('warehouseIn.system')}：${h.comments || h.comment || h.description || $t('warehouseIn.noComment')}`"
              :time="h.approvedAt || h.timestamp || h.operatedAt"
            />
          </NTimeline>
        </NCard>
      </NGi>

      <NGi>
        <NCard :title="$t('warehouseIn.quickActions')" size="small">
          <NSpace vertical>
            <NButton block type="primary" :disabled="!canSubmit" @click="handleSubmit">{{ $t('warehouseIn.submitApproval') }}</NButton>
            <NButton block type="warning" :disabled="!canApprove" @click="showApproveDialog = true">{{ $t('warehouseIn.approvePass') }}</NButton>
            <NButton block type="error" :disabled="!canApprove" @click="showRejectDialog = true">{{ $t('warehouseIn.rejectApplication') }}</NButton>
            <NButton block type="info" :disabled="!canGenerate" @click="handleGenerateSlip">{{ $t('warehouseIn.generateSlip') }}</NButton>
          </NSpace>
        </NCard>
        <AttachmentList
          :files="files"
          :title="$t('warehouseIn.attachmentList')"
          :empty-text="$t('warehouseIn.noAttachments')"
          :download-url="warehouseInApi.downloadFile"
          class="attachment-card"
        />
      </NGi>
    </NGrid>

    <!-- 审批弹窗 -->
    <NModal v-model:show="showApproveDialog" :title="$t('warehouseIn.approveTitle')" preset="dialog" :positive-text="$t('common.confirm')" :negative-text="$t('common.cancel')" @positive-click="handleApprove">
      <NInput v-model:value="approveComments" type="textarea" :placeholder="$t('warehouseIn.pleaseInputApprovalComment')" />
    </NModal>

    <!-- 拒绝弹窗 -->
    <NModal v-model:show="showRejectDialog" :title="$t('warehouseIn.rejectTitle')" preset="dialog" :positive-text="$t('warehouseIn.confirmReject')" :negative-text="$t('common.cancel')" @positive-click="handleReject">
      <NInput v-model:value="rejectComments" type="textarea" :placeholder="$t('warehouseIn.pleaseInputRejectReason')" />
    </NModal>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import warehouseZoneApi from '@/api/warehouse-zone'
import warehouseApi from '@/api/warehouse'
import { NCard, NButton, NGrid, NGi, NDescriptions, NDescriptionsItem, NTag, NSpace, NTimeline, NTimelineItem, NEmpty, NModal, NInput, useMessage, useDialog } from 'naive-ui'
import warehouseInApi, { type WarehouseInItem, type HistoryRecord, type AttachmentFile } from '@/api/warehouse-in'
import AttachmentList from '@/components/common/AttachmentList.vue'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const route = useRoute()
const message = useMessage()
const dialog = useDialog()
const authStore = useAuthStore()
const { t } = useI18n()

const id = computed(() => route.params.id as string)
const detail = ref<Partial<WarehouseInItem>>({})
const history = ref<HistoryRecord[]>([])
const files = ref<AttachmentFile[]>([])

const showApproveDialog = ref(false)
const showRejectDialog = ref(false)
const approveComments = ref(t('warehouseIn.agree'))
const rejectComments = ref('')

const canEdit = computed(() => authStore.isAdmin || ['DRAFT', 'REJECTED'].includes(detail.value.status || ''))
const canSubmit = computed(() => detail.value.status === 'DRAFT')
const canApprove = computed(() => {
  if (!['SUBMITTED', 'IN_REVIEW'].includes(detail.value.status || '')) return false
  const userRole = authStore.user?.role || ''
  const step = detail.value.currentStep || 1
  const stepRoleMap: Record<number, string> = {
    1: 'BUSINESS_MANAGER',
    2: 'RISK_OFFICER',
    3: 'COMPLIANCE_OFFICER',
    4: 'WAREHOUSE_MANAGER'
  }
  const requiredRole = stepRoleMap[step]
  if (!requiredRole) return false
  return authStore.isAdmin || userRole === requiredRole
})
const canDelete = computed(() => ['DRAFT', 'REJECTED'].includes(detail.value.status || ''))
const canGenerate = computed(() => ['APPROVED', 'COMPLETED'].includes(detail.value.status || ''))

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}
function formatStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), SUBMITTED: t('status.submitted'), IN_REVIEW: t('status.inReview'), APPROVED: t('status.approved'), REJECTED: t('status.rejected'), COMPLETED: t('status.completed') }
  return map[status || ''] || status || '-'
}
function getStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', SUBMITTED: 'info', IN_REVIEW: 'warning', APPROVED: 'success', REJECTED: 'error', COMPLETED: 'success' }
  return map[status || ''] || 'default'
}

async function loadData() {
  try {
    const res = await warehouseInApi.getDetail(id.value)
    const raw = res.warehouseIn || {}
    const additional = res.additionalInfo || {}
    const zoneInfo = additional.zone || {}
    const whInfo = additional.warehouse || {}
    detail.value = {
      ...raw,
      zoneName: zoneInfo.zoneName,
      zoneType: zoneInfo.zoneType,
      warehouseName: whInfo.warehouseName
    }
    files.value = res.files || []
    history.value = res.approvals || []
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.loadDetailFailed'))
    detail.value = { id: id.value, status: 'DRAFT', whCode: `WH-MOCK-${id.value}`, customerName: t('warehouseIn.testCustomer'), collateralType: 'REAL_ESTATE', collateralValue: 1000000, intakeType: 'NEW', currentStep: 0 }
    files.value = []
    history.value = []
  }
}

function handleEdit() {
  router.push(`/warehouse-in/create?editId=${id.value}`)
}
async function handleSubmit() {
  try {
    await warehouseInApi.submit(id.value, authStore.userFullName || 'system')
    message.success(t('warehouseIn.submitSuccess'))
    loadData()
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.submitFailed'))
  }
}
async function handleApprove() {
  try {
    await warehouseInApi.approve(id.value, detail.value.currentStep || 1, {
      approverUser: authStore.user?.username || 'system',
      approverRole: authStore.user?.role || '',
      comments: approveComments.value
    })
    message.success(t('warehouseIn.approveSuccess'))
    showApproveDialog.value = false
    loadData()
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.approveFailed'))
  }
}
async function handleReject() {
  try {
    await warehouseInApi.reject(id.value, detail.value.currentStep || 1, {
      approverUser: authStore.user?.username || 'system',
      approverRole: authStore.user?.role || '',
      reason: rejectComments.value,
      comments: rejectComments.value
    })
    message.success(t('warehouseIn.rejectedSuccess'))
    showRejectDialog.value = false
    loadData()
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.operationFailed'))
  }
}
async function handleGenerateSlip() {
  try {
    await warehouseInApi.generateSlip(id.value, authStore.userFullName || 'system')
    message.success(t('warehouseIn.generateSlipSuccess'))
  } catch (e: any) {
    message.error(e.message || t('warehouseIn.generateFailed'))
  }
}
function handleDelete() {
  dialog.warning({
    title: t('warehouseIn.deleteTitle'),
    content: t('warehouseIn.deleteConfirmSimple'),
    positiveText: t('common.delete'),
    negativeText: t('common.cancel'),
    onPositiveClick: async () => {
      try {
        await warehouseInApi.delete(id.value)
        message.success(t('warehouseIn.deleteSuccess'))
        router.push('/warehouse-in')
      } catch (e: any) {
        message.error(e.message || t('warehouseIn.deleteFailed'))
      }
    }
  })
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.warehouse-in-detail-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.history-card {
  margin-top: 16px;
}
.attachment-card {
  margin-top: 16px;
}
</style>
