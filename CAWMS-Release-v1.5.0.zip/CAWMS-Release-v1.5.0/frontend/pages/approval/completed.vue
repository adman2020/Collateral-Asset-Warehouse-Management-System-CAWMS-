<template>
  <div class="approval-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('approval.completedTitle') }}</h1>
      <p class="page-subtitle">{{ $t('approval.completedSubtitle') }}</p>
    </div>

    <NTabs v-model:value="activeTab" type="line" @update:value="handleTabChange">
      <NTabPane name="warehouse-in" :tab="$t('approval.whInTab')">
        <DataTable
          :data="whTableData"
          :columns="whColumns"
          :loading="whLoading"
          :pagination="whPagination"
          @update:page="(p) => handlePageChange('wh', p)"
          @update:page-size="(s) => handlePageSizeChange('wh', s)"
        >
          <template #status="{ row }">
            <NTag :type="getStatusType(row.status)">{{ formatStatus(row.status) }}</NTag>
          </template>
          <template #actions="{ row }">
            <NSpace size="small">
              <NButton size="small" @click="handleView(row, 'warehouse-in')">{{ $t('approval.view') }}</NButton>
            </NSpace>
          </template>
        </DataTable>
      </NTabPane>

      <NTabPane name="loan-out" :tab="$t('approval.loanOutTab')">
        <DataTable
          :data="loanTableData"
          :columns="loanColumns"
          :loading="loanLoading"
          :pagination="loanPagination"
          @update:page="(p) => handlePageChange('loan', p)"
          @update:page-size="(s) => handlePageSizeChange('loan', s)"
        >
          <template #status="{ row }">
            <NTag :type="getLoanStatusType(row.status)">{{ formatLoanStatus(row.status) }}</NTag>
          </template>
          <template #currentStep="{ row }">
            <span>{{ getLoanCurrentStep(row) }}</span>
          </template>
          <template #actions="{ row }">
            <NSpace size="small">
              <NButton size="small" @click="handleView(row, 'loan-out')">{{ $t('approval.view') }}</NButton>
            </NSpace>
          </template>
        </DataTable>
      </NTabPane>

      <NTabPane name="transfer" :tab="$t('approval.transferTab')">
        <DataTable
          :data="transferTableData"
          :columns="transferColumns"
          :loading="transferLoading"
          :pagination="transferPagination"
          @update:page="(p) => handlePageChange('transfer', p)"
          @update:page-size="(s) => handlePageSizeChange('transfer', s)"
        >
          <template #status="{ row }">
            <NTag :type="getTransferStatusType(row.status)">{{ formatTransferStatus(row.status) }}</NTag>
          </template>
          <template #actions="{ row }">
            <NSpace size="small">
              <NButton size="small" @click="handleView(row, 'transfer')">{{ $t('approval.view') }}</NButton>
            </NSpace>
          </template>
        </DataTable>
      </NTabPane>

      <NTabPane name="warehouse-out" :tab="$t('approval.warehouseOutTab')">
        <DataTable
          :data="woTableData"
          :columns="woColumns"
          :loading="woLoading"
          :pagination="woPagination"
          @update:page="(p) => handlePageChange('wo', p)"
          @update:page-size="(s) => handlePageSizeChange('wo', s)"
        >
          <template #status="{ row }">
            <NTag :type="getWarehouseOutStatusType(row.status)">{{ formatWarehouseOutStatus(row.status) }}</NTag>
          </template>
          <template #actions="{ row }">
            <NSpace size="small">
              <NButton size="small" @click="handleView(row, 'warehouse-out')">{{ $t('approval.view') }}</NButton>
            </NSpace>
          </template>
        </DataTable>
      </NTabPane>
    </NTabs>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, h, onMounted, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { NTag, NButton, NSpace, NTabs, NTabPane, useMessage } from 'naive-ui'
import DataTable from '@/components/common/DataTable.vue'
import warehouseInApi, { type WarehouseInItem, type WarehouseInPageResult } from '@/api/warehouse-in'
import loanOutApi, { type LoanOutItem, type LoanOutPageResult } from '@/api/loan-out'
import { getMyApprovals as getTransferMyApprovals, type Transfer } from '@/api/transfer'
import { getMyApprovals as getWarehouseOutMyApprovals, type WarehouseOut } from '@/api/warehouse-out'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const message = useMessage()
const authStore = useAuthStore()
const { t } = useI18n()

function getCurrentUsername() {
  if (authStore.user?.username) return authStore.user.username
  try {
    const info = JSON.parse(sessionStorage.getItem('userInfo') || '{}')
    return info.username || ''
  } catch (e) { return '' }
}

function getCurrentUserId() {
  if (authStore.user?.id) return String(authStore.user.id)
  try {
    const info = JSON.parse(sessionStorage.getItem('userInfo') || '{}')
    return String(info.id || '')
  } catch (e) { return '' }
}

const activeTab = ref('warehouse-in')

const whLoading = ref(false)
const whTableData = ref<WarehouseInItem[]>([])
const whTotal = ref(0)
const whPagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  prefix: () => h('span', {}, `${t('approval.total')} ${whTotal.value} ${t('table.totalRecords')}`)
})
const whColumns = computed(() => [
  { title: t('table.whCode'), key: 'whCode', width: 160 },
  { title: t('table.buCode'), key: 'buCode', width: 120 },
  { title: t('table.customerName'), key: 'customerName', minWidth: 160, ellipsis: { tooltip: true } },
  { title: t('table.collateralType'), key: 'collateralType', width: 120 },
  { title: t('table.collateralValue'), key: 'collateralValue', width: 140, render: (row: WarehouseInItem) => formatCurrency(row.collateralValue) },
  { title: t('table.intakeType'), key: 'intakeType', width: 120 },
  { title: t('table.status'), key: 'status', width: 100, slot: 'status' },
  { title: t('table.currentStep'), key: 'currentStep', width: 90 },
  { title: t('table.submittedAt'), key: 'submittedAt', width: 160 },
  { title: t('table.operation'), key: 'actions', width: 100, fixed: 'right', slot: 'actions' }
])

const loanLoading = ref(false)
const loanTableData = ref<LoanOutItem[]>([])
const loanTotal = ref(0)
const loanPagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  prefix: () => h('span', {}, `${t('approval.total')} ${loanTotal.value} ${t('table.totalRecords')}`)
})
const loanColumns = computed(() => [
  { title: t('table.loanId'), key: 'id', width: 80 },
  { title: t('table.whCode'), key: 'whCode', width: 140 },
  { title: t('table.customerName'), key: 'customerName', minWidth: 160, ellipsis: { tooltip: true } },
  { title: t('table.collateralType'), key: 'collateralType', width: 120 },
  { title: t('table.collateralValue'), key: 'collateralValue', width: 140, render: (row: LoanOutItem) => formatCurrency(row.collateralValue) },
  { title: t('table.loanPurpose'), key: 'loanPurpose', width: 120 },
  { title: t('table.status'), key: 'status', width: 100, slot: 'status' },
  { title: t('table.currentStep'), key: 'currentStep', width: 120, slot: 'currentStep' },
  { title: t('table.submittedAt'), key: 'createdAt', width: 160 },
  { title: t('table.operation'), key: 'actions', width: 100, fixed: 'right', slot: 'actions' }
])

const transferLoading = ref(false)
const transferTableData = ref<Transfer[]>([])
const transferTotal = ref(0)
const transferPagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  prefix: () => h('span', {}, `${t('approval.total')} ${transferTotal.value} ${t('table.totalRecords')}`)
})
const transferColumns = computed(() => [
  { title: t('table.transferNo'), key: 'transferNo', width: 160 },
  { title: t('table.warehouseInNo'), key: 'warehouseInNo', width: 140 },
  { title: t('table.collateralName'), key: 'collateralName', minWidth: 160, ellipsis: { tooltip: true } },
  { title: t('table.sourceWarehouse'), key: 'sourceWarehouseName', width: 140 },
  { title: t('table.targetWarehouse'), key: 'targetWarehouseName', width: 140 },
  { title: t('table.transferType'), key: 'transferType', width: 120, render: (row: Transfer) => row.transferType === 'INTERNAL' ? t('transferType.internal') : t('transferType.cross') },
  { title: t('table.status'), key: 'status', width: 100, slot: 'status' },
  { title: t('table.submittedAt'), key: 'applyTime', width: 160 },
  { title: t('table.operation'), key: 'actions', width: 100, fixed: 'right', slot: 'actions' }
])

const woLoading = ref(false)
const woTableData = ref<WarehouseOut[]>([])
const woTotal = ref(0)
const woPagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  prefix: () => h('span', {}, `${t('approval.total')} ${woTotal.value} ${t('table.totalRecords')}`)
})
const woColumns = computed(() => [
  { title: t('table.warehouseOutNo'), key: 'warehouseOutNo', width: 160 },
  { title: t('table.warehouseInNo'), key: 'warehouseInNo', width: 140 },
  { title: t('table.collateralName'), key: 'collateralName', minWidth: 160, ellipsis: { tooltip: true } },
  { title: t('table.warehouse'), key: 'warehouseName', width: 140 },
  { title: t('table.releaseAmount'), key: 'releaseAmount', width: 140, render: (row: WarehouseOut) => formatCurrency(row.releaseAmount) },
  { title: t('table.releaseType'), key: 'releaseType', width: 120, render: (row: WarehouseOut) => row.releaseType === 'FULL' ? t('releaseType.full') : t('releaseType.partial') },
  { title: t('table.status'), key: 'status', width: 100, slot: 'status' },
  { title: t('table.submittedAt'), key: 'applyTime', width: 160 },
  { title: t('table.operation'), key: 'actions', width: 100, fixed: 'right', slot: 'actions' }
])

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}
function formatStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), SUBMITTED: t('status.submitted'), IN_REVIEW: t('status.inReview'), APPROVED: t('status.approved'), REJECTED: t('status.rejected'), COMPLETED: t('status.completed') }
  return map[status || ''] || status || '-'
}
function getStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', SUBMITTED: 'info', IN_REVIEW: 'warning', APPROVED: 'success', REJECTED: 'error', COMPLETED: 'success' }
  return map[status || ''] || 'default'
}
function formatLoanStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), PENDING: t('status.pending'), APPROVED: t('status.approved'), LOANED: t('status.loaned'), RETURNED: t('status.returned'), REJECTED: t('status.rejected') }
  return map[status || ''] || status || '-'
}
function getLoanStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', PENDING: 'warning', APPROVED: 'success', LOANED: 'info', RETURNED: 'success', REJECTED: 'error' }
  return map[status || ''] || 'default'
}
function getLoanCurrentStep(row: any) {
  const approvals = row.approvals || []
  const pending = approvals.find((a: any) => a.status === 'PENDING')
  return pending?.stepName || pending?.stepNumber || '-'
}
function formatTransferStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), SUBMITTED: t('status.submitted'), APPROVED: t('status.approved'), COMPLETED: t('status.completed'), CANCELLED: t('status.cancelled') }
  return map[status || ''] || status || '-'
}
function getTransferStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', SUBMITTED: 'info', APPROVED: 'success', COMPLETED: 'success', CANCELLED: 'default' }
  return map[status || ''] || 'default'
}
function formatWarehouseOutStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), SUBMITTED: t('status.submitted'), APPROVED: t('status.approved'), COMPLETED: t('status.completed'), CANCELLED: t('status.cancelled') }
  return map[status || ''] || status || '-'
}
function getWarehouseOutStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', SUBMITTED: 'info', APPROVED: 'success', COMPLETED: 'success', CANCELLED: 'default' }
  return map[status || ''] || 'default'
}

async function loadWarehouseIn() {
  whLoading.value = true
  try {
    const result: WarehouseInPageResult = await warehouseInApi.getMyApprovals({
      type: 'ongoing',
      approverUser: getCurrentUsername(),
      pageNum: whPagination.page,
      pageSize: whPagination.pageSize
    })
    whTableData.value = result.records || []
    whTotal.value = result.total || 0
    whPagination.pageCount = result.pages || 1
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
    whTableData.value = []
    whTotal.value = 0
    whPagination.pageCount = 1
  } finally {
    whLoading.value = false
  }
}

async function loadLoanOut() {
  loanLoading.value = true
  try {
    const result: LoanOutPageResult = await loanOutApi.getMyApprovals({
      type: 'ongoing',
      approverUser: getCurrentUserId(),
      pageNum: loanPagination.page,
      pageSize: loanPagination.pageSize
    })
    loanTableData.value = result.records || []
    loanTotal.value = result.total || 0
    loanPagination.pageCount = result.pages || 1
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
    loanTableData.value = []
    loanTotal.value = 0
    loanPagination.pageCount = 1
  } finally {
    loanLoading.value = false
  }
}

async function loadTransfer() {
  transferLoading.value = true
  try {
    const result = await getTransferMyApprovals({
      type: 'ongoing',
      approverUser: getCurrentUsername(),
      pageNum: transferPagination.page,
      pageSize: transferPagination.pageSize
    })
    transferTableData.value = result.records || []
    transferTotal.value = result.total || 0
    transferPagination.pageCount = result.pages || 1
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
    transferTableData.value = []
    transferTotal.value = 0
    transferPagination.pageCount = 1
  } finally {
    transferLoading.value = false
  }
}

async function loadWarehouseOut() {
  woLoading.value = true
  try {
    const result = await getWarehouseOutMyApprovals({
      type: 'ongoing',
      approverUser: getCurrentUsername(),
      pageNum: woPagination.page,
      pageSize: woPagination.pageSize
    })
    woTableData.value = result.records || []
    woTotal.value = result.total || 0
    woPagination.pageCount = result.pages || 1
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
    woTableData.value = []
    woTotal.value = 0
    woPagination.pageCount = 1
  } finally {
    woLoading.value = false
  }
}

function handleTabChange(tab: string) {
  if (tab === 'warehouse-in') loadWarehouseIn()
  else if (tab === 'loan-out') loadLoanOut()
  else if (tab === 'transfer') loadTransfer()
  else if (tab === 'warehouse-out') loadWarehouseOut()
}

function handlePageChange(module: 'wh' | 'loan' | 'transfer' | 'wo', page: number) {
  if (module === 'wh') {
    whPagination.page = page
    loadWarehouseIn()
  } else if (module === 'loan') {
    loanPagination.page = page
    loadLoanOut()
  } else if (module === 'transfer') {
    transferPagination.page = page
    loadTransfer()
  } else if (module === 'wo') {
    woPagination.page = page
    loadWarehouseOut()
  }
}
function handlePageSizeChange(module: 'wh' | 'loan' | 'transfer' | 'wo', size: number) {
  if (module === 'wh') {
    whPagination.pageSize = size
    whPagination.page = 1
    loadWarehouseIn()
  } else if (module === 'loan') {
    loanPagination.pageSize = size
    loanPagination.page = 1
    loadLoanOut()
  } else if (module === 'transfer') {
    transferPagination.pageSize = size
    transferPagination.page = 1
    loadTransfer()
  } else if (module === 'wo') {
    woPagination.pageSize = size
    woPagination.page = 1
    loadWarehouseOut()
  }
}
function handleView(row: any, module: string) {
  if (module === 'warehouse-in') router.push(`/warehouse-in/${row.id}`)
  else if (module === 'loan-out') router.push(`/loan-out/${row.id}`)
  else if (module === 'transfer') router.push(`/transfer/${row.id}`)
  else if (module === 'warehouse-out') router.push(`/warehouse-out/${row.id}`)
}

onMounted(() => {
  loadWarehouseIn()
  loadLoanOut()
  loadTransfer()
  loadWarehouseOut()
})
</script>

<style scoped>
.approval-page {
  padding: 24px;
}
.page-header {
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.page-subtitle {
  font-size: 14px;
  color: var(--text-color-secondary);
  margin: 4px 0 0;
}
</style>
