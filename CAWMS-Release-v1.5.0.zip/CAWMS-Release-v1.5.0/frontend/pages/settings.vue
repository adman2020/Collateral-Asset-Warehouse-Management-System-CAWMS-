<template>
  <div class="settings-page">
    <div class="page-header">
      <h1 class="page-title">{{ $t('settings.title') }}</h1>
    </div>

    <div class="settings-layout">
      <!-- 界面设置 -->
      <n-card :title="$t('settings.appearance')" class="settings-card">
        <div class="setting-row">
          <div class="setting-label">
            <div class="setting-title">{{ $t('settings.themeMode') }}</div>
            <div class="setting-desc">{{ $t('settings.themeModeDesc') }}</div>
          </div>
          <div class="setting-control">
            <n-radio-group v-model:value="settings.theme" @update:value="handleThemeChange">
              <n-radio-button value="light">{{ $t('settings.light') }}</n-radio-button>
              <n-radio-button value="dark">{{ $t('settings.dark') }}</n-radio-button>
              <n-radio-button value="system">{{ $t('settings.followSystem') }}</n-radio-button>
            </n-radio-group>
          </div>
        </div>

        <n-divider />

        <div class="setting-row">
          <div class="setting-label">
            <div class="setting-title">{{ $t('settings.sidebarCollapse') }}</div>
            <div class="setting-desc">{{ $t('settings.sidebarCollapseDesc') }}</div>
          </div>
          <div class="setting-control">
            <n-switch v-model:value="settings.sidebarCollapsed" @update:value="handleSidebarChange" />
          </div>
        </div>
      </n-card>

      <!-- 通知设置 -->
      <n-card :title="$t('settings.notifications')" class="settings-card">
        <div class="setting-row">
          <div class="setting-label">
            <div class="setting-title">{{ $t('settings.systemNotification') }}</div>
            <div class="setting-desc">{{ $t('settings.systemNotificationDesc') }}</div>
          </div>
          <div class="setting-control">
            <n-switch v-model:value="settings.systemNotify" />
          </div>
        </div>

        <n-divider />

        <div class="setting-row">
          <div class="setting-label">
            <div class="setting-title">{{ $t('settings.approvalNotification') }}</div>
            <div class="setting-desc">{{ $t('settings.approvalNotificationDesc') }}</div>
          </div>
          <div class="setting-control">
            <n-switch v-model:value="settings.approvalNotify" />
          </div>
        </div>

        <n-divider />

        <div class="setting-row">
          <div class="setting-label">
            <div class="setting-title">{{ $t('settings.alertNotification') }}</div>
            <div class="setting-desc">{{ $t('settings.alertNotificationDesc') }}</div>
          </div>
          <div class="setting-control">
            <n-switch v-model:value="settings.alertNotify" />
          </div>
        </div>
      </n-card>

      <!-- 安全设置 -->
      <n-card :title="$t('settings.security')" class="settings-card">
        <div class="setting-row">
          <div class="setting-label">
            <div class="setting-title">{{ $t('settings.changePassword') }}</div>
            <div class="setting-desc">{{ $t('settings.changePasswordDesc') }}</div>
          </div>
          <div class="setting-control">
            <n-button type="primary" ghost @click="goToProfile">{{ $t('settings.goToChange') }}</n-button>
          </div>
        </div>
      </n-card>
    </div>

    <div class="settings-footer">
      <n-button type="primary" :loading="saving" @click="handleSave">{{ $t('settings.saveSettings') }}</n-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useThemeState } from '@/composables/useThemeState'

const { t } = useI18n()
const { setThemeMode } = useThemeState()

definePageMeta({
  middleware: ['auth'],
  layout: 'default',
  meta: { title: '账户设置', requiresAuth: true }
})

const message = useMessage()
const router = useRouter()

const settings = reactive({
  theme: 'system',
  sidebarCollapsed: false,
  systemNotify: true,
  approvalNotify: true,
  alertNotify: true
})

const saving = ref(false)

onMounted(() => {
  const stored = typeof window !== 'undefined' ? localStorage.getItem('appSettings') : null
  if (stored) {
    try {
      const parsed = JSON.parse(stored)
      Object.assign(settings, parsed)
    } catch {}
  }
})

const handleThemeChange = (val: string) => {
  settings.theme = val
  const effective = val === 'dark' ? 'dark' : val === 'light' ? 'light' : (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
  setThemeMode(effective)
  document.documentElement.setAttribute('data-theme', effective)
}

const handleSidebarChange = (val: boolean) => {
  settings.sidebarCollapsed = val
}

const goToProfile = () => {
  router.push('/profile')
}

const handleSave = () => {
  saving.value = true
  try {
    if (typeof window !== 'undefined') {
      localStorage.setItem('appSettings', JSON.stringify(settings))
      localStorage.setItem('theme', settings.theme)
    }
    message.success(t('settings.saveSuccess'))
  } catch {
    message.error(t('settings.saveFailed'))
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.settings-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
  margin: 0;
}
.settings-layout {
  display: grid;
  grid-template-columns: 1fr;
  gap: 24px;
  max-width: 800px;
}
.settings-card {
  width: 100%;
}
.setting-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  padding: 8px 0;
}
.setting-label {
  flex: 1;
}
.setting-title {
  font-size: 15px;
  font-weight: 500;
  color: #333;
}
.setting-desc {
  font-size: 13px;
  color: #888;
  margin-top: 4px;
}
.setting-control {
  flex-shrink: 0;
}
.settings-footer {
  margin-top: 24px;
  max-width: 800px;
  display: flex;
  justify-content: flex-end;
}
@media (max-width: 576px) {
  .setting-row {
    flex-direction: column;
    align-items: flex-start;
  }
}
</style>
