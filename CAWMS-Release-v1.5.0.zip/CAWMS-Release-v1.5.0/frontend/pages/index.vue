<template>
  <div class="dashboard-page">
    <!-- 页面标题 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ t('menu.dashboard') }}</h1>
        <p class="page-subtitle">{{ t('dashboard.subtitle') }}</p>
      </div>
      <div class="header-actions">
        <NButton type="primary" @click="handleRefresh">
          <template #icon>
            <NIcon><RefreshOutline /></NIcon>
          </template>
          {{ t('common.refresh') }}
        </NButton>
        <NButton @click="handleExport">
          <template #icon>
            <NIcon><DownloadOutline /></NIcon>
          </template>
          {{ t('dashboard.exportReport') }}
        </NButton>
      </div>
    </div>
    
    <!-- 统计卡片 -->
    <div class="stats-grid">
      <!-- 入库统计 -->
      <NCard class="stat-card" hoverable>
        <template #cover>
          <div class="stat-card-cover" style="background: linear-gradient(135deg, #1890ff 0%, #36cfc9 100%);">
            <NIcon size="32" color="white"><FileTrayFullOutline /></NIcon>
          </div>
        </template>
        <div class="stat-card-content">
          <div class="stat-card-header">
            <h3>{{ t('menu.warehouseIn') }}</h3>
            <NTag type="success" size="small">{{ t('status.normal') }}</NTag>
          </div>
          <div class="stat-card-body">
            <div class="stat-value">{{ stats.inbound.total || 0 }}</div>
            <div class="stat-label">{{ t('dashboard.totalInbound') }}</div>
          </div>
          <div class="stat-card-footer">
            <div class="stat-trend">
              <NIcon v-if="stats.inbound.trend === 'up'" color="#52c41a">
                <TrendingUpOutline />
              </NIcon>
              <NIcon v-else color="#f5222d">
                <TrendingDownOutline />
              </NIcon>
              <span :class="stats.inbound.trend === 'up' ? 'trend-up' : 'trend-down'">
                {{ stats.inbound.change || 0 }}%
              </span>
            </div>
            <div class="stat-meta">{{ t('dashboard.today') }} {{ stats.inbound.today || 0 }} {{ t('dashboard.countUnit') }}</div>
          </div>
        </div>
      </NCard>
      
      <!-- 借出统计 -->
      <NCard class="stat-card" hoverable>
        <template #cover>
          <div class="stat-card-cover" style="background: linear-gradient(135deg, #722ed1 0%, #eb2f96 100%);">
            <NIcon size="32" color="white"><LogOutOutline /></NIcon>
          </div>
        </template>
        <div class="stat-card-content">
          <div class="stat-card-header">
            <h3>{{ t('menu.loanOut') }}</h3>
            <NTag type="warning" size="small">{{ t('status.warning') }}</NTag>
          </div>
          <div class="stat-card-body">
            <div class="stat-value">{{ stats.loanOut.total || 0 }}</div>
            <div class="stat-label">{{ t('dashboard.totalLoanOut') }}</div>
          </div>
          <div class="stat-card-footer">
            <div class="stat-trend">
              <NIcon v-if="stats.loanOut.trend === 'up'" color="#52c41a">
                <TrendingUpOutline />
              </NIcon>
              <NIcon v-else color="#f5222d">
                <TrendingDownOutline />
              </NIcon>
              <span :class="stats.loanOut.trend === 'up' ? 'trend-up' : 'trend-down'">
                {{ stats.loanOut.change || 0 }}%
              </span>
            </div>
            <div class="stat-meta">{{ t('dashboard.pendingReturn') }} {{ stats.loanOut.pending || 0 }} {{ t('dashboard.countUnit') }}</div>
          </div>
        </div>
      </NCard>
      
      <!-- 逾期统计 -->
      <NCard class="stat-card" hoverable>
        <template #cover>
          <div class="stat-card-cover" style="background: linear-gradient(135deg, #f5222d 0%, #fa541c 100%);">
            <NIcon size="32" color="white"><AlertCircleOutline /></NIcon>
          </div>
        </template>
        <div class="stat-card-content">
          <div class="stat-card-header">
            <h3>{{ t('dashboard.overdueManagement') }}</h3>
            <NTag type="error" size="small">{{ t('status.alert') }}</NTag>
          </div>
          <div class="stat-card-body">
            <div class="stat-value">{{ stats.overdue.total || 0 }}</div>
            <div class="stat-label">{{ t('dashboard.overdueAssets') }}</div>
          </div>
          <div class="stat-card-footer">
            <div class="stat-trend">
              <NIcon v-if="stats.overdue.trend === 'up'" color="#52c41a">
                <TrendingUpOutline />
              </NIcon>
              <NIcon v-else color="#f5222d">
                <TrendingDownOutline />
              </NIcon>
              <span :class="stats.overdue.trend === 'up' ? 'trend-up' : 'trend-down'">
                {{ stats.overdue.change || 0 }}%
              </span>
            </div>
            <div class="stat-meta">{{ t('dashboard.pendingProcess') }} {{ stats.overdue.pending || 0 }} {{ t('dashboard.countUnit') }}</div>
          </div>
        </div>
      </NCard>
      
      <!-- 财务统计 -->
      <NCard class="stat-card" hoverable>
        <template #cover>
          <div class="stat-card-cover" style="background: linear-gradient(135deg, #52c41a 0%, #a0d911 100%);">
            <NIcon size="32" color="white"><CashOutline /></NIcon>
          </div>
        </template>
        <div class="stat-card-content">
          <div class="stat-card-header">
            <h3>{{ t('dashboard.financialStats') }}</h3>
            <NTag type="info" size="small">{{ t('status.stable') }}</NTag>
          </div>
          <div class="stat-card-body">
            <div class="stat-value">{{ formatCurrency(stats.financial.total || 0) }}</div>
            <div class="stat-label">{{ t('dashboard.totalAssets') }}</div>
          </div>
          <div class="stat-card-footer">
            <div class="stat-trend">
              <NIcon v-if="stats.financial.trend === 'up'" color="#52c41a">
                <TrendingUpOutline />
              </NIcon>
              <NIcon v-else color="#f5222d">
                <TrendingDownOutline />
              </NIcon>
              <span :class="stats.financial.trend === 'up' ? 'trend-up' : 'trend-down'">
                {{ stats.financial.change || 0 }}%
              </span>
            </div>
            <div class="stat-meta">{{ t('dashboard.monthlyRevenue') }} {{ formatCurrency(stats.financial.monthly || 0) }}</div>
          </div>
        </div>
      </NCard>
    </div>
    
    <!-- 图表区域 -->
    <div class="charts-grid">
      <!-- 入库趋势图 -->
      <NCard class="chart-card" :title="t('dashboard.inboundTrend')" size="small" hoverable>
        <div class="chart-container">
          <VChart class="chart" :option="inboundTrendOption" autoresize />
        </div>
      </NCard>
      
      <!-- 借出分布 -->
      <NCard class="chart-card" :title="t('dashboard.loanOutDistribution')" size="small" hoverable>
        <div class="chart-container">
          <VChart class="chart" :option="loanOutDistributionOption" autoresize />
        </div>
      </NCard>
    </div>
    
    <!-- 最近活动 -->
    <div class="recent-activity">
      <NCard :title="t('dashboard.recentActivity')" size="small" hoverable>
        <template #header-extra>
          <NuxtLink to="/activities">{{ t('common.viewAll') }}</NuxtLink>
        </template>
        <div class="activity-list">
          <div v-for="activity in recentActivities" :key="activity.id" class="activity-item">
            <div class="activity-icon" :class="activity.type">
              <NIcon>
                <component :is="activity.icon" />
              </NIcon>
            </div>
            <div class="activity-content">
              <div class="activity-title">{{ activity.title }}</div>
              <div class="activity-description">{{ activity.description }}</div>
            </div>
            <div class="activity-time">{{ activity.time }}</div>
          </div>
        </div>
      </NCard>
    </div>
    
    <!-- 待办事项 -->
    <div class="todo-list">
      <NCard :title="t('dashboard.todoList')" size="small" hoverable>
        <template #header-extra>
          <NuxtLink to="/tasks">{{ t('common.manage') }}</NuxtLink>
        </template>
        <div class="todo-items">
          <div v-for="task in pendingTasks" :key="task.id" class="todo-item">
            <NCheckbox v-model:checked="task.completed" @update:checked="handleTaskToggle(task)">
              <div class="todo-content">
                <div class="todo-title" :class="{ completed: task.completed }">{{ task.title }}</div>
                <div class="todo-meta">
                  <NTag size="small" :type="task.priority === 'high' ? 'error' : task.priority === 'medium' ? 'warning' : 'info'">
                    {{ task.priority }}
                  </NTag>
                  <span class="todo-deadline">{{ t('dashboard.deadline') }} {{ task.deadline }}</span>
                </div>
              </div>
            </NCheckbox>
          </div>
        </div>
        <template #footer>
          <div class="todo-footer">
            <NInput
              v-model:value="newTask"
              :placeholder="t('dashboard.addTaskPlaceholder')"
              round
              @keyup.enter="handleAddTask"
            >
              <template #suffix>
                <NButton quaternary circle @click="handleAddTask">
                  <template #icon>
                    <NIcon><AddOutline /></NIcon>
                  </template>
                </NButton>
              </template>
            </NInput>
          </div>
        </template>
      </NCard>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  NCard,
  NButton,
  NIcon,
  NTag,
  NCheckbox,
  NInput,
  useMessage
} from 'naive-ui'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { BarChart, LineChart, PieChart } from 'echarts/charts'
import { GridComponent, TooltipComponent, LegendComponent, TitleComponent } from 'echarts/components'
import VChart from 'vue-echarts'
import {
  RefreshOutline,
  DownloadOutline,
  FileTrayFullOutline,
  LogOutOutline,
  AlertCircleOutline,
  CashOutline,
  TrendingUpOutline,
  TrendingDownOutline,
  BarChartOutline,
  PieChartOutline,
  DocumentTextOutline,
  CheckmarkCircleOutline,
  TimeOutline,
  PeopleOutline,
  AddOutline
} from '@vicons/ionicons5'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores/auth'
import * as warehouseInApi from '@/api/warehouse-in'
import * as loanOutApi from '@/api/loan-out'

use([CanvasRenderer, BarChart, LineChart, PieChart, GridComponent, TooltipComponent, LegendComponent, TitleComponent])

// 页面元信息
definePageMeta({
  middleware: ['auth'],
  layout: 'default',
  meta: {
    title: 'Dashboard - CAWMS',
    description: 'Collateral Asset Warehouse Management Dashboard',
    requiresAuth: true
  }
})

// 状态管理
const authStore = useAuthStore()
const message = useMessage()
const { t } = useI18n()

// 响应式状态
const stats = reactive({
  inbound: {
    total: 1248,
    today: 12,
    trend: 'up' as 'up' | 'down',
    change: 8.5
  },
  loanOut: {
    total: 892,
    pending: 24,
    trend: 'down' as 'up' | 'down',
    change: -2.3
  },
  overdue: {
    total: 18,
    pending: 5,
    trend: 'up' as 'up' | 'down',
    change: 12.7
  },
  financial: {
    total: 48250000,
    monthly: 1250000,
    trend: 'up' as 'up' | 'down',
    change: 3.2
  }
})

const recentActivities = ref([
  {
    id: 1,
    type: 'inbound',
    icon: FileTrayFullOutline,
    title: t('dashboard.activity.newInbound'),
    description: t('dashboard.activity.newInboundDesc', { user: '张三', id: '202403001' }),
    time: t('time.minutesAgo', { n: 5 })
  },
  {
    id: 2,
    type: 'approval',
    icon: CheckmarkCircleOutline,
    title: t('dashboard.activity.approved'),
    description: t('dashboard.activity.approvedDesc', { id: '202402998' }),
    time: t('time.minutesAgo', { n: 30 })
  },
  {
    id: 3,
    type: 'loan',
    icon: LogOutOutline,
    title: t('dashboard.activity.loanOut'),
    description: t('dashboard.activity.loanOutDesc', { asset: '笔记本电脑', user: '李四' }),
    time: t('time.hoursAgo', { n: 2 })
  },
  {
    id: 4,
    type: 'overdue',
    icon: AlertCircleOutline,
    title: t('dashboard.activity.overdueAlert'),
    description: t('dashboard.activity.overdueAlertDesc', { count: 3 }),
    time: t('time.hoursAgo', { n: 5 })
  },
  {
    id: 5,
    type: 'report',
    icon: DocumentTextOutline,
    title: t('dashboard.activity.reportGenerated'),
    description: t('dashboard.activity.reportGeneratedDesc'),
    time: t('time.yesterday')
  }
])

const pendingTasks = ref([
  {
    id: 1,
    title: t('dashboard.task.reviewInbound', { id: '202403001' }),
    completed: false,
    priority: 'high' as 'high' | 'medium' | 'low',
    deadline: `${t('common.today')} 18:00`
  },
  {
    id: 2,
    title: t('dashboard.task.handleOverdue', { id: '202402123' }),
    completed: false,
    priority: 'high',
    deadline: `${t('common.today')} 20:00`
  },
  {
    id: 3,
    title: t('dashboard.task.generateMonthlyReport'),
    completed: true,
    priority: 'medium',
    deadline: `4${t('common.month')}5${t('common.day')}`
  },
  {
    id: 4,
    title: t('dashboard.task.updateSystemConfig'),
    completed: false,
    priority: 'low',
    deadline: `4${t('common.month')}10${t('common.day')}`
  },
  {
    id: 5,
    title: t('dashboard.task.reviewUserPermissions'),
    completed: false,
    priority: 'medium',
    deadline: `4${t('common.month')}7${t('common.day')}`
  }
])

const newTask = ref('')

// 计算属性
const completedTasks = computed(() => {
  return pendingTasks.value.filter(task => task.completed).length
})

const totalTasks = computed(() => {
  return pendingTasks.value.length
})

// 方法
const handleRefresh = async () => {
  message.loading(t('dashboard.refreshing'), { duration: 1000 })
  await loadDashboardData()
  message.success(t('dashboard.dataRefreshed'))
}

const handleExport = () => {
  message.info(t('dashboard.exportDeveloping'))
}

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('zh-CN', {
    style: 'currency',
    currency: 'CNY',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(value)
}

const handleTaskToggle = (task: any) => {
  console.log(t('dashboard.taskStatusUpdate'), task)
  message.success(t('dashboard.taskStatus', { title: task.title, status: task.completed ? t('common.completed') : t('common.todo') }))
}

const handleAddTask = () => {
  if (!newTask.value.trim()) {
    message.warning(t('dashboard.pleaseEnterTask'))
    return
  }
  
  const newTaskItem = {
    id: pendingTasks.value.length + 1,
    title: newTask.value,
    completed: false,
    priority: 'medium' as 'high' | 'medium' | 'low',
    deadline: `${t('common.today')} 23:59`
  }
  
  pendingTasks.value.unshift(newTaskItem)
  message.success(t('dashboard.taskAdded'))
  newTask.value = ''
}

// 图表配置
const inboundTrendOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
  xAxis: { type: 'category', data: [t('months.jan'), t('months.feb'), t('months.mar'), t('months.apr'), t('months.may'), t('months.jun')] },
  yAxis: { type: 'value' },
  series: [
    {
      name: t('dashboard.inboundCount'),
      type: 'bar',
      data: [120, 132, 101, 134, 190, 230],
      itemStyle: { color: '#1890ff', borderRadius: [4, 4, 0, 0] }
    },
    {
      name: t('dashboard.approvedCount'),
      type: 'line',
      data: [110, 125, 95, 128, 180, 210],
      smooth: true,
      itemStyle: { color: '#52c41a' }
    }
  ]
}))

const loanOutDistributionOption = computed(() => ({
  tooltip: { trigger: 'item' },
  legend: { bottom: '0%', left: 'center' },
  series: [
    {
      name: t('dashboard.loanOutDistribution'),
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      label: { show: false, position: 'center' },
      emphasis: { label: { show: true, fontSize: 16, fontWeight: 'bold' } },
      data: [
        { value: 340, name: t('departments.tech'), itemStyle: { color: '#1890ff' } },
        { value: 210, name: t('departments.finance'), itemStyle: { color: '#52c41a' } },
        { value: 158, name: t('departments.marketing'), itemStyle: { color: '#faad14' } },
        { value: 104, name: t('departments.operations'), itemStyle: { color: '#eb2f96' } },
        { value: 80, name: t('departments.others'), itemStyle: { color: '#722ed1' } }
      ]
    }
  ]
}))

// 加载仪表板数据
const loadDashboardData = async () => {
  try {
    const whStats = await warehouseInApi.getStatistics()
    stats.inbound.total = whStats.total || 0
    stats.inbound.today = whStats.completed || 0
  } catch (e) {
    // 使用默认 mock 数据
  }
  try {
    const loStats = await loanOutApi.getStatistics()
    stats.loanOut.total = loStats.total || 0
    stats.loanOut.pending = loStats.loaned || 0
    stats.overdue.total = loStats.overdue || 0
    stats.overdue.pending = loStats.nearDue || 0
  } catch (e) {
    // 使用默认 mock 数据
  }
}

// 初始化
onMounted(async () => {
  await loadDashboardData()
})
</script>

<style scoped>
.dashboard-page {
  padding: 24px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.header-content {
  flex: 1;
}

.page-title {
  font-size: 24px;
  font-weight: 700;
  margin: 0 0 8px 0;
  color: var(--text-color);
}

.page-subtitle {
  font-size: 14px;
  color: var(--text-color-secondary);
  margin: 0;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}

.stat-card {
  height: 100%;
}

.stat-card-cover {
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px 8px 0 0;
}

.stat-card-content {
  padding: 16px;
}

.stat-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.stat-card-header h3 {
  font-size: 16px;
  font-weight: 600;
  margin: 0;
  color: var(--text-color);
}

.stat-card-body {
  margin-bottom: 12px;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  line-height: 1.2;
  color: var(--text-color);
  margin-bottom: 4px;
}

.stat-label {
  font-size: 12px;
  color: var(--text-color-secondary);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.stat-card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 12px;
  border-top: 1px solid var(--border-color-split);
}

.stat-trend {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 14px;
  font-weight: 500;
}

.trend-up {
  color: var(--success-color);
}

.trend-down {
  color: var(--error-color);
}

.stat-meta {
  font-size: 12px;
  color: var(--text-color-secondary);
}

.charts-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}

.chart-card {
  height: 300px;
}

.chart-container {
  height: 240px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.chart-placeholder {
  text-align: center;
}

.chart {
  width: 100%;
  height: 100%;
}

.recent-activity,
.todo-list {
  margin-bottom: 24px;
}

.activity-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.activity-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 0;
}

.activity-icon {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  flex-shrink: 0;
}

.activity-icon.inbound {
  background-color: #1890ff;
}

.activity-icon.approval {
  background-color: #52c41a;
}

.activity-icon.loan {
  background-color: #722ed1;
}

.activity-icon.overdue {
  background-color: #f5222d;
}

.activity-icon.report {
  background-color: #fa8c16;
}

.activity-content {
  flex: 1;
}

.activity-title {
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 4px;
  color: var(--text-color);
}

.activity-description {
  font-size: 12px;
  color: var(--text-color-secondary);
}

.activity-time {
  font-size: 12px;
  color: var(--text-color-disabled);
  flex-shrink: 0;
}

.todo-items {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.todo-item {
  padding: 8px 0;
}

.todo-content {
  margin-left: 8px;
}

.todo-title {
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 4px;
  color: var(--text-color);
}

.todo-title.completed {
  text-decoration: line-through;
  color: var(--text-color-disabled);
}

.todo-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
}

.todo-deadline {
  color: var(--text-color-secondary);
}

.todo-footer {
  padding-top: 12px;
  border-top: 1px solid var(--border-color-split);
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .charts-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .dashboard-page {
    padding: 16px;
  }
  
  .page-header {
    flex-direction: column;
    align-items: stretch;
    gap: 16px;
  }
  
  .header-actions {
    justify-content: flex-start;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
  }
  
  .activity-item {
    flex-wrap: wrap;
  }
  
  .activity-time {
    width: 100%;
    text-align: right;
    margin-top: 4px;
  }
}

@media (max-width: 576px) {
  .dashboard-page {
    padding: 12px;
  }
  
  .page-title {
    font-size: 20px;
  }
  
  .stat-value {
    font-size: 24px;
  }
}
</style>