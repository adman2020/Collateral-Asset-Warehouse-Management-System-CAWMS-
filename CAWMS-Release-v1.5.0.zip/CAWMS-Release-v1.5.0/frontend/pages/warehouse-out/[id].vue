<template>
  <div class="warehouse-out-detail-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('warehouseOut.detailTitle') }}</h1>
        <p class="page-subtitle">{{ $t('warehouseOut.warehouseOutNo') }}: {{ detail.warehouseOutNo || detail.id }} | {{ $t('warehouseOut.status') }}: {{ formatStatus(detail.status) }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="router.back()">{{ $t('common.back') }}</NButton>
        <NButton :disabled="!canEdit" @click="handleEdit">{{ $t('common.edit') }}</NButton>
        <NButton type="primary" :disabled="!canSubmit" @click="handleSubmit">{{ $t('common.submit') }}</NButton>
        <NButton type="warning" :disabled="!canApprove" @click="handleApprove">{{ $t('common.approve') }}</NButton>
        <NButton type="info" :disabled="!canComplete" @click="handleComplete">{{ $t('common.completed') }}</NButton>
        <NButton type="error" :disabled="!canCancel" @click="handleCancel">{{ $t('common.cancel') }}</NButton>
      </div>
    </div>

    <NGrid :cols="3" :x-gap="16" :y-gap="16">
      <NGi :span="2">
        <NCard :title="$t('warehouseOut.basicInfo')" size="small">
          <NDescriptions :column="2" bordered size="small">
            <NDescriptionsItem :label="$t('warehouseOut.warehouseOutNo')">{{ detail.warehouseOutNo || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.warehouseInNo')">{{ detail.warehouseInNo || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.collateralName')">{{ detail.collateralName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.collateralType')">{{ detail.collateralType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.warehouse')">{{ detail.warehouseName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.releaseType')">{{ formatReleaseType(detail.releaseType) }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.releaseAmount')">{{ formatCurrency(detail.releaseAmount) }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.releasePercentage')">{{ detail.releasePercentage ? detail.releasePercentage + '%' : '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.releaseReason')">{{ detail.releaseReason || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.applicant')">{{ detail.applicantName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.applyTime')">{{ detail.applyTime ? detail.applyTime.slice(0, 16).replace('T', ' ') : '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.status')">
              <NTag :type="getStatusType(detail.status)">{{ formatStatus(detail.status) }}</NTag>
            </NDescriptionsItem>
            <NDescriptionsItem :label="$t('common.remark')" :span="2">{{ detail.remarks || '-' }}</NDescriptionsItem>
          </NDescriptions>
        </NCard>

        <NCard :title="$t('warehouseOut.approvalHistory')" size="small" class="history-card">
          <NEmpty v-if="!detail.approvals || detail.approvals.length === 0" :description="$t('warehouseOut.noApprovalRecords')" />
          <NTimeline v-else>
            <NTimelineItem
              v-for="item in detail.approvals"
              :key="item.id"
              :type="getApprovalTimelineType(item.approvalStatus)"
              :title="item.stepName || getApprovalStepName(item.step)"
              :content="formatApprovalContent(item)"
              :time="item.approvalTime ? item.approvalTime.slice(0, 16).replace('T', ' ') : $t('warehouseOut.pendingApproval')"
            />
          </NTimeline>
        </NCard>
      </NGi>

      <NGi>
        <NCard :title="$t('warehouseOut.quickActions')" size="small">
          <NSpace vertical>
            <NButton block type="primary" :disabled="!canSubmit" @click="handleSubmit">{{ $t('warehouseOut.submitApproval') }}</NButton>
            <NButton block type="warning" :disabled="!canApprove" @click="handleApprove">{{ $t('warehouseOut.approvePass') }}</NButton>
            <NButton block type="error" :disabled="!canApprove" @click="handleReject">{{ $t('warehouseOut.rejectApplication') }}</NButton>
            <NButton block type="info" :disabled="!canComplete" @click="handleComplete">{{ $t('warehouseOut.completeWarehouseOut') }}</NButton>
          </NSpace>
        </NCard>
      </NGi>
    </NGrid>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { NCard, NButton, NGrid, NGi, NDescriptions, NDescriptionsItem, NTag, NSpace, NTimeline, NTimelineItem, NEmpty, useMessage } from 'naive-ui'
import { getWarehouseOutDetail, submitWarehouseOut, approveWarehouseOut, completeWarehouseOut, cancelWarehouseOut, type WarehouseOut, type WarehouseOutApproval } from '~/api/warehouse-out'

const router = useRouter()
const route = useRoute()
const message = useMessage()
const { t } = useI18n()

const id = computed(() => route.params.id as string)
const detail = ref<Partial<WarehouseOut>>({})

const canEdit = computed(() => detail.value.status === 'DRAFT')
const canSubmit = computed(() => detail.value.status === 'DRAFT')
const canApprove = computed(() => detail.value.status === 'SUBMITTED')
const canComplete = computed(() => detail.value.status === 'APPROVED')
const canCancel = computed(() => detail.value.status !== 'COMPLETED')

function formatReleaseType(type?: string) {
  const map: Record<string, string> = { PARTIAL: t('warehouseOut.releaseTypePartial'), FULL: t('warehouseOut.releaseTypeFullAmount') }
  return map[type || ''] || type || '-'
}
function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}
function formatStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), SUBMITTED: t('status.submitted'), APPROVED: t('status.approved'), COMPLETED: t('status.completed'), CANCELLED: t('status.cancelled') }
  return map[status || ''] || status || '-'
}
function getStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', SUBMITTED: 'warning', APPROVED: 'success', COMPLETED: 'success', CANCELLED: 'error' }
  return map[status || ''] || 'default'
}

function getApprovalTimelineType(status?: string) {
  const map: Record<string, any> = { PENDING: 'default', APPROVED: 'success', REJECTED: 'error', RETURNED: 'warning', CANCELLED: 'error' }
  return map[status || ''] || 'default'
}
function getApprovalStepName(step?: number) {
  const map: Record<number, string> = { 1: t('warehouseOut.stepRiskReview'), 2: t('warehouseOut.stepComplianceAudit'), 3: t('warehouseOut.stepWarehouseManagerApprove'), 4: t('warehouseOut.stepFinalConfirm') }
  return map[step || 0] || `${t('warehouseOut.step')} ${step}`
}
function formatApprovalContent(item: WarehouseOutApproval) {
  let content = `${t('warehouseOut.approver')}：${item.approverName || item.approverRole || t('common.pending')}`
  if (item.approvalOpinion) {
    content += ` | ${t('warehouseOut.opinionLabel')}：${item.approvalOpinion}`
  }
  if (item.approvalStatus) {
    content += ` | ${t('warehouseOut.resultLabel')}：${formatApprovalStatus(item.approvalStatus)}`
  }
  return content
}
function formatApprovalStatus(status?: string) {
  const map: Record<string, string> = { PENDING: t('status.pending'), APPROVED: t('warehouseOut.statusPassed'), REJECTED: t('status.rejected'), RETURNED: t('warehouseOut.statusReturned') }
  return map[status || ''] || status || '-'
}

async function loadData() {
  try {
    const res = await getWarehouseOutDetail(Number(id.value))
    console.log('[WarehouseOut Detail] API Response:', res.data)
    if (res.data.code === 0) {
      detail.value = res.data.data
      console.log('[WarehouseOut Detail] approvals:', detail.value.approvals)
    } else {
      throw new Error(res.data.message)
    }
  } catch (e: any) {
    console.error('[WarehouseOut Detail] Load error:', e)
    message.error(e.message || t('warehouseOut.loadDetailFailed'))
    detail.value = { id: Number(id.value), status: 'DRAFT', warehouseOutNo: `WOUT-${id.value}`, collateralName: t('warehouseOut.testCollateral'), warehouseName: t('warehouseOut.testWarehouse') }
  }
}

function handleEdit() {
  router.push(`/warehouse-out/${id.value}?mode=edit`)
}
async function handleSubmit() {
  try {
    const res = await submitWarehouseOut({ id: Number(id.value) })
    if (res.data.code === 0) {
      message.success(t('warehouseOut.submitSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('warehouseOut.submitFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('warehouseOut.submitFailed'))
  }
}
async function handleApprove() {
  try {
    const res = await approveWarehouseOut({ id: Number(id.value), step: 1, approvalStatus: 'APPROVED', approvalOpinion: t('common.agree') })
    if (res.data.code === 0) {
      message.success(t('warehouseOut.approveSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('warehouseOut.approveFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('warehouseOut.approveFailed'))
  }
}
async function handleReject() {
  try {
    const res = await cancelWarehouseOut(Number(id.value))
    if (res.data.code === 0) {
      message.success(t('warehouseOut.rejectSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('warehouseOut.operationFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('warehouseOut.operationFailed'))
  }
}
async function handleComplete() {
  try {
    const res = await completeWarehouseOut(Number(id.value))
    if (res.data.code === 0) {
      message.success(t('warehouseOut.completeSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('warehouseOut.operationFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('warehouseOut.operationFailed'))
  }
}
async function handleCancel() {
  try {
    const res = await cancelWarehouseOut(Number(id.value))
    if (res.data.code === 0) {
      message.success(t('warehouseOut.cancelSuccess'))
      loadData()
    } else {
      message.error(res.data.message || t('warehouseOut.operationFailed'))
    }
  } catch (e: any) {
    message.error(e.message || t('warehouseOut.operationFailed'))
  }
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.warehouse-out-detail-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.page-subtitle {
  margin: 4px 0 0;
  color: #666;
}
.header-actions {
  display: flex;
  gap: 8px;
}
</style>
