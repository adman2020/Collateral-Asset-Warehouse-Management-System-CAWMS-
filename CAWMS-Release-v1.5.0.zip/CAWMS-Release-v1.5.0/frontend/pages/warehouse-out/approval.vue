<template>
  <div class="warehouse-out-approval-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('warehouseOut.approvalTitle') }}</h1>
        <p class="page-subtitle">{{ $t('warehouseOut.warehouseOutNo') }}: {{ detail.whCode || detail.id }} | {{ $t('warehouseOut.collateralName') }}: {{ detail.collateralName }} | {{ $t('warehouseOut.status') }}: {{ formatStatus(detail.status) }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="router.back()">{{ $t('common.back') }}</NButton>
        <NButton type="info" @click="router.push(`/warehouse-out/${id}`)">{{ $t('warehouseOut.viewDetail') }}</NButton>
      </div>
    </div>

    <NGrid :cols="3" :x-gap="16" :y-gap="16">
      <NGi :span="2">
        <NCard :title="$t('warehouseOut.approvalProgress')" size="small" class="progress-card">
          <NSteps :current="currentStep" status="process">
            <NStep :title="$t('warehouseOut.stepSubmit')" :description="submitDesc" />
            <NStep :title="$t('warehouseOut.stepRiskReview')" :description="stepDesc(1)" />
            <NStep :title="$t('warehouseOut.stepComplianceReview')" :description="stepDesc(2)" />
            <NStep :title="$t('warehouseOut.stepWarehouseConfirm')" :description="stepDesc(3)" />
            <NStep :title="$t('warehouseOut.stepFinalVerification')" :description="stepDesc(4)" />
          </NSteps>
        </NCard>

        <NCard :title="$t('warehouseOut.approvalAction')" size="small" class="approval-card">
          <NForm ref="formRef" :model="form" :rules="rules" label-placement="left" label-width="100px">
            <NFormItem :label="$t('warehouseOut.approvalResult')" path="result">
              <NRadioGroup v-model:value="form.result">
                <NSpace>
                  <NRadio value="APPROVE"><NTag type="success" size="small">{{ $t('common.agree') }}</NTag></NRadio>
                  <NRadio value="REJECT"><NTag type="error" size="small">{{ $t('common.reject') }}</NTag></NRadio>
                </NSpace>
              </NRadioGroup>
            </NFormItem>
            <NFormItem :label="$t('warehouseOut.approvalComment')" path="comment">
              <NInput v-model:value="form.comment" type="textarea" :rows="3" :placeholder="$t('warehouseOut.pleaseInputApprovalComment')" />
            </NFormItem>
          </NForm>
          <NSpace justify="end">
            <NButton :loading="submitting" type="primary" @click="handleSubmit">{{ $t('warehouseOut.submitApproval') }}</NButton>
          </NSpace>
        </NCard>
      </NGi>

      <NGi>
        <NCard :title="$t('warehouseOut.applicationInfo')" size="small">
          <NDescriptions :column="1" bordered size="small">
            <NDescriptionsItem :label="$t('warehouseOut.warehouseInNo')">{{ detail.warehouseInCode || detail.inCode || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.collateralName')">{{ detail.collateralName || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.collateralType')">{{ detail.collateralType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.warehouse')">{{ detail.warehouseName || detail.warehouseCode || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.releaseType')">{{ detail.releaseType || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.releaseAmount')">{{ formatCurrency(detail.releaseAmount) }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.releaseReason')">{{ detail.releaseReason || '-' }}</NDescriptionsItem>
            <NDescriptionsItem :label="$t('warehouseOut.status')">
              <NTag :type="getStatusType(detail.status)">{{ formatStatus(detail.status) }}</NTag>
            </NDescriptionsItem>
          </NDescriptions>
        </NCard>

        <NCard :title="$t('warehouseOut.approvalHistory')" size="small" class="history-card">
          <NEmpty v-if="history.length === 0" :description="$t('warehouseOut.noRecords')" />
          <NTimeline v-else>
            <NTimelineItem
              v-for="h in history"
              :key="h.id"
              :title="h.operationType || h.operationDesc"
              :content="`${h.operatorName || $t('common.system')}：${h.operationDesc || $t('warehouseOut.noOpinion')}`"
              :time="h.operationTime"
            />
          </NTimeline>
        </NCard>
      </NGi>
    </NGrid>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { NCard, NButton, NGrid, NGi, NForm, NFormItem, NInput, NRadioGroup, NRadio, NTag, NSpace, NSteps, NStep, NDescriptions, NDescriptionsItem, NTimeline, NTimelineItem, NEmpty, useMessage, type FormInst, type FormRules } from 'naive-ui'
import { getWarehouseOutDetail, getWarehouseOutHistory, approveWarehouseOut, cancelWarehouseOut, type WarehouseOut, type WarehouseOutHistory } from '~/api/warehouse-out'
import { useAuthStore } from '@/stores/auth'
import { useI18n } from 'vue-i18n'

const router = useRouter()
const route = useRoute()
const message = useMessage()
const authStore = useAuthStore()
const { t } = useI18n()

const id = computed(() => (route.query.id || route.params.id) as string)
const detail = ref<Partial<WarehouseOut>>({})
const history = ref<WarehouseOutHistory[]>([])
const submitting = ref(false)

const formRef = ref<FormInst | null>(null)
const form = reactive({
  result: 'APPROVE',
  comment: t('common.agree')
})

const rules: FormRules = {
  result: [{ required: true, message: t('warehouseOut.pleaseSelectApprovalResult'), trigger: 'change' }],
  comment: [{ required: true, message: t('warehouseOut.pleaseInputApprovalComment'), trigger: 'blur' }]
}

const stepNames: Record<number, string> = {
  1: t('warehouseOut.stepRiskReview'),
  2: t('warehouseOut.stepComplianceReview'),
  3: t('warehouseOut.stepWarehouseConfirm'),
  4: t('warehouseOut.stepFinalVerification')
}

const currentStep = computed(() => {
  const status = detail.value.status
  if (status === 'APPROVED' || status === 'COMPLETED') return 5
  if (status === 'SUBMITTED') {
    const pending = detail.value.approvals?.find((a: any) => a.status === 'PENDING' || a.approvalStatus === 'PENDING')
    if (pending) {
      return (pending.step || pending.stepNumber || 1) + 1
    }
  }
  return 1
})

const submitDesc = computed(() => {
  return detail.value.submittedAt ? `${t('warehouseOut.submittedAt')} ${detail.value.submittedAt}` : t('warehouseOut.pendingSubmit')
})

function stepDesc(step: number) {
  const name = stepNames[step]
  if (!name) return t('warehouseOut.pendingApproval')
  const rec = history.value.find(h => h.operationDesc?.includes(name))
  return rec ? `${rec.operatorName || t('common.system')}: ${rec.operationDesc || t('warehouseOut.noOpinion')}` : t('warehouseOut.pendingApproval')
}

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}
function formatStatus(status?: string) {
  const map: Record<string, string> = { DRAFT: t('status.draft'), SUBMITTED: t('status.submitted'), IN_REVIEW: t('status.inReview'), APPROVED: t('warehouseOut.statusPassed'), REJECTED: t('status.rejected'), COMPLETED: t('status.completed') }
  return map[status || ''] || status || '-'
}
function getStatusType(status?: string) {
  const map: Record<string, any> = { DRAFT: 'default', SUBMITTED: 'info', IN_REVIEW: 'warning', APPROVED: 'success', REJECTED: 'error', COMPLETED: 'success' }
  return map[status || ''] || 'default'
}

async function loadData() {
  if (!id.value || id.value === 'undefined') {
    message.error(t('warehouseOut.missingApprovalId'))
    router.push('/warehouse-out')
    return
  }
  try {
    const [detailRes, historyRes] = await Promise.all([
      getWarehouseOutDetail(Number(id.value)),
      getWarehouseOutHistory(Number(id.value)).catch(() => ({ data: { data: [] } }))
    ])
    detail.value = detailRes.data.data || {}
    history.value = historyRes.data.data || []
  } catch (e: any) {
    message.error(e.message || t('message.loadFailed'))
    detail.value = {
      id: Number(id.value),
      whCode: `WO-${id.value}`,
      status: 'SUBMITTED',
      collateralName: t('warehouseOut.testCollateral'),
      collateralType: t('warehouseOut.movableProperty'),
      warehouseName: t('warehouseOut.testWarehouse'),
      releaseType: t('warehouseOut.normalRelease'),
      releaseAmount: 1000000,
      releaseReason: t('common.test'),
      approvals: [{ step: 1, status: 'PENDING' }]
    }
    history.value = []
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    if (form.result === 'APPROVE') {
      const res = await approveWarehouseOut({ id: Number(id.value), step: 1, approvalStatus: 'APPROVED', approvalOpinion: form.comment })
      if (res.data.code !== 0) throw new Error(res.data.message)
      message.success(t('warehouseOut.approveSuccess'))
    } else if (form.result === 'REJECT') {
      const res = await cancelWarehouseOut(Number(id.value))
      if (res.data.code !== 0) throw new Error(res.data.message)
      message.success(t('warehouseOut.rejectSuccess'))
    }
    router.push('/warehouse-out')
  } catch (e: any) {
    message.error(e.message || t('warehouseOut.submitFailed'))
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.warehouse-out-approval-page {
  padding: 24px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
}
.progress-card, .approval-card, .history-card {
  margin-bottom: 16px;
}
</style>
