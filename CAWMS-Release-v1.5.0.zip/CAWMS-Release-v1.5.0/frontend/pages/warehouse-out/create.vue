<template>
  <div class="create-warehouse-out-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">{{ $t('warehouseOut.createTitle') }}</h1>
        <p class="page-subtitle">{{ $t('warehouseOut.createSubtitle') }}</p>
      </div>
      <div class="header-actions">
        <NButton @click="handleCancel">{{ $t('common.cancel') }}</NButton>
        <NButton type="primary" :loading="submitting" @click="handleSubmit">{{ $t('warehouseOut.submitApplication') }}</NButton>
      </div>
    </div>

    <NForm ref="formRef" :model="form" :rules="rules" label-placement="left" label-width="140px">
      <NCard :title="$t('warehouseOut.selectAsset')" size="small" class="form-section">
        <NFormItem :label="$t('warehouseOut.warehouseInRecord')" path="warehouseInId">
          <NSelect
            v-model:value="form.warehouseInId"
            :options="warehouseInOptions"
            filterable
            :loading="whInLoading"
            :placeholder="$t('warehouseOut.pleaseSelectAsset')"
            clearable
            @focus="loadWarehouseInOptions"
            @update:value="onWarehouseInChange"
          />
        </NFormItem>
        <NDescriptions v-if="selectedWarehouseIn" label-placement="left" :column="3" bordered size="small" class="asset-preview">
          <NDescriptionsItem :label="$t('warehouseOut.warehouseInNo')">{{ selectedWarehouseIn.whCode || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('warehouseOut.businessDepartment')">{{ selectedWarehouseIn.buName || selectedWarehouseIn.buCode || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('warehouseOut.customerId')">{{ selectedWarehouseIn.customerId || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('warehouseOut.customerName')">{{ selectedWarehouseIn.customerName || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('warehouseOut.collateralType')">{{ selectedWarehouseIn.collateralType || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('warehouseOut.collateralValue')">{{ formatCurrency(selectedWarehouseIn.collateralValue) }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('warehouseOut.creditAgreementNo')">{{ selectedWarehouseIn.creditAgreementNo || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('warehouseOut.intakeType')">{{ selectedWarehouseIn.intakeType || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('common.status')"><NTag type="success">COMPLETED</NTag></NDescriptionsItem>
          <NDescriptionsItem :label="$t('warehouseOut.warehouse')">{{ selectedWarehouseIn.warehouseName || '-' }}</NDescriptionsItem>
          <NDescriptionsItem :label="$t('warehouseOut.zone')">{{ selectedWarehouseIn.zoneName || '-' }}</NDescriptionsItem>
        </NDescriptions>
      </NCard>

      <NCard :title="$t('warehouseOut.releaseInfo')" size="small" class="form-section">
        <div class="form-row">
          <NFormItem :label="$t('warehouseOut.releaseType')" path="releaseType" style="flex: 1;">
            <NSelect
              v-model:value="form.releaseType"
              :options="releaseTypeOptions"
              :placeholder="$t('warehouseOut.pleaseSelectReleaseType')"
              @update:value="onReleaseTypeChange"
            />
          </NFormItem>
          <NFormItem :label="$t('warehouseOut.releaseReasonType')" path="releaseReasonType" style="flex: 1;">
            <NSelect
              v-model:value="form.releaseReasonType"
              :options="releaseReasonTypeOptions"
              :placeholder="$t('warehouseOut.pleaseSelectReleaseReasonType')"
            />
          </NFormItem>
        </div>
        <div v-if="form.releaseType === 'PARTIAL'" class="form-row">
          <NFormItem :label="$t('warehouseOut.releaseAmount')" path="releaseAmount" style="flex: 1;">
            <NInputNumber v-model:value="form.releaseAmount" :min="0" :placeholder="$t('warehouseOut.pleaseInputReleaseAmount')" style="width: 100%" />
          </NFormItem>
          <NFormItem :label="$t('warehouseOut.releasePercentage')" path="releasePercentage" style="flex: 1;">
            <NInputNumber v-model:value="form.releasePercentage" :min="0" :max="100" :placeholder="$t('warehouseOut.pleaseInputReleasePercentage')" style="width: 100%" />
          </NFormItem>
        </div>
        <NFormItem :label="$t('warehouseOut.releaseReason')" path="releaseReason">
          <NInput
            v-model:value="form.releaseReason"
            type="textarea"
            :rows="3"
            :placeholder="$t('warehouseOut.pleaseInputReleaseReason')"
          />
        </NFormItem>
        <NFormItem :label="$t('common.remark')" path="remarks">
          <NInput
            v-model:value="form.remarks"
            type="textarea"
            :rows="2"
            :placeholder="$t('warehouseOut.pleaseInputRemarks')"
          />
        </NFormItem>
      </NCard>
    </NForm>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { NCard, NButton, NForm, NFormItem, NSelect, NInput, NInputNumber, NDescriptions, NDescriptionsItem, NTag, useMessage, type FormInst, type FormRules } from 'naive-ui'
import warehouseInApi from '@/api/warehouse-in'
import warehouseApi from '@/api/warehouse'
import warehouseZoneApi from '@/api/warehouse-zone'
import { useI18n } from 'vue-i18n'
import { createWarehouseOut } from '~/api/warehouse-out'

const router = useRouter()
const message = useMessage()
const { t } = useI18n()

const formRef = ref<FormInst | null>(null)
const submitting = ref(false)
const whInLoading = ref(false)

const form = reactive({
  warehouseInId: null as number | null,
  releaseType: 'PARTIAL' as 'PARTIAL' | 'FULL',
  releaseAmount: null as number | null,
  releasePercentage: null as number | null,
  releaseReasonType: 'LOAN_REPAYMENT' as 'LOAN_REPAYMENT' | 'CREDIT_LINE_REDUCTION' | 'COLLATERAL_REPLACEMENT' | 'OTHER',
  releaseReason: '',
  remarks: ''
})

const rules: FormRules = {
  warehouseInId: { required: true, message: t('warehouseOut.pleaseSelectWarehouseIn'), trigger: 'change', type: 'number' },
  releaseType: { required: true, message: t('warehouseOut.pleaseSelectReleaseType'), trigger: 'change' },
  releaseReasonType: { required: true, message: t('warehouseOut.pleaseSelectReleaseReasonType'), trigger: 'change' },
  releaseReason: { required: true, message: t('warehouseOut.pleaseInputReleaseReason'), trigger: 'blur' }
}

const releaseTypeOptions = [
  { label: t('warehouseOut.releaseTypePartial'), value: 'PARTIAL' },
  { label: t('warehouseOut.releaseTypeFull'), value: 'FULL' }
]

const releaseReasonTypeOptions = [
  { label: t('warehouseOut.reasonLoanRepayment'), value: 'LOAN_REPAYMENT' },
  { label: t('warehouseOut.reasonCreditLineReduction'), value: 'CREDIT_LINE_REDUCTION' },
  { label: t('warehouseOut.reasonCollateralReplacement'), value: 'COLLATERAL_REPLACEMENT' },
  { label: t('common.other'), value: 'OTHER' }
]

const warehouseInOptions = ref<{ label: string; value: number; whCode?: string; customerId?: string; customerName: string; collateralType: string; collateralValue: number; creditAgreementNo?: string; intakeType?: string; buName?: string; buCode?: string; warehouseId?: number; zoneId?: number }[]>([])
const selectedWarehouseIn = ref<any>(null)

const loadWarehouseInOptions = async () => {
  if (warehouseInOptions.value.length > 0) return
  whInLoading.value = true
  try {
    const res = await warehouseInApi.getList({ pageNum: 1, pageSize: 100, status: 'COMPLETED' })
    warehouseInOptions.value = (res.records || []).map((item: any) => ({
      label: `${item.whCode || item.id} - ${item.customerName}`,
      value: Number(item.id),
      whCode: item.whCode,
      customerId: item.customerId,
      customerName: item.customerName,
      collateralType: item.collateralType,
      collateralValue: item.collateralValue,
      creditAgreementNo: item.creditAgreementNo,
      intakeType: item.intakeType,
      buName: item.buName,
      buCode: item.buCode,
      warehouseId: item.warehouseId,
      zoneId: item.zoneId
    }))
  } catch (error) {
    message.error(t('warehouseOut.loadWarehouseInFailed'))
  } finally {
    whInLoading.value = false
  }
}

const onWarehouseInChange = async (value: number) => {
  const option = warehouseInOptions.value.find(o => o.value === value) || null
  if (!option) {
    selectedWarehouseIn.value = null
    return
  }
  selectedWarehouseIn.value = { ...option }
  if (option.warehouseId) {
    try {
      const wh = await warehouseApi.getById(option.warehouseId)
      selectedWarehouseIn.value.warehouseName = wh.warehouseName || '-'
    } catch (e) {
      selectedWarehouseIn.value.warehouseName = '-'
    }
  } else {
    selectedWarehouseIn.value.warehouseName = '-'
  }
  if (option.zoneId) {
    try {
      const zone = await warehouseZoneApi.getById(option.zoneId)
      selectedWarehouseIn.value.zoneName = zone.zoneName || '-'
    } catch (e) {
      selectedWarehouseIn.value.zoneName = '-'
    }
  } else {
    selectedWarehouseIn.value.zoneName = '-'
  }
}

const onReleaseTypeChange = (value: string) => {
  if (value === 'FULL') {
    const collateralValue = selectedWarehouseIn.value?.collateralValue
    if (collateralValue) {
      form.releaseAmount = collateralValue
      form.releasePercentage = 100
    } else {
      form.releaseAmount = null
      form.releasePercentage = null
    }
  }
}

const formatCurrency = (value?: number) => {
  if (value == null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

const handleCancel = () => {
  router.push('/warehouse-out')
}

const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    submitting.value = true

    const res = await createWarehouseOut({
      warehouseInId: form.warehouseInId!,
      releaseType: form.releaseType,
      releaseAmount: form.releaseAmount || undefined,
      releasePercentage: form.releasePercentage || undefined,
      releaseReasonType: form.releaseReasonType,
      releaseReason: form.releaseReason,
      remarks: form.remarks
    })

    if (res.data.code === 0) {
      message.success(t('warehouseOut.createSuccess'))
      router.push('/warehouse-out')
    } else {
      message.error(res.data.message || t('warehouseOut.createFailed'))
    }
  } catch (error: any) {
    if (error?.message === 'validation failed') return
    const backendMsg = error?.response?.data?.message
    const msg = backendMsg || error?.message || t('common.unknownError')
    console.error(t('warehouseOut.createFailed') + ':', error?.response?.data || error)
    message.error(t('warehouseOut.createFailed') + ': ' + msg)
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  loadWarehouseInOptions()
})
</script>

<style scoped>
.create-warehouse-out-page {
  padding: 24px;
  max-width: 1200px;
  margin: 0 auto;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.header-content {
  flex: 1;
}

.page-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
  margin: 0;
}

.page-subtitle {
  color: #666;
  margin-top: 4px;
  margin-bottom: 0;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.form-section {
  margin-bottom: 24px;
}

.form-row {
  display: flex;
  gap: 24px;
}

.asset-preview {
  margin-top: 12px;
}

:deep(.n-descriptions-table-content) {
  font-size: 14px;
}

:deep(.n-descriptions-header) {
  font-weight: 600;
}
</style>
