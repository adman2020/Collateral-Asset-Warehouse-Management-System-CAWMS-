<template>
  <div class="warehouse-out-page">
    <!-- 页面标题 -->
    <div class="page-header">
      <h1 class="page-title">{{ $t('warehouseOut.title') }}</h1>
      <n-button type="primary" @click="handleCreate">
        <template #icon>
          <n-icon><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg></n-icon>
        </template>
        {{ $t('warehouseOut.createBtn') }}
      </n-button>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #e6f7ff;">📦</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.total || 0 }}</div>
          <div class="stat-label">{{ $t('warehouseOut.total') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #fff7e6;">⏳</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.pendingApprovals || 0 }}</div>
          <div class="stat-label">{{ $t('warehouseOut.pendingApproval') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #f6ffed;">✅</div>
        <div class="stat-content">
          <div class="stat-value">{{ statistics?.completedToday || 0 }}</div>
          <div class="stat-label">{{ $t('warehouseOut.completedToday') }}</div>
        </div>
      </n-card>
      <n-card class="stat-card">
        <div class="stat-icon" style="background: #f0f5ff;">💰</div>
        <div class="stat-content">
          <div class="stat-value">¥{{ (statistics?.totalReleaseAmount || 0) / 10000 }}{{ $t('warehouseOut.tenThousand') }}</div>
          <div class="stat-label">{{ $t('warehouseOut.totalReleaseAmount') }}</div>
        </div>
      </n-card>
    </div>

    <!-- 搜索栏 -->
    <n-card class="search-card">
      <n-grid :cols="4" :x-gap="16" :y-gap="12">
        <n-gi>
          <n-input v-model:value="searchForm.collateralName" :placeholder="$t('warehouseOut.collateralName')" clearable />
        </n-gi>
        <n-gi>
          <n-input v-model:value="searchForm.warehouseInNo" :placeholder="$t('warehouseOut.warehouseInNo')" clearable />
        </n-gi>
        <n-gi>
          <n-select
            v-model:value="searchForm.status"
            :placeholder="$t('warehouseOut.status')"
            :options="statusOptions"
            clearable
          />
        </n-gi>
        <n-gi>
          <n-select
            v-model:value="searchForm.releaseType"
            :placeholder="$t('warehouseOut.releaseType')"
            :options="releaseTypeOptions"
            clearable
          />
        </n-gi>
        <n-gi>
          <n-date-picker
            v-model:value="searchForm.startDate"
            type="date"
            :placeholder="$t('warehouseOut.startDate')"
            style="width: 100%"
          />
        </n-gi>
        <n-gi>
          <n-date-picker
            v-model:value="searchForm.endDate"
            type="date"
            :placeholder="$t('warehouseOut.endDate')"
            style="width: 100%"
          />
        </n-gi>
        <n-gi>
          <n-button type="primary" block @click="handleSearch">
            <template #icon>
              <n-icon><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg></n-icon>
            </template>
            {{ $t('warehouseOut.search') }}
          </n-button>
        </n-gi>
        <n-gi>
          <n-button block @click="handleReset">{{ $t('warehouseOut.reset') }}</n-button>
        </n-gi>
      </n-grid>
    </n-card>

    <!-- 表格 -->
    <n-card class="table-card">
      <n-data-table
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :pagination="pagination"
        :row-key="(row) => row.id"
      />
    </n-card>

    <!-- 新建/详情模态框 -->
    <n-modal
      v-model:show="showModal"
      :title="modalTitle"
      preset="card"
      style="width: 800px"
    >
      <warehouse-out-form
        v-if="showModal"
        :warehouse-out-id="currentWarehouseOutId"
        @success="handleModalSuccess"
        @close="showModal = false"
      />
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useMessage, NButton } from 'naive-ui'
import type { DataTableColumns } from 'naive-ui'
import {
  getWarehouseOutList,
  getWarehouseOutStatistics,
  type WarehouseOut,
  type WarehouseOutStatistics
} from '~/api/warehouse-out'
import { useAuthStore } from '@/stores/auth'
import { useI18n } from 'vue-i18n'
import WarehouseOutForm from '~/components/warehouse-out/WarehouseOutForm.vue'

const router = useRouter()
const message = useMessage()
const authStore = useAuthStore()
const { t } = useI18n()

// 加载状态
const loading = ref(false)

// 统计数据
const statistics = ref<WarehouseOutStatistics>()

// 搜索表单
const searchForm = reactive({
  collateralName: '',
  warehouseInNo: '',
  status: '',
  releaseType: '',
  startDate: null as number | null,
  endDate: null as number | null
})

// 表格数据
const tableData = ref<WarehouseOut[]>([])

// 分页
const pagination = reactive({
  page: 1,
  pageSize: 10,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  itemCount: 0,
  onChange: (page: number) => {
    pagination.page = page
    loadTableData()
  },
  onUpdatePageSize: (pageSize: number) => {
    pagination.pageSize = pageSize
    pagination.page = 1
    loadTableData()
  }
})

// 模态框
const showModal = ref(false)
const modalTitle = ref('')
const currentWarehouseOutId = ref<number | null>(null)

// 选项
const statusOptions = [
  { label: t('status.draft'), value: 'DRAFT' },
  { label: t('status.submitted'), value: 'SUBMITTED' },
  { label: t('status.approved'), value: 'APPROVED' },
  { label: t('status.completed'), value: 'COMPLETED' },
  { label: t('status.cancelled'), value: 'CANCELLED' }
]

const releaseTypeOptions = [
  { label: t('warehouseOut.releaseTypePartial'), value: 'PARTIAL' },
  { label: t('warehouseOut.releaseTypeFull'), value: 'FULL' }
]

// 表格列定义
const columns: DataTableColumns<WarehouseOut> = [
  {
    type: 'selection',
    fixed: 'left'
  },
  {
    title: t('warehouseOut.warehouseOutNo'),
    key: 'warehouseOutNo',
    width: 150,
    fixed: 'left'
  },
  {
    title: t('warehouseOut.warehouseInNo'),
    key: 'warehouseInNo',
    width: 120
  },
  {
    title: t('warehouseOut.collateralName'),
    key: 'collateralName',
    width: 150
  },
  {
    title: t('warehouseOut.releaseType'),
    key: 'releaseType',
    width: 100,
    render: (row) => {
      const typeMap: Record<string, string> = {
        PARTIAL: t('warehouseOut.releaseTypePartial'),
        FULL: t('warehouseOut.releaseTypeFull')
      }
      return typeMap[row.releaseType] || row.releaseType
    }
  },
  {
    title: t('warehouseOut.releaseAmount'),
    key: 'releaseAmount',
    width: 120,
    render: (row) => row.releaseAmount != null ? `¥${(row.releaseAmount / 10000).toFixed(2)}${t('warehouseOut.tenThousand')}` : '-'
  },
  {
    title: t('warehouseOut.releasePercentage'),
    key: 'releasePercentage',
    width: 100,
    render: (row) => row.releasePercentage != null ? `${row.releasePercentage}%` : '-'
  },
  {
    title: t('warehouseOut.warehouse'),
    key: 'warehouseName',
    width: 120
  },
  {
    title: t('warehouseOut.status'),
    key: 'status',
    width: 100,
    render: (row) => {
      const statusMap: Record<string, { type: string; label: string }> = {
        DRAFT: { type: 'default', label: t('status.draft') },
        SUBMITTED: { type: 'warning', label: t('status.inReview') },
        APPROVED: { type: 'info', label: t('status.approved') },
        COMPLETED: { type: 'success', label: t('status.completed') },
        CANCELLED: { type: 'error', label: t('status.cancelled') }
      }
      const status = statusMap[row.status] || { type: 'default', label: row.status }
      return h('n-tag', { type: status.type as any }, { default: () => status.label })
    }
  },
  {
    title: t('warehouseOut.applicant'),
    key: 'applicantName',
    width: 100
  },
  {
    title: t('warehouseOut.applyTime'),
    key: 'applyTime',
    width: 160,
    render: (row) => row.applyTime?.slice(0, 16).replace('T', ' ')
  },
  {
    title: t('common.operation'),
    key: 'actions',
    width: 320,
    fixed: 'right',
    render: (row) => {
      return h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } }, [
        h(NButton, { size: 'small', onClick: () => handleView(row.id) }, { default: () => t('common.view') }),
        h(NButton, { size: 'small', disabled: !canEdit(row), onClick: () => handleEdit(row.id) }, { default: () => t('common.edit') }),
        h(NButton, { size: 'small', type: 'primary', disabled: !canSubmit(row), onClick: () => handleSubmit(row.id) }, { default: () => t('common.submit') }),
        h(NButton, { size: 'small', type: 'warning', disabled: !canApprove(row), onClick: () => handleGoApprove(row.id) }, { default: () => t('common.approve') }),
        h(NButton, { size: 'small', type: 'error', disabled: !canReject(row), onClick: () => handleReject(row.id) }, { default: () => t('common.reject') }),
        h(NButton, { size: 'small', type: 'info', disabled: !canComplete(row), onClick: () => handleComplete(row.id) }, { default: () => t('common.completed') })
      ])
    }
  }
]

// 加载表格数据
const loadTableData = async () => {
  loading.value = true
  try {
    const res = await getWarehouseOutList({
      page: pagination.page,
      size: pagination.pageSize,
      ...searchForm
    })
    if (res.data.code === 0) {
      tableData.value = res.data.data.records
      pagination.itemCount = res.data.data.total
    }
  } catch (error) {
    message.error(t('warehouseOut.loadDataFailed'))
  } finally {
    loading.value = false
  }
}

// 加载统计数据
const loadStatistics = async () => {
  try {
    const res = await getWarehouseOutStatistics()
    if (res.data.code === 0) {
      statistics.value = res.data.data
    }
  } catch (error) {
    console.error(t('warehouseOut.loadStatisticsFailed'), error)
  }
}

// 搜索
const handleSearch = () => {
  pagination.page = 1
  loadTableData()
}

// 重置
const handleReset = () => {
  searchForm.collateralName = ''
  searchForm.warehouseInNo = ''
  searchForm.status = ''
  searchForm.releaseType = ''
  searchForm.startDate = null
  searchForm.endDate = null
  handleSearch()
}

// 新建
const handleCreate = () => {
  router.push('/warehouse-out/create')
}

// 查看
const handleView = (id: number) => {
  router.push(`/warehouse-out/${id}`)
}

// 编辑
const handleEdit = (id: number) => {
  modalTitle.value = t('warehouseOut.editModalTitle')
  currentWarehouseOutId.value = id
  showModal.value = true
}

// 提交
const handleSubmit = async (id: number) => {
  try {
    const { submitWarehouseOut } = await import('~/api/warehouse-out')
    const res = await submitWarehouseOut({ id })
    if (res.data.code === 0) {
      message.success(t('warehouseOut.submitSuccess'))
      loadTableData()
      loadStatistics()
    } else {
      message.error(res.data.message || t('warehouseOut.submitFailed'))
    }
  } catch (error: any) {
    message.error(t('warehouseOut.submitFailed') + ': ' + (error?.response?.data?.message || error?.message))
  }
}

// 审批
const handleApprove = async (id: number) => {
  try {
    const { approveWarehouseOut } = await import('~/api/warehouse-out')
    const res = await approveWarehouseOut({ id, step: 1, approvalStatus: 'APPROVED', approvalOpinion: t('common.agree') })
    if (res.data.code === 0) {
      message.success(t('warehouseOut.approveSuccess'))
      loadTableData()
      loadStatistics()
    } else {
      message.error(res.data.message || t('warehouseOut.approveFailed'))
    }
  } catch (error: any) {
    message.error(t('warehouseOut.approveFailed') + ': ' + (error?.response?.data?.message || error?.message))
  }
}

// 拒绝
const handleReject = async (id: number) => {
  try {
    const { cancelWarehouseOut } = await import('~/api/warehouse-out')
    const res = await cancelWarehouseOut(id)
    if (res.data.code === 0) {
      message.success(t('warehouseOut.rejectSuccess'))
      loadTableData()
      loadStatistics()
    } else {
      message.error(res.data.message || t('warehouseOut.operationFailed'))
    }
  } catch (error: any) {
    message.error(t('warehouseOut.operationFailed') + ': ' + (error?.response?.data?.message || error?.message))
  }
}

// 完成
const handleComplete = async (id: number) => {
  try {
    const { completeWarehouseOut } = await import('~/api/warehouse-out')
    const res = await completeWarehouseOut(id)
    if (res.data.code === 0) {
      message.success(t('warehouseOut.completeSuccess'))
      loadTableData()
      loadStatistics()
    } else {
      message.error(res.data.message || t('warehouseOut.operationFailed'))
    }
  } catch (error: any) {
    message.error(t('warehouseOut.operationFailed') + ': ' + (error?.response?.data?.message || error?.message))
  }
}

// 权限判断
function canEdit(row: WarehouseOut) {
  if (authStore.isAdmin) return true
  const isCreator = authStore.user?.username === row.applicantName || authStore.user?.id === row.applicantId
  return isCreator && row.status === 'DRAFT'
}
function canSubmit(row: WarehouseOut) {
  if (authStore.isAdmin) return true
  const isCreator = authStore.user?.username === row.applicantName || authStore.user?.id === row.applicantId
  return isCreator && row.status === 'DRAFT'
}
function canApprove(row: WarehouseOut) {
  if (!['SUBMITTED'].includes(row.status)) return false
  const pending = row.approvals?.find((a: any) => a.approvalStatus === 'PENDING')
  if (!pending) return false
  return authStore.isAdmin || authStore.user?.role === pending.approverRole
}
function canReject(row: WarehouseOut) {
  if (!['SUBMITTED'].includes(row.status)) return false
  const pending = row.approvals?.find((a: any) => a.approvalStatus === 'PENDING')
  if (!pending) return false
  return authStore.isAdmin || authStore.user?.role === pending.approverRole
}
function canComplete(row: WarehouseOut) {
  return row.status === 'APPROVED'
}

// 跳转到审批页面
function handleGoApprove(id: number) {
  router.push(`/warehouse-out/approval?id=${id}`)
}

// 模态框成功
const handleModalSuccess = () => {
  showModal.value = false
  loadTableData()
  loadStatistics()
}

// 初始化
onMounted(() => {
  loadTableData()
  loadStatistics()
})
</script>

<style scoped>
.warehouse-out-page {
  padding: 24px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.page-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: 600;
  color: #333;
}

.stat-label {
  font-size: 14px;
  color: #666;
  margin-top: 4px;
}

.search-card {
  margin-bottom: 24px;
}

.table-card {
  min-height: 400px;
}
</style>
