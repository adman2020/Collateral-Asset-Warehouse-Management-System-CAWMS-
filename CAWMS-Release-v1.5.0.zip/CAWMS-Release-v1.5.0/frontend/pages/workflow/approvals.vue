<template>
  <div class="approval-page">
    <NCard class="page-header" :bordered="false">
      <div class="header-content">
        <h1 class="page-title">{{ $t('workflow.title') }}</h1>
        <p class="page-subtitle">{{ $t('workflow.subtitle') }}</p>
      </div>
    </NCard>

    <NCard class="page-content">
      <NTabs v-model:value="activeTab" type="line" animated>
        <NTabPane name="transfer" :tab="$t('workflow.transferTab')">
          <NDataTable
            :columns="transferColumns"
            :data="transferData"
            :loading="transferLoading"
            :pagination="transferPagination"
            @update:page="(page: number) => handlePageChange('transfer', page)"
            @update:page-size="(size: number) => handlePageSizeChange('transfer', size)"
            striped
            remote
          />
        </NTabPane>

        <NTabPane name="warehouseOut" :tab="$t('workflow.warehouseOutTab')">
          <NDataTable
            :columns="warehouseOutColumns"
            :data="warehouseOutData"
            :loading="warehouseOutLoading"
            :pagination="warehouseOutPagination"
            @update:page="(page: number) => handlePageChange('warehouseOut', page)"
            @update:page-size="(size: number) => handlePageSizeChange('warehouseOut', size)"
            striped
            remote
          />
        </NTabPane>
      </NTabs>
    </NCard>
  </div>
</template>

<script setup lang="ts">
import { h, ref, onMounted, computed } from 'vue'
import {
  NCard,
  NTabs,
  NTabPane,
  NDataTable,
  NButton,
  NSpace,
  useMessage,
  type DataTableColumns
} from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { getPendingApprovals as getTransferPending, approveTransfer, cancelTransfer, type Transfer } from '~/api/transfer'
import { getPendingApprovals as getWarehouseOutPending, approveWarehouseOut, cancelWarehouseOut, type WarehouseOut } from '~/api/warehouse-out'
import { useAuthStore } from '@/stores/auth'

const message = useMessage()
const authStore = useAuthStore()
const { t } = useI18n()

const activeTab = ref('transfer')

// Transfer state
const transferData = ref<Transfer[]>([])
const transferLoading = ref(false)
const transferPagination = ref({
  page: 1,
  pageSize: 10,
  itemCount: 0,
  showSizePicker: true,
  pageSizes: [10, 20, 50]
})

// Warehouse-out state
const warehouseOutData = ref<WarehouseOut[]>([])
const warehouseOutLoading = ref(false)
const warehouseOutPagination = ref({
  page: 1,
  pageSize: 10,
  itemCount: 0,
  showSizePicker: true,
  pageSizes: [10, 20, 50]
})

function formatCurrency(value?: number) {
  if (value === undefined || value === null) return '-'
  return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(value)
}

function formatTime(value?: string) {
  if (!value) return '-'
  return value.slice(0, 16).replace('T', ' ')
}

// Transfer columns
const transferColumns = computed<DataTableColumns<Transfer>>(() => [
  { title: t('table.transferNo'), key: 'transferNo' },
  { title: t('table.warehouseInNo'), key: 'warehouseInNo' },
  { title: t('table.collateralName'), key: 'collateralName' },
  { title: t('table.sourceWarehouse'), key: 'sourceWarehouseName' },
  { title: t('table.targetWarehouse'), key: 'targetWarehouseName' },
  { title: t('table.applicant'), key: 'applicantName' },
  { title: t('table.applyTime'), key: 'applyTime', render: (row) => formatTime(row.applyTime) },
  {
    title: t('table.operation'),
    key: 'actions',
    fixed: 'right',
    width: 180,
    render: (row) => {
      return h(NSpace, { size: 'small' }, () => [
        h(
          NButton,
          {
            type: 'warning',
            size: 'small',
            onClick: () => handleApproveTransfer(row.id!)
          },
          { default: () => t('workflow.approve') }
        ),
        h(
          NButton,
          {
            type: 'error',
            size: 'small',
            onClick: () => handleRejectTransfer(row.id!)
          },
          { default: () => t('workflow.reject') }
        )
      ])
    }
  }
])

// Warehouse-out columns
const warehouseOutColumns = computed<DataTableColumns<WarehouseOut>>(() => [
  { title: t('table.warehouseOutNo'), key: 'warehouseOutNo' },
  { title: t('table.warehouseInNo'), key: 'warehouseInNo' },
  { title: t('table.collateralName'), key: 'collateralName' },
  { title: t('table.warehouse'), key: 'warehouseName' },
  { title: t('table.releaseType'), key: 'releaseType' },
  { title: t('table.releaseAmount'), key: 'releaseAmount', render: (row) => formatCurrency(row.releaseAmount) },
  { title: t('table.applicant'), key: 'applicantName' },
  { title: t('table.applyTime'), key: 'applyTime', render: (row) => formatTime(row.applyTime) },
  {
    title: t('table.operation'),
    key: 'actions',
    fixed: 'right',
    width: 180,
    render: (row) => {
      return h(NSpace, { size: 'small' }, () => [
        h(
          NButton,
          {
            type: 'warning',
            size: 'small',
            onClick: () => handleApproveWarehouseOut(row.id!)
          },
          { default: () => t('workflow.approve') }
        ),
        h(
          NButton,
          {
            type: 'error',
            size: 'small',
            onClick: () => handleRejectWarehouseOut(row.id!)
          },
          { default: () => t('workflow.reject') }
        )
      ])
    }
  }
])

async function loadTransfers() {
  transferLoading.value = true
  try {
    const res = await getTransferPending({
      page: transferPagination.value.page,
      size: transferPagination.value.pageSize
    })
    const data = res.data.data
    transferData.value = data?.records ?? []
    transferPagination.value.itemCount = data?.total ?? 0
  } catch (err: any) {
    message.error(err?.message || t('workflow.loadTransferFailed'))
  } finally {
    transferLoading.value = false
  }
}

async function loadWarehouseOuts() {
  warehouseOutLoading.value = true
  try {
    const res = await getWarehouseOutPending({
      page: warehouseOutPagination.value.page,
      size: warehouseOutPagination.value.pageSize
    })
    const data = res.data.data
    warehouseOutData.value = data?.records ?? []
    warehouseOutPagination.value.itemCount = data?.total ?? 0
  } catch (err: any) {
    message.error(err?.message || t('workflow.loadWarehouseOutFailed'))
  } finally {
    warehouseOutLoading.value = false
  }
}

async function handleApproveTransfer(id: number) {
  try {
    await approveTransfer({ id, step: 1, approvalStatus: 'APPROVED', approvalOpinion: t('common.agree') })
    message.success(t('workflow.approveSuccess'))
    await loadTransfers()
  } catch (err: any) {
    message.error(err?.message || t('workflow.approveFailed'))
  }
}

async function handleRejectTransfer(id: number) {
  try {
    await cancelTransfer(id)
    message.success(t('workflow.rejectSuccess'))
    await loadTransfers()
  } catch (err: any) {
    message.error(err?.message || t('workflow.rejectFailed'))
  }
}

async function handleApproveWarehouseOut(id: number) {
  try {
    await approveWarehouseOut({ id, step: 1, approvalStatus: 'APPROVED', approvalOpinion: t('common.agree') })
    message.success(t('workflow.approveSuccess'))
    await loadWarehouseOuts()
  } catch (err: any) {
    message.error(err?.message || t('workflow.approveFailed'))
  }
}

async function handleRejectWarehouseOut(id: number) {
  try {
    await cancelWarehouseOut(id)
    message.success(t('workflow.rejectSuccess'))
    await loadWarehouseOuts()
  } catch (err: any) {
    message.error(err?.message || t('workflow.rejectFailed'))
  }
}

function handlePageChange(type: 'transfer' | 'warehouseOut', page: number) {
  if (type === 'transfer') {
    transferPagination.value.page = page
    loadTransfers()
  } else {
    warehouseOutPagination.value.page = page
    loadWarehouseOuts()
  }
}

function handlePageSizeChange(type: 'transfer' | 'warehouseOut', size: number) {
  if (type === 'transfer') {
    transferPagination.value.page = 1
    transferPagination.value.pageSize = size
    loadTransfers()
  } else {
    warehouseOutPagination.value.page = 1
    warehouseOutPagination.value.pageSize = size
    loadWarehouseOuts()
  }
}

onMounted(() => {
  loadTransfers()
  loadWarehouseOuts()
})
</script>

<style scoped>
.approval-page {
  padding: 24px;
}

.page-header {
  margin-bottom: 24px;
}

.header-content {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.page-title {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
  color: #1f2937;
}

.page-subtitle {
  margin: 0;
  font-size: 14px;
  color: #6b7280;
}
</style>
