<template>
  <div class="login-page">
    <!-- 登录表单卡片 -->
    <div class="login-card">
      <!-- 顶部品牌 -->
      <div class="login-header">
        <div class="login-logo">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="currentColor"/>
            <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2"/>
            <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2"/>
          </svg>
        </div>
        <h1 class="login-title">CAWMS</h1>
        <p class="login-subtitle">{{ t('login.subtitle') }}</p>
      </div>
      
      <!-- 登录表单 -->
      <NForm
        ref="loginFormRef"
        :model="loginForm"
        :rules="loginRules"
        @submit.prevent="handleLogin"
        class="login-form"
      >
        <!-- 用户名/邮箱 -->
        <NFormItem :label="t('login.username')" path="username" required>
          <NInput
            v-model:value="loginForm.username"
            :placeholder="t('login.usernamePlaceholder') || t('common.pleaseInput') + t('login.username')"
            size="large"
            round
            :disabled="loading"
            @keyup.enter="handleLogin"
          >
            <template #prefix>
              <NIcon><PersonOutline /></NIcon>
            </template>
          </NInput>
        </NFormItem>
        
        <!-- 密码 -->
        <NFormItem :label="t('login.password')" path="password" required>
          <NInput
            v-model:value="loginForm.password"
            type="password"
            :placeholder="t('login.passwordPlaceholder') || t('common.pleaseInput') + t('login.password')"
            size="large"
            round
            show-password-on="click"
            :disabled="loading"
            @keyup.enter="handleLogin"
          >
            <template #prefix>
              <NIcon><LockClosedOutline /></NIcon>
            </template>
          </NInput>
        </NFormItem>
        
        <!-- 记住我和忘记密码 -->
        <div class="login-options">
          <NCheckbox v-model:checked="rememberMe">{{ t('login.rememberMe') }}</NCheckbox>
          <NuxtLink to="/forgot-password" class="forgot-password">{{ t('login.forgotPassword') }}</NuxtLink>
        </div>
        
        <!-- 登录按钮 -->
        <NButton
          type="primary"
          size="large"
          round
          block
          :loading="loading"
          @click="handleLogin"
          class="login-button"
        >
          {{ loading ? t('login.loggingIn') : t('login.login') }}
        </NButton>
        
        <!-- 分割线 -->
        <div class="login-divider">
          <span>{{ t('login.or') }}</span>
        </div>
        
        <!-- 其他登录方式 -->
        <div class="login-methods">
          <NButton
            quaternary
            round
            block
            size="large"
            @click="handleSSOLogin"
            class="sso-button"
          >
            <template #icon>
              <NIcon><FingerPrintOutline /></NIcon>
            </template>
            {{ t('login.sso') }}
          </NButton>
        </div>
        
        <!-- 注册链接 -->
        <div class="login-register">
          <span>{{ t('login.noAccount') }}</span>
          <NuxtLink to="/register" class="register-link">{{ t('login.registerNow') }}</NuxtLink>
        </div>
      </NForm>
      
      <!-- 底部信息 -->
      <div class="login-footer">
        <p>{{ t('login.copyright') }}</p>
        <p class="version">版本 {{ appVersion }}</p>
      </div>
    </div>
    
  </div>
</template>

<script setup lang="ts">
import { 
  NForm, 
  NFormItem, 
  NInput, 
  NIcon, 
  NButton, 
  NCheckbox,
  FormInst,
  FormRules,
  useMessage
} from 'naive-ui'
import { 
  PersonOutline, 
  LockClosedOutline, 
  FingerPrintOutline 
} from '@vicons/ionicons5'
import { useAuthStore } from '@/stores/auth'
import { useI18n } from 'vue-i18n'

// 页面元信息
definePageMeta({
  layout: 'auth',
  middleware: ['guest'], // 已登录用户访问登录页会自动重定向
  meta: {
    title: '登录 - CAWMS',
    description: '抵押资产管理系统登录页面'
  }
})

// 状态管理
const authStore = useAuthStore()
const router = useRouter()
const route = useRoute()
const message = useMessage()
const { t } = useI18n()

// 表单引用
const loginFormRef = ref<FormInst | null>(null)

// 响应式状态
const loginForm = reactive({
  username: '',
  password: ''
})

const rememberMe = ref(false)
const loading = ref(false)

// 应用版本
const appVersion = ref(process.env.APP_VERSION || '1.0.0')

// 验证规则
const loginRules: FormRules = {
  username: [
    { required: true, message: t('login.usernameRequired') || t('common.pleaseInput') + t('login.username'), trigger: 'blur' },
    { 
      validator: (_, value) => {
        if (!value) return true
        const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
        const isUsername = value.length >= 3
        return isEmail || isUsername
      },
      message: t('login.usernameInvalid') || '用户名至少3个字符或请输入有效邮箱',
      trigger: 'blur'
    }
  ],
  password: [
    { required: true, message: t('login.passwordRequired') || t('common.pleaseInput') + t('login.password'), trigger: 'blur' },
    { min: 6, message: t('login.passwordMin') || '密码至少6个字符', trigger: 'blur' }
  ]
}

// 方法
const handleLogin = async () => {
  try {
    // 表单验证
    await loginFormRef.value?.validate()
    
    loading.value = true
    
    // 调用认证store的登录方法
    const success = await authStore.login({
      username: loginForm.username,
      password: loginForm.password,
      rememberMe: rememberMe.value
    })
    
    if (!success) {
      message.error(authStore.error || t('login.invalidCredentials'))
      return
    }
    
    // 登录成功消息
    message.success(t('login.welcomeBack'), {
      duration: 2000
    })
    
    // 重定向到目标页面或首页
    const redirectTo = route.query.redirect as string || '/'
    await router.push(redirectTo)
    
  } catch (error: any) {
    console.error('登录失败:', error)
    
    // 显示错误消息
    if (error.response?.status === 401) {
      message.error(t('login.invalidCredentials'))
    } else if (error.message) {
      message.error(error.message)
    } else {
      message.error(t('login.loginFailed'))
    }
  } finally {
    loading.value = false
  }
}

const handleSSOLogin = () => {
  message.info('单点登录功能开发中...')
  // 实际应用中这里会跳转到SSO登录页面
  // window.location.href = '/sso/login'
}

// 初始化
onMounted(() => {
  // 从本地存储恢复记住的用户名
  const savedUsername = localStorage.getItem('remembered-username')
  if (savedUsername) {
    loginForm.username = savedUsername
    rememberMe.value = true
  }
  
  // 如果有错误消息，显示它
  if (route.query.error) {
    message.error(decodeURIComponent(route.query.error as string))
  }
})

// 监听记住我选项变化
watch(rememberMe, (newValue) => {
  if (newValue && loginForm.username) {
    localStorage.setItem('remembered-username', loginForm.username)
  } else {
    localStorage.removeItem('remembered-username')
  }
})
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
}

.login-card {
  width: 100%;
  max-width: 420px;
  background: white;
  border-radius: 20px;
  padding: 40px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
}

.login-header {
  text-align: center;
  margin-bottom: 32px;
}

.login-logo {
  width: 64px;
  height: 64px;
  margin: 0 auto 16px;
  color: var(--primary-color);
}

.login-title {
  font-size: 24px;
  font-weight: 700;
  margin: 0 0 8px 0;
  color: var(--text-color);
}

.login-subtitle {
  font-size: 14px;
  color: var(--text-color-secondary);
  margin: 0;
}

.login-form {
  margin-bottom: 24px;
}

.login-form :deep(.n-form-item-label) {
  font-size: 14px;
  font-weight: 500;
}

.login-form :deep(.n-input) {
  font-size: 15px;
}

.login-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  font-size: 14px;
}

.forgot-password {
  color: var(--primary-color);
  text-decoration: none;
  transition: color 0.2s;
}

.forgot-password:hover {
  color: var(--primary-hover);
  text-decoration: underline;
}

.login-button {
  margin-bottom: 24px;
  font-weight: 500;
  font-size: 16px;
  height: 48px;
}

.login-divider {
  display: flex;
  align-items: center;
  margin: 24px 0;
  color: var(--text-color-secondary);
}

.login-divider::before,
.login-divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background-color: var(--border-color);
}

.login-divider span {
  padding: 0 16px;
  font-size: 13px;
  background: white;
}

.login-methods {
  margin-bottom: 24px;
}

.sso-button {
  border: 1px solid var(--border-color);
  color: var(--text-color);
  font-weight: 500;
}

.sso-button:hover {
  border-color: var(--primary-color);
  color: var(--primary-color);
}

.login-register {
  text-align: center;
  font-size: 14px;
  color: var(--text-color-secondary);
}

.register-link {
  color: var(--primary-color);
  text-decoration: none;
  font-weight: 500;
  margin-left: 8px;
  transition: color 0.2s;
}

.register-link:hover {
  color: var(--primary-hover);
  text-decoration: underline;
}

.login-footer {
  text-align: center;
  font-size: 12px;
  color: var(--text-color-disabled);
  padding-top: 24px;
  border-top: 1px solid var(--border-color-split);
}

.login-footer p {
  margin: 4px 0;
}

.version {
  font-size: 11px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .login-card {
    padding: 32px 24px;
    border-radius: 16px;
  }
  
  .login-header {
    margin-bottom: 24px;
  }
  
  .login-logo {
    width: 48px;
    height: 48px;
  }
  
  .login-title {
    font-size: 20px;
  }
}

@media (max-width: 480px) {
  .login-page {
    padding: 12px;
  }
  
  .login-card {
    padding: 24px 20px;
    border-radius: 12px;
  }
  
  .login-form :deep(.n-input) {
    font-size: 14px;
  }
  
  .login-button {
    height: 44px;
    font-size: 15px;
  }
}
</style>