#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
验证SQL文件语法
"""

import re
import sys

def validate_sql_file(file_path):
    """验证SQL文件基本语法"""
    print(f"验证SQL文件: {file_path}")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    print(f"文件大小: {len(content)} 字符")
    
    # 检查关键SQL语句
    checks = [
        (r'CREATE DATABASE', '数据库创建语句'),
        (r'CREATE TABLE IF NOT EXISTS', '表创建语句'),
        (r'CREATE INDEX', '索引创建语句'),
        (r'ALTER TABLE', '表修改语句'),
        (r'INSERT INTO', '数据插入语句'),
        (r'CREATE VIEW', '视图创建语句'),
        (r'CREATE PROCEDURE', '存储过程语句'),
        (r'CREATE FUNCTION', '函数创建语句')
    ]
    
    print("\nSQL语句统计:")
    for pattern, description in checks:
        matches = re.findall(pattern, content, re.IGNORECASE)
        if matches:
            print(f"  {description}: {len(matches)} 个")
    
    # 检查表数量
    table_matches = re.findall(r'CREATE TABLE IF NOT EXISTS\s+(\w+)', content, re.IGNORECASE)
    print(f"\n表数量: {len(table_matches)}")
    if table_matches:
        print("表名列表:")
        for i, table in enumerate(table_matches[:15], 1):
            print(f"  {i:2}. {table}")
        if len(table_matches) > 15:
            print(f"  ... 还有 {len(table_matches)-15} 个表")
    
    # 检查索引数量
    index_matches = re.findall(r'CREATE INDEX\s+(\w+)\s+ON', content, re.IGNORECASE)
    print(f"\n索引数量: {len(index_matches)}")
    
    # 检查注释中的中文字符
    chinese_in_comments = re.findall(r"COMMENT\s+'([^']*[\u4e00-\u9fff]+[^']*)'", content)
    print(f"\n中文注释字段: {len(chinese_in_comments)} 个")
    
    # 检查外键约束
    foreign_keys = re.findall(r'FOREIGN KEY\s*\([^)]+\)\s+REFERENCES\s+(\w+)', content, re.IGNORECASE)
    print(f"外键约束: {len(foreign_keys)} 个")
    
    # 检查文件结构完整性
    sections = [
        '基础表结构',
        '现有表字段修复',
        '新增表',
        '视图',
        '存储过程和函数',
        '初始化数据',
        '索引和性能优化'
    ]
    
    print("\n文件结构检查:")
    for section in sections:
        if section in content:
            print(f"  ✓ {section}")
        else:
            print(f"  ✗ {section} (未找到)")
    
    # 验证SQL分隔符
    print("\nSQL语句分隔符检查:")
    statements = re.split(r';\s*\n', content)
    print(f"  SQL语句数量: {len(statements)}")
    
    # 检查是否有不完整的语句
    incomplete = [s for s in statements if 'CREATE' in s and not s.strip().endswith(';')]
    if incomplete:
        print(f"  ⚠ 发现 {len(incomplete)} 个可能不完整的语句")
    else:
        print("  ✓ 所有语句都有正确的结束符")
    
    return True

def main():
    if len(sys.argv) != 2:
        print("用法: python validate_sql.py <SQL文件>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    try:
        validate_sql_file(file_path)
        print("\n✅ 验证完成")
    except Exception as e:
        print(f"\n❌ 验证失败: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()