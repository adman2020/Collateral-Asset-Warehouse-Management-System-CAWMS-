#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
修复init_v2.sql文件编码问题
"""

import os
import sys

def detect_encoding(file_path):
    """简单检测文件编码"""
    encodings = ['utf-8', 'gbk', 'gb2312', 'latin-1', 'utf-16', 'utf-8-sig']
    
    with open(file_path, 'rb') as f:
        raw_data = f.read(10000)  # 读取前10000字节
        
        # 检查UTF-8 BOM
        if raw_data.startswith(b'\xef\xbb\xbf'):
            return 'utf-8-sig'
        
        # 尝试解码
        for enc in encodings:
            try:
                raw_data.decode(enc)
                print(f"尝试编码 {enc}: 成功")
                return enc
            except UnicodeDecodeError:
                print(f"尝试编码 {enc}: 失败")
                continue
    
    # 默认返回utf-8
    return 'utf-8'

def read_file_with_encoding(file_path, encoding):
    """用指定编码读取文件"""
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            content = f.read()
        print(f"使用编码 {encoding} 成功读取文件")
        return content
    except UnicodeDecodeError as e:
        print(f"使用编码 {encoding} 读取失败: {e}")
        return None

def write_file_with_encoding(file_path, content, encoding='utf-8'):
    """用指定编码写入文件"""
    try:
        with open(file_path, 'w', encoding=encoding) as f:
            f.write(content)
        print(f"使用编码 {encoding} 成功写入文件")
        return True
    except Exception as e:
        print(f"写入文件失败: {e}")
        return False

def fix_sql_encoding(input_file, output_file):
    """修复SQL文件编码"""
    print(f"处理输入文件: {input_file}")
    print(f"输出文件: {output_file}")
    
    # 检测原始编码
    original_encoding = detect_encoding(input_file)
    print(f"检测到的原始编码: {original_encoding}")
    
    # 读取文件
    content = read_file_with_encoding(input_file, original_encoding)
    if content is None:
        print("无法读取文件，尝试latin-1作为后备")
        content = read_file_with_encoding(input_file, 'latin-1')
        if content is None:
            print("所有编码尝试都失败")
            return False
    
    print(f"文件内容长度: {len(content)} 字符")
    
    # 检查中文字符
    chinese_chars = sum(1 for c in content if '\u4e00' <= c <= '\u9fff')
    print(f"中文字符数量: {chinese_chars}")
    
    if chinese_chars == 0:
        print("警告: 文件中未检测到中文字符，可能是乱码")
    
    # 写入UTF-8编码的文件
    success = write_file_with_encoding(output_file, content, 'utf-8')
    
    if success:
        # 验证写入的文件
        verify_content = read_file_with_encoding(output_file, 'utf-8')
        if verify_content:
            print(f"验证成功: 输出文件 {output_file} 包含 {len(verify_content)} 字符")
            return True
    
    return False

def main():
    if len(sys.argv) != 3:
        print("用法: python fix_encoding_v2.py <输入文件> <输出文件>")
        print("示例: python fix_encoding_v2.py init_v2.sql init_v2_fixed.sql")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    if not os.path.exists(input_file):
        print(f"输入文件不存在: {input_file}")
        sys.exit(1)
    
    if fix_sql_encoding(input_file, output_file):
        print(f"\n修复完成! 生成的文件: {output_file}")
        print(f"文件大小: {os.path.getsize(output_file)} 字节")
    else:
        print("修复失败")
        sys.exit(1)

if __name__ == '__main__':
    main()