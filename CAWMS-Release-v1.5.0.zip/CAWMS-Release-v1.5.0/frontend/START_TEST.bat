@echo off
echo ======================================
echo    CAWMS Frontend Test Launcher
echo ======================================
echo.
echo This will open the dashboard for testing.
echo.
echo Tasks Completed:
echo - Task13.8: Warehouse In Management (Enhanced)
echo - Task14.7: Loan Out Management (Enhanced)  
echo - Static Page Path Fixes
echo.
echo Login Credentials:
echo   admin / admin123
echo   user  / user123
echo.
echo Press any key to open dashboard.html...
pause >nul

start "" "dashboard.html"
echo.
echo Dashboard opened. Please login and test.
echo.
echo For status reports, see:
echo   TASK_STATUS.txt
echo   COMPLETION.md
echo.
echo Press any key to exit...
pause >nul