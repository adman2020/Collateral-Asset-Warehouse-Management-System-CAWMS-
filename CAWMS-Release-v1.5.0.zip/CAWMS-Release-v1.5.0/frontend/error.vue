<template>
  <NConfigProvider>
    <NMessageProvider>
      <div class="error-page">
        <div class="error-content">
          <div class="error-code">{{ props.error?.statusCode || 500 }}</div>
          <h1 class="error-title">{{ title }}</h1>
          <p class="error-message">{{ message }}</p>
          <div class="error-actions">
            <NButton type="primary" size="large" @click="handleBackHome">
              返回首页
            </NButton>
            <NButton size="large" @click="handleBack">
              返回上一页
            </NButton>
          </div>
        </div>
      </div>
    </NMessageProvider>
  </NConfigProvider>
</template>

<script setup lang="ts">
import { NButton, NConfigProvider, NMessageProvider } from 'naive-ui'

const props = defineProps<{
  error: {
    statusCode: number
    statusMessage?: string
    message?: string
    description?: string
  }
}>()

const title = computed(() => {
  const code = props.error?.statusCode
  if (code === 404) return '页面未找到'
  if (code === 403) return '无权访问'
  if (code === 500) return '服务器错误'
  return '出错了'
})

const message = computed(() => {
  return props.error?.statusMessage || props.error?.message || '请稍后重试或联系管理员'
})

const handleBackHome = () => {
  clearError({ redirect: '/' })
}

const handleBack = () => {
  clearError({ redirect: '/' })
  // In real usage could use $router.back()
}
</script>

<style scoped>
.error-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  padding: 24px;
}

.error-content {
  text-align: center;
  max-width: 480px;
}

.error-code {
  font-size: 120px;
  font-weight: 700;
  line-height: 1;
  color: #1890ff;
  margin-bottom: 16px;
  opacity: 0.8;
}

.error-title {
  font-size: 32px;
  font-weight: 600;
  margin: 0 0 12px 0;
  color: #1f2937;
}

.error-message {
  font-size: 16px;
  color: #6b7280;
  margin-bottom: 32px;
}

.error-actions {
  display: flex;
  gap: 16px;
  justify-content: center;
}
</style>
