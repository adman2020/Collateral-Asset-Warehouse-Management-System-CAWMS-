import { computed } from 'vue'
import { darkTheme } from 'naive-ui'

export type ThemeMode = 'light' | 'dark'

export function useThemeState() {
  // useState 是 Nuxt 3 提供的 SSR-friendly 全局状态，自动在服务端/客户端同步
  const themeMode = useState<ThemeMode>('app-theme', () => 'light')

  const naiveTheme = computed(() => {
    return themeMode.value === 'dark' ? darkTheme : undefined
  })

  function setThemeMode(mode: ThemeMode) {
    themeMode.value = mode
  }

  function initThemeMode() {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('theme') : null
    const effective: ThemeMode =
      saved === 'dark' ? 'dark'
      : saved === 'light' ? 'light'
      : (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')

    themeMode.value = effective
    document.documentElement.setAttribute('data-theme', effective)
  }

  return {
    themeMode,
    naiveTheme,
    setThemeMode,
    initThemeMode
  }
}
