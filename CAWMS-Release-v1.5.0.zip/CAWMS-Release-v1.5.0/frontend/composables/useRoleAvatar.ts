/**
 * 角色头像映射
 * 根据用户角色返回对应的SVG头像路径
 */

const ROLE_AVATAR_MAP: Record<string, string> = {
  // 超级管理员
  SUPER_ADMIN: '/assets/avatars/super-admin.svg',
  // 系统管理员
  SYSTEM_ADMIN: '/assets/avatars/system-admin.svg',
  // CTS集群主管
  CTS_CLUSTER_HEAD: '/assets/avatars/cts-cluster-head.svg',
  // 省运营主管
  PROVINCIAL_OPS_HEAD: '/assets/avatars/provincial-ops-head.svg',
  // 财务主管
  TREASURY_HEAD: '/assets/avatars/treasury-head.svg',
  // 仓库管理员
  WAREHOUSE_MANAGER: '/assets/avatars/warehouse-manager.svg',
  // 信贷处理人员
  CREDIT_OFFICER: '/assets/avatars/credit-officer.svg',
  // BU/CTS官员
  BU_OFFICER: '/assets/avatars/bu-officer.svg',
  // 业务经理
  BUSINESS_MANAGER: '/assets/avatars/business-manager.svg',
  // 风控专员
  RISK_OFFICER: '/assets/avatars/risk-officer.svg',
  // 合规专员
  COMPLIANCE_OFFICER: '/assets/avatars/compliance-officer.svg'
}

/**
 * 根据角色获取头像URL
 * @param role 角色代码
 * @returns 头像路径，找不到时返回默认头像
 */
export function getRoleAvatar(role?: string | null): string {
  if (!role) return '/assets/images/default-avatar.png'
  const upperRole = role.toUpperCase()
  return ROLE_AVATAR_MAP[upperRole] || '/assets/images/default-avatar.png'
}

/**
 * 角色中文名称映射
 */
export const ROLE_NAME_MAP: Record<string, string> = {
  SUPER_ADMIN: '超级管理员',
  SYSTEM_ADMIN: '系统管理员',
  CTS_CLUSTER_HEAD: 'CTS集群主管',
  PROVINCIAL_OPS_HEAD: '省运营主管',
  TREASURY_HEAD: '财务主管',
  WAREHOUSE_MANAGER: '仓库管理员',
  CREDIT_OFFICER: '信贷处理人员',
  BU_OFFICER: 'BU/CTS官员',
  BUSINESS_MANAGER: '业务经理',
  RISK_OFFICER: '风控专员',
  COMPLIANCE_OFFICER: '合规专员'
}

/**
 * 获取角色中文名称
 */
export function getRoleName(role?: string | null): string {
  if (!role) return '普通用户'
  return ROLE_NAME_MAP[role.toUpperCase()] || role
}

export default { getRoleAvatar, getRoleName, ROLE_AVATAR_MAP, ROLE_NAME_MAP }
