-- ============================================
-- SeABank CAWMS Database Initialization Script V2
-- MySQL 8.x
-- 基于旧版本 (2026-04-15) 升级到最新版本 (2026-04-21)
-- 生成时间: 2026-04-21
-- 包含:
--   - 15个基础表 (来自旧版本)
--   - 现有表的字段修复 (来自fix_schema_generated.sql)
--   - 8个新增表 (报表相关和Flyway)
--   - 视图、存储过程、函数
-- ============================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS cawms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE cawms;

-- ============================================
-- 1. 基础表结构 (来自旧版本)
-- ============================================

CREATE TABLE IF NOT EXISTS collateral_warehouse_in (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    wh_code VARCHAR(50) NOT NULL UNIQUE COMMENT '仓库编码',
    bu_name VARCHAR(100) COMMENT '业务单元名称',
    bu_code VARCHAR(50) COMMENT '业务单元代码',
    customer_name VARCHAR(200) COMMENT '客户名称',
    customer_id VARCHAR(50) COMMENT '客户ID',
    collateral_type VARCHAR(50) COMMENT '抵押资产类型',
    collateral_value DECIMAL(18,2) COMMENT '资产估值',
    credit_agreement_no VARCHAR(100) COMMENT '信贷协议号',
    intake_type VARCHAR(20) DEFAULT 'NEW' COMMENT '入库类型: NEW, SUPPLEMENTARY',
    status VARCHAR(20) DEFAULT 'DRAFT' COMMENT '状态: DRAFT, SUBMITTED, APPROVED, COMPLETED',
    current_step INT DEFAULT 1 COMMENT '当前审批步骤',
    data_source VARCHAR(20) DEFAULT 'MANUAL' COMMENT '数据来源: MANUAL, SEAOPS, LOS, T24, EXCEL',
    created_by VARCHAR(50) COMMENT '创建人',
    updated_by VARCHAR(50) COMMENT '更新人',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志',
    INDEX idx_status (status),
    INDEX idx_customer (customer_id),
    INDEX idx_bu (bu_code),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='入库申请表';

CREATE TABLE IF NOT EXISTS warehouse_in_files (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    wh_in_id BIGINT NOT NULL,
    file_name VARCHAR(200) COMMENT '文件名称',
    file_type VARCHAR(50) COMMENT '文件类型',
    file_path VARCHAR(500) COMMENT '文件存储路径',
    file_size BIGINT COMMENT '文件大小',
    upload_user VARCHAR(50) COMMENT '上传用户',
    upload_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    file_hash VARCHAR(64) COMMENT '文件哈希',
    mime_type VARCHAR(100) COMMENT 'MIME类型',
    checksum VARCHAR(64) COMMENT '校验和',
    uploaded_by VARCHAR(50) COMMENT '上传人',
    description TEXT COMMENT '描述',
    status VARCHAR(20) DEFAULT 'ACTIVE' COMMENT '状态',
    download_count INT DEFAULT 0 COMMENT '下载次数',
    last_download_at DATETIME COMMENT '最后下载时间',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (wh_in_id) REFERENCES collateral_warehouse_in(id) ON DELETE CASCADE,
    INDEX idx_wh_in (wh_in_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='入库文件清单表';

CREATE TABLE IF NOT EXISTS warehouse_in_approval (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    wh_in_id BIGINT NOT NULL,
    step_number INT NOT NULL COMMENT '步骤编号',
    step_name VARCHAR(100) COMMENT '步骤名称',
    approver_role VARCHAR(50) COMMENT '审批人角色',
    approver_user VARCHAR(50) COMMENT '审批人用户',
    status VARCHAR(20) DEFAULT 'PENDING' COMMENT '状态: PENDING, APPROVED, REJECTED',
    comments TEXT COMMENT '审批意见',
    approved_at DATETIME COMMENT '审批时间',
    approver_name VARCHAR(100) COMMENT '审批人姓名',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    due_date DATETIME COMMENT '预计完成时间',
    completed_at DATETIME COMMENT '实际完成时间',
    processing_minutes INT COMMENT '处理时长（分钟）',
    auto_approved BOOLEAN DEFAULT FALSE COMMENT '是否自动审批',
    approval_attachments TEXT COMMENT '审批附件（JSON格式）',
    ext_data TEXT COMMENT '扩展字段（JSON格式）',
    version INT DEFAULT 0 COMMENT '版本号（乐观锁）',
    FOREIGN KEY (wh_in_id) REFERENCES collateral_warehouse_in(id) ON DELETE CASCADE,
    INDEX idx_wh_in_step (wh_in_id, step_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='入库审批流程表';

CREATE TABLE IF NOT EXISTS collateral_loan_out (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    wh_in_id BIGINT NOT NULL COMMENT '关联的入库记录',
    loan_purpose VARCHAR(200) COMMENT '借出目的',
    loan_duration INT COMMENT '借出期限(天)',
    expected_return_date DATE COMMENT '预计归还日期',
    actual_return_date DATE COMMENT '实际归还日期',
    status VARCHAR(20) DEFAULT 'DRAFT' COMMENT '状态: DRAFT, LOANED, RETURNED, OVERDUE',
    t24_sync_status VARCHAR(20) DEFAULT 'PENDING' COMMENT 'T24同步状态: PENDING, SYNCED, FAILED',
    t24_sync_time DATETIME COMMENT 'T24同步时间',
    created_by VARCHAR(50) COMMENT '创建人',
    updated_by VARCHAR(50) COMMENT '更新人',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志',
    FOREIGN KEY (wh_in_id) REFERENCES collateral_warehouse_in(id),
    INDEX idx_status (status),
    INDEX idx_return_date (expected_return_date),
    INDEX idx_sync_status (t24_sync_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='借出申请表';

CREATE TABLE IF NOT EXISTS loan_out_approval (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    loan_out_id BIGINT NOT NULL,
    step_number INT NOT NULL COMMENT '步骤编号',
    step_name VARCHAR(100) COMMENT '步骤名称',
    approver_role VARCHAR(50) COMMENT '审批人角色',
    approver_user VARCHAR(50) COMMENT '审批人用户',
    status VARCHAR(20) DEFAULT 'PENDING' COMMENT '状态: PENDING, APPROVED, REJECTED',
    comments TEXT COMMENT '审批意见',
    approved_at DATETIME COMMENT '审批时间',
    approver_name VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    due_date DATETIME,
    completed_at DATETIME,
    processing_minutes INT,
    auto_approved BOOLEAN DEFAULT FALSE,
    approval_attachments TEXT,
    ext_data TEXT,
    version INT DEFAULT 0,
    FOREIGN KEY (loan_out_id) REFERENCES collateral_loan_out(id) ON DELETE CASCADE,
    INDEX idx_loan_out_step (loan_out_id, step_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='借出审批流程表';

CREATE TABLE IF NOT EXISTS overdue_alert_config (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    alert_days_before INT DEFAULT 3 COMMENT '提前几天预警',
    alert_recipients TEXT COMMENT '预警接收人',
    enabled BOOLEAN DEFAULT TRUE COMMENT '是否启用',
    alert_method VARCHAR(20) COMMENT '预警方式: EMAIL, SMS, SYSTEM_NOTIFICATION, ALL',
    alert_template_id VARCHAR(50) COMMENT '预警模板ID',
    alert_frequency_hours INT DEFAULT 24 COMMENT '预警频率（小时）',
    max_alert_count INT DEFAULT 0 COMMENT '最大预警次数，0表示无限制',
    created_by VARCHAR(50) COMMENT '创建人',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50) COMMENT '更新人',
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='逾期预警配置表';

CREATE TABLE IF NOT EXISTS overdue_alert_log (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    loan_out_id BIGINT NOT NULL,
    alert_type VARCHAR(20) COMMENT '预警类型: WARNING, OVERDUE',
    alert_message TEXT COMMENT '预警消息',
    alert_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    recipients TEXT COMMENT '接收人',
    sent_status VARCHAR(20) DEFAULT 'PENDING' COMMENT '发送状态',
    sent_time DATETIME COMMENT '发送时间',
    send_method VARCHAR(20) COMMENT '发送方式: EMAIL, SMS, SYSTEM_NOTIFICATION',
    send_details TEXT COMMENT '发送详情（JSON格式）',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (loan_out_id) REFERENCES collateral_loan_out(id),
    INDEX idx_loan_out (loan_out_id),
    INDEX idx_alert_time (alert_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='逾期预警记录表';

CREATE TABLE IF NOT EXISTS collateral_transfer (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    wh_in_id BIGINT NOT NULL COMMENT '关联的入库记录',
    source_wh_code VARCHAR(50) COMMENT '来源仓库编码',
    source_location VARCHAR(100) COMMENT '来源位置',
    target_wh_code VARCHAR(50) COMMENT '目标仓库编码',
    target_location VARCHAR(100) COMMENT '目标位置',
    transfer_type VARCHAR(20) COMMENT '转移类型: INTERNAL, CROSS_WAREHOUSE',
    transfer_reason VARCHAR(200) COMMENT '转移原因',
    transfer_date DATE COMMENT '转移日期',
    status VARCHAR(20) DEFAULT 'PENDING' COMMENT '状态: PENDING, IN_TRANSIT, COMPLETED, CANCELLED',
    created_by VARCHAR(50) COMMENT '创建人',
    updated_by VARCHAR(50) COMMENT '更新人',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志',
    FOREIGN KEY (wh_in_id) REFERENCES collateral_warehouse_in(id),
    INDEX idx_status (status),
    INDEX idx_source_wh (source_wh_code),
    INDEX idx_target_wh (target_wh_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='转移申请表';

CREATE TABLE IF NOT EXISTS transfer_approval (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    transfer_id BIGINT NOT NULL,
    step_number INT NOT NULL,
    step_name VARCHAR(100),
    approver_role VARCHAR(50),
    approver_user VARCHAR(50),
    status VARCHAR(20) DEFAULT 'PENDING',
    comments TEXT,
    approved_at DATETIME,
    created_by VARCHAR(50) COMMENT '创建人',
    updated_by VARCHAR(50) COMMENT '更新人',
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志',
    FOREIGN KEY (transfer_id) REFERENCES collateral_transfer(id) ON DELETE CASCADE,
    INDEX idx_transfer_step (transfer_id, step_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='转移审批流程表';

CREATE TABLE IF NOT EXISTS collateral_warehouse_out (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    wh_in_id BIGINT NOT NULL COMMENT '关联的入库记录',
    out_type VARCHAR(20) COMMENT '出库类型: PARTIAL, FULL',
    out_reason VARCHAR(50) COMMENT '出库原因: LOAN_SETTLED, DEBT_HANDLING, ASSET_SWAP, PARTIAL_OUT, OFFSET',
    out_amount DECIMAL(18,2) COMMENT '出库金额（部分释放时）',
    out_percentage DECIMAL(5,2) COMMENT '出库比例（部分释放时）',
    status VARCHAR(20) DEFAULT 'DRAFT' COMMENT '状态: DRAFT, SUBMITTED, APPROVED, COMPLETED',
    current_step INT DEFAULT 1 COMMENT '当前审批步骤',
    created_by VARCHAR(50) COMMENT '创建人',
    updated_by VARCHAR(50) COMMENT '更新人',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志',
    FOREIGN KEY (wh_in_id) REFERENCES collateral_warehouse_in(id),
    INDEX idx_status (status),
    INDEX idx_wh_in (wh_in_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='出库申请表';

CREATE TABLE IF NOT EXISTS warehouse_out_approval (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    wh_out_id BIGINT NOT NULL,
    step_number INT NOT NULL,
    step_name VARCHAR(100),
    approver_role VARCHAR(50),
    approver_user VARCHAR(50),
    status VARCHAR(20) DEFAULT 'PENDING',
    comments TEXT,
    approved_at DATETIME,
    created_by VARCHAR(50) COMMENT '创建人',
    updated_by VARCHAR(50) COMMENT '更新人',
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志',
    FOREIGN KEY (wh_out_id) REFERENCES collateral_warehouse_out(id) ON DELETE CASCADE,
    INDEX idx_wh_out_step (wh_out_id, step_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='出库审批流程表';

CREATE TABLE IF NOT EXISTS system_users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL COMMENT 'BCrypt加密',
    full_name VARCHAR(100),
    email VARCHAR(100),
    phone_number VARCHAR(20),
    department VARCHAR(100),
    bu_code VARCHAR(50) COMMENT '所属业务单元',
    role VARCHAR(50) COMMENT '角色',
    status VARCHAR(20) DEFAULT 'ACTIVE' COMMENT '状态: ACTIVE, INACTIVE, LOCKED',
    last_login_time DATETIME,
    last_login_ip VARCHAR(45),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by VARCHAR(50) COMMENT '创建人',
    updated_by VARCHAR(50) COMMENT '更新人',
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志',
    INDEX idx_username (username),
    INDEX idx_bu_code (bu_code),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统用户表';

CREATE TABLE IF NOT EXISTS system_roles (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    role_code VARCHAR(50) NOT NULL UNIQUE,
    role_name VARCHAR(100),
    description TEXT,
    permissions TEXT COMMENT 'JSON格式权限列表',
    data_scope VARCHAR(20) COMMENT '数据范围: ALL, BU, SELF',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by VARCHAR(50) COMMENT '创建人',
    updated_by VARCHAR(50) COMMENT '更新人',
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色权限表';

CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50) COMMENT '创建人',
    user_id BIGINT COMMENT '用户ID',
    username VARCHAR(100) COMMENT '用户名',
    action VARCHAR(200) COMMENT '操作动作',
    resource_type VARCHAR(50) COMMENT '资源类型',
    resource_id VARCHAR(100) COMMENT '资源ID',
    old_value TEXT COMMENT '旧值',
    new_value TEXT COMMENT '新值',
    ip_address VARCHAR(45) COMMENT 'IP地址',
    user_agent TEXT COMMENT '用户代理',
    request_url VARCHAR(500) COMMENT '请求URL',
    request_method VARCHAR(10) COMMENT '请求方法',
    execution_time INT COMMENT '执行时间(ms)',
    status VARCHAR(20) COMMENT '执行状态: SUCCESS, FAILED',
    error_message TEXT COMMENT '错误信息',
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50) COMMENT '更新人',
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志',
    INDEX idx_user_time (user_id, timestamp),
    INDEX idx_resource (resource_type, resource_id),
    INDEX idx_timestamp (timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='审计日志表';

CREATE TABLE IF NOT EXISTS system_config (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    config_key VARCHAR(100) NOT NULL UNIQUE,
    config_value TEXT,
    config_type VARCHAR(20) COMMENT '配置类型: STRING, NUMBER, BOOLEAN, JSON',
    description TEXT,
    editable BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by VARCHAR(50) COMMENT '创建人',
    updated_by VARCHAR(50) COMMENT '更新人',
    deleted INT DEFAULT 0 COMMENT '逻辑删除标志'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统配置表';

-- ============================================
-- 2. 现有表字段修复 (来自 fix_schema_generated.sql)
-- ============================================

-- ============================================
-- CAWMS 数据库结构修复脚本（自动生成，针对 MySQL 8.4）
-- 仅包含当前数据库中实际缺失的字段
-- 使用 --force 执行，数据完全保留
-- ============================================

USE cawms;
/*
-- 2. 修复入库文件清单表
ALTER TABLE warehouse_in_files ADD COLUMN file_hash VARCHAR(64) COMMENT '文件哈希' AFTER file_size;
ALTER TABLE warehouse_in_files ADD COLUMN mime_type VARCHAR(100) COMMENT 'MIME类型' AFTER file_hash;
ALTER TABLE warehouse_in_files ADD COLUMN checksum VARCHAR(64) COMMENT '校验和' AFTER mime_type;
ALTER TABLE warehouse_in_files ADD COLUMN uploaded_by VARCHAR(50) COMMENT '上传人' AFTER checksum;
ALTER TABLE warehouse_in_files ADD COLUMN description TEXT COMMENT '描述' AFTER uploaded_by;
ALTER TABLE warehouse_in_files ADD COLUMN status VARCHAR(20) DEFAULT 'ACTIVE' COMMENT '状态' AFTER description;
ALTER TABLE warehouse_in_files ADD COLUMN download_count INT DEFAULT 0 COMMENT '下载次数' AFTER status;
ALTER TABLE warehouse_in_files ADD COLUMN last_download_at DATETIME COMMENT '最后下载时间' AFTER download_count;
ALTER TABLE warehouse_in_files ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER last_download_at;
ALTER TABLE warehouse_in_files ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- 3. 修复入库审批流程表
ALTER TABLE warehouse_in_approval ADD COLUMN approver_name VARCHAR(100) COMMENT '审批人姓名' AFTER approver_user;
ALTER TABLE warehouse_in_approval ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER approved_at;
ALTER TABLE warehouse_in_approval ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;
ALTER TABLE warehouse_in_approval ADD COLUMN due_date DATETIME COMMENT '预计完成时间' AFTER updated_at;
ALTER TABLE warehouse_in_approval ADD COLUMN completed_at DATETIME COMMENT '实际完成时间' AFTER due_date;
ALTER TABLE warehouse_in_approval ADD COLUMN processing_minutes INT COMMENT '处理时长（分钟）' AFTER completed_at;
ALTER TABLE warehouse_in_approval ADD COLUMN auto_approved BOOLEAN DEFAULT FALSE COMMENT '是否自动审批' AFTER processing_minutes;
ALTER TABLE warehouse_in_approval ADD COLUMN approval_attachments TEXT COMMENT '审批附件（JSON格式）' AFTER auto_approved;
ALTER TABLE warehouse_in_approval ADD COLUMN ext_data TEXT COMMENT '扩展字段（JSON格式）' AFTER approval_attachments;
ALTER TABLE warehouse_in_approval ADD COLUMN version INT DEFAULT 0 COMMENT '版本号（乐观锁）' AFTER ext_data;

-- 4. 修复借出申请表
ALTER TABLE collateral_loan_out ADD COLUMN updated_by VARCHAR(50) COMMENT '更新人' AFTER updated_at;
ALTER TABLE collateral_loan_out ADD COLUMN deleted INT DEFAULT 0 COMMENT '逻辑删除标志' AFTER updated_by;

-- 5. 修复借出审批流程表
ALTER TABLE loan_out_approval ADD COLUMN approver_name VARCHAR(100) COMMENT '审批人姓名' AFTER approver_user;
ALTER TABLE loan_out_approval ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER approved_at;
ALTER TABLE loan_out_approval ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;
ALTER TABLE loan_out_approval ADD COLUMN due_date DATETIME COMMENT '预计完成时间' AFTER updated_at;
ALTER TABLE loan_out_approval ADD COLUMN completed_at DATETIME COMMENT '实际完成时间' AFTER due_date;
ALTER TABLE loan_out_approval ADD COLUMN processing_minutes INT COMMENT '处理时长（分钟）' AFTER completed_at;
ALTER TABLE loan_out_approval ADD COLUMN auto_approved BOOLEAN DEFAULT FALSE COMMENT '是否自动审批' AFTER processing_minutes;
ALTER TABLE loan_out_approval ADD COLUMN approval_attachments TEXT COMMENT '审批附件（JSON格式）' AFTER auto_approved;
ALTER TABLE loan_out_approval ADD COLUMN ext_data TEXT COMMENT '扩展字段（JSON格式）' AFTER approval_attachments;
ALTER TABLE loan_out_approval ADD COLUMN version INT DEFAULT 0 COMMENT '版本号（乐观锁）' AFTER ext_data;

-- 6. 修复逾期预警配置表
ALTER TABLE overdue_alert_config ADD COLUMN alert_method VARCHAR(20) COMMENT '预警方式: EMAIL, SMS, SYSTEM_NOTIFICATION, ALL' AFTER alert_recipients;
ALTER TABLE overdue_alert_config ADD COLUMN alert_template_id VARCHAR(50) COMMENT '预警模板ID' AFTER alert_method;
ALTER TABLE overdue_alert_config ADD COLUMN alert_frequency_hours INT DEFAULT 24 COMMENT '预警频率（小时）' AFTER alert_template_id;
ALTER TABLE overdue_alert_config ADD COLUMN max_alert_count INT DEFAULT 0 COMMENT '最大预警次数，0表示无限制' AFTER alert_frequency_hours;
ALTER TABLE overdue_alert_config ADD COLUMN created_by VARCHAR(50) COMMENT '创建人' AFTER created_at;
ALTER TABLE overdue_alert_config ADD COLUMN updated_by VARCHAR(50) COMMENT '更新人' AFTER updated_at;
ALTER TABLE overdue_alert_config ADD COLUMN deleted INT DEFAULT 0 COMMENT '逻辑删除标志' AFTER updated_by;

-- 7. 修复逾期预警记录表
ALTER TABLE overdue_alert_log ADD COLUMN sent_time DATETIME COMMENT '发送时间' AFTER sent_status;
ALTER TABLE overdue_alert_log ADD COLUMN send_method VARCHAR(20) COMMENT '发送方式: EMAIL, SMS, SYSTEM_NOTIFICATION' AFTER sent_time;
ALTER TABLE overdue_alert_log ADD COLUMN send_details TEXT COMMENT '发送详情（JSON格式）' AFTER send_method;
ALTER TABLE overdue_alert_log ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER send_details;
ALTER TABLE overdue_alert_log ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- 8. 修复转移申请表
ALTER TABLE collateral_transfer ADD COLUMN updated_by VARCHAR(50) COMMENT '更新人' AFTER updated_at;
ALTER TABLE collateral_transfer ADD COLUMN deleted INT DEFAULT 0 COMMENT '逻辑删除标志' AFTER updated_by;

-- 9. 修复出库申请表
ALTER TABLE collateral_warehouse_out ADD COLUMN updated_by VARCHAR(50) COMMENT '更新人' AFTER updated_at;
ALTER TABLE collateral_warehouse_out ADD COLUMN deleted INT DEFAULT 0 COMMENT '逻辑删除标志' AFTER updated_by;

-- 10. 修复转移审批流程表
ALTER TABLE transfer_approval ADD COLUMN created_by VARCHAR(50) COMMENT '创建人' AFTER id;
ALTER TABLE transfer_approval ADD COLUMN updated_by VARCHAR(50) COMMENT '更新人' AFTER updated_at;
ALTER TABLE transfer_approval ADD COLUMN deleted INT DEFAULT 0 COMMENT '逻辑删除标志' AFTER updated_by;

-- 12. 修复审计日志表
ALTER TABLE audit_logs ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER id;
ALTER TABLE audit_logs ADD COLUMN created_by VARCHAR(50) COMMENT '创建人' AFTER created_at;
ALTER TABLE audit_logs ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER timestamp;
ALTER TABLE audit_logs ADD COLUMN updated_by VARCHAR(50) COMMENT '更新人' AFTER updated_at;
ALTER TABLE audit_logs ADD COLUMN deleted INT DEFAULT 0 COMMENT '逻辑删除标志' AFTER updated_by;

-- 13. 修复出库审批流程表
ALTER TABLE warehouse_out_approval ADD COLUMN created_by VARCHAR(50) COMMENT '创建人' AFTER id;
ALTER TABLE warehouse_out_approval ADD COLUMN updated_by VARCHAR(50) COMMENT '更新人' AFTER updated_at;
ALTER TABLE warehouse_out_approval ADD COLUMN deleted INT DEFAULT 0 COMMENT '逻辑删除标志' AFTER updated_by;

-- 14. 修复角色权限表
ALTER TABLE system_roles ADD COLUMN created_by VARCHAR(50) COMMENT '创建人' AFTER updated_at;
ALTER TABLE system_roles ADD COLUMN updated_by VARCHAR(50) COMMENT '更新人' AFTER created_by;
ALTER TABLE system_roles ADD COLUMN deleted INT DEFAULT 0 COMMENT '逻辑删除标志' AFTER updated_by;

-- 15. 修复系统配置表
ALTER TABLE system_config ADD COLUMN created_by VARCHAR(50) COMMENT '创建人' AFTER updated_at;
ALTER TABLE system_config ADD COLUMN updated_by VARCHAR(50) COMMENT '更新人' AFTER created_by;
ALTER TABLE system_config ADD COLUMN deleted INT DEFAULT 0 COMMENT '逻辑删除标志' AFTER updated_by;

*/
-- ============================================
-- 3. 新增表 (报表相关和Flyway) flyway_schema_history  report_chart_config report_config report_data_cache  report_execution_log report_statistics report_template
-- ============================================

CREATE TABLE IF NOT EXISTS `flyway_schema_history` (\n  `installed_rank` int NOT NULL,\n  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,\n  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,\n  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,\n  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,\n  `checksum` int DEFAULT NULL,\n  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,\n  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  `execution_time` int NOT NULL,\n  `success` tinyint(1) NOT NULL,\n  PRIMARY KEY (`installed_rank`),\n  KEY `flyway_schema_history_s_idx` (`success`)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `report_chart_config` (\n  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',\n  `config_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置名称',\n  `report_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '报表类型',\n  `chart_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图表类型: BAR-柱状图, LINE-折线图, PIE-饼图, AREA-面积图, SCATTER-散点图',\n  `data_source_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '数据源类型: SQL-SQL查询, API-API调用, STATIC-静态数据',\n  `data_source_config` json NOT NULL COMMENT '数据源配置（JSON格式）',\n  `chart_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图表标题',\n  `x_axis_label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'X轴标签',\n  `y_axis_label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Y轴标签',\n  `legend_position` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'RIGHT' COMMENT '图例位置: TOP, BOTTOM, LEFT, RIGHT, NONE',\n  `color_scheme` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'DEFAULT' COMMENT '颜色方案',\n  `background_color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '背景颜色',\n  `border_color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '边框颜色',\n  `font_family` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Arial' COMMENT '字体家族',\n  `font_size` int DEFAULT '12' COMMENT '字体大小',\n  `enable_tooltip` tinyint(1) DEFAULT '1' COMMENT '是否启用工具提示: 0-否, 1-是',\n  `enable_animation` tinyint(1) DEFAULT '1' COMMENT '是否启用动画: 0-否, 1-是',\n  `enable_zoom` tinyint(1) DEFAULT '0' COMMENT '是否启用缩放: 0-否, 1-是',\n  `is_default` tinyint(1) DEFAULT '0' COMMENT '是否默认配置: 0-否, 1-是',\n  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号',\n  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '状态: ACTIVE-活跃, INACTIVE-未激活',\n  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',\n  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',\n  `updated_by` bigint DEFAULT NULL COMMENT '更新人ID',\n  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',\n  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',\n  PRIMARY KEY (`id`),\n  UNIQUE KEY `uk_config_name_version` (`config_name`,`version`),\n  KEY `idx_report_type` (`report_type`),\n  KEY `idx_chart_type` (`chart_type`),\n  KEY `idx_status` (`status`)\n) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表图表配置表';

CREATE TABLE IF NOT EXISTS `report_config` (\n  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',\n  `config_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置名称',\n  `report_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '报表类型',\n  `statistic_dimension` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '统计维度',\n  `cron_expression` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '定时任务Cron表达式',\n  `scheduled_enabled` tinyint(1) DEFAULT '0' COMMENT '是否启用定时任务: 0-禁用, 1-启用',\n  `schedule_description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '定时任务执行时间描述',\n  `recipient_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '接收人类型: USER-指定用户, ROLE-指定角色, DEPARTMENT-指定部门, EMAIL-邮箱列表',\n  `recipient_ids` json DEFAULT NULL COMMENT '接收人ID列表（JSON数组）',\n  `recipient_emails` json DEFAULT NULL COMMENT '接收人邮箱列表（JSON数组）',\n  `notification_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'SYSTEM' COMMENT '通知方式: EMAIL-邮件通知, SYSTEM-系统通知, BOTH-两者都通知',\n  `export_format` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'EXCEL' COMMENT '导出格式: EXCEL-Excel格式, PDF-PDF格式, CSV-CSV格式, ALL-所有格式',\n  `include_attachment` tinyint(1) DEFAULT '1' COMMENT '是否包含附件: 0-否, 1-是',\n  `include_charts` tinyint(1) DEFAULT '1' COMMENT '是否包含图表: 0-否, 1-是',\n  `chart_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'BAR' COMMENT '图表类型: BAR-柱状图, LINE-折线图, PIE-饼图, ALL-所有图表',\n  `data_retention_days` int DEFAULT '365' COMMENT '数据保留天数（0表示永久保留）',\n  `warehouse_ids` json DEFAULT NULL COMMENT '仓库ID筛选（JSON数组，空表示所有仓库）',\n  `collateral_types` json DEFAULT NULL COMMENT '资产类型筛选（JSON数组，空表示所有类型）',\n  `department_ids` json DEFAULT NULL COMMENT '部门ID筛选（JSON数组，空表示所有部门）',\n  `customer_ids` json DEFAULT NULL COMMENT '客户ID筛选（JSON数组，空表示所有客户）',\n  `extra_filters` json DEFAULT NULL COMMENT '额外过滤条件（JSON格式）',\n  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '配置状态: ACTIVE-活跃, INACTIVE-未激活, DELETED-已删除',\n  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',\n  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',\n  `updated_by` bigint DEFAULT NULL COMMENT '更新人ID',\n  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',\n  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',\n  `version` int DEFAULT '1' COMMENT '版本号（乐观锁）',\n  `execution_count` int DEFAULT '0' COMMENT '执行次数',\n  `success_count` int DEFAULT '0' COMMENT '成功次数',\n  `failure_count` int DEFAULT '0' COMMENT '失败次数',\n  `average_execution_seconds` decimal(10,2) DEFAULT '0.00' COMMENT '平均执行时长（秒）',\n  `last_execution_time` datetime DEFAULT NULL COMMENT '上一次执行时间',\n  `last_execution_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '上一次执行状态',\n  `next_execution_time` datetime DEFAULT NULL COMMENT '下一次执行时间',\n  PRIMARY KEY (`id`),\n  UNIQUE KEY `uk_config_name` (`config_name`),\n  KEY `idx_report_type` (`report_type`),\n  KEY `idx_status` (`status`),\n  KEY `idx_scheduled_enabled` (`scheduled_enabled`),\n  KEY `idx_created_by` (`created_by`),\n  KEY `idx_create_time` (`create_time`)\n) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表配置表';

CREATE TABLE IF NOT EXISTS `report_data_cache` (\n  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',\n  `cache_key` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '缓存键（MD5哈希）',\n  `cache_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '缓存类型',\n  `cache_data` json NOT NULL COMMENT '缓存数据（JSON格式）',\n  `data_size` int DEFAULT NULL COMMENT '数据大小（字节数）',\n  `created_time` datetime NOT NULL COMMENT '创建时间',\n  `expiry_time` datetime NOT NULL COMMENT '过期时间',\n  `last_accessed_time` datetime DEFAULT NULL COMMENT '最后访问时间',\n  `access_count` int DEFAULT '0' COMMENT '访问次数',\n  PRIMARY KEY (`id`),\n  UNIQUE KEY `uk_cache_key` (`cache_key`),\n  KEY `idx_cache_type` (`cache_type`),\n  KEY `idx_expiry_time` (`expiry_time`),\n  KEY `idx_last_accessed_time` (`last_accessed_time`)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表数据缓存表';

CREATE TABLE IF NOT EXISTS `report_execution_log` (\n  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',\n  `report_config_id` bigint NOT NULL COMMENT '报表配置ID',\n  `report_statistics_id` bigint DEFAULT NULL COMMENT '报表统计ID',\n  `execution_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '执行类型: SCHEDULED-定时执行, MANUAL-手动执行, API-API调用',\n  `execution_time` datetime NOT NULL COMMENT '执行时间',\n  `completion_time` datetime DEFAULT NULL COMMENT '完成时间',\n  `execution_duration_ms` bigint DEFAULT NULL COMMENT '执行耗时（毫秒）',\n  `execution_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '执行状态: STARTED-已开始, PROCESSING-处理中, COMPLETED-已完成, FAILED-已失败, CANCELLED-已取消',\n  `error_message` text COLLATE utf8mb4_unicode_ci COMMENT '错误信息',\n  `error_stack_trace` text COLLATE utf8mb4_unicode_ci COMMENT '错误堆栈跟踪',\n  `input_parameters` json DEFAULT NULL COMMENT '输入参数（JSON格式）',\n  `output_result` json DEFAULT NULL COMMENT '输出结果（JSON格式）',\n  `export_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '导出文件名',\n  `export_file_size` bigint DEFAULT NULL COMMENT '导出文件大小（字节）',\n  `export_file_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '导出文件路径',\n  `export_file_md5` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '导出文件MD5',\n  `notification_sent` tinyint(1) DEFAULT '0' COMMENT '通知是否已发送: 0-否, 1-是',\n  `notification_time` datetime DEFAULT NULL COMMENT '通知发送时间',\n  `notification_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '通知状态',\n  `executed_by` bigint DEFAULT NULL COMMENT '执行人ID',\n  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',\n  PRIMARY KEY (`id`),\n  KEY `idx_report_config_id` (`report_config_id`),\n  KEY `idx_report_statistics_id` (`report_statistics_id`),\n  KEY `idx_execution_time` (`execution_time`),\n  KEY `idx_execution_status` (`execution_status`),\n  KEY `idx_execution_type` (`execution_type`),\n  KEY `idx_executed_by` (`executed_by`),\n  CONSTRAINT `report_execution_log_ibfk_1` FOREIGN KEY (`report_config_id`) REFERENCES `report_config` (`id`) ON DELETE CASCADE\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表执行日志表';

CREATE TABLE IF NOT EXISTS `report_statistics` (\n  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',\n  `report_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '报表类型: INBOUND_STATS-入库统计, LOAN_OUT_STATS-借出统计, OVERDUE_STATS-逾期统计, INVENTORY_STATS-库存统计, FINANCIAL_STATS-财务统计, APPROVAL_EFFICIENCY-审批效率统计',\n  `statistic_dimension` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '统计维度: DAILY-日报, WEEKLY-周报, MONTHLY-月报, QUARTERLY-季报, YEARLY-年报, CUSTOM-自定义',\n  `start_time` datetime NOT NULL COMMENT '统计开始时间',\n  `end_time` datetime NOT NULL COMMENT '统计结束时间',\n  `generated_time` datetime NOT NULL COMMENT '统计生成时间',\n  `inbound_count` int DEFAULT '0' COMMENT '入库数量',\n  `inbound_total_value` decimal(18,2) DEFAULT '0.00' COMMENT '入库总价值',\n  `loan_out_count` int DEFAULT '0' COMMENT '借出数量',\n  `loan_out_total_value` decimal(18,2) DEFAULT '0.00' COMMENT '借出总价值',\n  `overdue_count` int DEFAULT '0' COMMENT '逾期数量',\n  `overdue_total_value` decimal(18,2) DEFAULT '0.00' COMMENT '逾期总价值',\n  `inventory_count` int DEFAULT '0' COMMENT '库存数量',\n  `inventory_total_value` decimal(18,2) DEFAULT '0.00' COMMENT '库存总价值',\n  `approval_pass_count` int DEFAULT '0' COMMENT '审批通过数量',\n  `approval_reject_count` int DEFAULT '0' COMMENT '审批拒绝数量',\n  `average_approval_hours` decimal(10,2) DEFAULT '0.00' COMMENT '平均审批时长（小时）',\n  `financial_income` decimal(18,2) DEFAULT '0.00' COMMENT '财务收入',\n  `financial_expense` decimal(18,2) DEFAULT '0.00' COMMENT '财务支出',\n  `financial_profit` decimal(18,2) DEFAULT '0.00' COMMENT '财务利润',\n  `warehouse_id` bigint DEFAULT NULL COMMENT '仓库ID（如果按仓库统计）',\n  `collateral_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产类型（如果按资产类型统计）',\n  `customer_id` bigint DEFAULT NULL COMMENT '客户ID（如果按客户统计）',\n  `department_id` bigint DEFAULT NULL COMMENT '部门ID（如果按部门统计）',\n  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',\n  `extended_fields` json DEFAULT NULL COMMENT '扩展字段（JSON格式）',\n  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',\n  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',\n  PRIMARY KEY (`id`),\n  KEY `idx_report_type` (`report_type`),\n  KEY `idx_statistic_dimension` (`statistic_dimension`),\n  KEY `idx_generated_time` (`generated_time`),\n  KEY `idx_time_range` (`start_time`,`end_time`),\n  KEY `idx_warehouse` (`warehouse_id`),\n  KEY `idx_collateral_type` (`collateral_type`),\n  KEY `idx_customer` (`customer_id`),\n  KEY `idx_department` (`department_id`),\n  KEY `idx_report_type_dimension_time` (`report_type`,`statistic_dimension`,`generated_time`)\n) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表统计表';

CREATE TABLE IF NOT EXISTS `report_template` (\n  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',\n  `template_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板名称',\n  `template_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板代码',\n  `report_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '报表类型',\n  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模板描述',\n  `template_content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板内容（HTML/XML等）',\n  `template_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板类型: HTML-HTML模板, XML-XML模板, JASPER-JasperReports模板, VELOCITY-Velocity模板',\n  `style_css` text COLLATE utf8mb4_unicode_ci COMMENT '样式CSS',\n  `header_template` text COLLATE utf8mb4_unicode_ci COMMENT '页眉模板',\n  `footer_template` text COLLATE utf8mb4_unicode_ci COMMENT '页脚模板',\n  `configuration` json DEFAULT NULL COMMENT '模板配置（JSON格式）',\n  `is_default` tinyint(1) DEFAULT '0' COMMENT '是否默认模板: 0-否, 1-是',\n  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号',\n  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '状态: ACTIVE-活跃, INACTIVE-未激活, DEPRECATED-已废弃',\n  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',\n  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',\n  `updated_by` bigint DEFAULT NULL COMMENT '更新人ID',\n  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',\n  PRIMARY KEY (`id`),\n  UNIQUE KEY `uk_template_code_version` (`template_code`,`version`),\n  KEY `idx_report_type` (`report_type`),\n  KEY `idx_status` (`status`),\n  KEY `idx_is_default` (`is_default`)\n) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表模板表';

-- ============================================
-- 4. 视图
-- ============================================

-- ============================================
-- 5. 存储过程和函数
-- ============================================

-- 当前数据库中没有存储过程或函数

-- ============================================
-- 6. 初始化数据
-- ============================================

INSERT INTO system_roles (role_code, role_name, description, data_scope) VALUES
INSERT INTO system_users (username, password, full_name, email, role, status) VALUES
INSERT INTO overdue_alert_config (alert_days_before, alert_recipients, enabled) VALUES
INSERT INTO system_config (config_key, config_value, config_type, description) VALUES

-- ============================================
-- 7. 索引和性能优化
-- ============================================

CREATE INDEX idx_wh_in_status_bu_created ON collateral_warehouse_in(status, bu_code, created_at);
CREATE INDEX idx_wh_in_customer_created ON collateral_warehouse_in(customer_id, created_at);
CREATE INDEX idx_wh_in_type_status ON collateral_warehouse_in(intake_type, status);
CREATE INDEX idx_wh_in_data_source ON collateral_warehouse_in(data_source);
CREATE INDEX idx_wh_in_files_upload_time ON warehouse_in_files(upload_time);
CREATE INDEX idx_wh_in_files_type ON warehouse_in_files(file_type);
CREATE INDEX idx_wh_in_approval_status ON warehouse_in_approval(wh_in_id, step_number, status);
CREATE INDEX idx_wh_in_approval_role ON warehouse_in_approval(approver_role, status);
CREATE INDEX idx_wh_in_approval_user ON warehouse_in_approval(approver_user, approved_at);
CREATE INDEX idx_loan_out_status_return ON collateral_loan_out(status, expected_return_date);
CREATE INDEX idx_loan_out_wh_in_status ON collateral_loan_out(wh_in_id, status);
CREATE INDEX idx_loan_out_created ON collateral_loan_out(created_at);
CREATE INDEX idx_loan_out_sync ON collateral_loan_out(t24_sync_status, t24_sync_time);
CREATE INDEX idx_overdue_alert_type_time ON overdue_alert_log(alert_type, alert_time);
CREATE INDEX idx_overdue_alert_sent_status ON overdue_alert_log(sent_status);
CREATE INDEX idx_transfer_wh_in_status ON collateral_transfer(wh_in_id, status);
CREATE INDEX idx_transfer_date ON collateral_transfer(transfer_date);
CREATE INDEX idx_transfer_type_status ON collateral_transfer(transfer_type, status);
CREATE INDEX idx_transfer_created ON collateral_transfer(created_at);
CREATE INDEX idx_transfer_approval_status ON transfer_approval(transfer_id, step_number, status);
CREATE INDEX idx_transfer_approval_role ON transfer_approval(approver_role, status);
CREATE INDEX idx_wh_out_type_status ON collateral_warehouse_out(out_type, status);
CREATE INDEX idx_wh_out_reason ON collateral_warehouse_out(out_reason);
CREATE INDEX idx_wh_out_created ON collateral_warehouse_out(created_at);
CREATE INDEX idx_wh_out_wh_in_status ON collateral_warehouse_out(wh_in_id, status);
CREATE INDEX idx_wh_out_approval_status ON warehouse_out_approval(wh_out_id, step_number, status);
CREATE INDEX idx_wh_out_approval_role ON warehouse_out_approval(approver_role, status);
CREATE INDEX idx_users_status ON system_users(status);
CREATE INDEX idx_users_email ON system_users(email);
CREATE INDEX idx_users_last_login ON system_users(last_login_time);
CREATE INDEX idx_users_bu_role ON system_users(bu_code, role);
CREATE INDEX idx_audit_user_time_resource ON audit_logs(user_id, timestamp, resource_type);
CREATE INDEX idx_audit_action_time ON audit_logs(action, timestamp);
CREATE INDEX idx_audit_status ON audit_logs(status);
CREATE INDEX idx_config_type ON system_config(config_type);
CREATE INDEX idx_config_editable ON system_config(editable);

-- ============================================
-- 初始化脚本生成完成
-- 执行说明:
--   1. 确保MySQL版本为8.x
--   2. 确保有足够的权限
--   3. 建议在测试环境先验证
--   4. 生产环境执行前请备份数据
-- ============================================