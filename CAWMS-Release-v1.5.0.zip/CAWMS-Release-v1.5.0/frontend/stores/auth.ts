import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { Ref } from 'vue'
import { getAuthToken, setAuthToken, clearAuth, post, get } from '@/utils/request'
import type { ApiResponse } from '@/utils/request'
import { getRoleAvatar } from '@/composables/useRoleAvatar'

/**
 * 用户信息接口
 */
export interface UserInfo {
  id: number
  username: string
  email?: string
  phone?: string
  fullName?: string
  avatar?: string
  department?: string
  role?: string
  permissions?: string[]
  lastLogin?: string
  status?: 'active' | 'inactive' | 'locked'
}

/**
 * 登录请求接口
 */
export interface LoginRequest {
  username: string
  password: string
  rememberMe?: boolean
  captcha?: string
}

/**
 * 登录响应接口
 */
export interface LoginResponse {
  token: string
  user: UserInfo
  expiresIn: number
  permissions: string[]
  roles: string[]
}

/**
 * 注册请求接口
 */
export interface RegisterRequest {
  username: string
  password: string
  email: string
  phone?: string
  fullName?: string
  captcha?: string
}

/**
 * 权限检查接口
 */
export interface PermissionCheck {
  required: string | string[]
  mode?: 'and' | 'or'
}

/**
 * 认证状态管理Store
 */
export const useAuthStore = defineStore('auth', () => {
  // 状态
  const token: Ref<string | null> = ref(getAuthToken())
  const user: Ref<UserInfo | null> = ref(null)
  const permissions: Ref<string[]> = ref([])
  const roles: Ref<string[]> = ref([])
  const loading: Ref<boolean> = ref(false)
  const error: Ref<string | null> = ref(null)
  
  // 计算属性
  const isAuthenticated = computed(() => !!token.value && !!user.value)
  const isAdmin = computed(() => roles.value.includes('admin') || roles.value.includes('super_admin'))
  const isUser = computed(() => roles.value.includes('user') || isAuthenticated.value)
  const hasUserInfo = computed(() => !!user.value)
  const userFullName = computed(() => user.value?.fullName || user.value?.username || '')
  const userAvatar = computed(() => {
    // 优先使用用户自定义头像
    if (user.value?.avatar) return user.value.avatar
    // 否则按角色显示对应头像
    return getRoleAvatar(user.value?.role)
  })
  
  /**
   * 登录
   */
  async function login(credentials: LoginRequest): Promise<boolean> {
    loading.value = true
    error.value = null
    
    try {
      const data = await post<LoginResponse>('/api/auth/login', credentials)
      
      if (data) {
        const { token: newToken, user: userInfo, permissions: userPermissions, roles: userRoles } = data
        
        // 更新状态
        token.value = newToken
        user.value = userInfo
        permissions.value = userPermissions
        roles.value = userRoles
        
        // 保存token到localStorage
        setAuthToken(newToken)
        
        // 保存用户信息到sessionStorage（可选）
        if (typeof window !== 'undefined') {
          sessionStorage.setItem('userInfo', JSON.stringify(userInfo))
        }
        
        return true
      }
    } catch (err: any) {
      error.value = err.message || '网络错误'
      return false
    } finally {
      loading.value = false
    }
  }
  
  /**
   * 登出
   */
  async function logout(): Promise<void> {
    loading.value = true
    
    try {
      await post('/api/auth/logout')
      clearAuthState()
      
      // 重定向到登录页（在组件中处理）
    } catch (err: any) {
      console.error('登出失败:', err)
      // 即使API失败也清除本地状态
      clearAuthState()
    } finally {
      loading.value = false
    }
  }
  
  /**
   * 清除认证状态
   */
  function clearAuthState(): void {
    token.value = null
    user.value = null
    permissions.value = []
    roles.value = []
    error.value = null
    
    // 清除存储
    clearAuth()
    if (typeof window !== 'undefined') {
      sessionStorage.removeItem('userInfo')
    }
  }
  
  /**
   * 获取用户信息
   */
  async function fetchUserInfo(): Promise<boolean> {
    if (!token.value) return false
    
    loading.value = true
    
    try {
      const data = await get<UserInfo>('/api/auth/me')
      if (data) {
        user.value = data
        permissions.value = data.permissions || []
        roles.value = data.role ? [data.role] : []
        if (typeof window !== 'undefined') {
          sessionStorage.setItem('userInfo', JSON.stringify(data))
        }
        return true
      } else {
        error.value = '获取用户信息失败'
        return false
      }
    } catch (err: any) {
      error.value = err.message || '网络错误'
      return false
    } finally {
      loading.value = false
    }
  }
  
  /**
   * 检查权限
   */
  function hasPermission(permission: string | string[], mode: 'and' | 'or' = 'or'): boolean {
    if (!permission) return true
    if (!permissions.value.length) return false
    
    if (Array.isArray(permission)) {
      if (mode === 'and') {
        // 需要所有权限
        return permission.every(p => permissions.value.includes(p))
      } else {
        // 需要任一权限
        return permission.some(p => permissions.value.includes(p))
      }
    } else {
      // 单个权限
      return permissions.value.includes(permission)
    }
  }
  
  /**
   * 检查角色
   */
  function hasRole(role: string | string[], mode: 'and' | 'or' = 'or'): boolean {
    if (!role) return true
    if (!roles.value.length) return false
    
    if (Array.isArray(role)) {
      if (mode === 'and') {
        return role.every(r => roles.value.includes(r))
      } else {
        return role.some(r => roles.value.includes(r))
      }
    } else {
      return roles.value.includes(role)
    }
  }
  
  /**
   * 更新用户信息
   */
  async function updateUserInfo(userData: Partial<UserInfo>): Promise<boolean> {
    loading.value = true
    
    try {
      user.value = { ...user.value, ...userData } as UserInfo
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('userInfo', JSON.stringify(user.value))
      }
      return true
    } catch (err: any) {
      error.value = err.message || '网络错误'
      return false
    } finally {
      loading.value = false
    }
  }
  
  /**
   * 修改密码
   */
  async function changePassword(oldPassword: string, newPassword: string): Promise<boolean> {
    loading.value = true
    
    try {
      await post('/api/auth/change-password', { oldPassword, newPassword })
      return true
    } catch (err: any) {
      error.value = err.message || '网络错误'
      return false
    } finally {
      loading.value = false
    }
  }
  
  /**
   * 初始化认证状态
   */
  async function initialize(): Promise<void> {
    // 检查本地是否有token
    const localToken = getAuthToken()
    
    if (localToken) {
      token.value = localToken
      // 无论 user 是否已有值，都尝试获取最新用户信息
      // 这样可以确保刷新页面或状态丢失后能恢复
      await fetchUserInfo()
    }
  }
  
  /**
   * 重置错误状态
   */
  function resetError(): void {
    error.value = null
  }
  
  return {
    // 状态
    token,
    user,
    permissions,
    roles,
    loading,
    error,
    
    // 计算属性
    isAuthenticated,
    isAdmin,
    isUser,
    hasUserInfo,
    userFullName,
    userAvatar,
    
    // 方法
    login,
    logout,
    clearAuthState,
    fetchUserInfo,
    hasPermission,
    hasRole,
    updateUserInfo,
    changePassword,
    initialize,
    resetError
  }
})

// 导出类型
export type AuthStore = ReturnType<typeof useAuthStore>