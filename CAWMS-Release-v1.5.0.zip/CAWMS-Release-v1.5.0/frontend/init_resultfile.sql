-- MySQL dump 10.13  Distrib 8.4.8, for Win64 (x86_64)
--
-- Host: localhost    Database: cawms
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `user_id` bigint DEFAULT NULL COMMENT '??ID',
  `username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '???',
  `action` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `resource_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `resource_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??ID',
  `old_value` text COLLATE utf8mb4_unicode_ci COMMENT '??',
  `new_value` text COLLATE utf8mb4_unicode_ci COMMENT '??',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IP??',
  `user_agent` text COLLATE utf8mb4_unicode_ci COMMENT '????',
  `request_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??URL',
  `request_method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `execution_time` int DEFAULT NULL COMMENT '????(ms)',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????: SUCCESS, FAILED',
  `error_message` text COLLATE utf8mb4_unicode_ci COMMENT '????',
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`),
  KEY `idx_user_time` (`user_id`,`timestamp`),
  KEY `idx_resource` (`resource_type`,`resource_id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_audit_user_time_resource` (`user_id`,`timestamp`,`resource_type`),
  KEY `idx_audit_action_time` (`action`,`timestamp`),
  KEY `idx_audit_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collateral_loan_out`
--

DROP TABLE IF EXISTS `collateral_loan_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collateral_loan_out` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint NOT NULL COMMENT '???????',
  `loan_purpose` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `loan_duration` int DEFAULT NULL COMMENT '????(?)',
  `expected_return_date` date DEFAULT NULL COMMENT '??????',
  `actual_return_date` date DEFAULT NULL COMMENT '??????',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'DRAFT' COMMENT '??: DRAFT, LOANED, RETURNED, OVERDUE',
  `t24_sync_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING' COMMENT 'T24????: PENDING, SYNCED, FAILED',
  `t24_sync_time` datetime DEFAULT NULL COMMENT 'T24????',
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '???',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_return_date` (`expected_return_date`),
  KEY `idx_sync_status` (`t24_sync_status`),
  KEY `idx_loan_out_status_return` (`status`,`expected_return_date`),
  KEY `idx_loan_out_wh_in_status` (`wh_in_id`,`status`),
  KEY `idx_loan_out_created` (`created_at`),
  KEY `idx_loan_out_sync` (`t24_sync_status`,`t24_sync_time`),
  CONSTRAINT `collateral_loan_out_ibfk_1` FOREIGN KEY (`wh_in_id`) REFERENCES `collateral_warehouse_in` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collateral_transfer`
--

DROP TABLE IF EXISTS `collateral_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collateral_transfer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint NOT NULL COMMENT '???????',
  `source_wh_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??????',
  `source_location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `target_wh_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??????',
  `target_location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `transfer_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????: INTERNAL, CROSS_WAREHOUSE',
  `transfer_reason` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `transfer_date` date DEFAULT NULL COMMENT '????',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING' COMMENT '??: PENDING, IN_TRANSIT, COMPLETED, CANCELLED',
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '???',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_source_wh` (`source_wh_code`),
  KEY `idx_target_wh` (`target_wh_code`),
  KEY `idx_transfer_wh_in_status` (`wh_in_id`,`status`),
  KEY `idx_transfer_date` (`transfer_date`),
  KEY `idx_transfer_type_status` (`transfer_type`,`status`),
  KEY `idx_transfer_created` (`created_at`),
  CONSTRAINT `collateral_transfer_ibfk_1` FOREIGN KEY (`wh_in_id`) REFERENCES `collateral_warehouse_in` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collateral_warehouse_in`
--

DROP TABLE IF EXISTS `collateral_warehouse_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collateral_warehouse_in` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '????',
  `bu_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??????',
  `bu_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??????',
  `customer_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `customer_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??ID',
  `collateral_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??????',
  `collateral_value` decimal(18,2) DEFAULT NULL COMMENT '????',
  `credit_agreement_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '?????',
  `intake_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'NEW' COMMENT '????: NEW, SUPPLEMENTARY',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'DRAFT' COMMENT '??: DRAFT, SUBMITTED, APPROVED, COMPLETED',
  `current_step` int DEFAULT '1' COMMENT '??????',
  `data_source` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'MANUAL' COMMENT '????: MANUAL, SEAOPS, LOS, T24, EXCEL',
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '???',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` tinyint DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wh_code` (`wh_code`),
  KEY `idx_status` (`status`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_bu` (`bu_code`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_wh_in_status_bu_created` (`status`,`bu_code`,`created_at`),
  KEY `idx_wh_in_customer_created` (`customer_id`,`created_at`),
  KEY `idx_wh_in_type_status` (`intake_type`,`status`),
  KEY `idx_wh_in_data_source` (`data_source`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collateral_warehouse_out`
--

DROP TABLE IF EXISTS `collateral_warehouse_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collateral_warehouse_out` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint NOT NULL COMMENT '???????',
  `out_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????: PARTIAL, FULL',
  `out_reason` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????: LOAN_SETTLED, DEBT_HANDLING, ASSET_SWAP, PARTIAL_OUT, OFFSET',
  `out_amount` decimal(18,2) DEFAULT NULL COMMENT '???????????',
  `out_percentage` decimal(5,2) DEFAULT NULL COMMENT '???????????',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'DRAFT' COMMENT '??: DRAFT, SUBMITTED, APPROVED, COMPLETED',
  `current_step` int DEFAULT '1' COMMENT '??????',
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '???',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_wh_in` (`wh_in_id`),
  KEY `idx_wh_out_type_status` (`out_type`,`status`),
  KEY `idx_wh_out_reason` (`out_reason`),
  KEY `idx_wh_out_created` (`created_at`),
  KEY `idx_wh_out_wh_in_status` (`wh_in_id`,`status`),
  CONSTRAINT `collateral_warehouse_out_ibfk_1` FOREIGN KEY (`wh_in_id`) REFERENCES `collateral_warehouse_in` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_out_approval`
--

DROP TABLE IF EXISTS `loan_out_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan_out_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `loan_out_id` bigint NOT NULL,
  `step_number` int NOT NULL,
  `step_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审批人姓名',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `comments` text COLLATE utf8mb4_unicode_ci,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `due_date` datetime DEFAULT NULL COMMENT '预计完成时间',
  `completed_at` datetime DEFAULT NULL COMMENT '实际完成时间',
  `processing_minutes` int DEFAULT NULL COMMENT '处理时长（分钟）',
  `auto_approved` tinyint(1) DEFAULT '0' COMMENT '是否自动审批',
  `approval_attachments` text COLLATE utf8mb4_unicode_ci COMMENT '审批附件（JSON格式）',
  `ext_data` text COLLATE utf8mb4_unicode_ci COMMENT '扩展字段（JSON格式）',
  `version` int DEFAULT '0' COMMENT '版本号（乐观锁）',
  PRIMARY KEY (`id`),
  KEY `idx_loan_out_step` (`loan_out_id`,`step_number`),
  CONSTRAINT `loan_out_approval_ibfk_1` FOREIGN KEY (`loan_out_id`) REFERENCES `collateral_loan_out` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `overdue_alert_config`
--

DROP TABLE IF EXISTS `overdue_alert_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `overdue_alert_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `alert_days_before` int DEFAULT '3' COMMENT '??????',
  `alert_recipients` text COLLATE utf8mb4_unicode_ci COMMENT '?????',
  `alert_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预警方式: EMAIL, SMS, SYSTEM_NOTIFICATION, ALL',
  `alert_template_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预警模板ID',
  `alert_frequency_hours` int DEFAULT '24' COMMENT '预警频率（小时）',
  `max_alert_count` int DEFAULT '0' COMMENT '最大预警次数，0表示无限制',
  `enabled` tinyint(1) DEFAULT '1' COMMENT '????',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='???????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `overdue_alert_log`
--

DROP TABLE IF EXISTS `overdue_alert_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `overdue_alert_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `loan_out_id` bigint NOT NULL,
  `alert_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????: WARNING, OVERDUE',
  `alert_message` text COLLATE utf8mb4_unicode_ci COMMENT '????',
  `alert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `recipients` text COLLATE utf8mb4_unicode_ci COMMENT '???',
  `sent_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING' COMMENT '????',
  `sent_time` datetime DEFAULT NULL COMMENT '发送时间',
  `send_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发送方式: EMAIL, SMS, SYSTEM_NOTIFICATION',
  `send_details` text COLLATE utf8mb4_unicode_ci COMMENT '发送详情（JSON格式）',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_loan_out` (`loan_out_id`),
  KEY `idx_alert_time` (`alert_time`),
  KEY `idx_overdue_alert_type_time` (`alert_type`,`alert_time`),
  KEY `idx_overdue_alert_sent_status` (`sent_status`),
  CONSTRAINT `overdue_alert_log_ibfk_1` FOREIGN KEY (`loan_out_id`) REFERENCES `collateral_loan_out` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='???????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_chart_config`
--

DROP TABLE IF EXISTS `report_chart_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_chart_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `config_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置名称',
  `report_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '报表类型',
  `chart_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图表类型: BAR-柱状图, LINE-折线图, PIE-饼图, AREA-面积图, SCATTER-散点图',
  `data_source_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '数据源类型: SQL-SQL查询, API-API调用, STATIC-静态数据',
  `data_source_config` json NOT NULL COMMENT '数据源配置（JSON格式）',
  `chart_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图表标题',
  `x_axis_label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'X轴标签',
  `y_axis_label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Y轴标签',
  `legend_position` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'RIGHT' COMMENT '图例位置: TOP, BOTTOM, LEFT, RIGHT, NONE',
  `color_scheme` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'DEFAULT' COMMENT '颜色方案',
  `background_color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '背景颜色',
  `border_color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '边框颜色',
  `font_family` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Arial' COMMENT '字体家族',
  `font_size` int DEFAULT '12' COMMENT '字体大小',
  `enable_tooltip` tinyint(1) DEFAULT '1' COMMENT '是否启用工具提示: 0-否, 1-是',
  `enable_animation` tinyint(1) DEFAULT '1' COMMENT '是否启用动画: 0-否, 1-是',
  `enable_zoom` tinyint(1) DEFAULT '0' COMMENT '是否启用缩放: 0-否, 1-是',
  `is_default` tinyint(1) DEFAULT '0' COMMENT '是否默认配置: 0-否, 1-是',
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '状态: ACTIVE-活跃, INACTIVE-未激活',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` bigint DEFAULT NULL COMMENT '更新人ID',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_name_version` (`config_name`,`version`),
  KEY `idx_report_type` (`report_type`),
  KEY `idx_chart_type` (`chart_type`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表图表配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_config`
--

DROP TABLE IF EXISTS `report_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `config_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置名称',
  `report_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '报表类型',
  `statistic_dimension` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '统计维度',
  `cron_expression` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '定时任务Cron表达式',
  `scheduled_enabled` tinyint(1) DEFAULT '0' COMMENT '是否启用定时任务: 0-禁用, 1-启用',
  `schedule_description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '定时任务执行时间描述',
  `recipient_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '接收人类型: USER-指定用户, ROLE-指定角色, DEPARTMENT-指定部门, EMAIL-邮箱列表',
  `recipient_ids` json DEFAULT NULL COMMENT '接收人ID列表（JSON数组）',
  `recipient_emails` json DEFAULT NULL COMMENT '接收人邮箱列表（JSON数组）',
  `notification_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'SYSTEM' COMMENT '通知方式: EMAIL-邮件通知, SYSTEM-系统通知, BOTH-两者都通知',
  `export_format` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'EXCEL' COMMENT '导出格式: EXCEL-Excel格式, PDF-PDF格式, CSV-CSV格式, ALL-所有格式',
  `include_attachment` tinyint(1) DEFAULT '1' COMMENT '是否包含附件: 0-否, 1-是',
  `include_charts` tinyint(1) DEFAULT '1' COMMENT '是否包含图表: 0-否, 1-是',
  `chart_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'BAR' COMMENT '图表类型: BAR-柱状图, LINE-折线图, PIE-饼图, ALL-所有图表',
  `data_retention_days` int DEFAULT '365' COMMENT '数据保留天数（0表示永久保留）',
  `warehouse_ids` json DEFAULT NULL COMMENT '仓库ID筛选（JSON数组，空表示所有仓库）',
  `collateral_types` json DEFAULT NULL COMMENT '资产类型筛选（JSON数组，空表示所有类型）',
  `department_ids` json DEFAULT NULL COMMENT '部门ID筛选（JSON数组，空表示所有部门）',
  `customer_ids` json DEFAULT NULL COMMENT '客户ID筛选（JSON数组，空表示所有客户）',
  `extra_filters` json DEFAULT NULL COMMENT '额外过滤条件（JSON格式）',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '配置状态: ACTIVE-活跃, INACTIVE-未激活, DELETED-已删除',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` bigint DEFAULT NULL COMMENT '更新人ID',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `version` int DEFAULT '1' COMMENT '版本号（乐观锁）',
  `execution_count` int DEFAULT '0' COMMENT '执行次数',
  `success_count` int DEFAULT '0' COMMENT '成功次数',
  `failure_count` int DEFAULT '0' COMMENT '失败次数',
  `average_execution_seconds` decimal(10,2) DEFAULT '0.00' COMMENT '平均执行时长（秒）',
  `last_execution_time` datetime DEFAULT NULL COMMENT '上一次执行时间',
  `last_execution_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '上一次执行状态',
  `next_execution_time` datetime DEFAULT NULL COMMENT '下一次执行时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_name` (`config_name`),
  KEY `idx_report_type` (`report_type`),
  KEY `idx_status` (`status`),
  KEY `idx_scheduled_enabled` (`scheduled_enabled`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_data_cache`
--

DROP TABLE IF EXISTS `report_data_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_data_cache` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cache_key` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '缓存键（MD5哈希）',
  `cache_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '缓存类型',
  `cache_data` json NOT NULL COMMENT '缓存数据（JSON格式）',
  `data_size` int DEFAULT NULL COMMENT '数据大小（字节数）',
  `created_time` datetime NOT NULL COMMENT '创建时间',
  `expiry_time` datetime NOT NULL COMMENT '过期时间',
  `last_accessed_time` datetime DEFAULT NULL COMMENT '最后访问时间',
  `access_count` int DEFAULT '0' COMMENT '访问次数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cache_key` (`cache_key`),
  KEY `idx_cache_type` (`cache_type`),
  KEY `idx_expiry_time` (`expiry_time`),
  KEY `idx_last_accessed_time` (`last_accessed_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表数据缓存表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_execution_log`
--

DROP TABLE IF EXISTS `report_execution_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_execution_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `report_config_id` bigint NOT NULL COMMENT '报表配置ID',
  `report_statistics_id` bigint DEFAULT NULL COMMENT '报表统计ID',
  `execution_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '执行类型: SCHEDULED-定时执行, MANUAL-手动执行, API-API调用',
  `execution_time` datetime NOT NULL COMMENT '执行时间',
  `completion_time` datetime DEFAULT NULL COMMENT '完成时间',
  `execution_duration_ms` bigint DEFAULT NULL COMMENT '执行耗时（毫秒）',
  `execution_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '执行状态: STARTED-已开始, PROCESSING-处理中, COMPLETED-已完成, FAILED-已失败, CANCELLED-已取消',
  `error_message` text COLLATE utf8mb4_unicode_ci COMMENT '错误信息',
  `error_stack_trace` text COLLATE utf8mb4_unicode_ci COMMENT '错误堆栈跟踪',
  `input_parameters` json DEFAULT NULL COMMENT '输入参数（JSON格式）',
  `output_result` json DEFAULT NULL COMMENT '输出结果（JSON格式）',
  `export_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '导出文件名',
  `export_file_size` bigint DEFAULT NULL COMMENT '导出文件大小（字节）',
  `export_file_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '导出文件路径',
  `export_file_md5` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '导出文件MD5',
  `notification_sent` tinyint(1) DEFAULT '0' COMMENT '通知是否已发送: 0-否, 1-是',
  `notification_time` datetime DEFAULT NULL COMMENT '通知发送时间',
  `notification_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '通知状态',
  `executed_by` bigint DEFAULT NULL COMMENT '执行人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_report_config_id` (`report_config_id`),
  KEY `idx_report_statistics_id` (`report_statistics_id`),
  KEY `idx_execution_time` (`execution_time`),
  KEY `idx_execution_status` (`execution_status`),
  KEY `idx_execution_type` (`execution_type`),
  KEY `idx_executed_by` (`executed_by`),
  CONSTRAINT `report_execution_log_ibfk_1` FOREIGN KEY (`report_config_id`) REFERENCES `report_config` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表执行日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_statistics`
--

DROP TABLE IF EXISTS `report_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_statistics` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `report_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '报表类型: INBOUND_STATS-入库统计, LOAN_OUT_STATS-借出统计, OVERDUE_STATS-逾期统计, INVENTORY_STATS-库存统计, FINANCIAL_STATS-财务统计, APPROVAL_EFFICIENCY-审批效率统计',
  `statistic_dimension` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '统计维度: DAILY-日报, WEEKLY-周报, MONTHLY-月报, QUARTERLY-季报, YEARLY-年报, CUSTOM-自定义',
  `start_time` datetime NOT NULL COMMENT '统计开始时间',
  `end_time` datetime NOT NULL COMMENT '统计结束时间',
  `generated_time` datetime NOT NULL COMMENT '统计生成时间',
  `inbound_count` int DEFAULT '0' COMMENT '入库数量',
  `inbound_total_value` decimal(18,2) DEFAULT '0.00' COMMENT '入库总价值',
  `loan_out_count` int DEFAULT '0' COMMENT '借出数量',
  `loan_out_total_value` decimal(18,2) DEFAULT '0.00' COMMENT '借出总价值',
  `overdue_count` int DEFAULT '0' COMMENT '逾期数量',
  `overdue_total_value` decimal(18,2) DEFAULT '0.00' COMMENT '逾期总价值',
  `inventory_count` int DEFAULT '0' COMMENT '库存数量',
  `inventory_total_value` decimal(18,2) DEFAULT '0.00' COMMENT '库存总价值',
  `approval_pass_count` int DEFAULT '0' COMMENT '审批通过数量',
  `approval_reject_count` int DEFAULT '0' COMMENT '审批拒绝数量',
  `average_approval_hours` decimal(10,2) DEFAULT '0.00' COMMENT '平均审批时长（小时）',
  `financial_income` decimal(18,2) DEFAULT '0.00' COMMENT '财务收入',
  `financial_expense` decimal(18,2) DEFAULT '0.00' COMMENT '财务支出',
  `financial_profit` decimal(18,2) DEFAULT '0.00' COMMENT '财务利润',
  `warehouse_id` bigint DEFAULT NULL COMMENT '仓库ID（如果按仓库统计）',
  `collateral_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产类型（如果按资产类型统计）',
  `customer_id` bigint DEFAULT NULL COMMENT '客户ID（如果按客户统计）',
  `department_id` bigint DEFAULT NULL COMMENT '部门ID（如果按部门统计）',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `extended_fields` json DEFAULT NULL COMMENT '扩展字段（JSON格式）',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_report_type` (`report_type`),
  KEY `idx_statistic_dimension` (`statistic_dimension`),
  KEY `idx_generated_time` (`generated_time`),
  KEY `idx_time_range` (`start_time`,`end_time`),
  KEY `idx_warehouse` (`warehouse_id`),
  KEY `idx_collateral_type` (`collateral_type`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_department` (`department_id`),
  KEY `idx_report_type_dimension_time` (`report_type`,`statistic_dimension`,`generated_time`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表统计表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_template`
--

DROP TABLE IF EXISTS `report_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_template` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `template_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板名称',
  `template_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板代码',
  `report_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '报表类型',
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模板描述',
  `template_content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板内容（HTML/XML等）',
  `template_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板类型: HTML-HTML模板, XML-XML模板, JASPER-JasperReports模板, VELOCITY-Velocity模板',
  `style_css` text COLLATE utf8mb4_unicode_ci COMMENT '样式CSS',
  `header_template` text COLLATE utf8mb4_unicode_ci COMMENT '页眉模板',
  `footer_template` text COLLATE utf8mb4_unicode_ci COMMENT '页脚模板',
  `configuration` json DEFAULT NULL COMMENT '模板配置（JSON格式）',
  `is_default` tinyint(1) DEFAULT '0' COMMENT '是否默认模板: 0-否, 1-是',
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '状态: ACTIVE-活跃, INACTIVE-未激活, DEPRECATED-已废弃',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` bigint DEFAULT NULL COMMENT '更新人ID',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_template_code_version` (`template_code`,`version`),
  KEY `idx_report_type` (`report_type`),
  KEY `idx_status` (`status`),
  KEY `idx_is_default` (`is_default`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报表模板表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci,
  `config_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????: STRING, NUMBER, BOOLEAN, JSON',
  `description` text COLLATE utf8mb4_unicode_ci,
  `editable` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`),
  KEY `idx_config_type` (`config_type`),
  KEY `idx_config_editable` (`editable`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_roles`
--

DROP TABLE IF EXISTS `system_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `permissions` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON??????',
  `data_scope` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????: ALL, BU, SELF',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_users`
--

DROP TABLE IF EXISTS `system_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'BCrypt??',
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bu_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??????',
  `role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '??: ACTIVE, INACTIVE, LOCKED',
  `last_login_time` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`),
  KEY `idx_bu_code` (`bu_code`),
  KEY `idx_role` (`role`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_last_login` (`last_login_time`),
  KEY `idx_users_bu_role` (`bu_code`,`role`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `transfer_approval`
--

DROP TABLE IF EXISTS `transfer_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transfer_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `transfer_id` bigint NOT NULL,
  `step_number` int NOT NULL,
  `step_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `comments` text COLLATE utf8mb4_unicode_ci,
  `approved_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`),
  KEY `idx_transfer_step` (`transfer_id`,`step_number`),
  KEY `idx_transfer_approval_status` (`transfer_id`,`step_number`,`status`),
  KEY `idx_transfer_approval_role` (`approver_role`,`status`),
  CONSTRAINT `transfer_approval_ibfk_1` FOREIGN KEY (`transfer_id`) REFERENCES `collateral_transfer` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='???????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `v_report_dashboard`
--

DROP TABLE IF EXISTS `v_report_dashboard`;
/*!50001 DROP VIEW IF EXISTS `v_report_dashboard`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_report_dashboard` AS SELECT 
 1 AS `category`,
 1 AS `total_count`,
 1 AS `total_value`,
 1 AS `last_update_time`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `warehouse_in_approval`
--

DROP TABLE IF EXISTS `warehouse_in_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_in_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint NOT NULL,
  `step_number` int NOT NULL COMMENT '????',
  `step_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `approver_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '?????',
  `approver_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '?????',
  `approver_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审批人姓名',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING' COMMENT '??: PENDING, APPROVED, REJECTED',
  `comments` text COLLATE utf8mb4_unicode_ci COMMENT '????',
  `approved_at` datetime DEFAULT NULL COMMENT '????',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `due_date` datetime DEFAULT NULL COMMENT '预计完成时间',
  `completed_at` datetime DEFAULT NULL COMMENT '实际完成时间',
  `processing_minutes` int DEFAULT NULL COMMENT '处理时长（分钟）',
  `auto_approved` tinyint(1) DEFAULT '0' COMMENT '是否自动审批',
  `approval_attachments` text COLLATE utf8mb4_unicode_ci COMMENT '审批附件（JSON格式）',
  `ext_data` text COLLATE utf8mb4_unicode_ci COMMENT '扩展字段（JSON格式）',
  `version` int DEFAULT '0' COMMENT '版本号（乐观锁）',
  PRIMARY KEY (`id`),
  KEY `idx_wh_in_step` (`wh_in_id`,`step_number`),
  KEY `idx_wh_in_approval_status` (`wh_in_id`,`step_number`,`status`),
  KEY `idx_wh_in_approval_role` (`approver_role`,`status`),
  KEY `idx_wh_in_approval_user` (`approver_user`,`approved_at`),
  CONSTRAINT `warehouse_in_approval_ibfk_1` FOREIGN KEY (`wh_in_id`) REFERENCES `collateral_warehouse_in` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='???????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_in_files`
--

DROP TABLE IF EXISTS `warehouse_in_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_in_files` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint NOT NULL,
  `file_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `file_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '??????',
  `file_size` bigint DEFAULT NULL COMMENT '????',
  `file_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '文件哈希',
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'MIME类型',
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '校验和',
  `uploaded_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '上传人',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '状态',
  `download_count` int DEFAULT '0' COMMENT '下载次数',
  `last_download_at` datetime DEFAULT NULL COMMENT '最后下载时间',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `upload_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '????',
  `upload_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_wh_in` (`wh_in_id`),
  KEY `idx_wh_in_files_upload_time` (`upload_time`),
  KEY `idx_wh_in_files_type` (`file_type`),
  CONSTRAINT `warehouse_in_files_ibfk_1` FOREIGN KEY (`wh_in_id`) REFERENCES `collateral_warehouse_in` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='???????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_out_approval`
--

DROP TABLE IF EXISTS `warehouse_out_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_out_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `wh_out_id` bigint NOT NULL,
  `step_number` int NOT NULL,
  `step_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `comments` text COLLATE utf8mb4_unicode_ci,
  `approved_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除标志',
  PRIMARY KEY (`id`),
  KEY `idx_wh_out_step` (`wh_out_id`,`step_number`),
  KEY `idx_wh_out_approval_status` (`wh_out_id`,`step_number`,`status`),
  KEY `idx_wh_out_approval_role` (`approver_role`,`status`),
  CONSTRAINT `warehouse_out_approval_ibfk_1` FOREIGN KEY (`wh_out_id`) REFERENCES `collateral_warehouse_out` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='???????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'cawms'
--

--
-- Dumping routines for database 'cawms'
--
/*!50003 DROP FUNCTION IF EXISTS `fn_get_report_type_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_get_report_type_name`(report_type_code VARCHAR(50)) RETURNS varchar(100) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci
    DETERMINISTIC
BEGIN
    DECLARE type_name VARCHAR(100);
    
    CASE report_type_code
        WHEN 'INBOUND_STATS' THEN SET type_name = '??????';
        WHEN 'LOAN_OUT_STATS' THEN SET type_name = '??????';
        WHEN 'OVERDUE_STATS' THEN SET type_name = '??????';
        WHEN 'INVENTORY_STATS' THEN SET type_name = '??????';
        WHEN 'FINANCIAL_STATS' THEN SET type_name = '??????';
        WHEN 'APPROVAL_EFFICIENCY' THEN SET type_name = '?????????';
        ELSE SET type_name = '??????';
    END CASE;
    
    RETURN type_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_cleanup_expired_reports` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_cleanup_expired_reports`(IN retention_days INT)
BEGIN
    DECLARE expiry_date DATETIME;
    
    IF retention_days <= 0 THEN
        SET retention_days = 365;
    END IF;
    
    SET expiry_date = DATE_SUB(NOW(), INTERVAL retention_days DAY);
    
    -- Delete expired report statistics
    DELETE FROM report_statistics WHERE generated_time < expiry_date;
    
    -- Delete expired execution logs
    DELETE FROM report_execution_log WHERE execution_time < expiry_date;
    
    -- Delete expired data cache
    DELETE FROM report_data_cache WHERE expiry_time < NOW();
    
    SELECT ROW_COUNT() as deleted_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `v_report_dashboard`
--

/*!50001 DROP VIEW IF EXISTS `v_report_dashboard`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_report_dashboard` AS select 'INBOUND' AS `category`,sum(`report_statistics`.`inbound_count`) AS `total_count`,sum(`report_statistics`.`inbound_total_value`) AS `total_value`,max(`report_statistics`.`generated_time`) AS `last_update_time` from `report_statistics` where ((`report_statistics`.`report_type` = 'INBOUND_STATS') and (`report_statistics`.`generated_time` >= (now() - interval 7 day))) union all select 'LOAN_OUT' AS `category`,sum(`report_statistics`.`loan_out_count`) AS `total_count`,sum(`report_statistics`.`loan_out_total_value`) AS `total_value`,max(`report_statistics`.`generated_time`) AS `last_update_time` from `report_statistics` where ((`report_statistics`.`report_type` = 'LOAN_OUT_STATS') and (`report_statistics`.`generated_time` >= (now() - interval 7 day))) union all select 'OVERDUE' AS `category`,sum(`report_statistics`.`overdue_count`) AS `total_count`,sum(`report_statistics`.`overdue_total_value`) AS `total_value`,max(`report_statistics`.`generated_time`) AS `last_update_time` from `report_statistics` where ((`report_statistics`.`report_type` = 'OVERDUE_STATS') and (`report_statistics`.`generated_time` >= (now() - interval 7 day))) union all select 'INVENTORY' AS `category`,sum(`report_statistics`.`inventory_count`) AS `total_count`,sum(`report_statistics`.`inventory_total_value`) AS `total_value`,max(`report_statistics`.`generated_time`) AS `last_update_time` from `report_statistics` where ((`report_statistics`.`report_type` = 'INVENTORY_STATS') and (`report_statistics`.`generated_time` >= (now() - interval 30 day))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-21 16:56:45
