/**
 * 权限检查中间件
 * 用于细粒度的权限控制，可以单独使用或与auth中间件配合使用
 */

import { useAuthStore } from '@/stores/auth'

/**
 * 权限中间件
 * 检查用户是否具有特定权限
 */
export default defineNuxtRouteMiddleware((to, from) => {
  const authStore = useAuthStore()
  
  // 如果路由指定了权限要求
  if (to.meta.permissions && to.meta.permissions.length > 0) {
    const requiredPermissions = to.meta.permissions as string[]
    const permissionMode = to.meta.permissionMode as 'and' | 'or' || 'or'
    
    // 检查用户是否登录
    if (!authStore.isAuthenticated) {
      const redirectTo = encodeURIComponent(to.fullPath)
      return navigateTo({
        path: '/login',
        query: { redirect: redirectTo }
      })
    }
    
    // 检查权限
    const hasPermission = authStore.hasPermission(requiredPermissions, permissionMode)
    
    if (!hasPermission) {
      // 记录权限检查失败
      console.warn(`权限检查失败: 用户缺少所需权限`, {
        requiredPermissions,
        userPermissions: authStore.permissions,
        mode: permissionMode,
        route: to.fullPath
      })
      
      // 重定向到无权限页面
      return navigateTo({
        path: '/403',
        query: { 
          from: to.fullPath,
          missingPermissions: JSON.stringify(requiredPermissions),
          mode: permissionMode
        }
      })
    }
  }
  
  // 如果路由指定了角色要求
  if (to.meta.roles && to.meta.roles.length > 0) {
    const requiredRoles = to.meta.roles as string[]
    const roleMode = to.meta.roleMode as 'and' | 'or' || 'or'
    
    // 检查用户是否登录
    if (!authStore.isAuthenticated) {
      const redirectTo = encodeURIComponent(to.fullPath)
      return navigateTo({
        path: '/login',
        query: { redirect: redirectTo }
      })
    }
    
    // 检查角色
    const hasRole = authStore.hasRole(requiredRoles, roleMode)
    
    if (!hasRole) {
      // 记录角色检查失败
      console.warn(`角色检查失败: 用户缺少所需角色`, {
        requiredRoles,
        userRoles: authStore.roles,
        mode: roleMode,
        route: to.fullPath
      })
      
      // 重定向到无权限页面
      return navigateTo({
        path: '/403',
        query: { 
          from: to.fullPath,
          missingRoles: JSON.stringify(requiredRoles),
          mode: roleMode
        }
      })
    }
  }
  
  // 如果路由需要管理员权限
  if (to.meta.requiresAdmin) {
    if (!authStore.isAuthenticated) {
      const redirectTo = encodeURIComponent(to.fullPath)
      return navigateTo({
        path: '/login',
        query: { redirect: redirectTo }
      })
    }
    
    if (!authStore.isAdmin) {
      return navigateTo({
        path: '/403',
        query: { from: to.fullPath, reason: 'admin_required' }
      })
    }
  }
  
  // 继续导航
  return true
})

/**
 * 权限检查函数
 * 可以在组件中直接使用
 */
export function checkPermission(permissions: string | string[], mode: 'and' | 'or' = 'or'): boolean {
  const authStore = useAuthStore()
  return authStore.hasPermission(permissions, mode)
}

/**
 * 角色检查函数
 * 可以在组件中直接使用
 */
export function checkRole(roles: string | string[], mode: 'and' | 'or' = 'or'): boolean {
  const authStore = useAuthStore()
  return authStore.hasRole(roles, mode)
}

/**
 * 权限指令
 * 可以在模板中使用 v-permission 指令
 */
export const permissionDirective = {
  mounted(el: HTMLElement, binding: any) {
    const authStore = useAuthStore()
    const { value } = binding
    
    if (!value) return
    
    let hasPermission = false
    
    if (typeof value === 'string') {
      hasPermission = authStore.hasPermission(value)
    } else if (Array.isArray(value)) {
      const permissions = value
      const mode = binding.arg === 'and' ? 'and' : 'or'
      hasPermission = authStore.hasPermission(permissions, mode)
    } else if (typeof value === 'object') {
      const { permissions, mode = 'or' } = value
      hasPermission = authStore.hasPermission(permissions, mode)
    }
    
    if (!hasPermission) {
      el.style.display = 'none'
    }
  }
}

/**
 * 角色指令
 * 可以在模板中使用 v-role 指令
 */
export const roleDirective = {
  mounted(el: HTMLElement, binding: any) {
    const authStore = useAuthStore()
    const { value } = binding
    
    if (!value) return
    
    let hasRole = false
    
    if (typeof value === 'string') {
      hasRole = authStore.hasRole(value)
    } else if (Array.isArray(value)) {
      const roles = value
      const mode = binding.arg === 'and' ? 'and' : 'or'
      hasRole = authStore.hasRole(roles, mode)
    } else if (typeof value === 'object') {
      const { roles, mode = 'or' } = value
      hasRole = authStore.hasRole(roles, mode)
    }
    
    if (!hasRole) {
      el.style.display = 'none'
    }
  }
}

/**
 * 使用示例：
 * 
 * // 在页面组件中使用中间件
 * definePageMeta({
 *   middleware: ['permission'],
 *   meta: {
 *     permissions: ['report:read', 'report:write'],
 *     permissionMode: 'and', // 需要同时具有读取和写入权限
 *     roles: ['manager'],
 *     roleMode: 'or' // 只需要经理或以上角色
 *   }
 * })
 * 
 * // 在组件中使用检查函数
 * const canEdit = checkPermission('user:edit')
 * const isManager = checkRole(['manager', 'admin'])
 * 
 * // 在模板中使用指令
 * <button v-permission="'user:edit'">编辑用户</button>
 * <button v-permission:and="['user:read', 'user:write']">管理用户</button>
 * <div v-role="'admin'">管理员内容</div>
 */