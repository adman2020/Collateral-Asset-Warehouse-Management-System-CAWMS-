/**
 * Guest middleware
 * 已登录用户访问登录/注册页时自动重定向到首页
 */
import { useAuthStore } from '@/stores/auth'

export default defineNuxtRouteMiddleware((to, from) => {
  const authStore = useAuthStore()
  
  if (authStore.isAuthenticated) {
    const redirect = (from.query.redirect as string) || (to.query.redirect as string) || '/'
    return navigateTo(redirect, { replace: true })
  }
})
