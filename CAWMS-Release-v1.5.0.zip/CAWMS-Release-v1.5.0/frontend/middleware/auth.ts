/**
 * 认证中间件
 * 用于路由守卫，检查用户登录状态
 */

import type { NavigationGuard } from '#vue-router'
import { useAuthStore } from '@/stores/auth'

/**
 * 认证中间件
 * 检查用户是否已登录，未登录则重定向到登录页
 */
export default defineNuxtRouteMiddleware(async (to, from) => {
  const authStore = useAuthStore()
  
  // 先尝试初始化认证状态（从 localStorage 恢复 token 并获取用户信息）
  await authStore.initialize()
  
  // 如果路由需要认证（通过meta.requiresAuth指定）
  if (to.meta.requiresAuth) {
    // 检查是否已认证
    if (!authStore.isAuthenticated) {
      // 保存目标路由，登录后可以重定向回来
      const redirectTo = encodeURIComponent(to.fullPath)
      
      // 重定向到登录页
      return navigateTo({
        path: '/login',
        query: { redirect: redirectTo }
      })
    }
    
    // 如果已认证但需要特定角色（通过meta.roles指定）
    if (to.meta.roles && to.meta.roles.length > 0) {
      const requiredRoles = to.meta.roles as string[]
      const hasRequiredRole = authStore.hasRole(requiredRoles, 'or')
      
      if (!hasRequiredRole) {
        // 没有所需角色，重定向到无权限页面或首页
        return navigateTo({
          path: '/403',
          query: { from: to.fullPath }
        })
      }
    }
    
    // 如果已认证但需要特定权限（通过meta.permissions指定）
    if (to.meta.permissions && to.meta.permissions.length > 0) {
      const requiredPermissions = to.meta.permissions as string[]
      const permissionMode = to.meta.permissionMode as 'and' | 'or' || 'or'
      const hasRequiredPermission = authStore.hasPermission(requiredPermissions, permissionMode)
      
      if (!hasRequiredPermission) {
        // 没有所需权限，重定向到无权限页面
        return navigateTo({
          path: '/403',
          query: { from: to.fullPath }
        })
      }
    }
  }
  
  // 如果路由是登录页且用户已登录，重定向到首页
  if (to.path === '/login' && authStore.isAuthenticated) {
    const redirect = from.query.redirect as string || '/'
    return navigateTo(redirect)
  }
  
  // 如果路由是注册页且用户已登录，重定向到首页
  if (to.path === '/register' && authStore.isAuthenticated) {
    return navigateTo('/')
  }
  
  // 如果路由需要管理员权限（通过meta.requiresAdmin指定）
  if (to.meta.requiresAdmin) {
    if (!authStore.isAdmin) {
      return navigateTo({
        path: '/403',
        query: { from: to.fullPath }
      })
    }
  }
  
  // 继续导航
  return true
})

/**
 * 全局路由守卫
 * 可以在app.vue或layout中使用
 */
export function createAuthGuard(): NavigationGuard {
  return async (to, from, next) => {
    const authStore = useAuthStore()
    
    // 初始化认证状态
    await authStore.initialize()
    
    // 应用认证中间件逻辑
    const middlewareResult = await authMiddleware(to, from)
    
    if (middlewareResult === true) {
      next()
    } else if (typeof middlewareResult === 'string' || typeof middlewareResult === 'object') {
      next(middlewareResult)
    } else {
      next(false)
    }
  }
}

/**
 * 路由元信息类型定义
 */
declare module '#vue-router' {
  interface RouteMeta {
    // 是否需要认证
    requiresAuth?: boolean
    // 需要的角色
    roles?: string[]
    // 需要的权限
    permissions?: string[]
    // 权限检查模式：and（需要所有权限）或 or（只需要任一权限）
    permissionMode?: 'and' | 'or'
    // 是否需要管理员权限
    requiresAdmin?: boolean
    // 页面标题
    title?: string
    // 页面描述
    description?: string
    // 是否在菜单中显示
    showInMenu?: boolean
    // 菜单图标
    icon?: string
    // 菜单顺序
    order?: number
  }
}

/**
 * 使用示例：
 * 
 * // 在页面组件中定义路由元信息
 * definePageMeta({
 *   middleware: ['auth'],
 *   meta: {
 *     requiresAuth: true,
 *     roles: ['admin', 'manager'],
 *     permissions: ['user:read', 'user:write'],
 *     permissionMode: 'and',
 *     title: '用户管理',
 *     icon: 'user'
 *   }
 * })
 * 
 * // 或在nuxt.config.ts中配置全局中间件
 * export default defineNuxtConfig({
 *   router: {
 *     middleware: ['auth']
 *   }
 * })
 */