<template>
  <NConfigProvider :theme="naiveTheme" :key="themeMode">
    <NLoadingBarProvider>
      <NMessageProvider>
        <NNotificationProvider>
          <NDialogProvider>
            <!-- 主布局容器 -->
            <NLayout class="app-layout" has-sider>
              <!-- 侧边栏 -->
              <AppSidebar :collapsed="sidebarCollapsed" @toggle="sidebarCollapsed = !sidebarCollapsed" />
              
              <!-- 主内容区域 -->
              <NLayout>
                <!-- 头部 -->
                <AppHeader 
                  :sidebar-collapsed="sidebarCollapsed" 
                  @toggle-sidebar="sidebarCollapsed = !sidebarCollapsed" 
                  @logout="handleLogout"
                />
                
                <!-- 面包屑导航（可选） -->
                <NBreadcrumb v-if="showBreadcrumb" class="layout-breadcrumb">
                  <NBreadcrumbItem v-for="(item, index) in breadcrumbItems" :key="index">
                    <NuxtLink v-if="item.path" :to="item.path">{{ item.title }}</NuxtLink>
                    <template v-else>{{ item.title }}</template>
                  </NBreadcrumbItem>
                </NBreadcrumb>
                
                <!-- 主要内容区域 -->
                <NLayoutContent class="layout-content">
                  <!-- 页面内容 -->
                  <slot />
                </NLayoutContent>
                
                <!-- 页脚 -->
                <AppFooter />
              </NLayout>
            </NLayout>
          </NDialogProvider>
        </NNotificationProvider>
      </NMessageProvider>
    </NLoadingBarProvider>
  </NConfigProvider>
</template>

<script setup lang="ts">
import { NConfigProvider, NLayout, NLayoutContent, NLayoutSider, NBreadcrumb, NBreadcrumbItem } from 'naive-ui'
import { ref, computed, watch, onMounted, provide } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { useRoute } from '#vue-router'
import { useThemeState } from '@/composables/useThemeState'

// 组件
import AppHeader from '@/components/common/AppHeader.vue'
import AppSidebar from '@/components/common/AppSidebar.vue'
import AppFooter from '@/components/common/AppFooter.vue'

// 状态管理
const authStore = useAuthStore()
const route = useRoute()
const colorScheme = usePreferredColorScheme()

// 禁用浏览器缓存，确保开发修改能立即生效
useHead({
  meta: [
    { name: 'cache-control', content: 'no-cache, no-store, must-revalidate' },
    { name: 'pragma', content: 'no-cache' },
    { name: 'expires', content: '0' }
  ]
})

// 响应式状态
const sidebarCollapsed = ref(false)
const showBreadcrumb = ref(true)
const breadcrumbItems = ref<Array<{ title: string; path?: string }>>([])

const { themeMode, naiveTheme, initThemeMode } = useThemeState()

const showSidebar = computed(() => {
  // 登录页面等不需要侧边栏
  const noSidebarRoutes = ['/login', '/register', '/403', '/404', '/500']
  return !noSidebarRoutes.includes(route.path)
})

// 方法
const handleLogout = async () => {
  try {
    await authStore.logout()
    // 登出后跳转到登录页
    await navigateTo('/login')
  } catch (error) {
    console.error('登出失败:', error)
  }
}

// 生命周期
onMounted(() => {
  // 初始化主题
  initThemeMode()

  // 初始化面包屑
  updateBreadcrumb()
  
  // 监听路由变化更新面包屑
  watch(() => route.path, () => {
    updateBreadcrumb()
  })
})

// 更新面包屑
const updateBreadcrumb = () => {
  const matched = route.matched
  breadcrumbItems.value = matched.map(item => ({
    title: item.meta?.title || item.name || '未命名',
    path: item.path
  }))
}

// 提供全局方法给子组件使用
provide('toggleSidebar', () => {
  sidebarCollapsed.value = !sidebarCollapsed.value
})

provide('getSidebarState', () => ({
  collapsed: sidebarCollapsed.value,
  width: sidebarCollapsed.value ? 64 : 256
}))
</script>

<style scoped>
.app-layout {
  height: 100vh;
  overflow: hidden;
}

.layout-breadcrumb {
  padding: 12px 24px;
  background-color: var(--background-color-light);
  border-bottom: 1px solid var(--border-color-split);
}

.layout-content {
  padding: 24px;
  background-color: var(--background-color);
  min-height: calc(100vh - 140px); /* 减去头部和页脚高度 */
  overflow-y: auto;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .layout-breadcrumb {
    padding: 8px 16px;
  }
  
  .layout-content {
    padding: 16px;
    min-height: calc(100vh - 120px);
  }
}

@media (max-width: 576px) {
  .layout-content {
    padding: 12px;
    min-height: calc(100vh - 100px);
  }
}
</style>