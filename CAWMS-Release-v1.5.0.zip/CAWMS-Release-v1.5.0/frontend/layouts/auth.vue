<template>
  <NConfigProvider :theme="naiveTheme" :key="themeMode">
    <NLoadingBarProvider>
      <NMessageProvider>
        <NNotificationProvider>
          <NDialogProvider>
            <!-- 认证布局容器 -->
            <div class="auth-layout">
              <!-- 背景装饰 -->
              <div class="auth-background">
                <div class="auth-background-pattern"></div>
                <div class="auth-background-overlay"></div>
              </div>
              
              <!-- 主内容区域 -->
              <div class="auth-container">
                <!-- 左侧品牌区域（桌面端显示） -->
                <div class="auth-brand-section">
                  <div class="auth-brand-content">
                    <!-- 品牌Logo -->
                    <div class="auth-brand-logo">
                      <div class="logo-icon">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="currentColor"/>
                          <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2"/>
                          <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2"/>
                        </svg>
                      </div>
                      <h1 class="brand-title">CAWMS</h1>
                      <p class="brand-subtitle">抵押资产管理系统</p>
                    </div>
                    
                    <!-- 品牌描述 -->
                    <div class="auth-brand-description">
                      <h2>安全 · 高效 · 智能</h2>
                      <p>专业的银行抵押资产全生命周期管理系统，助力风险管理与资产优化</p>
                    </div>
                    
                    <!-- 功能特性列表 -->
                    <div class="auth-features">
                      <div class="feature-item">
                        <div class="feature-icon">
                          <NIcon><LockClosedOutline /></NIcon>
                        </div>
                        <div class="feature-text">
                          <h4>银行级安全</h4>
                          <p>多重加密与权限控制</p>
                        </div>
                      </div>
                      <div class="feature-item">
                        <div class="feature-icon">
                          <NIcon><AnalyticsOutline /></NIcon>
                        </div>
                        <div class="feature-text">
                          <h4>实时监控</h4>
                          <p>资产状态实时跟踪</p>
                        </div>
                      </div>
                      <div class="feature-item">
                        <div class="feature-icon">
                          <NIcon><DocumentTextOutline /></NIcon>
                        </div>
                        <div class="feature-text">
                          <h4>智能报表</h4>
                          <p>自动生成分析报告</p>
                        </div>
                      </div>
                    </div>
                    
                    <!-- 底部信息 -->
                    <div class="auth-brand-footer">
                      <p>© 2026 CAWMS. 版权所有</p>
                      <p>版本: {{ appVersion }}</p>
                    </div>
                  </div>
                </div>
                
                <!-- 右侧表单区域 -->
                <div class="auth-form-section">
                  <div class="auth-form-container">
                    <!-- 移动端品牌显示 -->
                    <div class="auth-mobile-brand">
                      <div class="mobile-logo">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="currentColor"/>
                        </svg>
                      </div>
                      <h2>CAWMS</h2>
                    </div>
                    
                    <!-- 页面内容 -->
                    <div class="auth-form-content">
                      <slot />
                    </div>
                    
                    <!-- 底部链接 -->
                    <div class="auth-form-footer">
                      <div class="footer-links">
                        <NuxtLink to="/">返回首页</NuxtLink>
                        <span class="divider">|</span>
                        <NuxtLink to="/help">帮助中心</NuxtLink>
                        <span class="divider">|</span>
                        <NuxtLink to="/contact">联系我们</NuxtLink>
                      </div>
                      <p class="footer-copyright">© 2026 CAWMS. 版本 {{ appVersion }}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </NDialogProvider>
        </NNotificationProvider>
      </NMessageProvider>
    </NLoadingBarProvider>
  </NConfigProvider>
</template>

<script setup lang="ts">
import { NConfigProvider, NLoadingBarProvider, NMessageProvider, NNotificationProvider, NDialogProvider, NIcon } from 'naive-ui'
import { LockClosedOutline, AnalyticsOutline, DocumentTextOutline } from '@vicons/ionicons5'
import { useAuthStore } from '@/stores/auth'
import { useThemeState } from '@/composables/useThemeState'

// 状态管理
const authStore = useAuthStore()
const colorScheme = usePreferredColorScheme()

// 应用版本
const appVersion = ref(process.env.APP_VERSION || '1.0.0')

const { themeMode, naiveTheme, initThemeMode } = useThemeState()

onMounted(() => {
  initThemeMode()
})

// 提供全局方法
provide('appVersion', appVersion)
</script>

<style scoped>
.auth-layout {
  height: 100vh;
  width: 100vw;
  position: relative;
  overflow: hidden;
}

.auth-background {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 0;
}

.auth-background-pattern {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image: 
    radial-gradient(circle at 25% 25%, rgba(24, 144, 255, 0.1) 0%, transparent 50%),
    radial-gradient(circle at 75% 75%, rgba(82, 196, 26, 0.1) 0%, transparent 50%);
  background-size: 400px 400px;
  background-position: 0 0, 200px 200px;
}

:global(html[data-theme="dark"]) .auth-background-pattern {
  background-image: 
    radial-gradient(circle at 25% 25%, rgba(0, 212, 255, 0.12) 0%, transparent 50%),
    radial-gradient(circle at 75% 75%, rgba(68, 138, 255, 0.08) 0%, transparent 50%);
}

.auth-background-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(245, 245, 245, 0.98) 100%);
}

:global(html[data-theme="dark"]) .auth-background-overlay {
  background: linear-gradient(135deg, rgba(10, 14, 39, 0.98) 0%, rgba(7, 10, 26, 0.99) 100%);
}

.auth-container {
  position: relative;
  z-index: 1;
  display: flex;
  height: 100%;
  max-width: 1400px;
  margin: 0 auto;
}

.auth-brand-section {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px;
  background: linear-gradient(135deg, rgba(24, 144, 255, 0.9) 0%, rgba(64, 169, 255, 0.9) 100%);
  color: white;
}

:global(html[data-theme="dark"]) .auth-brand-section {
  background: linear-gradient(135deg, #0c112e 0%, #111936 100%);
  color: var(--text-color);
}

.auth-brand-content {
  max-width: 480px;
  width: 100%;
}

.auth-brand-logo {
  margin-bottom: 48px;
}

.logo-icon {
  width: 64px;
  height: 64px;
  color: white;
  margin-bottom: 16px;
}

:global(html[data-theme="dark"]) .logo-icon {
  color: var(--primary-color);
}

.brand-title {
  font-size: 32px;
  font-weight: 700;
  margin: 0 0 8px 0;
  color: white;
}

:global(html[data-theme="dark"]) .brand-title {
  color: var(--text-color);
}

.brand-subtitle {
  font-size: 16px;
  opacity: 0.9;
  margin: 0;
  color: white;
}

:global(html[data-theme="dark"]) .brand-subtitle {
  color: var(--text-color-secondary);
}

.auth-brand-description {
  margin-bottom: 48px;
}

.auth-brand-description h2 {
  font-size: 24px;
  font-weight: 600;
  margin: 0 0 12px 0;
  color: white;
}

:global(html[data-theme="dark"]) .auth-brand-description h2 {
  color: var(--text-color);
}

.auth-brand-description p {
  font-size: 16px;
  line-height: 1.6;
  opacity: 0.9;
  color: white;
}

:global(html[data-theme="dark"]) .auth-brand-description p {
  color: var(--text-color-secondary);
}

.auth-features {
  margin-bottom: 48px;
}

.feature-item {
  display: flex;
  align-items: center;
  margin-bottom: 24px;
}

.feature-icon {
  width: 40px;
  height: 40px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
  color: white;
}

:global(html[data-theme="dark"]) .feature-icon {
  background: rgba(0, 212, 255, 0.15);
  color: var(--primary-color);
}

.feature-text h4 {
  margin: 0 0 4px 0;
  font-size: 16px;
  font-weight: 600;
  color: white;
}

:global(html[data-theme="dark"]) .feature-text h4 {
  color: var(--text-color);
}

.feature-text p {
  margin: 0;
  font-size: 14px;
  opacity: 0.8;
  color: white;
}

:global(html[data-theme="dark"]) .feature-text p {
  color: var(--text-color-secondary);
}

.auth-brand-footer {
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding-top: 24px;
  font-size: 14px;
  opacity: 0.8;
  color: white;
}

:global(html[data-theme="dark"]) .auth-brand-footer {
  border-top-color: var(--border-color);
  color: var(--text-color-secondary);
}

.auth-form-section {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px;
  background: var(--background-color-light);
}

.auth-form-container {
  max-width: 400px;
  width: 100%;
}

.auth-mobile-brand {
  display: none;
  text-align: center;
  margin-bottom: 32px;
}

.mobile-logo {
  width: 48px;
  height: 48px;
  color: var(--primary-color);
  margin: 0 auto 12px;
}

.auth-mobile-brand h2 {
  font-size: 24px;
  font-weight: 600;
  margin: 0;
  color: var(--text-color);
}

.auth-form-content {
  background: var(--background-color-light);
  border-radius: 16px;
  padding: 32px;
  box-shadow: var(--box-shadow-light);
}

:global(html[data-theme="dark"]) .auth-form-content {
  border: 1px solid var(--border-color);
}

.auth-form-footer {
  margin-top: 24px;
  text-align: center;
  color: var(--text-color-secondary);
}

.footer-links {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 8px;
  gap: 12px;
}

.footer-links a {
  color: var(--text-color-secondary);
  text-decoration: none;
  font-size: 14px;
  transition: color 0.3s;
}

.footer-links a:hover {
  color: var(--primary-color);
}

.divider {
  color: var(--border-color);
}

.footer-copyright {
  font-size: 12px;
  margin: 0;
  opacity: 0.7;
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .auth-brand-section {
    display: none;
  }
  
  .auth-form-section {
    padding: 24px;
  }
  
  .auth-form-content {
    padding: 24px;
  }
  
  .auth-mobile-brand {
    display: block;
  }
}

@media (max-width: 576px) {
  .auth-container {
    padding: 16px;
  }
  
  .auth-form-section {
    padding: 16px;
  }
  
  .auth-form-content {
    padding: 20px;
    border-radius: 12px;
  }
  
  .footer-links {
    flex-wrap: wrap;
    gap: 8px;
  }
}
</style>