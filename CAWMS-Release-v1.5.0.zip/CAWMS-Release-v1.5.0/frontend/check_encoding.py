#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检查SQL文件编码
"""

import os
import chardet

def check_file_encoding(file_path):
    """检查文件编码"""
    print(f"检查文件: {file_path}")
    print(f"文件大小: {os.path.getsize(file_path)} 字节")
    
    # 读取文件二进制内容
    with open(file_path, 'rb') as f:
        raw_data = f.read()
    
    # 检测编码
    result = chardet.detect(raw_data[:10000])  # 只检查前10000字节
    print(f"检测到的编码: {result['encoding']} (置信度: {result['confidence']:.2%})")
    
    # 尝试用不同编码解码
    encodings = ['utf-8', 'gbk', 'gb2312', 'latin-1', 'utf-16']
    
    for enc in encodings:
        try:
            decoded = raw_data[:500].decode(enc)
            print(f"\n{enc} 解码成功 (前500字符):")
            print("-" * 40)
            print(decoded)
            print("-" * 40)
            break
        except UnicodeDecodeError as e:
            print(f"{enc} 解码失败: {e}")
    
    return result['encoding']

if __name__ == '__main__':
    file_path = r'D:\frontend\init_v2.sql'
    if os.path.exists(file_path):
        encoding = check_file_encoding(file_path)
        print(f"\n建议使用编码: {encoding}")
    else:
        print(f"文件不存在: {file_path}")