#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成从旧版本升级到新版本的SQL脚本
"""

import re
import subprocess
import sys

def run_mysql_query(query):
    """执行MySQL查询并返回结果"""
    cmd = ['mysql', '-u', 'root', '-pG-;fnxjV4Ck(', '-D', 'cawms', '-e', query]
    result = subprocess.run(cmd, capture_output=True, text=True, shell=True)
    return result.stdout.strip()

def get_table_info():
    """获取所有表的详细信息"""
    tables = {}
    
    # 获取所有表名
    output = run_mysql_query('SHOW TABLES')
    table_names = [line.strip() for line in output.split('\n')[1:] if line.strip()]
    
    for table in table_names:
        # 获取表结构
        create_output = run_mysql_query(f'SHOW CREATE TABLE `{table}`')
        lines = create_output.split('\n')
        if len(lines) > 1:
            create_stmt = lines[1]  # 第二行是CREATE语句
            
            # 解析列定义
            match = re.search(r'CREATE TABLE `[^`]+`\s*\((.*?)\)[^)]*$', create_stmt, re.DOTALL)
            if match:
                table_def = match.group(1)
                columns = parse_columns(table_def)
                tables[table] = {
                    'create_stmt': create_stmt,
                    'columns': columns,
                    'definition': table_def
                }
    
    return tables

def parse_columns(table_def):
    """解析列定义"""
    columns = {}
    
    # 分割成行
    lines = [line.strip() for line in table_def.split('\n')]
    
    current_col = ''
    col_lines = []
    
    for line in lines:
        if not line:
            continue
        
        # 如果是新列的开始（以`开头）
        if line.startswith('`'):
            # 保存上一个列
            if current_col and col_lines:
                col_def = ' '.join(col_lines)
                columns[current_col] = col_def
            
            # 开始新列
            match = re.match(r'`([^`]+)`', line)
            if match:
                current_col = match.group(1)
                col_lines = [line]
            else:
                current_col = ''
                col_lines = []
        elif current_col:
            # 继续当前列的定义
            col_lines.append(line)
        elif line.startswith('PRIMARY KEY') or line.startswith('KEY') or line.startswith('INDEX') or line.startswith('UNIQUE') or line.startswith('FOREIGN'):
            # 跳过约束和索引
            pass
    
    # 保存最后一个列
    if current_col and col_lines:
        col_def = ' '.join(col_lines)
        columns[current_col] = col_def
    
    return columns

def parse_old_schema(old_file):
    """解析旧版本SQL文件"""
    with open(old_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    tables = {}
    
    # 提取CREATE TABLE语句
    pattern = r'CREATE TABLE IF NOT EXISTS (\w+)\s*\(([^;]+?)\)[^)]*?ENGINE=(\w+)'
    matches = re.findall(pattern, content, re.DOTALL | re.IGNORECASE)
    
    for match in matches:
        table_name = match[0]
        table_def = match[1].strip()
        engine = match[2]
        
        columns = parse_columns(table_def)
        
        tables[table_name] = {
            'columns': columns,
            'engine': engine,
            'definition': table_def
        }
    
    return tables

def generate_upgrade_script(old_schema, new_schema):
    """生成升级脚本"""
    script_lines = []
    
    script_lines.append("-- ============================================")
    script_lines.append("-- CAWMS数据库升级脚本")
    script_lines.append("-- 从旧版本升级到最新版本")
    script_lines.append("-- 生成时间: 2026-04-21")
    script_lines.append("-- ============================================")
    script_lines.append("")
    script_lines.append("USE cawms;")
    script_lines.append("")
    
    old_tables = set(old_schema.keys())
    new_tables = set(new_schema.keys())
    
    # 1. 新增的表
    added_tables = new_tables - old_tables
    if added_tables:
        script_lines.append("-- 1. 创建新表")
        script_lines.append("-- ============================================")
        
        for table in sorted(added_tables):
            create_stmt = new_schema[table]['create_stmt']
            # 替换IF NOT EXISTS
            create_stmt = re.sub(r'CREATE TABLE', 'CREATE TABLE IF NOT EXISTS', create_stmt)
            script_lines.append(create_stmt + ";")
            script_lines.append("")
    
    # 2. 修改现有表
    common_tables = old_tables & new_tables
    if common_tables:
        script_lines.append("-- 2. 修改现有表结构")
        script_lines.append("-- ============================================")
        
        for table in sorted(common_tables):
            old_cols = old_schema[table]['columns']
            new_cols = new_schema[table]['columns']
            
            added_columns = set(new_cols.keys()) - set(old_cols.keys())
            removed_columns = set(old_cols.keys()) - set(new_cols.keys())
            
            # 检查列定义是否改变
            changed_columns = []
            common_cols = set(old_cols.keys()) & set(new_cols.keys())
            for col in common_cols:
                if old_cols[col] != new_cols[col]:
                    changed_columns.append(col)
            
            if added_columns or removed_columns or changed_columns:
                script_lines.append(f"-- 表: {table}")
                
                # 新增列
                for col in sorted(added_columns):
                    col_def = new_cols[col]
                    script_lines.append(f"ALTER TABLE `{table}` ADD COLUMN {col_def};")
                
                # 列定义改变（需要先删除再添加，或者修改）
                for col in changed_columns:
                    old_def = old_cols[col]
                    new_def = new_cols[col]
                    script_lines.append(f"-- 列 '{col}' 定义已改变")
                    script_lines.append(f"-- 旧定义: {old_def}")
                    script_lines.append(f"-- 新定义: {new_def}")
                    # 使用MODIFY COLUMN
                    script_lines.append(f"ALTER TABLE `{table}` MODIFY COLUMN {new_def};")
                
                # 删除列（谨慎操作）
                if removed_columns:
                    script_lines.append("-- 注意：以下列将被删除，请确认数据已备份")
                    for col in sorted(removed_columns):
                        script_lines.append(f"-- ALTER TABLE `{table}` DROP COLUMN `{col}`;")
                
                script_lines.append("")
    
    # 3. 新增的视图、存储过程等
    script_lines.append("-- 3. 其他对象（视图、存储过程、函数）")
    script_lines.append("-- ============================================")
    script_lines.append("-- 注：以下对象需要从当前数据库导出")
    script_lines.append("")
    
    # 检查是否有视图
    output = run_mysql_query("SHOW FULL TABLES WHERE Table_type = 'VIEW'")
    views = [line.split('\t')[0] for line in output.split('\n')[1:] if line.strip()]
    if views:
        script_lines.append("-- 视图:")
        for view in views:
            script_lines.append(f"-- {view}")
        script_lines.append("")
    
    # 检查存储过程和函数
    output = run_mysql_query("SHOW PROCEDURE STATUS WHERE Db = 'cawms'")
    procedures = [line.split('\t')[1] for line in output.split('\n')[1:] if line.strip()]
    if procedures:
        script_lines.append("-- 存储过程:")
        for proc in procedures:
            script_lines.append(f"-- {proc}")
        script_lines.append("")
    
    output = run_mysql_query("SHOW FUNCTION STATUS WHERE Db = 'cawms'")
    functions = [line.split('\t')[1] for line in output.split('\n')[1:] if line.strip()]
    if functions:
        script_lines.append("-- 函数:")
        for func in functions:
            script_lines.append(f"-- {func}")
        script_lines.append("")
    
    script_lines.append("-- ============================================")
    script_lines.append("-- 升级脚本生成完成")
    script_lines.append("-- 请仔细审查后执行，建议先在测试环境验证")
    script_lines.append("-- ============================================")
    
    return "\n".join(script_lines)

def main():
    if len(sys.argv) != 3:
        print("用法: python generate_upgrade_script.py <旧版本SQL> <输出升级脚本>")
        sys.exit(1)
    
    old_file = sys.argv[1]
    output_file = sys.argv[2]
    
    print("获取当前数据库结构...")
    new_schema = get_table_info()
    print(f"当前数据库有 {len(new_schema)} 个表")
    
    print("解析旧版本SQL文件...")
    old_schema = parse_old_schema(old_file)
    print(f"旧版本有 {len(old_schema)} 个表")
    
    print("生成升级脚本...")
    upgrade_script = generate_upgrade_script(old_schema, new_schema)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(upgrade_script)
    
    print(f"升级脚本已生成: {output_file}")
    
    # 统计信息
    old_tables = set(old_schema.keys())
    new_tables = set(new_schema.keys())
    
    print(f"\n统计:")
    print(f"  新增表: {len(new_tables - old_tables)} 个")
    print(f"  共同表: {len(old_tables & new_tables)} 个")
    print(f"  删除表: {len(old_tables - new_tables)} 个（理论上应为0）")

if __name__ == '__main__':
    main()