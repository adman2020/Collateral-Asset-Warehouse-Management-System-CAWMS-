import path from 'path'

// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',
  devtools: { enabled: true },
  
  // 模块
  modules: [
    '@pinia/nuxt',
    '@vueuse/nuxt',
    '@nuxtjs/i18n'
  ],

  i18n: {
    strategy: 'no_prefix',
    defaultLocale: 'zh',
    locales: [
      { code: 'zh', name: '中文', file: 'zh.json' },
      { code: 'vi', name: 'Tiếng Việt', file: 'vi.json' },
      { code: 'en', name: 'English', file: 'en.json' }
    ],
    lazy: true,
    langDir: 'locales/',
    detectBrowserLanguage: false,
    vueI18n: './i18n.config.ts',
    restructureDir: false
  },
  
  // 插件
  plugins: [
    '@/plugins/naive-ui.client',
    '@/plugins/axios.client'
  ],
  
  // Pinia配置
  pinia: {
    autoImports: [
      'defineStore',
      'storeToRefs'
    ]
  },
  
  // 自动导入
  imports: {
    dirs: [
      'stores',
      'composables',
      'composables/**',
      'utils',
      'types'
    ]
  },
  
  // CSS配置
  css: [
    '@/assets/styles/main.css'
  ],
  
  // Vite配置
  vite: {
    resolve: {
      alias: {
        '@': path.resolve('./')
      }
    },
    server: {
      headers: {
        'Cache-Control': 'no-store, max-age=0, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    },
    optimizeDeps: {
      include: ['naive-ui', 'vueuc', 'axios', '@vicons/ionicons5']
    },
    css: {
      preprocessorOptions: {
        scss: {
          additionalData: '@import "@/assets/styles/variables.scss";'
        }
      }
    }
  },
  
  // 路径别名
  alias: {
    '@': './',
    '@components': './components',
    '@pages': './pages',
    '@stores': './stores',
    '@utils': './utils',
    '@assets': './assets',
    '@plugins': './plugins',
    '@types': './types',
    '@middleware': './middleware'
  },
  
  // TypeScript配置
  typescript: {
    strict: true,
    typeCheck: false
  },
  
  // 运行时配置（环境变量）
  runtimeConfig: {
    public: {
      apiBaseUrl: process.env.API_BASE_URL || 'http://localhost:8080',
      apiTimeout: parseInt(process.env.API_TIMEOUT || '10000'),
      appName: process.env.APP_NAME || 'CAWMS',
      appVersion: process.env.APP_VERSION || '1.0.0',
      appEnv: process.env.APP_ENV || 'development',
      featureAnalytics: process.env.FEATURE_ANALYTICS === 'true',
      featureDebug: process.env.FEATURE_DEBUG === 'true'
    }
  },
  
  // 构建配置
  build: {
    transpile: process.env.NODE_ENV === 'production' ? ['naive-ui'] : []
  },
  
  // 安全配置
  security: {
    headers: {
      contentSecurityPolicy: {
        'script-src': ["'self'", "'unsafe-inline'"],
        'style-src': ["'self'", "'unsafe-inline'"]
      }
    }
  },
  
  // SSR配置
  ssr: false,
  
  // 源目录配置
  srcDir: './',
  
  // 构建目录
  buildDir: '.nuxt',
  
  // 生成配置（静态站点）
  generate: {
    routes: ['/', '/login', '/register', '/dashboard']
  },

  hooks: {
    'pages:extend': (pages) => {
      pages.push(
        { name: 'reports-inbound', path: '/reports/inbound', file: path.resolve('pages/reports/inbound.vue') },
        { name: 'reports-loan-out', path: '/reports/loan-out', file: path.resolve('pages/reports/loan-out.vue') },
        { name: 'reports-overdue', path: '/reports/overdue', file: path.resolve('pages/reports/overdue.vue') },
        { name: 'reports-financial', path: '/reports/financial', file: path.resolve('pages/reports/financial.vue') },
        { name: 'reports-dashboard', path: '/reports/dashboard', file: path.resolve('pages/reports/dashboard.vue') },
        { name: 'transfer-index', path: '/transfer', file: path.resolve('pages/transfer/index.vue') },
        { name: 'transfer-create', path: '/transfer/create', file: path.resolve('pages/transfer/create.vue') },
        { name: 'transfer-approval', path: '/transfer/approval', file: path.resolve('pages/transfer/approval.vue') },
        { name: 'transfer-detail', path: '/transfer/:id', file: path.resolve('pages/transfer/[id].vue') },
        { name: 'warehouse-out-index', path: '/warehouse-out', file: path.resolve('pages/warehouse-out/index.vue') },
        { name: 'warehouse-out-create', path: '/warehouse-out/create', file: path.resolve('pages/warehouse-out/create.vue') },
        { name: 'warehouse-out-approval', path: '/warehouse-out/approval', file: path.resolve('pages/warehouse-out/approval.vue') },
        { name: 'warehouse-out-detail', path: '/warehouse-out/:id', file: path.resolve('pages/warehouse-out/[id].vue') },
        { name: 'workflow-approvals', path: '/workflow/approvals', file: path.resolve('pages/workflow/approvals.vue') }
      )
    }
  }
})
