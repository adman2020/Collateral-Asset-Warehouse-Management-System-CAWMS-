#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
移除SQL文件中的COMMENT注释
"""

import re
import sys

def remove_comments(input_file, output_file):
    # 读取文件，尝试多种编码
    content = None
    for encoding in ['utf-8-sig', 'utf-8', 'gbk', 'latin-1']:
        try:
            with open(input_file, 'r', encoding=encoding) as f:
                content = f.read()
            print(f"使用编码 {encoding} 成功读取文件")
            break
        except UnicodeDecodeError:
            continue
    
    if content is None:
        raise ValueError(f"无法解码文件 {input_file}")
    
    # 移除 COMMENT '...'（包括前面的空格）
    # 使用非贪婪匹配
    pattern = r'\s+COMMENT\s+\'[^\']*\''
    new_content = re.sub(pattern, '', content)
    
    # 移除 TABLE_COMMENT='...'
    table_pattern = r'\s+TABLE_COMMENT\s*=\s*\'[^\']*\''
    new_content = re.sub(table_pattern, '', new_content)
    
    # 写入文件，使用UTF-8 without BOM
    with open(output_file, 'w', encoding='utf-8', newline='\n') as f:
        f.write(new_content)
    
    print(f"注释移除完成，输出文件: {output_file}")
    print(f"原始文件大小: {len(content)} 字节")
    print(f"处理后大小: {len(new_content)} 字节")

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("用法: python remove_comments.py <输入文件> <输出文件>")
        sys.exit(1)
    
    remove_comments(sys.argv[1], sys.argv[2])