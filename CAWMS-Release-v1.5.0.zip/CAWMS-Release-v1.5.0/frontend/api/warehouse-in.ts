import request from '@/utils/request'

/**
 * 抵押资产入库管理API（对齐后端领域模型）
 */

// ==================== 类型定义 ====================

export interface WarehouseInItem {
  id: string | number
  whCode?: string
  buCode: string
  buName?: string
  customerId?: string
  customerName: string
  collateralType: string
  collateralValue: number
  creditAgreementNo?: string
  intakeType: string
  status: string
  currentStep?: number
  dataSource?: string
  remarks?: string
  createdBy?: string
  updatedBy?: string
  submittedAt?: string
  reviewedAt?: string
  completedAt?: string
  createdAt?: string
  updatedAt?: string
  version?: number
}

export interface AttachmentFile {
  id: number
  fileName: string
  filePath: string
  fileSize: number
  fileHash?: string
  mimeType?: string
  uploadUser?: string
  uploadTime?: string
  status?: string
}

export interface WarehouseInDetail {
  warehouseIn: WarehouseInItem
  files: AttachmentFile[]
  approvals: any[]
  additionalInfo?: Record<string, any>
}

export interface WarehouseInCreateParams {
  buCode: string
  buName?: string
  customerId?: string
  customerName: string
  collateralType: string
  collateralValue: number
  creditAgreementNo?: string
  intakeType: string
  remarks?: string
  uploader: string
  files?: File[]
}

export interface WarehouseInUpdateParams {
  whCode?: string
  buCode: string
  buName?: string
  customerId?: string
  customerName: string
  collateralType: string
  collateralValue: number
  creditAgreementNo?: string
  intakeType: string
  remarks?: string
  updater: string
  files?: File[]
}

export interface WarehouseInFilterParams {
  buCode?: string
  customerId?: string
  customerName?: string
  collateralType?: string
  intakeType?: string
  status?: string
  currentStep?: number
  startTime?: string
  endTime?: string
  keyword?: string
  pageNum?: number
  pageSize?: number
}

export interface WarehouseInPageResult {
  records: WarehouseInItem[]
  total: number
  size: number
  current: number
  pages: number
}

export interface WarehouseInStats {
  totalDrafts?: number
  totalSubmitted?: number
  totalInReview?: number
  totalApproved?: number
  totalRejected?: number
  totalCompleted?: number
  totalCount?: number
  byCollateralType?: Record<string, number>
  byIntakeType?: Record<string, number>
  byStatus?: Record<string, number>
  byBuCode?: Record<string, number>
}

export interface ApprovalRequest {
  approverUser: string
  approverRole?: string
  approverName?: string
  comments?: string
  autoApproved?: boolean
}

export interface ApprovalResult {
  success: boolean
  message?: string
  updatedWarehouseIn?: WarehouseInItem
  nextStep?: number
  nextApproverRole?: string
}

export interface RejectionRequest {
  approverUser: string
  approverRole?: string
  approverName?: string
  reason?: string
  comments?: string
}

export interface ReturnRequest {
  approverUser: string
  approverRole?: string
  approverName?: string
  reason?: string
  comments?: string
  returnToStep?: number
}

export interface PendingApproval {
  id: number
  whCode?: string
  customerName?: string
  collateralType?: string
  collateralValue?: number
  currentStep?: number
  stepName?: string
  approverRole?: string
  submittedAt?: string
}

export interface HistoryRecord {
  id: number
  warehouseInId: number
  action: string
  operator: string
  operatedAt: string
  comment?: string
  // 后端实际返回字段
  timestamp?: string
  user?: string
  description?: string
  userRole?: string
  details?: Record<string, any>
}

export interface ValidationResult {
  valid: boolean
  message?: string
  errors?: string[]
}

// ==================== API 函数 ====================

const warehouseInApi = {
  /**
   * 获取入库列表（分页）
   */
  getList(params: WarehouseInFilterParams): Promise<WarehouseInPageResult> {
    return request.get('/api/warehouse-in/list', { params })
  },

  /**
   * 获取入库详情
   */
  getDetail(id: string | number): Promise<WarehouseInDetail> {
    return request.get(`/api/warehouse-in/${id}`)
  },

  /**
   * 按入库编码查询
   */
  getByWhCode(whCode: string): Promise<WarehouseInDetail> {
    return request.get(`/api/warehouse-in/by-wh-code/${whCode}`)
  },

  /**
   * 下载附件
   */
  downloadFile(fileId: number): string {
    return `/api/warehouse-in/files/${fileId}`
  },

  /**
   * 创建草稿
   */
  createDraft(params: WarehouseInCreateParams): Promise<string | number> {
    const formData = new FormData()
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && key !== 'files') {
        formData.append(key, String(value))
      }
    })
    if (params.files) {
      params.files.forEach(file => formData.append('files', file))
    }
    return request.post('/api/warehouse-in/draft', formData)
  },

  /**
   * 更新申请
   */
  update(id: string | number, params: WarehouseInUpdateParams): Promise<void> {
    const formData = new FormData()
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && key !== 'files') {
        formData.append(key, String(value))
      }
    })
    if (params.files) {
      params.files.forEach(file => formData.append('files', file))
    }
    return request.put(`/api/warehouse-in/${id}`, formData)
  },

  /**
   * 删除申请
   */
  delete(id: string | number): Promise<void> {
    return request.delete(`/api/warehouse-in/${id}`)
  },

  /**
   * 提交申请
   */
  submit(id: string | number, submitter: string): Promise<void> {
    return request.put(`/api/warehouse-in/${id}/submit`, null, {
      params: { submitter }
    })
  },

  /**
   * 审批通过
   */
  approve(id: string | number, stepNumber: number, data: ApprovalRequest): Promise<ApprovalResult> {
    return request.post(`/api/warehouse-in/${id}/approve`, data, {
      params: { stepNumber }
    })
  },

  /**
   * 拒绝申请
   */
  reject(id: string | number, stepNumber: number, data: RejectionRequest): Promise<void> {
    return request.post(`/api/warehouse-in/${id}/reject`, data, {
      params: { stepNumber }
    })
  },

  /**
   * 退回申请
   */
  returnApplication(id: string | number, stepNumber: number, data: ReturnRequest): Promise<void> {
    return request.post(`/api/warehouse-in/${id}/return`, data, {
      params: { stepNumber }
    })
  },

  /**
   * 获取待审批列表
   */
  getPendingApprovals(params: {
    approverRole?: string
    approverUser?: string
    pageNum?: number
    pageSize?: number
  }): Promise<WarehouseInPageResult> {
    return request.get('/api/warehouse-in/pending-approvals', { params })
  },

  /**
   * 获取我的审批列表（待我审批 / 我已审批 / 审批记录）
   */
  getMyApprovals(params: {
    type: 'pending' | 'ongoing' | 'history'
    approverUser?: string
    approverRole?: string
    pageNum?: number
    pageSize?: number
  }): Promise<WarehouseInPageResult> {
    return request.get('/api/warehouse-in/my-approvals', { params })
  },

  /**
   * 获取统计信息
   */
  getStatistics(params?: {
    startTime?: string
    endTime?: string
    buCode?: string
    collateralType?: string
    intakeType?: string
  }): Promise<WarehouseInStats> {
    return request.get('/api/warehouse-in/statistics', { params })
  },

  /**
   * 生成入库单
   */
  generateSlip(id: string | number, generator: string): Promise<Record<string, any>> {
    return request.post(`/api/warehouse-in/${id}/generate-slip`, null, {
      params: { generator }
    })
  },

  /**
   * 导出数据
   */
  exportData(params: {
    filter?: WarehouseInFilterParams
    columns?: string[]
    exportFormat?: string
    includeFiles?: boolean
    includeApprovals?: boolean
  }): Promise<Blob> {
    return request.post('/api/warehouse-in/export', params, { responseType: 'blob' })
  },

  /**
   * 导入数据
   */
  importData(data: WarehouseInItem[], importer: string): Promise<any> {
    return request.post('/api/warehouse-in/import', data, {
      params: { importer }
    })
  },

  /**
   * 获取历史记录
   */
  getHistory(id: string | number): Promise<HistoryRecord[]> {
    return request.get(`/api/warehouse-in/${id}/history`)
  },

  /**
   * 验证申请
   */
  validate(entity: Partial<WarehouseInItem>): Promise<ValidationResult> {
    return request.post('/api/warehouse-in/validate', entity)
  }
}

export default warehouseInApi
