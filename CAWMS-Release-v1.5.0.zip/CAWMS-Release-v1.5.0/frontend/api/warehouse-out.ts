// Warehouse Out API - 出库管理模块
// CAWMS - 抵押资产出库管理 API 调用

import type { Response, PageResult } from '~/types'
import api from '~/utils/api'

// ==================== 类型定义 ====================

export interface WarehouseOut {
  id: number
  warehouseOutNo: string
  warehouseInId: number
  warehouseInNo: string
  collateralName: string
  collateralType: string
  warehouseId: number
  warehouseName: string
  warehouseLocation: string
  releaseType: 'PARTIAL' | 'FULL'
  releaseAmount: number
  releasePercentage: number
  remainingValue: number
  originalValue: number
  releaseReason: string
  releaseReasonType: 'LOAN_REPAYMENT' | 'CREDIT_LINE_REDUCTION' | 'COLLATERAL_REPLACEMENT' | 'OTHER'
  status: 'DRAFT' | 'SUBMITTED' | 'APPROVED' | 'COMPLETED' | 'CANCELLED'
  applicantId: number
  applicantName: string
  applyTime: string
  actualReleaseTime: string | null
  remarks: string
  createTime: string
  updateTime: string
  approvals?: WarehouseOutApproval[]
}

export interface WarehouseOutApproval {
  id: number
  warehouseOutId: number
  step: number
  approverRole: string
  approverId: number | null
  approverName: string | null
  approvalStatus: 'PENDING' | 'APPROVED' | 'REJECTED' | 'RETURNED'
  approvalOpinion: string | null
  approvalTime: string | null
  createTime: string
}

export interface WarehouseOutCreateRequest {
  warehouseInId: number
  releaseType: 'PARTIAL' | 'FULL'
  releaseAmount?: number
  releasePercentage?: number
  releaseReasonType: 'LOAN_REPAYMENT' | 'CREDIT_LINE_REDUCTION' | 'COLLATERAL_REPLACEMENT' | 'OTHER'
  releaseReason: string
  remarks?: string
}

export interface WarehouseOutSubmitRequest {
  id: number
}

export interface WarehouseOutApprovalRequest {
  id: number
  step: number
  approvalStatus: 'APPROVED' | 'REJECTED' | 'RETURNED'
  approvalOpinion?: string
}

export interface WarehouseOutHistory {
  id: number
  warehouseOutId: number
  operationType: string
  operationDesc: string
  operatorId: number
  operatorName: string
  operationTime: string
  beforeValue: string | null
  afterValue: string | null
}

export interface WarehouseOutStatistics {
  total: number
  byStatus: Record<string, number>
  byReleaseType: Record<string, number>
  byReasonType: Record<string, number>
  pendingApprovals: number
  completedToday: number
  totalReleaseAmount: number
}

// ==================== API 调用 ====================

/**
 * 分页查询出库列表
 */
export function getWarehouseOutList(params: {
  page: number
  size: number
  status?: string
  releaseType?: string
  releaseReasonType?: string
  warehouseInNo?: string
  collateralName?: string
  startDate?: string
  endDate?: string
}) {
  return api.get<PageResult<WarehouseOut>>('/api/warehouse-out', { params })
}

/**
 * 获取出库详情
 */
export function getWarehouseOutDetail(id: number) {
  return api.get<Response<WarehouseOut>>(`/api/warehouse-out/${id}`)
}

/**
 * 创建出库申请
 */
export function createWarehouseOut(data: WarehouseOutCreateRequest) {
  return api.post<Response<WarehouseOut>>('/api/warehouse-out', data)
}

/**
 * 更新出库申请
 */
export function updateWarehouseOut(id: number, data: Partial<WarehouseOutCreateRequest>) {
  return api.put<Response<WarehouseOut>>(`/api/warehouse-out/${id}`, data)
}

/**
 * 删除出库申请
 */
export function deleteWarehouseOut(id: number) {
  return api.delete<Response<void>>(`/api/warehouse-out/${id}`)
}

/**
 * 提交出库申请（进入审批流程）
 */
export function submitWarehouseOut(data: WarehouseOutSubmitRequest) {
  return api.post<Response<WarehouseOut>>('/api/warehouse-out/submit', data)
}

/**
 * 审批出库申请
 */
export function approveWarehouseOut(data: WarehouseOutApprovalRequest) {
  return api.post<Response<WarehouseOut>>('/api/warehouse-out/approve', data)
}

/**
 * 完成出库
 */
export function completeWarehouseOut(id: number) {
  return api.post<Response<WarehouseOut>>(`/api/warehouse-out/${id}/complete`)
}

/**
 * 取消出库
 */
export function cancelWarehouseOut(id: number) {
  return api.post<Response<WarehouseOut>>(`/api/warehouse-out/${id}/cancel`)
}

/**
 * 计算出库释放价值（部分释放）
 */
export function calculateReleaseAmount(warehouseInId: number, releasePercentage: number) {
  return api.get<Response<{ releaseAmount: number; remainingValue: number }>>(
    '/api/warehouse-out/calculate-release',
    { params: { warehouseInId, releasePercentage } }
  )
}

/**
 * 验证出库原因
 */
export function validateReleaseReason(data: {
  releaseReasonType: string
  releaseReason: string
}) {
  return api.post<Response<{ valid: boolean; message?: string }>>(
    '/api/warehouse-out/validate-reason',
    data
  )
}

/**
 * 获取出库审批进度
 */
export function getApprovalProgress(warehouseOutId: number) {
  return api.get<Response<WarehouseOutApproval[]>>(
    `/api/warehouse-out/${warehouseOutId}/approval-progress`
  )
}

/**
 * 获取当前待审批步骤
 */
export function getCurrentPendingStep(warehouseOutId: number) {
  return api.get<Response<WarehouseOutApproval>>(
    `/api/warehouse-out/${warehouseOutId}/current-pending-step`
  )
}

/**
 * 获取出库历史
 */
export function getWarehouseOutHistory(warehouseOutId: number) {
  return api.get<Response<WarehouseOutHistory[]>>(
    `/api/warehouse-out/${warehouseOutId}/history`
  )
}

/**
 * 获取出库统计信息
 */
export function getWarehouseOutStatistics() {
  return api.get<Response<WarehouseOutStatistics>>('/api/warehouse-out/statistics')
}

/**
 * 查询待审批出库列表
 */
export function getPendingApprovals(params?: {
  page?: number
  size?: number
}) {
  return api.get<PageResult<WarehouseOut>>('/api/warehouse-out/pending-approvals', { params })
}

/**
 * 查询我的申请列表
 */
export function getMyApplications(params?: {
  page?: number
  size?: number
  status?: string
}) {
  return api.get<PageResult<WarehouseOut>>('/api/warehouse-out/my-applications', { params })
}

/**
 * 获取我的审批列表（待我审批 / 我已审批 / 审批记录）
 */
export async function getMyApprovals(params: {
  type: 'pending' | 'ongoing' | 'history'
  approverUser?: string
  approverRole?: string
  pageNum?: number
  pageSize?: number
}): Promise<any> {
  const res = await api.get('/api/warehouse-out/my-approvals', { params })
  return res.data?.data || res.data
}
