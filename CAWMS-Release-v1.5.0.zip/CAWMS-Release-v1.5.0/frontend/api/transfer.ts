// Transfer API - 转移管理模块
// CAWMS - 抵押资产转移管理 API 调用

import type { Response, PageResult } from '~/types'
import api from '~/utils/api'

// ==================== 类型定义 ====================

export interface Transfer {
  id: number
  transferNo: string
  warehouseInId: number
  warehouseInNo: string
  collateralName: string
  collateralType: string
  sourceWarehouseId: number
  sourceWarehouseName: string
  sourceWarehouseLocation: string
  targetWarehouseId: number
  targetWarehouseName: string
  targetWarehouseLocation: string
  transferType: 'INTERNAL' | 'CROSS_BRANCH'
  transferReason: string
  status: 'DRAFT' | 'SUBMITTED' | 'APPROVED' | 'COMPLETED' | 'CANCELLED'
  applicantId: number
  applicantName: string
  applyTime: string
  actualTransferTime: string | null
  remarks: string
  createTime: string
  updateTime: string
  approvals?: TransferApproval[]
}

export interface TransferApproval {
  id: number
  transferId: number
  step: number
  stepName: string | null
  approverRole: string
  approverId: number | null
  approverName: string | null
  approvalStatus: 'PENDING' | 'APPROVED' | 'REJECTED' | 'RETURNED'
  approvalOpinion: string | null
  approvalTime: string | null
  createTime: string
}

export interface TransferCreateRequest {
  warehouseInId: number
  targetWarehouseId: number
  transferType: 'INTERNAL' | 'CROSS_BRANCH'
  transferReason: string
  remarks?: string
}

export interface TransferSubmitRequest {
  id: number
}

export interface TransferApprovalRequest {
  id: number
  step: number
  approvalStatus: 'APPROVED' | 'REJECTED' | 'RETURNED'
  approvalOpinion?: string
}

export interface TransferHistory {
  id: number
  transferId: number
  operationType: string
  operationDesc: string
  operatorId: number
  operatorName: string
  operationTime: string
  beforeValue: string | null
  afterValue: string | null
}

export interface TransferStatistics {
  total: number
  byStatus: Record<string, number>
  byType: Record<string, number>
  pendingApprovals: number
  completedToday: number
}

// ==================== API 调用 ====================

/**
 * 分页查询转移列表
 */
export function getTransferList(params: {
  page: number
  size: number
  status?: string
  transferType?: string
  warehouseInNo?: string
  collateralName?: string
  startDate?: string
  endDate?: string
}) {
  return api.get<PageResult<Transfer>>('/api/transfer', { params })
}

/**
 * 获取转移详情
 */
export function getTransferDetail(id: number) {
  return api.get<Response<Transfer>>(`/api/transfer/${id}`)
}

/**
 * 创建转移申请
 */
export function createTransfer(data: TransferCreateRequest) {
  return api.post<Response<Transfer>>('/api/transfer', data)
}

/**
 * 更新转移申请
 */
export function updateTransfer(id: number, data: Partial<TransferCreateRequest>) {
  return api.put<Response<Transfer>>(`/api/transfer/${id}`, data)
}

/**
 * 删除转移申请
 */
export function deleteTransfer(id: number) {
  return api.delete<Response<void>>(`/api/transfer/${id}`)
}

/**
 * 提交转移申请（进入审批流程）
 */
export function submitTransfer(data: TransferSubmitRequest) {
  return api.post<Response<Transfer>>('/api/transfer/submit', data)
}

/**
 * 审批转移申请
 */
export function approveTransfer(data: TransferApprovalRequest) {
  return api.post<Response<Transfer>>('/api/transfer/approve', data)
}

/**
 * 完成转移
 */
export function completeTransfer(id: number) {
  return api.post<Response<Transfer>>(`/api/transfer/${id}/complete`)
}

/**
 * 取消转移
 */
export function cancelTransfer(id: number) {
  return api.post<Response<Transfer>>(`/api/transfer/${id}/cancel`)
}

/**
 * 获取转移审批进度
 */
export function getApprovalProgress(transferId: number) {
  return api.get<Response<TransferApproval[]>>(`/api/transfer/${transferId}/approval-progress`)
}

/**
 * 获取当前待审批步骤
 */
export function getCurrentPendingStep(transferId: number) {
  return api.get<Response<TransferApproval>>(`/api/transfer/${transferId}/current-pending-step`)
}

/**
 * 获取转移历史
 */
export function getTransferHistory(transferId: number) {
  return api.get<Response<TransferHistory[]>>(`/api/transfer/${transferId}/history`)
}

/**
 * 获取转移统计信息
 */
export function getTransferStatistics() {
  return api.get<Response<TransferStatistics>>('/api/transfer/statistics')
}

/**
 * 查询待审批转移列表
 */
export function getPendingApprovals(params?: {
  page?: number
  size?: number
}) {
  return api.get<PageResult<Transfer>>('/api/transfer/pending-approvals', { params })
}

/**
 * 查询我的申请列表
 */
export function getMyApplications(params?: {
  page?: number
  size?: number
  status?: string
}) {
  return api.get<PageResult<Transfer>>('/api/transfer/my-applications', { params })
}

/**
 * 获取我的审批列表（待我审批 / 我已审批 / 审批记录）
 */
export async function getMyApprovals(params: {
  type: 'pending' | 'ongoing' | 'history'
  approverUser?: string
  approverRole?: string
  pageNum?: number
  pageSize?: number
}): Promise<any> {
  const res = await api.get('/api/transfer/my-approvals', { params })
  return res.data?.data || res.data
}
