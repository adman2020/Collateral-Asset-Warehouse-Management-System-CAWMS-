import request from '@/utils/request'

export interface WarehouseItem {
  id: string | number
  warehouseCode: string
  warehouseName: string
  zoneId: string | number
  manager?: string
  capacity?: number
  status: string
  createdAt?: string
  updatedAt?: string
}

export interface WarehousePageResult {
  records: WarehouseItem[]
  total: number
  size: number
  current: number
  pages: number
}

const warehouseApi = {
  getList(params: { zoneId?: string | number; keyword?: string; pageNum?: number; pageSize?: number }): Promise<WarehousePageResult> {
    return request.get('/api/warehouses', { params })
  },

  getAllActive(): Promise<WarehouseItem[]> {
    return request.get('/api/warehouses/all-active')
  },

  getById(id: string | number): Promise<WarehouseItem> {
    return request.get(`/api/warehouses/${id}`)
  },

  getByZoneId(zoneId: string | number): Promise<WarehouseItem[]> {
    return request.get(`/api/warehouse-zones/${zoneId}/warehouses`)
  },

  create(data: Omit<WarehouseItem, 'id'>): Promise<WarehouseItem> {
    return request.post('/api/warehouses', data)
  },

  update(id: string | number, data: Partial<WarehouseItem>): Promise<WarehouseItem> {
    return request.put(`/api/warehouses/${id}`, data)
  },

  delete(id: string | number): Promise<void> {
    return request.delete(`/api/warehouses/${id}`)
  }
}

export default warehouseApi
