import request from '@/utils/request'

/**
 * 抵押资产借出管理API（对齐后端领域模型）
 */

// ==================== 类型定义 ====================

export interface LoanOutApproval {
  id: number
  loanOutId: number
  stepNumber: number
  stepName?: string
  approverRole?: string
  approverUser?: string
  approverName?: string
  status?: string
  comments?: string
  approvedAt?: string
  createdAt?: string
  updatedAt?: string
}

export interface LoanReturnApproval {
  id: number
  loanOutId: number
  stepNumber: number
  stepName?: string
  approverRole?: string
  approverUser?: string
  approverName?: string
  status?: string
  comments?: string
  approvedAt?: string
  assetCondition?: string
  conditionDescription?: string
  settlementAmount?: number
  settlementMethod?: string
  createdAt?: string
  updatedAt?: string
}

export interface LoanOutItem {
  id: string | number
  loanCode?: string
  whInId: number
  whCode?: string
  loanPurpose?: string
  loanDuration?: number
  expectedReturnDate?: string
  actualReturnDate?: string
  status: string
  t24SyncStatus?: string
  t24SyncTime?: string
  customerName?: string
  collateralType?: string
  collateralValue?: number
  buCode?: string
  buName?: string
  remarks?: string
  createdAt?: string
  updatedAt?: string
  createdBy?: string
  updatedBy?: string
  overdue?: boolean
  remainingDays?: number
  approvals?: LoanOutApproval[]
  returnApprovals?: LoanReturnApproval[]
}

export interface LoanOutCreateParams {
  whInId: number
  loanPurpose: string
  loanDuration: number
  expectedReturnDate: string
  remarks?: string
  extData?: Record<string, any>
}

export interface LoanOutUpdateParams {
  whInId?: number
  loanPurpose?: string
  loanDuration?: number
  expectedReturnDate?: string
  remarks?: string
  extData?: Record<string, any>
}

export interface LoanOutFilterParams {
  loanCode?: string
  customerName?: string
  loanPurpose?: string
  status?: string
  buCode?: string
  startDate?: string
  endDate?: string
  expectedReturnStart?: string
  expectedReturnEnd?: string
  t24SyncStatus?: string
  pageNum?: number
  pageSize?: number
  sortField?: string
  sortOrder?: string
}

export interface LoanOutPageResult {
  records: LoanOutItem[]
  total: number
  size: number
  current: number
  pages: number
}

export interface LoanOutStats {
  totalCount?: number
  draftCount?: number
  pendingCount?: number
  loanedCount?: number
  returnedCount?: number
  overdueCount?: number
  totalLoanValue?: number
  overdueValue?: number
  statusDistribution?: Record<string, number>
  collateralTypeDistribution?: Record<string, number>
  businessUnitDistribution?: Record<string, number>
  todayLoans?: number
  monthLoans?: number
  expiringLoans?: number
}

export interface SubmitApprovalRequest {
  approverId?: string
  approverName?: string
  approverRole?: string
  comments?: string
}

// ==================== API 函数 ====================

const loanOutApi = {
  /**
   * 获取借出列表（分页）
   */
  getList(params: LoanOutFilterParams): Promise<LoanOutPageResult> {
    return request.get('/api/loan-out', { params })
  },

  /**
   * 获取我的审批列表（待我审批 / 我已审批 / 审批记录）
   */
  getMyApprovals(params: {
    type: 'pending' | 'ongoing' | 'history'
    approverUser?: string
    approverRole?: string
    pageNum?: number
    pageSize?: number
  }): Promise<LoanOutPageResult> {
    return request.get('/api/loan-out/my-approvals', { params })
  },

  /**
   * 获取借出详情
   */
  getDetail(id: string | number): Promise<LoanOutItem> {
    return request.get(`/api/loan-out/${id}`)
  },

  /**
   * 创建借出草稿
   */
  createDraft(params: LoanOutCreateParams): Promise<LoanOutItem> {
    return request.post('/api/loan-out/drafts', params)
  },

  /**
   * 更新借出申请
   */
  update(id: string | number, params: LoanOutUpdateParams): Promise<LoanOutItem> {
    return request.put(`/api/loan-out/${id}`, params)
  },

  /**
   * 删除借出申请
   */
  delete(id: string | number): Promise<void> {
    return request.delete(`/api/loan-out/${id}`)
  },

  /**
   * 提交借出申请
   */
  submit(id: string | number, data?: SubmitApprovalRequest): Promise<LoanOutItem> {
    return request.post(`/api/loan-out/${id}/submit`, data || {})
  },

  /**
   * 审批通过
   */
  approve(id: string | number, comments: string): Promise<LoanOutItem> {
    return request.post(`/api/loan-out/${id}/approve`, null, { params: { comments } })
  },

  /**
   * 拒绝借出申请
   */
  reject(id: string | number, comments: string): Promise<LoanOutItem> {
    return request.post(`/api/loan-out/${id}/reject`, null, { params: { comments } })
  },

  /**
   * 确认借出
   */
  confirm(id: string | number): Promise<LoanOutItem> {
    return request.post(`/api/loan-out/${id}/confirm`)
  },

  /**
   * 归还抵押资产
   */
  returnCollateral(id: string | number, actualReturnDate: string, remarks?: string): Promise<LoanOutItem> {
    return request.post(`/api/loan-out/${id}/return`, null, {
      params: { actualReturnDate, remarks }
    })
  },

  /**
   * 获取待审批列表
   */
  getPendingApprovals(params: {
    pageNum?: number
    pageSize?: number
  }): Promise<LoanOutPageResult> {
    return request.get('/api/loan-out/pending-approvals', { params })
  },

  /**
   * 获取统计信息
   */
  getStatistics(params?: {
    startDate?: string
    endDate?: string
  }): Promise<LoanOutStats> {
    return request.get('/api/loan-out/statistics', { params })
  },

  /**
   * 获取逾期列表
   */
  getOverdueList(params?: {
    pageNum?: number
    pageSize?: number
  }): Promise<LoanOutPageResult> {
    return request.get('/api/loan-out/overdue-loans', { params })
  },

  /**
   * 获取即将到期列表
   */
  getExpiringList(params?: {
    pageNum?: number
    pageSize?: number
  }): Promise<LoanOutPageResult> {
    return request.get('/api/loan-out/expiring-loans', { params })
  },

  /**
   * 同步到T24
   */
  syncT24(id: string | number): Promise<any> {
    return request.post(`/api/loan-out/${id}/sync-t24`)
  },

  /**
   * 导出数据
   */
  exportData(params: any): Promise<Blob> {
    return request.post('/api/loan-out/export', params, { responseType: 'blob' })
  }
}

export default loanOutApi
