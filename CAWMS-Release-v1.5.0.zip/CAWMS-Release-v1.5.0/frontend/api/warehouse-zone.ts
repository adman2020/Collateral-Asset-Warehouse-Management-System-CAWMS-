import request from '@/utils/request'

export interface WarehouseZoneItem {
  id: string | number
  zoneCode: string
  zoneName: string
  zoneType: 'SUPERVISED' | 'SELF_MANAGED'
  address?: string
  contactPerson?: string
  contactPhone?: string
  status: string
  createdAt?: string
  updatedAt?: string
}

export interface WarehouseZonePageResult {
  records: WarehouseZoneItem[]
  total: number
  size: number
  current: number
  pages: number
}

const warehouseZoneApi = {
  getList(params: { keyword?: string; pageNum?: number; pageSize?: number }): Promise<WarehouseZonePageResult> {
    return request.get('/api/warehouse-zones', { params })
  },

  getAllActive(): Promise<WarehouseZoneItem[]> {
    return request.get('/api/warehouse-zones/all-active')
  },

  getById(id: string | number): Promise<WarehouseZoneItem> {
    return request.get(`/api/warehouse-zones/${id}`)
  },

  create(data: Omit<WarehouseZoneItem, 'id'>): Promise<WarehouseZoneItem> {
    return request.post('/api/warehouse-zones', data)
  },

  update(id: string | number, data: Partial<WarehouseZoneItem>): Promise<WarehouseZoneItem> {
    return request.put(`/api/warehouse-zones/${id}`, data)
  },

  delete(id: string | number): Promise<void> {
    return request.delete(`/api/warehouse-zones/${id}`)
  }
}

export default warehouseZoneApi
