// Reports API - 报表模块
// CAWMS - 报表生成和数据统计 API 调用

import type { Response } from '~/types'
import api from '~/utils/api'

// ==================== 类型定义 ====================

export interface ReportDefinition {
  id: number
  reportName: string
  reportCode: string
  reportType: 'INBOUND' | 'LOAN_OUT' | 'TRANSFER' | 'WAREHOUSE_OUT' | 'OVERDUE' | 'CUSTOM'
  description: string | null
  columns: string[]
  filters: string[]
  createTime: string
}

export interface ReportData {
  columns: string[]
  rows: Record<string, any>[]
  total: number
  summary?: Record<string, any>
}

export interface DashboardStat {
  inboundTotal: number
  inboundToday: number
  loanOutTotal: number
  loanOutToday: number
  overdueCount: number
  pendingApprovals: number
  warehouseCount: number
  collateralTotalValue: number
}

export interface InboundStats {
  total: number
  byStatus: Record<string, number>
  byType: Record<string, number>
  trend: { date: string; count: number }[]
}

export interface LoanOutStats {
  total: number
  byStatus: Record<string, number>
  overdueCount: number
  totalAmount: number
  trend: { date: string; count: number }[]
}

// ==================== 报表定义 ====================

export function getReportDefinitions() {
  return api.get<Response<ReportDefinition[]>>('/api/reports/definitions')
}

export function getReportDefinition(id: number) {
  return api.get<Response<ReportDefinition>>(`/api/reports/definitions/${id}`)
}

// ==================== 报表生成 ====================

export function generateReport(reportCode: string, params: Record<string, any>) {
  return api.post<Response<ReportData>>('/api/reports/generate', { reportCode, params })
}

export function exportReportExcel(reportCode: string, params: Record<string, any>) {
  return api.post<Blob>('/api/reports/export/excel', { reportCode, params }, { responseType: 'blob' })
}

export function exportReportPDF(reportCode: string, params: Record<string, any>) {
  return api.post<Blob>('/api/reports/export/pdf', { reportCode, params }, { responseType: 'blob' })
}

// ==================== 仪表板统计 ====================

export function getDashboardStats() {
  return api.get<Response<DashboardStat>>('/api/reports/dashboard/stats')
}

export function getInboundStats(params?: {
  startDate?: string
  endDate?: string
}) {
  return api.get<Response<InboundStats>>('/api/reports/inbound/stats', { params })
}

export function getLoanOutStats(params?: {
  startDate?: string
  endDate?: string
}) {
  return api.get<Response<LoanOutStats>>('/api/reports/loan-out/stats', { params })
}

export function getOverdueStats() {
  return api.get<Response<{ overdueCount: number; overdueAmount: number; byDays: Record<string, number> }>>(
    '/api/reports/overdue/stats'
  )
}

export function getApprovalStats() {
  return api.get<Response<{ pendingCount: number; approvedToday: number; avgApprovalTime: number }>>(
    '/api/reports/approval/stats'
  )
}

// ==================== 自定义查询 ====================

export interface CustomQueryRequest {
  queryName: string
  tables: string[]
  fields: string[]
  conditions: Array<{
    field: string
    operator: string
    value: any
  }>
  orderBy?: string
  order?: 'ASC' | 'DESC'
}

export function executeCustomQuery(data: CustomQueryRequest) {
  return api.post<Response<ReportData>>('/api/reports/custom/query', data)
}

export function saveCustomQuery(data: CustomQueryRequest & { queryName: string; description?: string }) {
  return api.post<Response<{ id: number }>>('/api/reports/custom/save', data)
}

export function getSavedQueries() {
  return api.get<Response<Array<{ id: number; queryName: string; description: string; createTime: string }>>>(
    '/api/reports/custom/saved'
  )
}

export function deleteSavedQuery(id: number) {
  return api.delete<Response<void>>(`/api/reports/custom/saved/${id}`)
}
