import request from '@/utils/request'

// ==================== 类型定义 ====================

export interface SystemUser {
  id: number
  username: string
  realName: string
  email: string
  phone: string
  departmentName: string
  roleNames: string[]
  status: 'ACTIVE' | 'INACTIVE' | 'LOCKED'
  createTime: string
  lastLoginTime: string | null
}

export interface AuditLog {
  id: number
  userId: number
  userName: string
  operation: string
  module: string
  method: string
  params: string | null
  result: string | null
  ipAddress: string
  userAgent: string
  executionTime: number
  status: 'SUCCESS' | 'FAILURE'
  createTime: string
}

export interface SystemStatistics {
  totalUsers: number
  activeUsers: number
  totalRoles: number
  totalPermissions: number
  auditLogsToday: number
  auditLogsTotal: number
}

export interface UserPageResult {
  records: SystemUser[]
  total: number
  size: number
  current: number
  pages: number
}

export interface AuditLogPageResult {
  records: AuditLog[]
  total: number
  size: number
  current: number
  pages: number
}

export interface UserCreateRequest {
  username: string
  password: string
  realName: string
  email: string
  phone: string
  departmentName: string
  roleNames: string[]
  status?: string
}

// ==================== 用户管理 ====================

export function getUserList(params: {
  page: number
  size: number
  username?: string
  realName?: string
  status?: string
}) {
  return request.get<UserPageResult>('/api/system/users', { params })
}

export function getUserDetail(id: number) {
  return request.get<SystemUser>(`/api/system/users/${id}`)
}

export function createUser(data: UserCreateRequest) {
  return request.post<SystemUser>('/api/system/users', data)
}

export function updateUser(id: number, data: Partial<UserCreateRequest>) {
  return request.put<SystemUser>(`/api/system/users/${id}`, data)
}

export function deleteUser(id: number) {
  return request.del<boolean>(`/api/system/users/${id}`)
}

export function resetUserPassword(id: number, newPassword: string) {
  return request.post<boolean>(`/api/system/users/${id}/reset-password`, { newPassword })
}

// ==================== 审计日志 ====================

export function getAuditLogList(params: {
  page: number
  size: number
  userId?: number
  module?: string
  operation?: string
  status?: string
  startDate?: string
  endDate?: string
}) {
  return request.get<AuditLogPageResult>('/api/system/audit-logs', { params })
}

// ==================== 角色管理 ====================

export interface SystemRole {
  id: number
  roleCode: string
  roleName: string
  description?: string
  dataScope?: string
  status: 'ACTIVE' | 'INACTIVE'
  permissions?: string
  createTime?: string
  updateTime?: string
}

export interface RolePageResult {
  records: SystemRole[]
  total: number
  size: number
  current: number
  pages: number
}

export interface RoleCreateRequest {
  roleCode: string
  roleName: string
  description?: string
  dataScope?: string
  status?: string
  permissions?: string
}

export function getRoleList(params: {
  page: number
  size: number
  roleCode?: string
  roleName?: string
}) {
  return request.get<RolePageResult>('/api/system/roles', { params })
}

export function getRoleDetail(id: number) {
  return request.get<SystemRole>(`/api/system/roles/${id}`)
}

export function createRole(data: RoleCreateRequest) {
  return request.post<SystemRole>('/api/system/roles', data)
}

export function updateRole(id: number, data: Partial<RoleCreateRequest>) {
  return request.put<SystemRole>(`/api/system/roles/${id}`, data)
}

export function deleteRole(id: number) {
  return request.del<boolean>(`/api/system/roles/${id}`)
}

// ==================== 系统配置 ====================

export interface SystemConfig {
  id: number
  configKey: string
  configValue: string
  configType: string
  description?: string
  editable: number
  createTime?: string
  updateTime?: string
}

export function getConfigList() {
  return request.get<SystemConfig[]>('/api/system/config')
}

export function updateConfig(id: number, data: { configValue: string }) {
  return request.put<SystemConfig>(`/api/system/config/${id}`, data)
}

// ==================== 统计信息 ====================

export function getSystemStatistics() {
  return request.get<SystemStatistics>('/api/system/statistics')
}
