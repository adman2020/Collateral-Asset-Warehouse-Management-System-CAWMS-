@echo off
chcp 65001 > nul
echo ========================================
echo    CAWMS 完整工作流测试启动脚本
echo ========================================
echo.
echo [1] 启动完整工作流演示 (推荐)
echo [2] 启动Vue开发服务器 (需要Node.js)
echo [3] 查看测试指南
echo [4] 打开所有测试页面
echo.
set /p choice="请选择测试方式 (1-4): "

if "%choice%"=="1" (
    echo.
    echo 正在打开完整工作流演示页面...
    start "" "complete_workflow_demo.html"
    echo.
    echo ✅ 演示页面已打开！
    echo.
    echo 测试说明:
    echo 1. 这是一个交互式演示，展示从申请到审批的完整流程
    echo 2. 点击"下一步"逐步执行每个工作流步骤
    echo 3. 可以点击"自动完成审批"快速查看完整流程
    echo 4. API调用日志会显示在页面底部
    echo.
    pause
)

if "%choice%"=="2" (
    echo.
    echo 正在启动Vue开发服务器...
    echo 请确保已安装Node.js和npm依赖
    echo.
    if exist "node_modules" (
        echo 检测到node_modules目录，启动服务器...
        npm run dev
    ) else (
        echo ❌ 未找到node_modules目录
        echo 请先运行: npm install
        pause
    )
)

if "%choice%"=="3" (
    echo.
    echo 正在打开测试指南...
    start "" "FINAL_TEST_GUIDE.txt"
    echo.
    echo 📋 测试指南已打开
    echo.
    echo 主要测试内容:
    echo 1. 页面导航测试
    echo 2. 入库管理功能测试 (Task 13.8)
    echo 3. 借出管理功能测试 (Task 14.7)
    echo 4. 审批工作流集成测试
    echo.
    pause
)

if "%choice%"=="4" (
    echo.
    echo 正在打开所有测试页面...
    start "" "test_navigation.html"
    start "" "complete_workflow_demo.html"
    start "" "dashboard.html"
    echo.
    echo ✅ 所有测试页面已打开！
    echo.
    echo 测试页面说明:
    echo 1. test_navigation.html - 基本页面导航测试
    echo 2. complete_workflow_demo.html - 完整工作流演示
    echo 3. dashboard.html - 系统仪表板
    echo.
    pause
)

echo.
echo ========================================
echo    测试脚本执行完成
echo ========================================
pause