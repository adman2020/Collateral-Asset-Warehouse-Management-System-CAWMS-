# 任务状态检查脚本
Write-Host "==========================================" -ForegroundColor Green
Write-Host "        任务完成状态检查 (PowerShell)       " -ForegroundColor Yellow
Write-Host "==========================================" -ForegroundColor Green
Write-Host ""

# 检查时间
$currentTime = Get-Date -Format "yyyy-MM-dd HH:mm"
Write-Host "检查时间: $currentTime" -ForegroundColor Cyan
Write-Host "工作目录: $(Get-Location)" -ForegroundColor Cyan
Write-Host ""

# 检查状态文件
$statusFile = "TASK_STATUS.txt"
if (Test-Path $statusFile) {
    Write-Host "✅ 检测到任务状态文件" -ForegroundColor Green
    Write-Host ""
    
    # 显示简要状态
    Write-Host "=== 简要状态 ===" -ForegroundColor Yellow
    Get-Content $statusFile | Select-String "TASK STATUS:" | ForEach-Object {
        Write-Host $_ -ForegroundColor White
    }
    Write-Host ""
    
    # 显示任务状态
    Write-Host "=== 已完成任务 ===" -ForegroundColor Yellow
    Get-Content $statusFile | Select-String "Task13" | ForEach-Object {
        Write-Host $_ -ForegroundColor White
    }
    Get-Content $statusFile | Select-String "Task14" | ForEach-Object {
        Write-Host $_ -ForegroundColor White
    }
    Write-Host ""
} else {
    Write-Host "❌ 错误: 状态文件不存在" -ForegroundColor Red
    exit 1
}

# 文件修改时间
Write-Host "=== 文件修改时间 ===" -ForegroundColor Yellow
$files = @("dashboard.html", "warehouse-in.html", "loan-out.html")
foreach ($file in $files) {
    if (Test-Path $file) {
        $lastWrite = (Get-Item $file).LastWriteTime.ToString("yyyy-MM-dd HH:mm")
        Write-Host "$file`: $lastWrite" -ForegroundColor White
    } else {
        Write-Host "$file`: 文件不存在" -ForegroundColor Red
    }
}
Write-Host ""

# 验证步骤
Write-Host "=== 快速验证 ===" -ForegroundColor Yellow
Write-Host "1. 双击打开 dashboard.html" -ForegroundColor White
Write-Host "2. 使用以下凭证登录:" -ForegroundColor White
Write-Host "   用户名: admin    密码: admin123" -ForegroundColor Gray
Write-Host "   用户名: user     密码: user123" -ForegroundColor Gray
Write-Host "3. 导航到入库管理或借出管理页面" -ForegroundColor White
Write-Host "4. 测试搜索、筛选和操作按钮" -ForegroundColor White
Write-Host ""

# 报告文件
Write-Host "=== 详细报告 ===" -ForegroundColor Yellow
Write-Host "完整报告: COMPLETION.md" -ForegroundColor White
Write-Host "状态文件: TASK_STATUS.txt" -ForegroundColor White
Write-Host "确认文件: COMPLETION_CONFIRMATION.txt" -ForegroundColor White
Write-Host ""

Write-Host "==========================================" -ForegroundColor Green
Write-Host "提示: 要打开dashboard.html，请手动双击文件" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Green