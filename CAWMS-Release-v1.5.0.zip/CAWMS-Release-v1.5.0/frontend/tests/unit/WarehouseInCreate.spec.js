import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import WarehouseInCreate from '@/pages/warehouse-in/create.vue'

// Mock API and router
const mockApiService = {
  async createWarehouseIn(data) {
    return {
      success: true,
      data: { id: 123, warehouseCode: 'WH-20240403-001' },
      message: '入库申请创建成功'
    }
  },
  async uploadFiles(files) {
    return {
      success: true,
      data: files.map(file => ({ id: 456, name: file.name, url: 'https://example.com/' + file.name })),
      message: '文件上传成功'
    }
  }
}

const mockRouter = {
  push: vi.fn(),
  back: vi.fn()
}

const mockMessage = {
  success: vi.fn(),
  error: vi.fn(),
  warning: vi.fn()
}

describe('WarehouseInCreate', () => {
  let wrapper
  
  beforeEach(() => {
    // Mount component with mocked dependencies
    wrapper = mount(WarehouseInCreate, {
      global: {
        mocks: {
          $api: mockApiService,
          $router: mockRouter,
          $message: mockMessage
        },
        stubs: {
          'a-form': true,
          'a-form-item': true,
          'a-input': true,
          'a-select': true,
          'a-select-option': true,
          'a-date-picker': true,
          'a-textarea': true,
          'a-upload': true,
          'a-button': true,
          'a-space': true,
          'a-card': true,
          'a-row': true,
          'a-col': true,
          'a-alert': true
        }
      }
    })
  })
  
  it('renders create form with all required fields', () => {
    // Check form exists
    expect(wrapper.find('form').exists()).toBe(true)
    
    // Check required fields
    const requiredFields = [
      'collateralName',
      'collateralType',
      'collateralValue',
      'applicant',
      'applyDate',
      'description'
    ]
    
    requiredFields.forEach(field => {
      expect(wrapper.find(`[name="${field}"]`).exists()).toBe(true)
    })
  })
  
  it('validates required fields before submission', async () => {
    // Submit empty form
    const submitButton = wrapper.find('.submit-btn')
    await submitButton.trigger('click')
    
    // Should show validation errors
    expect(wrapper.findAll('.ant-form-item-explain-error').length).toBeGreaterThan(0)
    expect(mockApiService.createWarehouseIn).not.toHaveBeenCalled()
  })
  
  it('submits form with valid data', async () => {
    // Fill form with valid data
    await wrapper.find('[name="collateralName"]').setValue('Commercial Property A')
    await wrapper.find('[name="collateralType"]').setValue('REAL_ESTATE')
    await wrapper.find('[name="collateralValue"]').setValue('5000000')
    await wrapper.find('[name="applicant"]').setValue('John Doe')
    await wrapper.find('[name="applyDate"]').setValue('2024-04-03')
    await wrapper.find('[name="description"]').setValue('Prime commercial property in downtown area')
    
    // Submit form
    const submitButton = wrapper.find('.submit-btn')
    await submitButton.trigger('click')
    
    // Check API was called
    expect(mockApiService.createWarehouseIn).toHaveBeenCalledWith(
      expect.objectContaining({
        collateralName: 'Commercial Property A',
        collateralType: 'REAL_ESTATE',
        collateralValue: 5000000,
        applicant: 'John Doe'
      })
    )
    
    // Check success message
    expect(mockMessage.success).toHaveBeenCalledWith('入库申请创建成功')
    
    // Check navigation
    expect(mockRouter.push).toHaveBeenCalledWith('/warehouse-in')
  })
  
  it('handles file upload', async () => {
    // Create mock file
    const mockFile = new File(['test content'], 'document.pdf', { type: 'application/pdf' })
    
    // Trigger file upload
    const uploadComponent = wrapper.findComponent({ name: 'AUpload' })
    await uploadComponent.vm.$emit('change', {
      file: mockFile,
      fileList: [mockFile]
    })
    
    // Check upload API was called
    expect(mockApiService.uploadFiles).toHaveBeenCalledWith([mockFile])
    
    // Check success message
    expect(mockMessage.success).toHaveBeenCalledWith('文件上传成功')
  })
  
  it('handles API errors gracefully', async () => {
    // Mock API failure
    mockApiService.createWarehouseIn = vi.fn().mockRejectedValue(new Error('Network error'))
    
    // Fill form with valid data
    await wrapper.find('[name="collateralName"]').setValue('Test Property')
    await wrapper.find('[name="collateralType"]').setValue('REAL_ESTATE')
    await wrapper.find('[name="collateralValue"]').setValue('1000000')
    await wrapper.find('[name="applicant"]').setValue('Test User')
    
    // Submit form
    const submitButton = wrapper.find('.submit-btn')
    await submitButton.trigger('click')
    
    // Check error message
    expect(mockMessage.error).toHaveBeenCalledWith('创建失败: Network error')
  })
  
  it('resets form when reset button is clicked', async () => {
    // Fill form with data
    await wrapper.find('[name="collateralName"]').setValue('Test Property')
    await wrapper.find('[name="collateralValue"]').setValue('1000000')
    
    // Click reset button
    const resetButton = wrapper.find('.reset-btn')
    await resetButton.trigger('click')
    
    // Check form is reset
    expect(wrapper.find('[name="collateralName"]').element.value).toBe('')
    expect(wrapper.find('[name="collateralValue"]').element.value).toBe('')
  })
  
  it('navigates back when cancel button is clicked', async () => {
    const cancelButton = wrapper.find('.cancel-btn')
    await cancelButton.trigger('click')
    
    expect(mockRouter.back).toHaveBeenCalled()
  })
  
  it('displays collateral type options', () => {
    const selectComponent = wrapper.findComponent({ name: 'ASelect' })
    const options = selectComponent.findAllComponents({ name: 'ASelectOption' })
    
    const expectedTypes = [
      'REAL_ESTATE',
      'SECURITIES',
      'EQUIPMENT',
      'INVENTORY',
      'RECEIVABLES',
      'OTHER'
    ]
    
    expect(options.length).toBe(expectedTypes.length)
    expectedTypes.forEach(type => {
      expect(wrapper.text()).toContain(type)
    })
  })
  
  it('calculates and displays total collateral value', async () => {
    // Set multiple collateral items
    const addButton = wrapper.find('.add-collateral-btn')
    await addButton.trigger('click')
    
    // Fill multiple collateral values
    const valueInputs = wrapper.findAll('[name="collateralValue"]')
    await valueInputs[0].setValue('1000000')
    await valueInputs[1].setValue('2000000')
    
    // Check total display
    const totalDisplay = wrapper.find('.total-value')
    expect(totalDisplay.text()).toContain('3,000,000')
  })
})