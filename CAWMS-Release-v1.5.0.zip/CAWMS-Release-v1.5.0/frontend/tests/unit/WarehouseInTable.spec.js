import { describe, it, expect, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import WarehouseInTable from '@/components/WarehouseInTable.vue'

// Mock API calls
const mockWarehouseInData = [
  {
    id: 1,
    warehouseCode: 'WH-20240403-001',
    collateralName: 'Commercial Property A',
    collateralType: 'REAL_ESTATE',
    collateralValue: 5000000,
    status: 'PENDING',
    applicant: 'John Doe',
    appliedAt: '2024-04-03T10:30:00Z'
  },
  {
    id: 2,
    warehouseCode: 'WH-20240403-002',
    collateralName: 'Corporate Bonds',
    collateralType: 'SECURITIES',
    collateralValue: 3000000,
    status: 'APPROVED',
    applicant: 'Jane Smith',
    appliedAt: '2024-04-03T11:15:00Z'
  }
]

// Mock API service
const mockApiService = {
  async fetchWarehouseInList(params) {
    return {
      data: mockWarehouseInData,
      total: mockWarehouseInData.length,
      page: params?.page || 1,
      size: params?.size || 10
    }
  }
}

describe('WarehouseInTable', () => {
  let wrapper
  
  beforeEach(() => {
    // Mount component with mocked props and global mocks
    wrapper = mount(WarehouseInTable, {
      props: {
        dataSource: mockWarehouseInData,
        loading: false,
        pagination: {
          current: 1,
          pageSize: 10,
          total: mockWarehouseInData.length,
          showSizeChanger: true,
          showQuickJumper: true
        }
      },
      global: {
        mocks: {
          $api: mockApiService
        },
        stubs: {
          'a-table': true,
          'a-button': true,
          'a-space': true,
          'a-tag': true,
          'a-dropdown': true,
          'a-menu': true,
          'a-menu-item': true,
          'a-icon': true
        }
      }
    })
  })
  
  it('renders table with correct columns', () => {
    // Check table exists
    expect(wrapper.find('.ant-table').exists()).toBe(true)
    
    // Check column headers
    const expectedColumns = ['仓库编码', '抵押物名称', '抵押物类型', '抵押物价值', '状态', '申请人', '申请时间', '操作']
    const headers = wrapper.findAll('th')
    expectedColumns.forEach(column => {
      expect(wrapper.text()).toContain(column)
    })
  })
  
  it('displays correct data in table rows', () => {
    const rows = wrapper.findAll('tbody tr')
    expect(rows.length).toBe(mockWarehouseInData.length)
    
    // Check first row data
    const firstRow = rows[0]
    expect(firstRow.text()).toContain('WH-20240403-001')
    expect(firstRow.text()).toContain('Commercial Property A')
    expect(firstRow.text()).toContain('REAL_ESTATE')
    expect(firstRow.text()).toContain('5,000,000')
    expect(firstRow.text()).toContain('待审批')
  })
  
  it('shows loading state when loading prop is true', async () => {
    wrapper = mount(WarehouseInTable, {
      props: {
        dataSource: [],
        loading: true
      }
    })
    
    expect(wrapper.find('.ant-table-placeholder').exists()).toBe(true)
    expect(wrapper.find('.ant-spin').exists()).toBe(true)
  })
  
  it('emits page-change event when pagination changes', async () => {
    const pagination = wrapper.findComponent({ name: 'APagination' })
    await pagination.vm.$emit('change', 2, 20)
    
    expect(wrapper.emitted('page-change')).toBeTruthy()
    expect(wrapper.emitted('page-change')[0]).toEqual([2, 20])
  })
  
  it('emits edit event when edit button is clicked', async () => {
    const editButton = wrapper.findAll('.edit-btn')[0]
    await editButton.trigger('click')
    
    expect(wrapper.emitted('edit')).toBeTruthy()
    expect(wrapper.emitted('edit')[0]).toEqual([1]) // id of first item
  })
  
  it('emits delete event when delete button is clicked', async () => {
    const deleteButton = wrapper.findAll('.delete-btn')[0]
    await deleteButton.trigger('click')
    
    expect(wrapper.emitted('delete')).toBeTruthy()
    expect(wrapper.emitted('delete')[0]).toEqual([1])
  })
  
  it('filters data based on search input', async () => {
    const searchInput = wrapper.find('.search-input')
    await searchInput.setValue('Commercial Property')
    
    // Trigger search
    const searchButton = wrapper.find('.search-btn')
    await searchButton.trigger('click')
    
    expect(wrapper.emitted('search')).toBeTruthy()
    expect(wrapper.emitted('search')[0]).toEqual(['Commercial Property'])
  })
  
  it('exports data when export button is clicked', async () => {
    const exportButton = wrapper.find('.export-btn')
    await exportButton.trigger('click')
    
    expect(wrapper.emitted('export')).toBeTruthy()
    expect(wrapper.emitted('export')[0]).toEqual([mockWarehouseInData])
  })
})