/**
 * Transfer API 测试 - 转移管理模块
 */

import { describe, it, expect, beforeEach, vi } from 'vitest'
import {
  getTransferList,
  getTransferDetail,
  createTransfer,
  updateTransfer,
  deleteTransfer,
  submitTransfer,
  approveTransfer,
  getTransferStatistics
} from '~/api/transfer'
import { api } from '~/utils/request'

// Mock api 模块
vi.mock('~/utils/request', () => ({
  api: {
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn()
  }
}))

describe('Transfer API', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('getTransferList', () => {
    it('应该成功获取转移列表', async () => {
      const mockData = {
        code: 0,
        data: {
          records: [
            { id: 1, transferNo: 'TRF202604070001', status: 'DRAFT' }
          ],
          total: 1
        }
      }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })

      const result = await getTransferList({ page: 1, size: 10 })

      expect(api.get).toHaveBeenCalledWith('/api/transfer', {
        params: { page: 1, size: 10 }
      })
      expect(result.data.code).toBe(0)
      expect(result.data.data.records).toHaveLength(1)
    })

    it('应该支持过滤条件', async () => {
      const mockData = { code: 0, data: { records: [], total: 0 } }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })

      await getTransferList({
        page: 1,
        size: 10,
        status: 'SUBMITTED',
        transferType: 'INTERNAL'
      })

      expect(api.get).toHaveBeenCalledWith('/api/transfer', {
        params: {
          page: 1,
          size: 10,
          status: 'SUBMITTED',
          transferType: 'INTERNAL'
        }
      })
    })
  })

  describe('getTransferDetail', () => {
    it('应该成功获取转移详情', async () => {
      const mockData = {
        code: 0,
        data: {
          id: 1,
          transferNo: 'TRF202604070001',
          warehouseInNo: 'WI202604070001',
          status: 'SUBMITTED'
        }
      }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })

      const result = await getTransferDetail(1)

      expect(api.get).toHaveBeenCalledWith('/api/transfer/1')
      expect(result.data.data.id).toBe(1)
    })
  })

  describe('createTransfer', () => {
    it('应该成功创建转移申请', async () => {
      const mockData = { code: 0, data: { id: 1, transferNo: 'TRF202604070001' } }
      vi.mocked(api.post).mockResolvedValue({ data: mockData })

      const result = await createTransfer({
        warehouseInId: 1,
        targetWarehouseId: 2,
        transferType: 'INTERNAL',
        transferReason: '库内调整'
      })

      expect(api.post).toHaveBeenCalledWith('/api/transfer', {
        warehouseInId: 1,
        targetWarehouseId: 2,
        transferType: 'INTERNAL',
        transferReason: '库内调整'
      })
      expect(result.data.code).toBe(0)
    })
  })

  describe('getTransferStatistics', () => {
    it('应该成功获取统计数据', async () => {
      const mockData = {
        code: 0,
        data: {
          total: 100,
          byStatus: { DRAFT: 10, SUBMITTED: 20, COMPLETED: 70 },
          pendingApprovals: 20,
          completedToday: 5
        }
      }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })

      const result = await getTransferStatistics()

      expect(api.get).toHaveBeenCalledWith('/api/transfer/statistics')
      expect(result.data.data.total).toBe(100)
      expect(result.data.data.pendingApprovals).toBe(20)
    })
  })
})
