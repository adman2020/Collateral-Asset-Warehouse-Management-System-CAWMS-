/**
 * Warehouse Out API 测试 - 出库管理模块
 */

import { describe, it, expect, beforeEach, vi } from 'vitest'
import {
  getWarehouseOutList,
  getWarehouseOutDetail,
  createWarehouseOut,
  calculateReleaseAmount,
  getWarehouseOutStatistics
} from '~/api/warehouse-out'
import { api } from '~/utils/request'

vi.mock('~/utils/request', () => ({
  api: {
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn()
  }
}))

describe('Warehouse Out API', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('getWarehouseOutList', () => {
    it('应该成功获取出库列表', async () => {
      const mockData = {
        code: 0,
        data: {
          records: [
            { id: 1, warehouseOutNo: 'WO202604070001', status: 'DRAFT' }
          ],
          total: 1
        }
      }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })

      const result = await getWarehouseOutList({ page: 1, size: 10 })

      expect(api.get).toHaveBeenCalledWith('/api/warehouse-out', {
        params: { page: 1, size: 10 }
      })
      expect(result.data.data.records).toHaveLength(1)
    })
  })

  describe('createWarehouseOut', () => {
    it('应该成功创建部分释放出库申请', async () => {
      const mockData = { code: 0, data: { id: 1 } }
      vi.mocked(api.post).mockResolvedValue({ data: mockData })

      const result = await createWarehouseOut({
        warehouseInId: 1,
        releaseType: 'PARTIAL',
        releasePercentage: 50,
        releaseReasonType: 'LOAN_REPAYMENT',
        releaseReason: '客户提前还款'
      })

      expect(api.post).toHaveBeenCalledWith('/api/warehouse-out', {
        warehouseInId: 1,
        releaseType: 'PARTIAL',
        releasePercentage: 50,
        releaseReasonType: 'LOAN_REPAYMENT',
        releaseReason: '客户提前还款'
      })
      expect(result.data.code).toBe(0)
    })

    it('应该成功创建完全释放出库申请', async () => {
      const mockData = { code: 0, data: { id: 1 } }
      vi.mocked(api.post).mockResolvedValue({ data: mockData })

      const result = await createWarehouseOut({
        warehouseInId: 1,
        releaseType: 'FULL',
        releaseReasonType: 'LOAN_REPAYMENT',
        releaseReason: '贷款结清'
      })

      expect(result.data.code).toBe(0)
    })
  })

  describe('calculateReleaseAmount', () => {
    it('应该成功计算释放金额', async () => {
      const mockData = {
        code: 0,
        data: {
          releaseAmount: 500000,
          remainingValue: 500000
        }
      }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })

      const result = await calculateReleaseAmount(1, 50)

      expect(api.get).toHaveBeenCalledWith(
        '/api/warehouse-out/calculate-release',
        { params: { warehouseInId: 1, releasePercentage: 50 } }
      )
      expect(result.data.data.releaseAmount).toBe(500000)
    })
  })

  describe('getWarehouseOutStatistics', () => {
    it('应该成功获取统计数据', async () => {
      const mockData = {
        code: 0,
        data: {
          total: 50,
          byReleaseType: { PARTIAL: 30, FULL: 20 },
          totalReleaseAmount: 5000000
        }
      }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })

      const result = await getWarehouseOutStatistics()

      expect(api.get).toHaveBeenCalledWith('/api/warehouse-out/statistics')
      expect(result.data.data.total).toBe(50)
      expect(result.data.data.totalReleaseAmount).toBe(5000000)
    })
  })
})
