/**
 * Reports API 测试 - 报表模块
 */

import { describe, it, expect, beforeEach, vi } from 'vitest'
import { getReportDefinitions, getDashboardStats, generateReport } from '~/api/reports'
import { api } from '~/utils/request'

vi.mock('~/utils/request', () => ({
  api: { get: vi.fn(), post: vi.fn() }
}))

describe('Reports API', () => {
  beforeEach(() => { vi.clearAllMocks() })

  describe('getReportDefinitions', () => {
    it('应该成功获取报表定义列表', async () => {
      const mockData = { code: 0, data: [{ id: 1, reportName: '入库报表' }] }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })
      const result = await getReportDefinitions()
      expect(result.data.data).toHaveLength(1)
    })
  })

  describe('getDashboardStats', () => {
    it('应该成功获取仪表板统计', async () => {
      const mockData = { code: 0, data: { inboundTotal: 100, loanOutTotal: 50 } }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })
      const result = await getDashboardStats()
      expect(result.data.data.inboundTotal).toBe(100)
    })
  })

  describe('generateReport', () => {
    it('应该成功生成报表', async () => {
      const mockData = { code: 0, data: { columns: ['name'], rows: [] } }
      vi.mocked(api.post).mockResolvedValue({ data: mockData })
      const result = await generateReport('INBOUND', {})
      expect(api.post).toHaveBeenCalledWith('/api/reports/generate', { reportCode: 'INBOUND', params: {} })
    })
  })
})
