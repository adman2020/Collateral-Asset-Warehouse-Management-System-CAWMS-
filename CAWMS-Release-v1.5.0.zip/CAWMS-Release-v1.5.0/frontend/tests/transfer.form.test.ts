/**
 * TransferForm 组件测试
 */

import { describe, it, expect, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import TransferForm from '~/components/transfer/TransferForm.vue'

describe('TransferForm', () => {
  const wrapper = mount(TransferForm, {
    global: {
      plugins: [createTestingPinia()],
      stubs: {
        NForm: true,
        NFormItem: true,
        NGrid: true,
        NGi: true,
        NSelect: true,
        NInput: true,
        NButton: true
      }
    },
    props: {
      transferId: null
    }
  })

  it('应该正确渲染表单字段', () => {
    expect(wrapper.exists()).toBe(true)
  })

  it('应该支持新建模式', async () => {
    const wrapper = mount(TransferForm, {
      global: {
        plugins: [createTestingPinia()],
        stubs: {
          NForm: true,
          NFormItem: true,
          NGrid: true,
          NGi: true,
          NSelect: true,
          NInput: true,
          NButton: true
        }
      },
      props: {
        transferId: null
      }
    })

    expect(wrapper.props('transferId')).toBeNull()
  })

  it('应该支持编辑模式', async () => {
    const wrapper = mount(TransferForm, {
      global: {
        plugins: [createTestingPinia()],
        stubs: {
          NForm: true,
          NFormItem: true,
          NGrid: true,
          NGi: true,
          NSelect: true,
          NInput: true,
          NButton: true
        }
      },
      props: {
        transferId: 1
      }
    })

    expect(wrapper.props('transferId')).toBe(1)
  })
})
