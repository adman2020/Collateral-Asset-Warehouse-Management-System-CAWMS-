/**
 * WarehouseOutForm 组件测试
 */

import { describe, it, expect, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import WarehouseOutForm from '~/components/warehouse-out/WarehouseOutForm.vue'

describe('WarehouseOutForm', () => {
  it('应该正确渲染表单字段', () => {
    const wrapper = mount(WarehouseOutForm, {
      global: {
        plugins: [createTestingPinia()],
        stubs: {
          NForm: true,
          NFormItem: true,
          NGrid: true,
          NGi: true,
          NSelect: true,
          NInput: true,
          NInputNumber: true,
          NButton: true
        }
      },
      props: {
        warehouseOutId: null
      }
    })

    expect(wrapper.exists()).toBe(true)
  })

  it('应该支持部分释放模式', async () => {
    const wrapper = mount(WarehouseOutForm, {
      global: {
        plugins: [createTestingPinia()],
        stubs: {
          NForm: true,
          NFormItem: true,
          NGrid: true,
          NGi: true,
          NSelect: true,
          NInput: true,
          NInputNumber: true,
          NButton: true
        }
      },
      props: {
        warehouseOutId: null
      }
    })

    expect(wrapper.props('warehouseOutId')).toBeNull()
  })

  it('应该支持完全释放模式', async () => {
    const wrapper = mount(WarehouseOutForm, {
      global: {
        plugins: [createTestingPinia()],
        stubs: {
          NForm: true,
          NFormItem: true,
          NGrid: true,
          NGi: true,
          NSelect: true,
          NInput: true,
          NInputNumber: true,
          NButton: true
        }
      },
      props: {
        warehouseOutId: null
      }
    })

    expect(wrapper.exists()).toBe(true)
  })

  it('应该支持编辑模式', async () => {
    const wrapper = mount(WarehouseOutForm, {
      global: {
        plugins: [createTestingPinia()],
        stubs: {
          NForm: true,
          NFormItem: true,
          NGrid: true,
          NGi: true,
          NSelect: true,
          NInput: true,
          NInputNumber: true,
          NButton: true
        }
      },
      props: {
        warehouseOutId: 1
      }
    })

    expect(wrapper.props('warehouseOutId')).toBe(1)
  })
})
