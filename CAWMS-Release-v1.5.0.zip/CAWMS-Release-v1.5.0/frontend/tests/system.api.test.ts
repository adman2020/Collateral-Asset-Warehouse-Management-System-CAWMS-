/**
 * System API 测试 - 系统管理模块
 */

import { describe, it, expect, beforeEach, vi } from 'vitest'
import { getUserList, getRoleList, getAuditLogList, getSystemStatistics } from '~/api/system'
import { api } from '~/utils/request'

vi.mock('~/utils/request', () => ({
  api: { get: vi.fn(), post: vi.fn(), put: vi.fn(), delete: vi.fn() }
}))

describe('System API', () => {
  beforeEach(() => { vi.clearAllMocks() })

  describe('getUserList', () => {
    it('应该成功获取用户列表', async () => {
      const mockData = { code: 0, data: { records: [{ id: 1, username: 'admin' }], total: 1 } }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })
      const result = await getUserList({ page: 1, size: 10 })
      expect(api.get).toHaveBeenCalledWith('/api/system/users', { params: { page: 1, size: 10 } })
      expect(result.data.data.records).toHaveLength(1)
    })
  })

  describe('getRoleList', () => {
    it('应该成功获取角色列表', async () => {
      const mockData = { code: 0, data: { records: [{ id: 1, roleName: 'Admin' }], total: 1 } }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })
      const result = await getRoleList({ page: 1, size: 10 })
      expect(result.data.data.records).toHaveLength(1)
    })
  })

  describe('getAuditLogList', () => {
    it('应该成功获取审计日志列表', async () => {
      const mockData = { code: 0, data: { records: [{ id: 1, operation: 'LOGIN' }], total: 1 } }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })
      const result = await getAuditLogList({ page: 1, size: 10 })
      expect(result.data.data.records).toHaveLength(1)
    })
  })

  describe('getSystemStatistics', () => {
    it('应该成功获取系统统计', async () => {
      const mockData = { code: 0, data: { totalUsers: 100, activeUsers: 80 } }
      vi.mocked(api.get).mockResolvedValue({ data: mockData })
      const result = await getSystemStatistics()
      expect(result.data.data.totalUsers).toBe(100)
    })
  })
})
