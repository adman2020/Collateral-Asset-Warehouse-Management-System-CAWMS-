export default defineNuxtPlugin(async (nuxtApp) => {
  const i18n = nuxtApp.$i18n as any

  // 清理之前可能保存的错误语言设置
  const savedLocale = localStorage.getItem('locale')
  if (savedLocale === 'en') {
    localStorage.removeItem('locale')
  }

  const localeToUse = savedLocale && ['zh', 'vi', 'en'].includes(savedLocale) ? savedLocale : 'zh'

  // 使用 setLocale 确保懒加载的语言包被正确加载
  if (i18n.setLocale) {
    await i18n.setLocale(localeToUse)
  } else if (i18n.locale) {
    i18n.locale.value = localeToUse
  }
})
