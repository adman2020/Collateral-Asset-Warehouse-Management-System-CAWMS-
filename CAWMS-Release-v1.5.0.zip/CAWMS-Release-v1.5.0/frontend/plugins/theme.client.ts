import { useThemeState } from '@/composables/useThemeState'

/**
 * Theme initialization plugin
 * Reads saved theme from localStorage and applies data-theme attribute.
 */
export default defineNuxtPlugin(() => {
  const { initThemeMode } = useThemeState()

  // Initialize on app mount
  initThemeMode()

  // Listen for system color scheme changes
  const mq = window.matchMedia('(prefers-color-scheme: dark)')
  mq.addEventListener('change', () => {
    const saved = localStorage.getItem('theme')
    if (!saved || saved === 'system') {
      initThemeMode()
    }
  })
})
