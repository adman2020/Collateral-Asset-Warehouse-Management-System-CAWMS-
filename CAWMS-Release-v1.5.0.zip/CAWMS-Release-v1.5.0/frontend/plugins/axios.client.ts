/**
 * Axios 插件
 * 提供全局的HTTP客户端配置和拦截器
 */

import { defineNuxtPlugin } from '#app'
import axios from 'axios'
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios'
import { useAuthStore } from '@/stores/auth'

// 创建axios实例
// 注意：不设置默认 Content-Type，让 axios 根据请求体自动检测
// （FormData → multipart/form-data，普通对象 → application/json）
const axiosInstance: AxiosInstance = axios.create({
  baseURL: 'http://localhost',
  timeout: parseInt(process.env.API_TIMEOUT || '10000'),
  headers: {
    'X-Requested-With': 'XMLHttpRequest'
  },
  withCredentials: process.env.NODE_ENV === 'production',
  validateStatus: (status) => status >= 200 && status < 500
})

// 请求拦截器
axiosInstance.interceptors.request.use(
  (config: AxiosRequestConfig) => {
    const authStore = useAuthStore()

    // 优先从 authStore 获取 token，否则兜底从 localStorage 读取
    let token = authStore.token
    if (!token && typeof window !== 'undefined') {
      token = localStorage.getItem('token')
    }

    // 添加认证令牌
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`
    }

    // 获取用户信息（优先 authStore，其次 sessionStorage 兜底）
    let userId = authStore.user?.id
    let userName = authStore.user?.username
    if ((!userId && !userName) && typeof window !== 'undefined') {
      try {
        const saved = sessionStorage.getItem('userInfo')
        if (saved) {
          const userInfo = JSON.parse(saved)
          userId = userInfo?.id
          userName = userInfo?.username
        }
      } catch { /* ignore */ }
    }

    // 添加用户ID（部分后端接口需要）
    if (config.headers) {
      if (userId) {
        config.headers['X-User-Id'] = String(userId)
      } else if (userName) {
        config.headers['X-User-Id'] = userName
      }
      if (userName) {
        config.headers['X-User-Name'] = userName
      }
    }

    // 添加请求ID（用于追踪）
    if (config.headers) {
      config.headers['X-Request-ID'] = generateRequestId()
    }

    // 开发环境日志
    if (process.env.NODE_ENV === 'development') {
      console.log(`🌐 [${config.method?.toUpperCase()}] ${config.url}`, {
        params: config.params,
        data: config.data
      })
    }

    return config
  },
  (error: AxiosError) => {
    console.error('请求配置错误:', error)
    return Promise.reject(error)
  }
)

// 响应拦截器
axiosInstance.interceptors.response.use(
  (response: AxiosResponse) => {
    // 开发环境日志
    if (process.env.NODE_ENV === 'development') {
      console.log(`✅ [${response.status}] ${response.config.url}`, response.data)
    }
    
    // 处理业务逻辑
    const data = response.data
    
    // 如果响应有标准格式，检查业务状态
    if (data && typeof data === 'object' && 'success' in data) {
      if (!data.success) {
        // 业务逻辑错误
        return Promise.reject(new Error(data.message || '业务请求失败'))
      }
    }
    
    return response
  },
  (error: AxiosError) => {
    const authStore = useAuthStore()
    
    // 响应错误处理
    if (error.response) {
      const { status, data } = error.response
      
      // 开发环境日志
      if (process.env.NODE_ENV === 'development') {
        console.error(`❌ [${status}] ${error.config?.url}`, data)
      }
      
      // 处理特定状态码
      switch (status) {
        case 401: // 未授权
          console.warn('用户未授权，清除认证信息')
          authStore.clearAuthState()
          
          // 重定向到登录页（避免在SSR中）
          if (typeof window !== 'undefined') {
            const currentPath = window.location.pathname
            if (!currentPath.includes('/login')) {
              window.location.href = `/login?redirect=${encodeURIComponent(currentPath)}`
            }
          }
          break
          
        case 403: // 禁止访问
          console.warn('权限不足，禁止访问')
          if (typeof window !== 'undefined') {
            window.location.href = '/403'
          }
          break
          
        case 404: // 未找到
          console.warn('请求的资源不存在')
          break
          
        case 429: // 请求过多
          console.warn('请求过于频繁，请稍后再试')
          break
          
        case 500: // 服务器错误
        case 502: // 网关错误
        case 503: // 服务不可用
        case 504: // 网关超时
          console.error('服务器错误，请稍后再试')
          break
          
        default:
          console.error(`HTTP错误 ${status}:`, error.message)
      }
      
      // 提取错误消息
      let errorMessage = '网络请求失败'
      if (data && typeof data === 'object') {
        errorMessage = (data as any).message || errorMessage
      } else if (typeof data === 'string') {
        errorMessage = data
      }
      
      error.message = errorMessage
    } else if (error.request) {
      // 请求已发出但没有收到响应
      console.error('网络连接失败，请检查网络设置')
      error.message = '网络连接失败，请检查网络设置'
    } else {
      // 请求配置错误
      console.error('请求配置错误:', error.message)
    }
    
    return Promise.reject(error)
  }
)

// 生成请求ID
function generateRequestId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
}

// 导出工具函数
export function useAxios(): AxiosInstance {
  return axiosInstance
}

// 导出请求方法
export const $get = axiosInstance.get
export const $post = axiosInstance.post
export const $put = axiosInstance.put
export const $patch = axiosInstance.patch
export const $delete = axiosInstance.delete
export const $head = axiosInstance.head
export const $options = axiosInstance.options
export const $request = axiosInstance.request

// 导出类型
export type { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError }

// Nuxt 插件
export default defineNuxtPlugin((nuxtApp) => {
  // 使用运行时配置覆盖 baseURL，确保客户端总是拿到最新的 API 地址
  const config = useRuntimeConfig()
  if (config.public.apiBaseUrl) {
    axiosInstance.defaults.baseURL = String(config.public.apiBaseUrl)
  }
  
  // 将axios实例挂载到app上下文
  nuxtApp.vueApp.provide('$axios', axiosInstance)
  nuxtApp.vueApp.config.globalProperties.$axios = axiosInstance
})

/**
 * 使用示例：
 * 
 * // 在nuxt.config.ts中配置
 * export default defineNuxtConfig({
 *   plugins: [
 *     { src: '@/plugins/axios', mode: 'client' }
 *   ]
 * })
 * 
 * // 在组件中使用
 * <script setup>
 * import { useAxios } from '@/plugins/axios'
 * 
 * const axios = useAxios()
 * 
 * // 发起请求
 * const fetchData = async () => {
 *   try {
 *     const response = await axios.get('/api/data')
 *     console.log(response.data)
 *   } catch (error) {
 *     console.error(error)
 *   }
 * }
 * </script>
 * 
 * // 或者使用导出的方法
 * import { $get, $post } from '@/plugins/axios'
 * 
 * $get('/api/data').then(data => {
 *   console.log(data)
 * })
 */