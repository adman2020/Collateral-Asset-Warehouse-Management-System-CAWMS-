/**
 * Naive UI 插件
 * 提供Naive UI组件库的全局配置和主题定制
 */

import { defineNuxtPlugin } from '#app'
import {
  // 全局组件
  NConfigProvider,
  NMessageProvider,
  NNotificationProvider,
  NDialogProvider,
  NLoadingBarProvider,
  
  // 布局组件
  NLayout,
  NLayoutHeader,
  NLayoutSider,
  NLayoutContent,
  NLayoutFooter,
  NGrid,
  NGridItem,
  
  // 导航组件
  NMenu,
  NBreadcrumb,
  NBreadcrumbItem,
  NDropdown,
  NTabs,
  NTabPane,
  
  // 数据录入组件
  NButton,
  NInput,
  NInputNumber,
  NSelect,
  NRadio,
  NRadioGroup,
  NCheckbox,
  NCheckboxGroup,
  NSwitch,
  NDatePicker,
  NTimePicker,
  NForm,
  NFormItem,
  NUpload,
  NRate,
  NSlider,
  NColorPicker,
  
  // 数据展示组件
  NDataTable,
  NTable,
  NTag,
  NBadge,
  NAvatar,
  NAvatarGroup,
  NList,
  NListItem,
  NThing,
  NStatistic,
  NDescriptions,
  NDescriptionsItem,
  NEmpty,
  NProgress,
  NTree,
  NTreeSelect,
  NCard,
  NCarousel,
  NCollapse,
  NCollapseItem,
  NTooltip,
  NPopover,
  NPopconfirm,
  NModal,
  NDrawer,
  
  // 反馈组件
  NAlert,
  NResult,
  NSpin,
  NSkeleton,

  // 其他组件
  NBackTop,
  NAnchor,
  NAnchorLink,
  NPageHeader,
  NTimeline,
  NTimelineItem,
  NDivider,
  NWatermark,
  
  // 图标
  NIcon,
  
  // 主题和样式
  darkTheme,
  lightTheme,
  useOsTheme,
  
  // 工具函数
  useMessage,
  useNotification,
  useDialog,
  useLoadingBar,
  useModal
} from 'naive-ui'

// 导出所有组件，用于按需导入
export const naiveComponents = {
  // 全局组件
  NConfigProvider,
  NMessageProvider,
  NNotificationProvider,
  NDialogProvider,
  NLoadingBarProvider,
  
  // 布局组件
  NLayout,
  NLayoutHeader,
  NLayoutSider,
  NLayoutContent,
  NLayoutFooter,
  NGrid,
  NGridItem,
  
  // 导航组件
  NMenu,
  NBreadcrumb,
  NBreadcrumbItem,
  NDropdown,
  NTabs,
  NTabPane,
  
  // 数据录入组件
  NButton,
  NInput,
  NInputNumber,
  NSelect,
  NRadio,
  NRadioGroup,
  NCheckbox,
  NCheckboxGroup,
  NSwitch,
  NDatePicker,
  NTimePicker,
  NForm,
  NFormItem,
  NUpload,
  NRate,
  NSlider,
  NColorPicker,
  
  // 数据展示组件
  NDataTable,
  NTable,
  NTag,
  NBadge,
  NAvatar,
  NAvatarGroup,
  NList,
  NListItem,
  NThing,
  NStatistic,
  NDescriptions,
  NDescriptionsItem,
  NEmpty,
  NProgress,
  NTree,
  NTreeSelect,
  NCard,
  NCarousel,
  NCollapse,
  NCollapseItem,
  NTooltip,
  NPopover,
  NPopconfirm,
  NModal,
  NDrawer,
  
  // 反馈组件
  NAlert,
  NResult,
  NSpin,
  NSkeleton,

  // 其他组件
  NBackTop,
  NAnchor,
  NAnchorLink,
  NPageHeader,
  NTimeline,
  NTimelineItem,
  NDivider,
  NWatermark,
  
  // 图标
  NIcon
}

// 主题配置
export function setupNaiveUI() {
  // 自动检测系统主题
  const osThemeRef = useOsTheme()

  return {
    theme: osThemeRef.value === 'dark' ? darkTheme : lightTheme,
    themeOverrides: {
      common: {
        primaryColor: '#1890ff',
        primaryColorHover: '#40a9ff',
        primaryColorPressed: '#096dd9',
        primaryColorSuppl: '#096dd9',
        infoColor: '#1890ff',
        successColor: '#52c41a',
        warningColor: '#faad14',
        errorColor: '#f5222d',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
        fontSize: '14px',
        fontSizeMedium: '14px',
        fontSizeSmall: '12px',
        fontSizeLarge: '16px',
        fontSizeHuge: '20px'
      },
      Button: {
        borderRadiusMedium: '6px',
        borderRadiusSmall: '4px',
        borderRadiusLarge: '8px'
      },
      Card: {
        borderRadius: '8px',
        paddingMedium: '16px'
      },
      Menu: {
        borderRadius: '6px'
      }
    }
  }
}

// 导出主题工具
export { darkTheme, lightTheme, useOsTheme }

// 导出工具函数
export { useMessage, useNotification, useDialog, useLoadingBar, useModal }

// Nuxt 插件
export default defineNuxtPlugin((nuxtApp) => {
  const app = nuxtApp.vueApp

  // 全局注册所有组件（按需注册，实际使用时可能只注册部分）
  Object.entries(naiveComponents).forEach(([name, component]) => {
    app.component(name, component)
  })

  // 注册常用别名
  app.component('NGi', naiveComponents.NGridItem)

  // 提供全局工具函数
  app.provide('$message', useMessage)
  app.provide('$notification', useNotification)
  app.provide('$dialog', useDialog)
  app.provide('$loadingBar', useLoadingBar)
  app.provide('$modal', useModal)
})

/**
 * 使用示例：
 * 
 * // 在nuxt.config.ts中配置
 * export default defineNuxtConfig({
 *   plugins: [
 *     { src: '@/plugins/naive-ui', mode: 'client' }
 *   ]
 * })
 * 
 * // 在组件中使用
 * <template>
 *   <NConfigProvider :theme="theme">
 *     <NButton type="primary">按钮</NButton>
 *   </NConfigProvider>
 * </template>
 * 
 * <script setup>
 * import { useOsTheme, darkTheme } from '@/plugins/naive-ui'
 * 
 * const osTheme = useOsTheme()
 * const theme = computed(() => osTheme.value === 'dark' ? darkTheme : undefined)
 * </script>
 */