import type { AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios'
import { useAxios } from '@/plugins/axios.client'

/**
 * 通用响应接口
 */
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  message?: string
  code?: number
  timestamp?: number
}

/**
 * 分页响应接口
 */
export interface PaginatedResponse<T = any> extends ApiResponse<T[]> {
  page: number
  pageSize: number
  total: number
  totalPages: number
}

/**
 * 请求配置
 */
export interface RequestConfig extends AxiosRequestConfig {
  showError?: boolean // 是否显示错误消息
  retry?: number // 重试次数
  timeout?: number // 超时时间（毫秒）
  params?: Record<string, any> // 查询参数
  data?: Record<string, any> // 请求体数据
}

/**
 * 错误处理
 */
export class ApiError extends Error {
  code?: number
  status?: number
  response?: AxiosResponse

  constructor(message: string, code?: number, status?: number, response?: AxiosResponse) {
    super(message)
    this.name = 'ApiError'
    this.code = code
    this.status = status
    this.response = response
  }
}

/**
 * 创建请求函数
 */
export function createRequest<T = any>(config: RequestConfig): Promise<T> {
  const {
    showError = true,
    retry = 0,
    timeout = 10000,
    ...axiosConfig
  } = config

  const request = async (attempt = 0): Promise<T> => {
    try {
      // 设置超时
      if (timeout) {
        axiosConfig.timeout = timeout
      }

      const response = await useAxios().request<ApiResponse<T>>(axiosConfig)
      
      // 检查响应结构
      if (response.data && typeof response.data === 'object') {
        const apiResponse = response.data as ApiResponse<T>
        
        // 业务逻辑成功（显式success=true 或 没有success字段但code为0）
        const isSuccess = apiResponse.success === true || 
          (apiResponse.success === undefined && apiResponse.code === 0)
        
        if (isSuccess) {
          return apiResponse.data as T
        } else {
          // 业务逻辑错误
          throw new ApiError(
            apiResponse.message || '业务请求失败',
            apiResponse.code,
            response.status,
            response
          )
        }
      }
      
      // 直接返回数据（如果没有包装）
      return response.data as T
    } catch (error) {
      const axiosError = error as AxiosError<ApiResponse>
      
      // 处理重试
      if (attempt < retry && axiosError.response?.status && axiosError.response.status >= 500) {
        console.warn(`请求失败，正在重试 (${attempt + 1}/${retry})`, axiosError.message)
        await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1))) // 指数退避
        return request(attempt + 1)
      }
      
      // 错误处理
      let errorMessage = '网络请求失败'
      let errorCode: number | undefined
      
      if (axiosError.response) {
        const responseData = axiosError.response.data as ApiResponse
        errorMessage = responseData?.message || axiosError.message || `HTTP ${axiosError.response.status}`
        errorCode = responseData?.code || axiosError.response.status
      } else if (axiosError.request) {
        errorMessage = '网络连接失败，请检查网络设置'
      } else {
        errorMessage = axiosError.message || '未知错误'
      }
      
      // 显示错误消息（根据配置）
      if (showError && typeof window !== 'undefined') {
        console.error('请求错误:', errorMessage)
        // 这里可以集成Naive UI的通知组件
        // message.error(errorMessage)
      }
      
      throw new ApiError(
        errorMessage,
        errorCode,
        axiosError.response?.status,
        axiosError.response
      )
    }
  }
  
  return request()
}

/**
 * GET 请求
 */
export function get<T = any>(url: string, config?: RequestConfig): Promise<T> {
  return createRequest<T>({
    method: 'GET',
    url,
    ...config
  })
}

/**
 * POST 请求
 */
export function post<T = any>(url: string, data?: any, config?: RequestConfig): Promise<T> {
  return createRequest<T>({
    method: 'POST',
    url,
    data,
    ...config
  })
}

/**
 * PUT 请求
 */
export function put<T = any>(url: string, data?: any, config?: RequestConfig): Promise<T> {
  return createRequest<T>({
    method: 'PUT',
    url,
    data,
    ...config
  })
}

/**
 * PATCH 请求
 */
export function patch<T = any>(url: string, data?: any, config?: RequestConfig): Promise<T> {
  return createRequest<T>({
    method: 'PATCH',
    url,
    data,
    ...config
  })
}

/**
 * DELETE 请求
 */
export function del<T = any>(url: string, config?: RequestConfig): Promise<T> {
  return createRequest<T>({
    method: 'DELETE',
    url,
    ...config
  })
}

/**
 * 上传文件
 */
export function upload<T = any>(url: string, file: File, config?: RequestConfig): Promise<T> {
  const formData = new FormData()
  formData.append('file', file)
  
  return createRequest<T>({
    method: 'POST',
    url,
    data: formData,
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    ...config
  })
}

/**
 * 下载文件
 */
export function download(url: string, filename?: string, config?: RequestConfig): Promise<void> {
  return createRequest<Blob>({
    method: 'GET',
    url,
    responseType: 'blob',
    ...config
  }).then(blob => {
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename || url.split('/').pop() || 'download'
    document.body.appendChild(a)
    a.click()
    window.URL.revokeObjectURL(url)
    document.body.removeChild(a)
  })
}

/**
 * 设置认证令牌
 */
export function setAuthToken(token: string | null): void {
  if (token) {
    localStorage.setItem('token', token)
  } else {
    localStorage.removeItem('token')
  }
}

/**
 * 获取认证令牌
 */
export function getAuthToken(): string | null {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('token')
  }
  return null
}

/**
 * 清除认证信息
 */
export function clearAuth(): void {
  localStorage.removeItem('token')
}

export default {
  createRequest,
  get,
  post,
  put,
  patch,
  del,
  upload,
  download,
  setAuthToken,
  getAuthToken,
  clearAuth
}