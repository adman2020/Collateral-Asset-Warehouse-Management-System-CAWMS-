import axios from 'axios'
import { useAuthStore } from '@/stores/auth'
import { getAuthToken } from './request'

const api = axios.create({
  baseURL: 'http://localhost',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Request interceptor
api.interceptors.request.use(
  (config) => {
    // Try localStorage first, then fallback to auth store
    let token = getAuthToken()

    if (!token && typeof window !== 'undefined') {
      try {
        const authStore = useAuthStore()
        token = authStore.token
      } catch (e) {
        // Auth store may not be available
      }
    }

    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`
    }

    // Add X-User-Id header for backend APIs that require it
    if (typeof window !== 'undefined' && config.headers) {
      let userId: string | null = null
      try {
        const authStore = useAuthStore()
        if (authStore.user?.id) {
          userId = String(authStore.user.id)
        } else if (authStore.user?.username) {
          userId = authStore.user.username
        }
      } catch (e) {
        // Auth store may not be available
      }

      // Fallback to sessionStorage if authStore user is not available
      if (!userId) {
        try {
          const userInfoStr = sessionStorage.getItem('userInfo')
          if (userInfoStr) {
            const userInfo = JSON.parse(userInfoStr)
            if (userInfo.id) {
              userId = String(userInfo.id)
            } else if (userInfo.username) {
              userId = userInfo.username
            }
          }
        } catch (e) {
          // ignore
        }
      }

      if (userId) {
        config.headers['X-User-Id'] = userId
      }

      // Add X-User-Name header
      let userName: string | null = null
      try {
        const authStore = useAuthStore()
        if (authStore.user?.username) {
          userName = authStore.user.username
        }
      } catch (e) {
        // ignore
      }
      if (!userName) {
        try {
          const userInfoStr = sessionStorage.getItem('userInfo')
          if (userInfoStr) {
            const userInfo = JSON.parse(userInfoStr)
            if (userInfo.username) {
              userName = userInfo.username
            }
          }
        } catch (e) {
          // ignore
        }
      }
      if (userName && config.headers) {
        config.headers['X-User-Name'] = userName
      }
    }

    console.log(`[API Request] ${config.method?.toUpperCase()} ${config.url}`, config.data, config.headers)
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor
api.interceptors.response.use(
  (response) => {
    console.log(`[API Response] ${response.status} ${response.config.url}`, response.data)
    return response
  },
  (error) => {
    console.error(`[API Error] ${error.config?.url}`, error.response?.status, error.response?.data || error.message)
    if (error.response?.status === 401) {
      // Handle unauthorized
      console.error('Unauthorized')
    }
    // 提取后端返回的友好错误信息
    if (error.response?.data?.message) {
      error.message = error.response.data.message
    } else if (error.response?.data && typeof error.response.data === 'string') {
      error.message = error.response.data
    }
    return Promise.reject(error)
  }
)

export default api
