@echo off
chcp 65001 >nul
color 0E
mode con: cols=80 lines=20

echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║                 HTTP服务器测试模式                      ║
echo ╠══════════════════════════════════════════════════════════╣
echo ║                                                          ║
echo ║  此模式可解决文件协议(file://)的安全限制问题。           ║
echo ║                                                          ║
echo ║  将在端口 8080 启动本地HTTP服务器。                     ║
echo ║  浏览器打开后请访问: http://localhost:8080/dashboard.html║
echo ║                                                          ║
echo ║  按任意键启动HTTP服务器...                              ║
echo ║                                                          ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
pause >nul

echo 正在启动HTTP服务器...
echo 请勿关闭此窗口，它将作为服务器运行。
echo.
echo 浏览器将自动打开，如果没有自动打开，请手动访问:
echo http://localhost:8080/dashboard.html
echo.
echo 登录凭证: admin/admin123 或 user/user123
echo.
echo 按 Ctrl+C 停止服务器。
echo.

REM 检查Python版本
python -c "import sys; print('Python版本:', sys.version)" 2>nul
if errorlevel 1 (
    echo 错误: 未找到Python，请先安装Python。
    pause
    exit /b 1
)

REM 启动HTTP服务器并在浏览器中打开
start "" "http://localhost:8080/dashboard.html"
python -m http.server 8080 --directory "%~dp0"