#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成完整新版初始化脚本 init_v2.sql
基于旧版本 init.sql 和当前数据库结构
"""

import re
import subprocess
import sys

def run_mysql_query(query):
    """执行MySQL查询并返回结果"""
    cmd = ['mysql', '-u', 'root', '-pG-;fnxjV4Ck(', '-D', 'cawms', '-e', query]
    result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='ignore')
    return result.stdout.strip()

def get_table_create_statement(table_name):
    """获取表的CREATE语句"""
    output = run_mysql_query(f'SHOW CREATE TABLE `{table_name}`')
    lines = output.split('\n')
    if len(lines) > 1:
        # 找到CREATE TABLE语句
        for line in lines:
            if 'CREATE TABLE' in line:
                # 清理输出，移除可能的控制字符
                line = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', line)
                return line
    return None

def get_view_create_statement(view_name):
    """获取视图的CREATE语句"""
    output = run_mysql_query(f'SHOW CREATE VIEW `{view_name}`')
    lines = output.split('\n')
    if len(lines) > 1:
        for line in lines:
            if 'CREATE VIEW' in line:
                line = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', line)
                return line
    return None

def get_routines():
    """获取存储过程和函数"""
    routines = []
    
    # 获取存储过程
    output = run_mysql_query("SHOW PROCEDURE STATUS WHERE Db = 'cawms'")
    lines = output.split('\n')
    for line in lines[1:]:  # 跳过标题行
        if line.strip():
            parts = line.split('\t')
            if len(parts) > 1:
                proc_name = parts[1]
                # 获取存储过程定义
                create_output = run_mysql_query(f"SHOW CREATE PROCEDURE `{proc_name}`")
                for create_line in create_output.split('\n'):
                    if 'CREATE PROCEDURE' in create_line:
                        create_line = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', create_line)
                        routines.append(create_line + ';')
                        break
    
    # 获取函数
    output = run_mysql_query("SHOW FUNCTION STATUS WHERE Db = 'cawms'")
    lines = output.split('\n')
    for line in lines[1:]:
        if line.strip():
            parts = line.split('\t')
            if len(parts) > 1:
                func_name = parts[1]
                # 获取函数定义
                create_output = run_mysql_query(f"SHOW CREATE FUNCTION `{func_name}`")
                for create_line in create_output.split('\n'):
                    if 'CREATE FUNCTION' in create_line:
                        create_line = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', create_line)
                        routines.append(create_line + ';')
                        break
    
    return routines

def read_old_sql(file_path):
    """读取旧版本SQL文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def read_fix_sql(file_path):
    """读取修复SQL文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def generate_init_v2(old_sql, fix_sql):
    """生成新版初始化脚本"""
    # 新增的8个表
    new_tables = [
        'flyway_schema_history',
        'report_chart_config',
        'report_config',
        'report_data_cache',
        'report_execution_log',
        'report_statistics',
        'report_template',
        'v_report_dashboard'  # 视图
    ]
    
    lines = []
    
    # 1. 头部信息
    lines.append("-- ============================================")
    lines.append("-- SeABank CAWMS Database Initialization Script V2")
    lines.append("-- MySQL 8.x")
    lines.append("-- 基于旧版本 (2026-04-15) 升级到最新版本 (2026-04-21)")
    lines.append("-- 生成时间: 2026-04-21")
    lines.append("-- 包含:")
    lines.append("--   - 15个基础表 (来自旧版本)")
    lines.append("--   - 现有表的字段修复 (来自fix_schema_generated.sql)")
    lines.append("--   - 8个新增表 (报表相关和Flyway)")
    lines.append("--   - 视图、存储过程、函数")
    lines.append("-- ============================================")
    lines.append("")
    
    # 2. 数据库创建
    lines.append("-- 创建数据库")
    lines.append("CREATE DATABASE IF NOT EXISTS cawms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
    lines.append("")
    lines.append("USE cawms;")
    lines.append("")
    
    # 3. 旧版本的表定义（从旧SQL中提取）
    lines.append("-- ============================================")
    lines.append("-- 1. 基础表结构 (来自旧版本)")
    lines.append("-- ============================================")
    lines.append("")
    
    # 从旧SQL中提取CREATE TABLE语句
    old_tables_section = []
    in_create_table = False
    current_table = []
    
    for line in old_sql.split('\n'):
        if 'CREATE TABLE IF NOT EXISTS' in line:
            in_create_table = True
            current_table = [line]
        elif in_create_table:
            current_table.append(line)
            if line.strip().endswith(';'):
                in_create_table = False
                old_tables_section.extend(current_table)
                old_tables_section.append("")
    
    # 添加旧版本的表定义
    lines.extend(old_tables_section)
    
    # 4. 修复语句
    lines.append("-- ============================================")
    lines.append("-- 2. 现有表字段修复 (来自 fix_schema_generated.sql)")
    lines.append("-- ============================================")
    lines.append("")
    
    # 添加修复语句
    lines.append(fix_sql)
    lines.append("")
    
    # 5. 新增的表
    lines.append("-- ============================================")
    lines.append("-- 3. 新增表 (报表相关和Flyway)")
    lines.append("-- ============================================")
    lines.append("")
    
    for table in new_tables:
        if table == 'v_report_dashboard':
            # 这是视图，稍后处理
            continue
            
        create_stmt = get_table_create_statement(table)
        if create_stmt:
            # 将CREATE TABLE改为CREATE TABLE IF NOT EXISTS
            create_stmt = re.sub(r'CREATE TABLE', 'CREATE TABLE IF NOT EXISTS', create_stmt)
            lines.append(create_stmt + ';')
            lines.append("")
    
    # 6. 视图
    lines.append("-- ============================================")
    lines.append("-- 4. 视图")
    lines.append("-- ============================================")
    lines.append("")
    
    view_stmt = get_view_create_statement('v_report_dashboard')
    if view_stmt:
        lines.append(view_stmt + ';')
        lines.append("")
    
    # 7. 存储过程和函数
    lines.append("-- ============================================")
    lines.append("-- 5. 存储过程和函数")
    lines.append("-- ============================================")
    lines.append("")
    
    routines = get_routines()
    if routines:
        for routine in routines:
            lines.append(routine)
            lines.append("")
    else:
        lines.append("-- 当前数据库中没有存储过程或函数")
        lines.append("")
    
    # 8. 初始化数据（从旧SQL中提取INSERT语句）
    lines.append("-- ============================================")
    lines.append("-- 6. 初始化数据")
    lines.append("-- ============================================")
    lines.append("")
    
    # 从旧SQL中提取INSERT语句部分
    in_insert_section = False
    insert_lines = []
    
    for line in old_sql.split('\n'):
        if '-- 初始化数据' in line or '-- ============================================' in line and in_insert_section:
            in_insert_section = True
            continue
        
        if in_insert_section and line.strip().startswith('INSERT INTO'):
            insert_lines.append(line)
        elif in_insert_section and line.strip().startswith('--') and '索引' in line:
            # 到达索引部分，停止
            break
    
    if insert_lines:
        lines.extend(insert_lines)
        lines.append("")
    else:
        lines.append("-- 初始化数据需要从旧版本复制")
        lines.append("")
    
    # 9. 索引和优化（从旧SQL中提取）
    lines.append("-- ============================================")
    lines.append("-- 7. 索引和性能优化")
    lines.append("-- ============================================")
    lines.append("")
    
    # 从旧SQL中提取索引部分
    in_index_section = False
    index_lines = []
    
    for line in old_sql.split('\n'):
        if '-- 额外索引优化' in line or '-- 索引策略总结' in line:
            in_index_section = True
        
        if in_index_section and line.strip().startswith('CREATE INDEX'):
            index_lines.append(line)
        elif in_index_section and line.strip().startswith('--') and '数据库性能优化建议' in line:
            # 跳过注释
            pass
    
    if index_lines:
        lines.extend(index_lines)
        lines.append("")
    else:
        lines.append("-- 索引定义需要从旧版本复制")
        lines.append("")
    
    # 10. 结束注释
    lines.append("-- ============================================")
    lines.append("-- 初始化脚本生成完成")
    lines.append("-- 执行说明:")
    lines.append("--   1. 确保MySQL版本为8.x")
    lines.append("--   2. 确保有足够的权限")
    lines.append("--   3. 建议在测试环境先验证")
    lines.append("--   4. 生产环境执行前请备份数据")
    lines.append("-- ============================================")
    
    return "\n".join(lines)

def main():
    if len(sys.argv) != 4:
        print("用法: python generate_init_v2.py <旧版本SQL> <修复SQL> <输出文件>")
        sys.exit(1)
    
    old_file = sys.argv[1]
    fix_file = sys.argv[2]
    output_file = sys.argv[3]
    
    print("读取旧版本SQL文件...")
    old_sql = read_old_sql(old_file)
    
    print("读取修复SQL文件...")
    fix_sql = read_fix_sql(fix_file)
    
    print("生成新版初始化脚本...")
    init_v2 = generate_init_v2(old_sql, fix_sql)
    
    print("写入输出文件...")
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(init_v2)
    
    print(f"新版初始化脚本已生成: {output_file}")
    print(f"文件大小: {len(init_v2)} 字节")

if __name__ == '__main__':
    main()