@echo off
chcp 65001 >nul
echo ==========================================
echo           任务完成状态检查
echo ==========================================
echo.
echo 检查时间: %date% %time%
echo 工作目录: %cd%
echo.

if not exist "D:\frontend\TASK_STATUS.txt" (
    echo ❌ 错误: 状态文件不存在
    echo 请确认是否在正确目录
    pause
    exit /b 1
)

echo ✅ 检测到任务状态文件
echo.

echo === 简要状态 ===
findstr /C:"TASK STATUS:" "D:\frontend\TASK_STATUS.txt"
echo.

echo === 已完成任务 ===
findstr /C:"Task13" "D:\frontend\TASK_STATUS.txt"
findstr /C:"Task14" "D:\frontend\TASK_STATUS.txt"
echo.

echo === 文件修改时间 ===
echo dashboard.html:     %~t0D:\frontend\dashboard.html 2>nul || echo 文件不存在
echo warehouse-in.html:  %~t0D:\frontend\warehouse-in.html 2>nul || echo 文件不存在
echo loan-out.html:      %~t0D:\frontend\loan-out.html 2>nul || echo 文件不存在
echo.

echo === 快速验证 ===
echo 1. 双击打开 dashboard.html
echo 2. 使用以下凭证登录:
echo    用户名: admin    密码: admin123
echo    用户名: user     密码: user123
echo 3. 导航到入库管理或借出管理页面
echo 4. 测试搜索、筛选和操作按钮
echo.

echo === 详细报告 ===
echo 完整报告: D:\frontend\COMPLETION.md
echo 状态文件: D:\frontend\TASK_STATUS.txt
echo.

echo ==========================================
echo 按任意键打开 dashboard.html，按 Ctrl+C 取消...
pause >nul

start "" "D:\frontend\dashboard.html"
echo.
echo 页面已打开，请测试功能。
echo 按任意键退出...
pause >nul