# CAWMS 发布包 - 独立部署指南

## 系统要求

- Docker Engine 24.0+
- Docker Compose 2.20+
- 可用磁盘空间：>= 5GB
- 内存：>= 4GB

## 包内容说明

```
.
├── docker-compose.yml          # Docker Compose 部署配置
├── .env.example                # 环境变量模板
├── database/
│   ├── cawms_final_clean.sql   # 完整数据库脚本（结构+数据）
│   └── cawms_data_only_clean.sql # 纯数据脚本
├── deployment/nginx/           # Nginx 配置文件
├── images/
│   ├── backend.tar             # 后端镜像（cawms-backend:release）
│   └── frontend.tar            # 前端镜像（cawms-frontend:release）
└── README.md                   # 本文件
```

## 快速部署步骤

### 1. 加载 Docker 镜像

```bash
docker load -i images/backend.tar
docker load -i images/frontend.tar
```

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env，修改所有密码（特别是 MYSQL_ROOT_PASSWORD、MYSQL_PASSWORD、REDIS_PASSWORD、JWT_SECRET）
```

### 3. 启动服务

```bash
docker-compose up -d
```

### 4. 等待服务就绪

首次启动需要约 1-2 分钟（MySQL 初始化数据库）：

```bash
docker-compose ps
```

### 5. 访问系统

- 前端界面：http://localhost
- 后端 API：http://localhost:8080/api
- 健康检查：http://localhost:8080/actuator/health

## 默认账号

| 账号 | 密码 | 角色 |
|------|------|------|
| admin | admin123 | 超级管理员 |

> **注意**：部署后请立即修改默认密码。

## 常用命令

```bash
# 查看日志
docker-compose logs -f

# 查看后端日志
docker-compose logs -f backend

# 停止服务
docker-compose down

# 停止并删除数据卷（谨慎使用）
docker-compose down -v

# 重启服务
docker-compose restart

# 进入 MySQL
docker-compose exec mysql mysql -u root -p${MYSQL_ROOT_PASSWORD} cawms
```

## 数据库说明

- `cawms_final_clean.sql`：包含完整的表结构和所有测试/业务数据，首次部署时自动导入
- `cawms_data_only_clean.sql`：仅包含 INSERT 数据，适用于已有表结构的场景

## 注意事项

1. **安全**：生产环境请务必修改 `.env` 中的所有默认密码，特别是 `JWT_SECRET`（建议 64 位随机字符串）
2. **端口**：默认占用 80（Nginx）和 8080（后端 API），如有冲突请修改 `docker-compose.yml`
3. **数据持久化**：MySQL 数据保存在 Docker Volume `mysql_data` 中，删除卷会导致数据丢失
4. **时区**：默认时区为 Asia/Ho_Chi_Minh，如需修改请调整 `.env` 中的 `TZ`

## 技术支持

如有部署问题，请检查各容器健康状态：

```bash
docker-compose ps
docker-compose logs --tail 50
```
