package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.WarehouseInEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * WarehouseInService unit tests using mock
 */
@ExtendWith(SpringExtension.class)
@DisplayName("WarehouseInService Tests")
class WarehouseInServiceTest {

    @Mock
    private WarehouseInService warehouseInService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    private WarehouseInEntity buildEntity(String whCode, String status) {
        WarehouseInEntity entity = new WarehouseInEntity();
        entity.setWhCode(whCode);
        entity.setStatus(status);
        entity.setCustomerName("Test Customer");
        entity.setCollateralType("REAL_ESTATE");
        entity.setCollateralValue(new BigDecimal("1000000000"));
        entity.setBuCode("BU001");
        entity.setIntakeType("NEW");
        return entity;
    }

    @Test
    @DisplayName("createWarehouseIn returns created entity")
    void testCreateWarehouseIn_Success() {
        WarehouseInEntity entity = buildEntity("WH-20240101-00001", "DRAFT");
        when(warehouseInService.createWarehouseIn(any())).thenReturn(entity);

        WarehouseInEntity result = warehouseInService.createWarehouseIn(entity);

        assertThat(result).isNotNull();
        assertThat(result.getWhCode()).isEqualTo("WH-20240101-00001");
        assertThat(result.getStatus()).isEqualTo("DRAFT");
        verify(warehouseInService).createWarehouseIn(any());
    }

    @Test
    @DisplayName("updateWarehouseIn returns updated entity")
    void testUpdateWarehouseIn_Success() {
        WarehouseInEntity updated = buildEntity("WH-20240101-00001", "DRAFT");
        updated.setCustomerName("Updated Customer");
        when(warehouseInService.updateWarehouseIn(eq(1L), any())).thenReturn(updated);

        WarehouseInEntity result = warehouseInService.updateWarehouseIn(1L, updated);

        assertThat(result).isNotNull();
        assertThat(result.getCustomerName()).isEqualTo("Updated Customer");
        verify(warehouseInService).updateWarehouseIn(eq(1L), any());
    }

    @Test
    @DisplayName("deleteWarehouseIn returns true on success")
    void testDeleteWarehouseIn_Success() {
        when(warehouseInService.deleteWarehouseIn(1L)).thenReturn(true);

        boolean result = warehouseInService.deleteWarehouseIn(1L);

        assertThat(result).isTrue();
        verify(warehouseInService).deleteWarehouseIn(1L);
    }

    @Test
    @DisplayName("getWarehouseInById returns entity")
    void testGetWarehouseInById_Found() {
        WarehouseInEntity entity = buildEntity("WH-20240101-00001", "DRAFT");
        when(warehouseInService.getWarehouseInById(1L)).thenReturn(entity);

        WarehouseInEntity result = warehouseInService.getWarehouseInById(1L);

        assertThat(result).isNotNull();
        assertThat(result.getWhCode()).isEqualTo("WH-20240101-00001");
    }

    @Test
    @DisplayName("getWarehouseInById returns null when not found")
    void testGetWarehouseInById_NotFound() {
        when(warehouseInService.getWarehouseInById(999L)).thenReturn(null);

        WarehouseInEntity result = warehouseInService.getWarehouseInById(999L);

        assertThat(result).isNull();
    }

    @Test
    @DisplayName("queryWarehouseInList returns paginated results")
    void testQueryWarehouseInList_WithPagination() {
        Page<WarehouseInEntity> mockPage = new Page<>(1, 10);
        mockPage.setRecords(Arrays.asList(buildEntity("WH001", "DRAFT"), buildEntity("WH002", "SUBMITTED")));
        mockPage.setTotal(2);
        when(warehouseInService.queryWarehouseInList(1, 10, null, null, null)).thenReturn(mockPage);

        Page<WarehouseInEntity> result = warehouseInService.queryWarehouseInList(1, 10, null, null, null);

        assertThat(result).isNotNull();
        assertThat(result.getRecords()).hasSize(2);
        assertThat(result.getTotal()).isEqualTo(2);
    }

    @Test
    @DisplayName("submitWarehouseIn changes status to SUBMITTED")
    void testSubmitWarehouseIn_StatusChange() {
        WarehouseInEntity submitted = buildEntity("WH001", "SUBMITTED");
        when(warehouseInService.submitWarehouseIn(1L)).thenReturn(submitted);

        WarehouseInEntity result = warehouseInService.submitWarehouseIn(1L);

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("SUBMITTED");
        verify(warehouseInService).submitWarehouseIn(1L);
    }

    @Test
    @DisplayName("approveWarehouseIn processes approval")
    void testApproveWarehouseIn_Approve() {
        WarehouseInEntity approved = buildEntity("WH001", "UNDER_REVIEW");
        when(warehouseInService.approveWarehouseIn(1L, 1, "APPROVED", "Looks good")).thenReturn(approved);

        WarehouseInEntity result = warehouseInService.approveWarehouseIn(1L, 1, "APPROVED", "Looks good");

        assertThat(result).isNotNull();
        verify(warehouseInService).approveWarehouseIn(1L, 1, "APPROVED", "Looks good");
    }

    @Test
    @DisplayName("rejectWarehouseIn processes rejection")
    void testRejectWarehouseIn() {
        WarehouseInEntity rejected = buildEntity("WH001", "REJECTED");
        when(warehouseInService.rejectWarehouseIn(1L, 2, "Missing documents")).thenReturn(rejected);

        WarehouseInEntity result = warehouseInService.rejectWarehouseIn(1L, 2, "Missing documents");

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("REJECTED");
    }

    @Test
    @DisplayName("returnWarehouseIn processes return")
    void testReturnWarehouseIn() {
        WarehouseInEntity returned = buildEntity("WH001", "RETURNED");
        when(warehouseInService.returnWarehouseIn(1L, "Need revision")).thenReturn(returned);

        WarehouseInEntity result = warehouseInService.returnWarehouseIn(1L, "Need revision");

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("RETURNED");
    }

    @Test
    @DisplayName("getStatistics returns statistics map")
    void testGetStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", 100);
        stats.put("draft", 20);
        stats.put("submitted", 30);
        stats.put("completed", 50);
        when(warehouseInService.getStatistics()).thenReturn(stats);

        Map<String, Object> result = warehouseInService.getStatistics();

        assertThat(result).isNotNull();
        assertThat(result).containsKey("total");
        assertThat(result.get("total")).isEqualTo(100);
    }

    @Test
    @DisplayName("generateWarehouseNo returns non-null unique number")
    void testGenerateWarehouseNo() {
        when(warehouseInService.generateWarehouseNo())
                .thenReturn("WH202401010001")
                .thenReturn("WH202401010002");

        String no1 = warehouseInService.generateWarehouseNo();
        String no2 = warehouseInService.generateWarehouseNo();

        assertThat(no1).isNotNull().isNotEmpty();
        assertThat(no2).isNotNull().isNotEmpty();
        assertThat(no1).isNotEqualTo(no2);
    }

    @Test
    @DisplayName("queryPendingApprovals returns pending list")
    void testQueryPendingApprovals() {
        Page<WarehouseInEntity> mockPage = new Page<>(1, 10);
        mockPage.setRecords(List.of(buildEntity("WH001", "SUBMITTED")));
        mockPage.setTotal(1);
        when(warehouseInService.queryPendingApprovals("ROLE_APPROVER", 1, 10)).thenReturn(mockPage);

        Page<WarehouseInEntity> result = warehouseInService.queryPendingApprovals("ROLE_APPROVER", 1, 10);

        assertThat(result).isNotNull();
        assertThat(result.getRecords()).hasSize(1);
    }

    @Test
    @DisplayName("getApprovalHistory returns history list")
    void testGetApprovalHistory() {
        List<String> history = Arrays.asList("Step 1: Approved by user1", "Step 2: Pending");
        when(warehouseInService.getApprovalHistory(1L)).thenReturn(history);

        List<String> result = warehouseInService.getApprovalHistory(1L);

        assertThat(result).isNotNull().hasSize(2);
    }

    @Test
    @DisplayName("validateProof returns validation result")
    void testValidateProof() {
        Map<String, Object> validationResult = new HashMap<>();
        validationResult.put("valid", true);
        validationResult.put("message", "All documents verified");
        when(warehouseInService.validateProof(1L)).thenReturn(validationResult);

        Map<String, Object> result = warehouseInService.validateProof(1L);

        assertThat(result).isNotNull();
        assertThat(result.get("valid")).isEqualTo(true);
    }
}
