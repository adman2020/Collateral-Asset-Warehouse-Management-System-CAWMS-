package com.seabank.cawms.integration.t24;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * T24 Mock Service单元测试
 */
@ExtendWith(MockitoExtension.class)
@ActiveProfiles("demo")
class T24MockServiceTest {

    private T24MockService t24MockService;

    @BeforeEach
    void setUp() {
        t24MockService = new T24MockService();
    }

    @Test
    void testGetServiceName() {
        assertEquals("T24 Mock Service", t24MockService.getServiceName());
    }

    @Test
    void testIsAvailable() {
        assertTrue(t24MockService.isAvailable());
    }

    @Test
    void testGetStatus() {
        assertEquals(IntegrationService.ServiceStatus.AVAILABLE, t24MockService.getStatus());
    }

    @Test
    void testTestConnection() {
        IntegrationService.ConnectionTestResult result = t24MockService.testConnection();
        assertNotNull(result);
        assertTrue(result.isSuccess());
        assertTrue(result.getResponseTimeMs() > 0);
        assertNotNull(result.getMessage());
        assertNotNull(result.getVersion());
    }

    @Test
    void testGetAccountBalance() {
        String accountNumber = "1001001001";
        T24IntegrationService.AccountBalanceResponse response = t24MockService.getAccountBalance(accountNumber);
        
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals(accountNumber, response.getAccountNumber());
        assertNotNull(response.getBalance());
        assertNotNull(response.getCurrency());
        assertNotNull(response.getLastUpdated());
    }

    @Test
    void testGetAccountBalanceInvalidAccount() {
        String accountNumber = "INVALID_ACCOUNT";
        T24IntegrationService.AccountBalanceResponse response = t24MockService.getAccountBalance(accountNumber);
        
        assertNotNull(response);
        assertFalse(response.isSuccess());
        assertNotNull(response.getErrorMessage());
    }

    @Test
    void testGetAccountDetails() {
        String accountNumber = "1001001001";
        T24IntegrationService.AccountDetailsResponse response = t24MockService.getAccountDetails(accountNumber);
        
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals(accountNumber, response.getAccountNumber());
        assertNotNull(response.getAccountName());
        assertNotNull(response.getAccountType());
        assertNotNull(response.getCustomerId());
        assertNotNull(response.getCurrency());
        assertNotNull(response.getStatus());
    }

    @Test
    void testGetCustomerAccounts() {
        String customerId = "CUST001";
        T24IntegrationService.CustomerAccountsResponse response = t24MockService.getCustomerAccounts(customerId);
        
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals(customerId, response.getCustomerId());
        assertNotNull(response.getAccounts());
        assertFalse(response.getAccounts().isEmpty());
    }

    @Test
    void testProcessTransaction() {
        T24IntegrationService.TransactionRequest request = new T24IntegrationService.TransactionRequest();
        request.setTransactionId("TXN" + System.currentTimeMillis());
        request.setFromAccount("1001001001");
        request.setToAccount("2002002002");
        request.setAmount(new BigDecimal("1000000"));
        request.setCurrency("VND");
        request.setTransactionType("TRANSFER");
        request.setNarrative("Test transfer");
        request.setValueDate(LocalDateTime.now());
        
        T24IntegrationService.TransactionResponse response = t24MockService.processTransaction(request);
        
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertNotNull(response.getTransactionId());
        assertNotNull(response.getReferenceNumber());
        assertNotNull(response.getStatus());
        assertNotNull(response.getTransactionDate());
    }

    @Test
    void testProcessTransactionInvalidAccount() {
        T24IntegrationService.TransactionRequest request = new T24IntegrationService.TransactionRequest();
        request.setTransactionId("TXN" + System.currentTimeMillis());
        request.setFromAccount("INVALID_ACCOUNT");
        request.setToAccount("2002002002");
        request.setAmount(new BigDecimal("1000000"));
        request.setCurrency("VND");
        request.setTransactionType("TRANSFER");
        
        T24IntegrationService.TransactionResponse response = t24MockService.processTransaction(request);
        
        assertNotNull(response);
        assertFalse(response.isSuccess());
        assertNotNull(response.getErrorMessage());
    }

    @Test
    void testProcessTransactionInsufficientBalance() {
        T24IntegrationService.TransactionRequest request = new T24IntegrationService.TransactionRequest();
        request.setTransactionId("TXN" + System.currentTimeMillis());
        request.setFromAccount("1001001001");
        request.setToAccount("2002002002");
        request.setAmount(new BigDecimal("1000000000")); // 非常大的金额
        request.setCurrency("VND");
        request.setTransactionType("TRANSFER");
        
        T24IntegrationService.TransactionResponse response = t24MockService.processTransaction(request);
        
        assertNotNull(response);
        assertFalse(response.isSuccess());
        assertNotNull(response.getErrorMessage());
        assertTrue(response.getErrorMessage().contains("insufficient"));
    }

    @Test
    void testQueryTransactionStatus() {
        String transactionId = "TXN001";
        T24IntegrationService.TransactionStatusResponse response = t24MockService.queryTransactionStatus(transactionId);
        
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals(transactionId, response.getTransactionId());
        assertNotNull(response.getStatus());
        assertNotNull(response.getLastUpdated());
    }

    @Test
    void testGetTransactionHistory() {
        String accountNumber = "1001001001";
        LocalDateTime startDate = LocalDateTime.now().minusDays(7);
        LocalDateTime endDate = LocalDateTime.now();
        
        T24IntegrationService.TransactionHistoryResponse response = 
                t24MockService.getTransactionHistory(accountNumber, startDate, endDate);
        
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals(accountNumber, response.getAccountNumber());
        assertNotNull(response.getTransactions());
        assertFalse(response.getTransactions().isEmpty());
    }

    @Test
    void testGetCurrencyExchangeRate() {
        String fromCurrency = "USD";
        String toCurrency = "VND";
        
        T24IntegrationService.ExchangeRateResponse response = 
                t24MockService.getCurrencyExchangeRate(fromCurrency, toCurrency);
        
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals(fromCurrency, response.getFromCurrency());
        assertEquals(toCurrency, response.getToCurrency());
        assertNotNull(response.getExchangeRate());
        assertNotNull(response.getValidFrom());
        assertNotNull(response.getValidTo());
    }

    @Test
    void testGetAccountHoldings() {
        String accountNumber = "1001001001";
        
        T24IntegrationService.AccountHoldingsResponse response = 
                t24MockService.getAccountHoldings(accountNumber);
        
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals(accountNumber, response.getAccountNumber());
        assertNotNull(response.getHoldings());
    }

    @Test
    void testBatchAccountBalance() {
        List<String> accountNumbers = List.of("1001001001", "2002002002", "3003003003");
        
        T24IntegrationService.BatchAccountBalanceResponse response = 
                t24MockService.getBatchAccountBalance(accountNumbers);
        
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertNotNull(response.getResults());
        assertEquals(accountNumbers.size(), response.getResults().size());
        
        for (T24IntegrationService.AccountBalanceResponse balanceResponse : response.getResults()) {
            assertNotNull(balanceResponse);
            assertNotNull(balanceResponse.getAccountNumber());
        }
    }
}