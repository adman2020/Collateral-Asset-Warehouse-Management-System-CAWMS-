package com.seabank.cawms.service;

import com.seabank.cawms.service.impl.WarehouseCodeGeneratorImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/**
 * WarehouseCodeGenerator 单元测试
 * 测试仓库编码生成器的核心逻辑
 */
@DisplayName("WarehouseCodeGenerator 单元测试")
class WarehouseCodeGeneratorTest {

    private WarehouseCodeGenerator generator;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

    @BeforeEach
    void setUp() {
        generator = new WarehouseCodeGeneratorImpl();
    }

    @Test
    @DisplayName("generateWarehouseCode - 生成格式正确的编码")
    void testGenerateWarehouseCode_CorrectFormat() {
        String prefix = "WH";
        String dateStr = "20240101";
        String code = generator.generateWarehouseCode(prefix, dateStr);

        assertNotNull(code);
        assertTrue(code.startsWith("WH-20240101-"), "编码应以 WH-20240101- 开头，实际: " + code);
    }

    @Test
    @DisplayName("generateWarehouseCode - 序列号为5位补零格式")
    void testGenerateWarehouseCode_SequencePadded() {
        String code = generator.generateWarehouseCode("WH", "20240101");
        // 格式: PREFIX-YYYYMMDD-SSSSS
        String[] parts = code.split("-");
        assertEquals(3, parts.length, "编码应有3个部分");
        String seq = parts[2];
        assertEquals(5, seq.length(), "序列号应为5位");
        assertTrue(seq.matches("\\d{5}"), "序列号应为数字");
    }

    @Test
    @DisplayName("generateWarehouseCode - 连续生成的编码不重复")
    void testGenerateWarehouseCode_Uniqueness() {
        Set<String> codes = new HashSet<>();
        String dateStr = "20240101";
        for (int i = 0; i < 10; i++) {
            codes.add(generator.generateWarehouseCode("WH", dateStr));
        }
        assertEquals(10, codes.size(), "连续生成的10个编码应各不相同");
    }

    @Test
    @DisplayName("generateWarehouseCode - dateStr为null时使用当前日期")
    void testGenerateWarehouseCode_NullDateStr() {
        String code = generator.generateWarehouseCode("WH", null);
        assertNotNull(code);
        String today = LocalDateTime.now().format(DATE_FORMATTER);
        assertTrue(code.contains(today), "编码应包含今天的日期: " + today + ", 实际: " + code);
    }

    @Test
    @DisplayName("generateWarehouseCode - 不同前缀生成不同编码")
    void testGenerateWarehouseCode_DifferentPrefixes() {
        String code1 = generator.generateWarehouseCode("WH", "20240101");
        String code2 = generator.generateWarehouseCode("LO", "20240101");
        assertNotEquals(code1, code2);
        assertTrue(code1.startsWith("WH-"));
        assertTrue(code2.startsWith("LO-"));
    }

    @Test
    @DisplayName("generateWarehouseCode - 序列号递增")
    void testGenerateWarehouseCode_SequenceIncreasing() {
        // 使用新实例确保序列从0开始
        WarehouseCodeGenerator freshGenerator = new WarehouseCodeGeneratorImpl();
        String code1 = freshGenerator.generateWarehouseCode("WH", "20240101");
        String code2 = freshGenerator.generateWarehouseCode("WH", "20240101");

        int seq1 = Integer.parseInt(code1.split("-")[2]);
        int seq2 = Integer.parseInt(code2.split("-")[2]);
        assertTrue(seq2 > seq1, "第二个序列号应大于第一个");
    }

    @Test
    @DisplayName("generateWarehouseCode - 大量生成不超过序列号上限")
    void testGenerateWarehouseCode_SequenceRollover() {
        // 序列号使用 counter % 10000，验证不会抛出异常
        WarehouseCodeGenerator freshGenerator = new WarehouseCodeGeneratorImpl();
        assertDoesNotThrow(() -> {
            for (int i = 0; i < 100; i++) {
                freshGenerator.generateWarehouseCode("WH", "20240101");
            }
        });
    }
}
