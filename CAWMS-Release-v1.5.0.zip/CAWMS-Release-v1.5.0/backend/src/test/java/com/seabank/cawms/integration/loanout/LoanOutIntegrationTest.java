package com.seabank.cawms.integration.loanout;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.seabank.cawms.entity.LoanOutEntity;
import com.seabank.cawms.mapper.LoanOutMapper;
import com.seabank.cawms.service.LoanOutService;
import com.seabank.cawms.service.LoanOutService.LoanOutDetail;
import com.seabank.cawms.service.LoanOutService.T24SyncResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * 借出管理集成测试
 * 测试完整的借出管理业务流程
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class LoanOutIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private LoanOutService loanOutService;

    @Autowired
    private LoanOutMapper loanOutMapper;

    private LoanOutDetail testDraft;

    @BeforeEach
    void setUp() {
        // 准备测试数据
        testDraft = new LoanOutDetail();
        testDraft.setWhInId(100L);
        testDraft.setLoanPurpose("业务运营资金");
        testDraft.setLoanDuration(30);
        testDraft.setExpectedReturnDate(LocalDate.now().plusDays(30));
        testDraft.setStatus("DRAFT");
        testDraft.setT24SyncStatus("PENDING");
    }

    @Test
    void testCreateAndGetLoanOut() throws Exception {
        // 创建借出记录
        String createResponse = mockMvc.perform(post("/api/loan-out")
                .header("X-User-Id", "test_user")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testDraft)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.loanPurpose").value("业务运营资金"))
                .andExpect(jsonPath("$.data.status").value("DRAFT"))
                .andReturn().getResponse().getContentAsString();

        // 提取创建的记录ID
        String responseJson = createResponse;
        Long createdId = Long.valueOf(objectMapper.readTree(responseJson)
                .path("data").path("id").asText());

        // 查询创建的记录
        mockMvc.perform(get("/api/loan-out/{id}", createdId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.id").value(createdId))
                .andExpect(jsonPath("$.data.loanPurpose").value("业务运营资金"))
                .andExpect(jsonPath("$.data.status").value("DRAFT"));
    }

    @Test
    void testUpdateLoanOut() throws Exception {
        // 先创建记录
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();

        // 更新记录
        LoanOutDetail updateDetail = new LoanOutDetail();
        updateDetail.setLoanPurpose("更新后的借出目的");
        updateDetail.setLoanDuration(60);
        updateDetail.setExpectedReturnDate(LocalDate.now().plusDays(60));

        mockMvc.perform(put("/api/loan-out/{id}", loanOutId)
                .header("X-User-Id", "test_updater")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updateDetail)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.loanPurpose").value("更新后的借出目的"))
                .andExpect(jsonPath("$.data.loanDuration").value(60));

        // 验证更新
        LoanOutDetail updated = loanOutService.getLoanOutById(loanOutId);
        assertEquals("更新后的借出目的", updated.getLoanPurpose());
        assertEquals(60, updated.getLoanDuration());
    }

    @Test
    void testSubmitForApproval() throws Exception {
        // 创建并提交审批
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();

        mockMvc.perform(post("/api/loan-out/{id}/submit-approval", loanOutId)
                .header("X-User-Id", "test_submitter"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("借出申请提交成功"));

        // 验证状态更新
        LoanOutDetail submitted = loanOutService.getLoanOutById(loanOutId);
        assertEquals("PENDING_APPROVAL", submitted.getStatus());
    }

    @Test
    void testApprovalWorkflow() throws Exception {
        // 创建并提交审批
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();
        loanOutService.submitForApproval(loanOutId, "test_submitter");

        // 获取审批进度
        mockMvc.perform(get("/api/loan-out/{id}/approval-progress", loanOutId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.totalSteps").value(6));

        // 获取当前待审批步骤
        mockMvc.perform(get("/api/loan-out/{id}/current-pending-step", loanOutId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.stepNumber").value(1))
                .andExpect(jsonPath("$.data.stepName").value("业务部门提交申请"));

        // 模拟审批通过第1步
        Map<String, String> approveRequest = new HashMap<>();
        approveRequest.put("comments", "业务部门审批通过");

        mockMvc.perform(post("/api/loan-out/{id}/approve", loanOutId)
                .header("X-User-Id", "business_manager")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(approveRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("审批操作成功"));

        // 验证下一步激活
        mockMvc.perform(get("/api/loan-out/{id}/current-pending-step", loanOutId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.stepNumber").value(2))
                .andExpect(jsonPath("$.data.stepName").value("风险部门初审"));
    }

    @Test
    void testRejectApproval() throws Exception {
        // 创建并提交审批
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();
        loanOutService.submitForApproval(loanOutId, "test_submitter");

        // 拒绝审批
        Map<String, String> rejectRequest = new HashMap<>();
        rejectRequest.put("comments", "业务不符合规定");

        mockMvc.perform(post("/api/loan-out/{id}/reject", loanOutId)
                .header("X-User-Id", "business_manager")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(rejectRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("拒绝操作成功"));

        // 验证状态更新为拒绝
        LoanOutDetail rejected = loanOutService.getLoanOutById(loanOutId);
        assertEquals("REJECTED", rejected.getStatus());
    }

    @Test
    void testReturnStep() throws Exception {
        // 创建并提交审批
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();
        loanOutService.submitForApproval(loanOutId, "test_submitter");

        // 审批通过第1步
        loanOutService.approve(loanOutId, "business_manager", "业务部门审批通过");

        // 退回修改
        Map<String, Object> returnRequest = new HashMap<>();
        returnRequest.put("comments", "需要补充材料");
        returnRequest.put("returnToStep", 1);

        mockMvc.perform(post("/api/loan-out/{id}/return-step", loanOutId)
                .header("X-User-Id", "risk_officer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(returnRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("退回操作成功"));

        // 验证步骤退回
        mockMvc.perform(get("/api/loan-out/{id}/current-pending-step", loanOutId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.stepNumber").value(1));
    }

    @Test
    void testApplyReturn() throws Exception {
        // 创建、提交并完成审批（模拟借出状态）
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();
        
        // 直接更新为借出状态（简化测试）
        LoanOutEntity entity = loanOutMapper.selectById(loanOutId);
        entity.setStatus("LOANED");
        loanOutMapper.updateById(entity);

        // 申请归还
        Map<String, String> returnRequest = new HashMap<>();
        returnRequest.put("returnReason", "业务完成");

        mockMvc.perform(post("/api/loan-out/{id}/apply-return", loanOutId)
                .header("X-User-Id", "test_applicant")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(returnRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("归还申请提交成功"));

        // 验证状态更新
        LoanOutDetail applied = loanOutService.getLoanOutById(loanOutId);
        assertEquals("RETURN_IN_PROGRESS", applied.getStatus());
    }

    @Test
    void testReturnApprovalWorkflow() throws Exception {
        // 创建并设置为借出状态
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();
        
        LoanOutEntity entity = loanOutMapper.selectById(loanOutId);
        entity.setStatus("LOANED");
        loanOutMapper.updateById(entity);

        // 申请归还
        loanOutService.applyReturn(loanOutId, "test_applicant", "业务完成");

        // 获取归还需审批进度
        mockMvc.perform(get("/api/loan-out/{id}/return-approval-progress", loanOutId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.totalSteps").value(4));

        // 获取当前待审批归还步骤
        mockMvc.perform(get("/api/loan-out/{id}/current-pending-return-step", loanOutId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.stepNumber").value(1))
                .andExpect(jsonPath("$.data.stepName").value("申请归还"));

        // 审批归还步骤
        Map<String, String> approveRequest = new HashMap<>();
        approveRequest.put("comments", "归还申请通过");

        mockMvc.perform(post("/api/loan-out/{id}/approve-return-step", loanOutId)
                .header("X-User-Id", "applicant")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(approveRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("归还审批操作成功"));
    }

    @Test
    void testSyncT24Status() throws Exception {
        // 创建记录
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();

        // 同步T24状态
        T24SyncResult syncResult = new T24SyncResult();
        syncResult.setSuccess(true);
        syncResult.setT24Reference("T2412345678");
        syncResult.setSyncMessage("同步成功");
        syncResult.setSyncTime(LocalDateTime.now());

        mockMvc.perform(post("/api/loan-out/{id}/sync-t24", loanOutId)
                .header("X-User-Id", "test_syncer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(syncResult)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("T24状态同步成功"));

        // 验证同步状态
        LoanOutDetail synced = loanOutService.getLoanOutById(loanOutId);
        assertEquals("SYNCED", synced.getT24SyncStatus());
        assertNotNull(synced.getT24SyncTime());
    }

    @Test
    void testQueryLoanOuts() throws Exception {
        // 创建多个测试记录
        for (int i = 1; i <= 3; i++) {
            LoanOutDetail detail = new LoanOutDetail();
            detail.setWhInId(100L + i);
            detail.setLoanPurpose("测试借出 " + i);
            detail.setLoanDuration(30);
            detail.setExpectedReturnDate(LocalDate.now().plusDays(30));
            loanOutService.createLoanOut(detail, "test_user");
        }

        // 查询所有记录
        mockMvc.perform(get("/api/loan-out")
                .param("pageNum", "1")
                .param("pageSize", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.content").isArray())
                .andExpect(jsonPath("$.data.totalElements").value(3));
    }

    @Test
    void testQueryLoanOutsWithFilters() throws Exception {
        // 创建不同状态的记录
        LoanOutDetail draft = new LoanOutDetail();
        draft.setWhInId(101L);
        draft.setLoanPurpose("草稿状态");
        draft.setLoanDuration(30);
        draft.setExpectedReturnDate(LocalDate.now().plusDays(30));
        draft.setStatus("DRAFT");
        loanOutService.createLoanOut(draft, "test_user");

        LoanOutDetail loaned = new LoanOutDetail();
        loaned.setWhInId(102L);
        loaned.setLoanPurpose("借出状态");
        loaned.setLoanDuration(30);
        loaned.setExpectedReturnDate(LocalDate.now().plusDays(30));
        LoanOutDetail created = loanOutService.createLoanOut(loaned, "test_user");
        
        // 更新为借出状态
        LoanOutEntity entity = loanOutMapper.selectById(created.getId());
        entity.setStatus("LOANED");
        loanOutMapper.updateById(entity);

        // 按状态查询
        mockMvc.perform(get("/api/loan-out")
                .param("status", "LOANED")
                .param("pageNum", "1")
                .param("pageSize", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.totalElements").value(1))
                .andExpect(jsonPath("$.data.content[0].loanPurpose").value("借出状态"));
    }

    @Test
    void testDeleteLoanOut() throws Exception {
        // 创建草稿记录
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();

        // 删除记录
        mockMvc.perform(delete("/api/loan-out/{id}", loanOutId)
                .header("X-User-Id", "test_deleter"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("借出记录删除成功"));

        // 验证记录已删除
        mockMvc.perform(get("/api/loan-out/{id}", loanOutId))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false));
    }

    @Test
    void testGetLoanOutStatistics() throws Exception {
        // 创建一些测试数据
        for (int i = 1; i <= 5; i++) {
            LoanOutDetail detail = new LoanOutDetail();
            detail.setWhInId(200L + i);
            detail.setLoanPurpose("统计测试 " + i);
            detail.setLoanDuration(30);
            detail.setExpectedReturnDate(LocalDate.now().plusDays(30));
            loanOutService.createLoanOut(detail, "test_user");
        }

        // 获取统计信息
        mockMvc.perform(get("/api/loan-out/statistics"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.totalLoans").isNumber())
                .andExpect(jsonPath("$.data.activeLoans").isNumber());
    }

    @Test
    void testGetReturnProcessStatistics() throws Exception {
        // 获取归还流程统计
        mockMvc.perform(get("/api/loan-out/return-process-statistics"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.totalReturns").isNumber())
                .andExpect(jsonPath("$.data.completedReturns").isNumber());
    }

    @Test
    void testExportLoanOuts() throws Exception {
        // 创建测试数据
        LoanOutDetail detail = new LoanOutDetail();
        detail.setWhInId(300L);
        detail.setLoanPurpose("导出测试");
        detail.setLoanDuration(30);
        detail.setExpectedReturnDate(LocalDate.now().plusDays(30));
        loanOutService.createLoanOut(detail, "test_user");

        // 导出请求
        Map<String, Object> exportRequest = new HashMap<>();
        exportRequest.put("format", "EXCEL");
        exportRequest.put("includeDetails", true);

        mockMvc.perform(post("/api/loan-out/export")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(exportRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.format").value("EXCEL"));
    }

    @Test
    void testGetOverdueLoanOuts() throws Exception {
        // 创建逾期测试数据
        LoanOutDetail detail = new LoanOutDetail();
        detail.setWhInId(400L);
        detail.setLoanPurpose("逾期测试");
        detail.setLoanDuration(30);
        detail.setExpectedReturnDate(LocalDate.now().minusDays(10)); // 10天前到期
        LoanOutDetail created = loanOutService.createLoanOut(detail, "test_user");
        
        // 更新为借出状态
        LoanOutEntity entity = loanOutMapper.selectById(created.getId());
        entity.setStatus("LOANED");
        loanOutMapper.updateById(entity);

        // 查询逾期记录
        mockMvc.perform(get("/api/loan-out/overdue")
                .param("pageNum", "1")
                .param("pageSize", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void testCompleteApprovalWorkflow() throws Exception {
        // 完整测试：创建 → 提交 → 审批全流程 → 借出 → 归还
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();

        // 1. 提交审批
        loanOutService.submitForApproval(loanOutId, "test_submitter");

        // 2. 模拟6步审批全通过
        String[] approvers = {
            "business_manager", "risk_officer", "compliance_officer",
            "treasury_officer", "warehouse_manager", "system"
        };
        
        String[] comments = {
            "业务部门审批通过", "风险部门审批通过", "合规部门审批通过",
            "资金部门审批通过", "仓库确认通过", "系统完成借出"
        };

        for (int i = 0; i < 6; i++) {
            Map<String, String> approveRequest = new HashMap<>();
            approveRequest.put("comments", comments[i]);
            
            mockMvc.perform(post("/api/loan-out/{id}/approve", loanOutId)
                    .header("X-User-Id", approvers[i])
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(approveRequest)))
                    .andExpect(status().isOk());
        }

        // 3. 验证借出状态
        LoanOutDetail loaned = loanOutService.getLoanOutById(loanOutId);
        assertEquals("LOANED", loaned.getStatus());

        // 4. 申请归还
        loanOutService.applyReturn(loanOutId, "test_applicant", "业务完成");

        // 5. 模拟4步归还审批全通过
        String[] returnApprovers = {"applicant", "warehouse_manager", "finance_officer", "system"};
        String[] returnComments = {"申请归还", "仓库确认完成", "财务结算完成", "系统完成归还"};

        for (int i = 0; i < 4; i++) {
            Map<String, String> approveRequest = new HashMap<>();
            approveRequest.put("comments", returnComments[i]);
            
            mockMvc.perform(post("/api/loan-out/{id}/approve-return-step", loanOutId)
                    .header("X-User-Id", returnApprovers[i])
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(approveRequest)))
                    .andExpect(status().isOk());
        }

        // 6. 验证归还完成
        LoanOutDetail returned = loanOutService.getLoanOutById(loanOutId);
        assertEquals("RETURNED", returned.getStatus());
    }

    @Test
    void testInvalidOperations() throws Exception {
        // 测试无效操作
        LoanOutDetail created = loanOutService.createLoanOut(testDraft, "test_user");
        Long loanOutId = created.getId();

        // 1. 尝试删除已借出的记录
        LoanOutEntity entity = loanOutMapper.selectById(loanOutId);
        entity.setStatus("LOANED");
        loanOutMapper.updateById(entity);

        mockMvc.perform(delete("/api/loan-out/{id}", loanOutId)
                .header("X-User-Id", "test_deleter"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false));

        // 2. 尝试审批不存在的记录
        mockMvc.perform(post("/api/loan-out/{id}/approve", 999999L)
                .header("X-User-Id", "test_approver")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"comments\":\"测试\"}"))
                .andExpect(status().isBadRequest());

        // 3. 尝试更新不存在的记录
        mockMvc.perform(put("/api/loan-out/{id}", 999999L)
                .header("X-User-Id", "test_updater")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testDraft)))
                .andExpect(status().isBadRequest());
    }
}