package com.seabank.cawms.service;

import com.seabank.cawms.entity.LoanOutApprovalEntity;
import com.seabank.cawms.mapper.LoanOutApprovalMapper;
import com.seabank.cawms.service.impl.LoanOutApprovalWorkflow;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * LoanOutApprovalWorkflow 单元测试
 * 测试6步骤出借审批流程状态机
 */
@ExtendWith(MockitoExtension.class)
class LoanOutApprovalWorkflowTest {

    @Mock
    private LoanOutApprovalMapper loanOutApprovalMapper;

    @InjectMocks
    private LoanOutApprovalWorkflow loanOutApprovalWorkflow;

    private LoanOutApprovalEntity testApprovalEntity1;
    private LoanOutApprovalEntity testApprovalEntity2;
    private LoanOutApprovalEntity testApprovalEntity3;

    @BeforeEach
    void setUp() {
        // 准备测试数据 - 第1步
        testApprovalEntity1 = new LoanOutApprovalEntity();
        testApprovalEntity1.setId(1L);
        testApprovalEntity1.setLoanOutId(1L);
        testApprovalEntity1.setStepNumber(1);
        testApprovalEntity1.setStepName("业务部门提交申请");
        testApprovalEntity1.setApproverRole("BUSINESS_MANAGER");
        testApprovalEntity1.setStatus("PENDING");
        testApprovalEntity1.setCreatedAt(LocalDateTime.now());

        // 第2步
        testApprovalEntity2 = new LoanOutApprovalEntity();
        testApprovalEntity2.setId(2L);
        testApprovalEntity2.setLoanOutId(1L);
        testApprovalEntity2.setStepNumber(2);
        testApprovalEntity2.setStepName("风险部门初审");
        testApprovalEntity2.setApproverRole("RISK_OFFICER");
        testApprovalEntity2.setStatus("WAITING");
        testApprovalEntity2.setCreatedAt(LocalDateTime.now());

        // 第3步
        testApprovalEntity3 = new LoanOutApprovalEntity();
        testApprovalEntity3.setId(3L);
        testApprovalEntity3.setLoanOutId(1L);
        testApprovalEntity3.setStepNumber(3);
        testApprovalEntity3.setStepName("合规部门审核");
        testApprovalEntity3.setApproverRole("COMPLIANCE_OFFICER");
        testApprovalEntity3.setStatus("WAITING");
        testApprovalEntity3.setCreatedAt(LocalDateTime.now());
    }

    @Test
    void testInitApprovalProcess_Success() {
        // 准备
        Long loanOutId = 1L;
        String initiator = "test_initiator";
        
        List<LoanOutApprovalEntity> expectedSteps = Arrays.asList(
            testApprovalEntity1, testApprovalEntity2, testApprovalEntity3
        );
        
        when(loanOutApprovalMapper.insert(any(LoanOutApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanOutApprovalWorkflow.initApprovalProcess(loanOutId, initiator);

        // 验证
        assertTrue(result);
        verify(loanOutApprovalMapper, times(6)).insert(any(LoanOutApprovalEntity.class));
    }

    @Test
    void testApproveStep_Success() {
        // 准备
        Long loanOutId = 1L;
        String approver = "test_approver";
        String comments = "审批通过";
        
        List<LoanOutApprovalEntity> pendingSteps = new ArrayList<>();
        testApprovalEntity1.setStatus("PENDING");
        pendingSteps.add(testApprovalEntity1);
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(Arrays.asList(testApprovalEntity1, testApprovalEntity2, testApprovalEntity3));
        when(loanOutApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);
        when(loanOutApprovalMapper.updateById(any(LoanOutApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanOutApprovalWorkflow.approveStep(loanOutId, approver, comments);

        // 验证
        assertTrue(result);
        assertEquals("APPROVED", testApprovalEntity1.getStatus());
        assertNotNull(testApprovalEntity1.getApprovedAt());
        assertEquals(approver, testApprovalEntity1.getApproverUser());
        assertEquals(comments, testApprovalEntity1.getComments());
        
        // 验证下一步被激活
        assertEquals("PENDING", testApprovalEntity2.getStatus());
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanOutApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanOutApprovalMapper, times(2)).updateById(any(LoanOutApprovalEntity.class));
    }

    @Test
    void testApproveStep_LastStep() {
        // 准备
        Long loanOutId = 1L;
        String approver = "test_approver";
        String comments = "最终审批通过";
        
        // 模拟最后一步（第6步）
        LoanOutApprovalEntity lastStep = new LoanOutApprovalEntity();
        lastStep.setId(6L);
        lastStep.setLoanOutId(1L);
        lastStep.setStepNumber(6);
        lastStep.setStepName("完成借出");
        lastStep.setApproverRole("SYSTEM");
        lastStep.setStatus("PENDING");
        
        List<LoanOutApprovalEntity> allSteps = Arrays.asList(
            createApprovalStep(1, "APPROVED"),
            createApprovalStep(2, "APPROVED"),
            createApprovalStep(3, "APPROVED"),
            createApprovalStep(4, "APPROVED"),
            createApprovalStep(5, "APPROVED"),
            lastStep
        );
        
        List<LoanOutApprovalEntity> pendingSteps = Arrays.asList(lastStep);
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanOutApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);
        when(loanOutApprovalMapper.updateById(any(LoanOutApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanOutApprovalWorkflow.approveStep(loanOutId, approver, comments);

        // 验证
        assertTrue(result);
        assertEquals("APPROVED", lastStep.getStatus());
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanOutApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanOutApprovalMapper, times(1)).updateById(any(LoanOutApprovalEntity.class));
    }

    @Test
    void testApproveStep_NoPendingSteps() {
        // 准备
        Long loanOutId = 1L;
        String approver = "test_approver";
        String comments = "审批通过";
        
        when(loanOutApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(new ArrayList<>());

        // 执行
        boolean result = loanOutApprovalWorkflow.approveStep(loanOutId, approver, comments);

        // 验证
        assertFalse(result);
        
        verify(loanOutApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanOutApprovalMapper, never()).updateById(any(LoanOutApprovalEntity.class));
    }

    @Test
    void testRejectStep_Success() {
        // 准备
        Long loanOutId = 1L;
        String rejector = "test_rejector";
        String comments = "审批不通过";
        
        List<LoanOutApprovalEntity> pendingSteps = new ArrayList<>();
        testApprovalEntity1.setStatus("PENDING");
        pendingSteps.add(testApprovalEntity1);
        
        List<LoanOutApprovalEntity> allSteps = Arrays.asList(
            testApprovalEntity1, testApprovalEntity2, testApprovalEntity3
        );
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanOutApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);
        when(loanOutApprovalMapper.updateById(any(LoanOutApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanOutApprovalWorkflow.rejectStep(loanOutId, rejector, comments);

        // 验证
        assertTrue(result);
        assertEquals("REJECTED", testApprovalEntity1.getStatus());
        assertEquals(rejector, testApprovalEntity1.getApproverUser());
        assertEquals(comments, testApprovalEntity1.getComments());
        
        // 验证后续步骤被取消
        assertEquals("CANCELLED", testApprovalEntity2.getStatus());
        assertEquals("CANCELLED", testApprovalEntity3.getStatus());
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanOutApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanOutApprovalMapper, times(3)).updateById(any(LoanOutApprovalEntity.class));
    }

    @Test
    void testReturnStep_Success() {
        // 准备
        Long loanOutId = 1L;
        String returner = "test_returner";
        String comments = "退回修改";
        Integer returnToStep = 1;
        
        // 模拟当前在第3步，要退回到第1步
        testApprovalEntity1.setStatus("APPROVED");
        testApprovalEntity2.setStatus("APPROVED");
        testApprovalEntity3.setStatus("PENDING");
        
        List<LoanOutApprovalEntity> allSteps = Arrays.asList(
            testApprovalEntity1, testApprovalEntity2, testApprovalEntity3
        );
        
        List<LoanOutApprovalEntity> pendingSteps = Arrays.asList(testApprovalEntity3);
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanOutApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);
        when(loanOutApprovalMapper.updateById(any(LoanOutApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanOutApprovalWorkflow.returnStep(loanOutId, returner, comments, returnToStep);

        // 验证
        assertTrue(result);
        
        // 验证当前步骤被标记为RETURNED
        assertEquals("RETURNED", testApprovalEntity3.getStatus());
        assertEquals(returner, testApprovalEntity3.getApproverUser());
        assertEquals(comments, testApprovalEntity3.getComments());
        
        // 验证指定步骤被重置为PENDING
        assertEquals("PENDING", testApprovalEntity1.getStatus());
        
        // 验证中间步骤被重置为WAITING
        assertEquals("WAITING", testApprovalEntity2.getStatus());
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanOutApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanOutApprovalMapper, times(3)).updateById(any(LoanOutApprovalEntity.class));
    }

    @Test
    void testReturnStep_InvalidReturnToStep() {
        // 准备
        Long loanOutId = 1L;
        String returner = "test_returner";
        String comments = "退回修改";
        Integer returnToStep = 10; // 无效的步骤号
        
        List<LoanOutApprovalEntity> pendingSteps = Arrays.asList(testApprovalEntity1);
        
        when(loanOutApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);

        // 执行
        boolean result = loanOutApprovalWorkflow.returnStep(loanOutId, returner, comments, returnToStep);

        // 验证
        assertFalse(result);
        
        verify(loanOutApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanOutApprovalMapper, never()).updateById(any(LoanOutApprovalEntity.class));
    }

    @Test
    void testGetApprovalProgress_Success() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanOutApprovalEntity> allSteps = Arrays.asList(
            createApprovalStep(1, "APPROVED"),
            createApprovalStep(2, "APPROVED"),
            createApprovalStep(3, "PENDING"),
            createApprovalStep(4, "WAITING"),
            createApprovalStep(5, "WAITING"),
            createApprovalStep(6, "WAITING")
        );
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        Map<String, Object> progress = loanOutApprovalWorkflow.getApprovalProgress(loanOutId);

        // 验证
        assertNotNull(progress);
        assertEquals(3, progress.get("currentStep")); // 当前在第3步
        assertEquals(6, progress.get("totalSteps"));
        assertEquals(33.33, (Double) progress.get("progress"), 0.01); // 2/6 = 33.33%
        assertEquals(2, progress.get("completedSteps"));
        assertEquals(1, progress.get("pendingSteps"));
        assertEquals(3, progress.get("waitingSteps"));
        assertEquals(0, progress.get("rejectedSteps"));
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    @Test
    void testGetCurrentPendingStep_Success() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanOutApprovalEntity> pendingSteps = Arrays.asList(testApprovalEntity2);
        
        when(loanOutApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);

        // 执行
        Map<String, Object> pendingStep = loanOutApprovalWorkflow.getCurrentPendingStep(loanOutId);

        // 验证
        assertNotNull(pendingStep);
        assertEquals(2, pendingStep.get("stepNumber"));
        assertEquals("风险部门初审", pendingStep.get("stepName"));
        assertEquals("RISK_OFFICER", pendingStep.get("approverRole"));
        
        verify(loanOutApprovalMapper, times(1)).selectPendingSteps(loanOutId);
    }

    @Test
    void testGetCurrentPendingStep_NoPendingSteps() {
        // 准备
        Long loanOutId = 1L;
        
        when(loanOutApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(new ArrayList<>());

        // 执行
        Map<String, Object> pendingStep = loanOutApprovalWorkflow.getCurrentPendingStep(loanOutId);

        // 验证
        assertNotNull(pendingStep);
        assertNull(pendingStep.get("stepNumber"));
        assertEquals("NONE", pendingStep.get("stepName"));
        
        verify(loanOutApprovalMapper, times(1)).selectPendingSteps(loanOutId);
    }

    @Test
    void testIsProcessCompleted_AllApproved() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanOutApprovalEntity> allSteps = Arrays.asList(
            createApprovalStep(1, "APPROVED"),
            createApprovalStep(2, "APPROVED"),
            createApprovalStep(3, "APPROVED"),
            createApprovalStep(4, "APPROVED"),
            createApprovalStep(5, "APPROVED"),
            createApprovalStep(6, "APPROVED")
        );
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        boolean result = loanOutApprovalWorkflow.isProcessCompleted(loanOutId);

        // 验证
        assertTrue(result);
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    @Test
    void testIsProcessCompleted_NotCompleted() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanOutApprovalEntity> allSteps = Arrays.asList(
            createApprovalStep(1, "APPROVED"),
            createApprovalStep(2, "APPROVED"),
            createApprovalStep(3, "PENDING"), // 还有待处理步骤
            createApprovalStep(4, "WAITING"),
            createApprovalStep(5, "WAITING"),
            createApprovalStep(6, "WAITING")
        );
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        boolean result = loanOutApprovalWorkflow.isProcessCompleted(loanOutId);

        // 验证
        assertFalse(result);
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    @Test
    void testIsProcessCompleted_Rejected() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanOutApprovalEntity> allSteps = Arrays.asList(
            createApprovalStep(1, "APPROVED"),
            createApprovalStep(2, "REJECTED"), // 被拒绝
            createApprovalStep(3, "CANCELLED"),
            createApprovalStep(4, "CANCELLED"),
            createApprovalStep(5, "CANCELLED"),
            createApprovalStep(6, "CANCELLED")
        );
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        boolean result = loanOutApprovalWorkflow.isProcessCompleted(loanOutId);

        // 验证
        assertTrue(result); // 拒绝也算流程完成
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    @Test
    void testGetStepStatus_Success() {
        // 准备
        Long loanOutId = 1L;
        Integer stepNumber = 2;
        
        LoanOutApprovalEntity step = createApprovalStep(2, "APPROVED");
        
        when(loanOutApprovalMapper.selectByLoanOutIdAndStep(loanOutId, stepNumber))
            .thenReturn(step);

        // 执行
        Map<String, Object> stepStatus = loanOutApprovalWorkflow.getStepStatus(loanOutId, stepNumber);

        // 验证
        assertNotNull(stepStatus);
        assertEquals(2, stepStatus.get("stepNumber"));
        assertEquals("APPROVED", stepStatus.get("status"));
        
        verify(loanOutApprovalMapper, times(1))
            .selectByLoanOutIdAndStep(loanOutId, stepNumber);
    }

    @Test
    void testGetStepStatus_NotFound() {
        // 准备
        Long loanOutId = 1L;
        Integer stepNumber = 10; // 不存在的步骤
        
        when(loanOutApprovalMapper.selectByLoanOutIdAndStep(loanOutId, stepNumber))
            .thenReturn(null);

        // 执行
        Map<String, Object> stepStatus = loanOutApprovalWorkflow.getStepStatus(loanOutId, stepNumber);

        // 验证
        assertNotNull(stepStatus);
        assertEquals(stepNumber, stepStatus.get("stepNumber"));
        assertEquals("NOT_FOUND", stepStatus.get("status"));
        
        verify(loanOutApprovalMapper, times(1))
            .selectByLoanOutIdAndStep(loanOutId, stepNumber);
    }

    @Test
    void testGetAllSteps_Success() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanOutApprovalEntity> allSteps = Arrays.asList(
            createApprovalStep(1, "APPROVED"),
            createApprovalStep(2, "PENDING"),
            createApprovalStep(3, "WAITING")
        );
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        List<Map<String, Object>> steps = loanOutApprovalWorkflow.getAllSteps(loanOutId);

        // 验证
        assertNotNull(steps);
        assertEquals(3, steps.size());
        
        Map<String, Object> firstStep = steps.get(0);
        assertEquals(1, firstStep.get("stepNumber"));
        assertEquals("APPROVED", firstStep.get("status"));
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    @Test
    void testCancelApprovalProcess_Success() {
        // 准备
        Long loanOutId = 1L;
        String canceller = "test_canceller";
        String reason = "申请取消";
        
        List<LoanOutApprovalEntity> allSteps = Arrays.asList(
            createApprovalStep(1, "PENDING"),
            createApprovalStep(2, "WAITING"),
            createApprovalStep(3, "WAITING")
        );
        
        when(loanOutApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanOutApprovalMapper.updateById(any(LoanOutApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanOutApprovalWorkflow.cancelApprovalProcess(loanOutId, canceller, reason);

        // 验证
        assertTrue(result);
        
        // 验证所有步骤都被取消
        for (LoanOutApprovalEntity step : allSteps) {
            assertEquals("CANCELLED", step.getStatus());
        }
        
        verify(loanOutApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanOutApprovalMapper, times(3)).updateById(any(LoanOutApprovalEntity.class));
    }

    // 辅助方法：创建审批步骤
    private LoanOutApprovalEntity createApprovalStep(int stepNumber, String status) {
        LoanOutApprovalEntity step = new LoanOutApprovalEntity();
        step.setId((long) stepNumber);
        step.setLoanOutId(1L);
        step.setStepNumber(stepNumber);
        step.setStepName("步骤 " + stepNumber);
        step.setApproverRole("ROLE_" + stepNumber);
        step.setStatus(status);
        step.setCreatedAt(LocalDateTime.now());
        return step;
    }
}