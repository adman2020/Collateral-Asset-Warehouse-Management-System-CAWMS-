package com.seabank.cawms.integration.warehouse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.seabank.cawms.entity.WarehouseInEntity;
import com.seabank.cawms.mapper.WarehouseInMapper;
import com.seabank.cawms.service.WarehouseInService;
import com.seabank.cawms.service.WarehouseInService.WarehouseInDetail;
import com.seabank.cawms.service.WarehouseInService.ApprovalRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * 入库管理集成测试
 * 测试完整的CRUD和审批流程
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class WarehouseInIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private WarehouseInService warehouseInService;

    @Autowired
    private WarehouseInMapper warehouseInMapper;

    private WarehouseInDetail testDraft;

    @BeforeEach
    void setUp() {
        // 清理测试数据
        warehouseInMapper.delete(null); // 删除所有数据
        
        // 准备测试数据
        testDraft = new WarehouseInDetail();
        testDraft.setBuCode("BU001");
        testDraft.setBuName("投行部");
        testDraft.setCustomerName("集成测试客户");
        testDraft.setCollateralType("REAL_ESTATE");
        testDraft.setCollateralValue(new BigDecimal("2000000.00"));
        testDraft.setIntakeType("NEW");
        testDraft.setRemarks("集成测试备注");
    }

    @Test
    void testCompleteWorkflow() throws Exception {
        // 1. 创建草稿
        String createJson = """
                {
                    "buCode": "BU001",
                    "buName": "投行部",
                    "customerName": "集成测试客户",
                    "collateralType": "REAL_ESTATE",
                    "collateralValue": 2000000.00,
                    "intakeType": "NEW",
                    "remarks": "集成测试备注"
                }
                """;

        String createResponse = mockMvc.perform(post("/api/warehouse-in/drafts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(createJson)
                        .header("X-User-Id", "test-user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.id").exists())
                .andExpect(jsonPath("$.data.whCode").exists())
                .andExpect(jsonPath("$.data.status").value("草稿"))
                .andReturn()
                .getResponse()
                .getContentAsString();

        Map<String, Object> createResult = objectMapper.readValue(createResponse, Map.class);
        Map<String, Object> data = (Map<String, Object>) createResult.get("data");
        Long draftId = ((Number) data.get("id")).longValue();
        String whCode = (String) data.get("whCode");

        assertNotNull(draftId);
        assertNotNull(whCode);
        assertTrue(whCode.startsWith("IB-RE-"));

        // 2. 查询草稿
        mockMvc.perform(get("/api/warehouse-in/{id}", draftId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.id").value(draftId))
                .andExpect(jsonPath("$.data.whCode").value(whCode))
                .andExpect(jsonPath("$.data.customerName").value("集成测试客户"))
                .andExpect(jsonPath("$.data.status").value("草稿"));

        // 3. 更新草稿
        String updateJson = """
                {
                    "customerName": "更新后的客户",
                    "collateralValue": 2500000.00,
                    "remarks": "更新后的备注"
                }
                """;

        mockMvc.perform(put("/api/warehouse-in/{id}", draftId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(updateJson)
                        .header("X-User-Id", "test-user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.customerName").value("更新后的客户"))
                .andExpect(jsonPath("$.data.collateralValue").value(2500000.00))
                .andExpect(jsonPath("$.data.remarks").value("更新后的备注"));

        // 4. 提交审批
        String submitJson = """
                {
                    "approverId": "approver-001",
                    "comments": "请审批此入库申请"
                }
                """;

        mockMvc.perform(post("/api/warehouse-in/{id}/submit", draftId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(submitJson)
                        .header("X-User-Id", "test-user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.status").value("待审批"))
                .andExpect(jsonPath("$.data.approverId").value("approver-001"));

        // 5. 审批通过
        mockMvc.perform(post("/api/warehouse-in/{id}/approve", draftId)
                        .param("comments", "审批通过，资料齐全")
                        .header("X-User-Id", "approver-001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.status").value("已批准"))
                .andExpect(jsonPath("$.data.approvalComments").value("审批通过，资料齐全"));

        // 6. 查询最终状态
        mockMvc.perform(get("/api/warehouse-in/{id}", draftId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.status").value("已批准"))
                .andExpect(jsonPath("$.data.approvedAt").exists());

        // 7. 查询列表
        mockMvc.perform(get("/api/warehouse-in")
                        .param("status", "APPROVED")
                        .param("pageNum", "1")
                        .param("pageSize", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.content").isArray())
                .andExpect(jsonPath("$.data.totalElements").value(1));
    }

    @Test
    void testRejectionWorkflow() throws Exception {
        // 1. 创建草稿
        String createJson = objectMapper.writeValueAsString(testDraft);

        String createResponse = mockMvc.perform(post("/api/warehouse-in/drafts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(createJson)
                        .header("X-User-Id", "test-user"))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        Map<String, Object> createResult = objectMapper.readValue(createResponse, Map.class);
        Map<String, Object> data = (Map<String, Object>) createResult.get("data");
        Long draftId = ((Number) data.get("id")).longValue();

        // 2. 提交审批
        ApprovalRequest approvalRequest = new ApprovalRequest();
        approvalRequest.setApproverId("approver-002");
        approvalRequest.setComments("请审批");

        mockMvc.perform(post("/api/warehouse-in/{id}/submit", draftId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(approvalRequest))
                        .header("X-User-Id", "test-user"))
                .andExpect(status().isOk());

        // 3. 审批拒绝
        mockMvc.perform(post("/api/warehouse-in/{id}/reject", draftId)
                        .param("comments", "资料不全，请补充")
                        .header("X-User-Id", "approver-002"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.status").value("已拒绝"))
                .andExpect(jsonPath("$.data.approvalComments").value("资料不全，请补充"));
    }

    @Test
    void testDeleteWorkflow() throws Exception {
        // 1. 创建草稿
        String createJson = objectMapper.writeValueAsString(testDraft);

        String createResponse = mockMvc.perform(post("/api/warehouse-in/drafts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(createJson)
                        .header("X-User-Id", "test-user"))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        Map<String, Object> createResult = objectMapper.readValue(createResponse, Map.class);
        Map<String, Object> data = (Map<String, Object>) createResult.get("data");
        Long draftId = ((Number) data.get("id")).longValue();

        // 2. 删除草稿
        mockMvc.perform(delete("/api/warehouse-in/{id}", draftId)
                        .header("X-User-Id", "test-user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("删除成功"));

        // 3. 验证已删除
        mockMvc.perform(get("/api/warehouse-in/{id}", draftId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success").value(false));
    }

    @Test
    void testQueryWithFilters() throws Exception {
        // 创建多个测试数据
        for (int i = 1; i <= 3; i++) {
            WarehouseInDetail draft = new WarehouseInDetail();
            draft.setBuCode("BU00" + i);
            draft.setCustomerName("客户" + i);
            draft.setCollateralType("REAL_ESTATE");
            draft.setCollateralValue(new BigDecimal("1000000.00").multiply(new BigDecimal(i)));
            
            warehouseInService.createDraft(draft, "test-user");
        }

        // 测试按业务部门查询
        mockMvc.perform(get("/api/warehouse-in")
                        .param("buCode", "BU001")
                        .param("pageNum", "1")
                        .param("pageSize", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.content").isArray())
                .andExpect(jsonPath("$.data.content[0].buCode").value("BU001"));

        // 测试按状态查询
        mockMvc.perform(get("/api/warehouse-in")
                        .param("status", "DRAFT")
                        .param("pageNum", "1")
                        .param("pageSize", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.totalElements").value(3));
    }

    @Test
    void testStatisticsEndpoint() throws Exception {
        // 创建一些测试数据
        for (int i = 1; i <= 5; i++) {
            WarehouseInDetail draft = new WarehouseInDetail();
            draft.setBuCode("BU001");
            draft.setCustomerName("统计测试客户" + i);
            draft.setCollateralType(i % 2 == 0 ? "REAL_ESTATE" : "EQUIPMENT");
            draft.setCollateralValue(new BigDecimal("500000.00").multiply(new BigDecimal(i)));
            
            WarehouseInDetail created = warehouseInService.createDraft(draft, "test-user");
            
            // 提交部分进行审批
            if (i <= 3) {
                ApprovalRequest approvalRequest = new ApprovalRequest();
                approvalRequest.setApproverId("approver-001");
                warehouseInService.submitForApproval(created.getId(), approvalRequest, "test-user");
                
                // 审批部分
                if (i <= 2) {
                    warehouseInService.approve(created.getId(), "批准", "approver-001");
                }
            }
        }

        // 获取统计信息
        mockMvc.perform(get("/api/warehouse-in/statistics"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.totalCount").value(5))
                .andExpect(jsonPath("$.data.totalValue").exists())
                .andExpect(jsonPath("$.data.statusDistribution").exists())
                .andExpect(jsonPath("$.data.collateralTypeDistribution").exists());
    }

    @Test
    void testValidationErrors() throws Exception {
        // 测试缺少必要字段
        String invalidJson = """
                {
                    "buCode": "BU001"
                    // 缺少customerName等必要字段
                }
                """;

        mockMvc.perform(post("/api/warehouse-in/drafts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(invalidJson)
                        .header("X-User-Id", "test-user"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").exists());

        // 测试无效的数值
        String invalidValueJson = """
                {
                    "buCode": "BU001",
                    "customerName": "测试客户",
                    "collateralType": "REAL_ESTATE",
                    "collateralValue": -1000.00,  // 无效的负值
                    "intakeType": "NEW"
                }
                """;

        mockMvc.perform(post("/api/warehouse-in/drafts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(invalidValueJson)
                        .header("X-User-Id", "test-user"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false));
    }

    @Test
    void testConcurrentOperations() throws Exception {
        // 创建初始草稿
        String createJson = objectMapper.writeValueAsString(testDraft);

        String createResponse = mockMvc.perform(post("/api/warehouse-in/drafts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(createJson)
                        .header("X-User-Id", "user1"))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        Map<String, Object> createResult = objectMapper.readValue(createResponse, Map.class);
        Map<String, Object> data = (Map<String, Object>) createResult.get("data");
        Long draftId = ((Number) data.get("id")).longValue();

        // 模拟并发更新（顺序执行）
        String update1Json = """
                {
                    "customerName": "用户1更新",
                    "remarks": "用户1的备注"
                }
                """;

        String update2Json = """
                {
                    "customerName": "用户2更新",
                    "remarks": "用户2的备注"
                }
                """;

        // 用户1更新
        mockMvc.perform(put("/api/warehouse-in/{id}", draftId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(update1Json)
                        .header("X-User-Id", "user1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.customerName").value("用户1更新"));

        // 用户2更新（应该覆盖用户1的更新）
        mockMvc.perform(put("/api/warehouse-in/{id}", draftId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(update2Json)
                        .header("X-User-Id", "user2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.customerName").value("用户2更新"));

        // 验证最终状态
        mockMvc.perform(get("/api/warehouse-in/{id}", draftId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.customerName").value("用户2更新"))
                .andExpect(jsonPath("$.data.remarks").value("用户2的备注"));
    }

    @Test
    void testErrorScenarios() throws Exception {
        // 测试不存在的ID
        mockMvc.perform(get("/api/warehouse-in/{id}", 999999))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success").value(false));

        // 测试无权限操作（不同用户尝试更新）
        // 1. 用户A创建草稿
        String createJson = objectMapper.writeValueAsString(testDraft);
        
        String createResponse = mockMvc.perform(post("/api/warehouse-in/drafts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(createJson)
                        .header("X-User-Id", "user-a"))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        Map<String, Object> createResult = objectMapper.readValue(createResponse, Map.class);
        Map<String, Object> data = (Map<String, Object>) createResult.get("data");
        Long draftId = ((Number) data.get("id")).longValue();

        // 2. 用户B尝试更新（应该允许，因为目前没有严格的权限控制）
        String updateJson = """
                {
                    "customerName": "用户B尝试更新"
                }
                """;

        mockMvc.perform(put("/api/warehouse-in/{id}", draftId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(updateJson)
                        .header("X-User-Id", "user-b"))
                .andExpect(status().isOk()); // 目前应该成功

        // 测试无效的审批操作
        // 尝试审批一个草稿状态（未提交）的记录
        mockMvc.perform(post("/api/warehouse-in/{id}/approve", draftId)
                        .param("comments", "直接审批")
                        .header("X-User-Id", "approver-001"))
                .andExpect(status().isBadRequest()); // 应该失败
    }
}