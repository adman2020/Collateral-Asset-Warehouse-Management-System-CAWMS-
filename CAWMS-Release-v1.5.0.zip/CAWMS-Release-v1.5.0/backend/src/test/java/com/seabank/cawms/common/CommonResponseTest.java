package com.seabank.cawms.common;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * CommonResponse unit tests
 */
@DisplayName("CommonResponse Tests")
class CommonResponseTest {

    @Test
    @DisplayName("success() returns response with 200 code and null data")
    void testSuccess_NoData() {
        CommonResponse<Object> response = CommonResponse.success();
        assertThat(response.getCode()).isEqualTo(200);
        assertThat(response.getData()).isNull();
        assertThat(response.getTimestamp()).isNotNull();
        assertThat(response.isSuccess()).isTrue();
    }

    @Test
    @DisplayName("success(data) returns response with data")
    void testSuccess_WithData() {
        String data = "test-data";
        CommonResponse<String> response = CommonResponse.success(data);
        assertThat(response.getCode()).isEqualTo(200);
        assertThat(response.getData()).isEqualTo("test-data");
        assertThat(response.isSuccess()).isTrue();
    }

    @Test
    @DisplayName("success(data, message) returns response with custom message")
    void testSuccess_WithDataAndMessage() {
        CommonResponse<Integer> response = CommonResponse.success(42, "Custom message");
        assertThat(response.getCode()).isEqualTo(200);
        assertThat(response.getData()).isEqualTo(42);
        assertThat(response.getMessage()).isEqualTo("Custom message");
        assertThat(response.isSuccess()).isTrue();
    }

    @Test
    @DisplayName("error(message) returns response with 500 code")
    void testError_WithMessage() {
        CommonResponse<Object> response = CommonResponse.error("Something went wrong");
        assertThat(response.getCode()).isEqualTo(500);
        assertThat(response.getMessage()).isEqualTo("Something went wrong");
        assertThat(response.getData()).isNull();
        assertThat(response.isSuccess()).isFalse();
    }

    @Test
    @DisplayName("error(code, message) returns response with custom code")
    void testError_WithCodeAndMessage() {
        CommonResponse<Object> response = CommonResponse.error(400, "Bad request");
        assertThat(response.getCode()).isEqualTo(400);
        assertThat(response.getMessage()).isEqualTo("Bad request");
        assertThat(response.isSuccess()).isFalse();
    }

    @Test
    @DisplayName("error(ResponseCode) returns response with enum code")
    void testError_WithResponseCode() {
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.NOT_FOUND);
        assertThat(response.getCode()).isEqualTo(404);
        assertThat(response.isSuccess()).isFalse();
    }

    @Test
    @DisplayName("error(ResponseCode, message) returns response with custom message")
    void testError_WithResponseCodeAndMessage() {
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.FORBIDDEN, "Access denied");
        assertThat(response.getCode()).isEqualTo(403);
        assertThat(response.getMessage()).isEqualTo("Access denied");
        assertThat(response.isSuccess()).isFalse();
    }

    @Test
    @DisplayName("isSuccess() returns false for non-200 codes")
    void testIsSuccess_NonSuccessCode() {
        CommonResponse<Object> response = new CommonResponse<>(404, "Not found", null, System.currentTimeMillis());
        assertThat(response.isSuccess()).isFalse();
    }

    @Test
    @DisplayName("timestamp is set on creation")
    void testTimestamp_IsSet() {
        long before = System.currentTimeMillis();
        CommonResponse<Object> response = CommonResponse.success();
        long after = System.currentTimeMillis();
        assertThat(response.getTimestamp()).isBetween(before, after);
    }
}
