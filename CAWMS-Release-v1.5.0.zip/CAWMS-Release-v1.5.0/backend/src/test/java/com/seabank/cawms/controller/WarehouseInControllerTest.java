package com.seabank.cawms.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.seabank.cawms.entity.WarehouseInEntity;
import com.seabank.cawms.service.WarehouseInService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.autoconfigure.web.servlet.*;
import org.springframework.boot.test.context.*;
import org.springframework.boot.test.mock.mockito.*;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * WarehouseInController 集成测试
 * 测试入库管理 REST API 端点
 */
@WebMvcTest(WarehouseInController.class)
@ExtendWith(SpringExtension.class)
@DisplayName("WarehouseInController 集成测试")
class WarehouseInControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private WarehouseInService warehouseInService;

    @Test
    @DisplayName("测试创建入库申请 API")
    void testCreateWarehouseIn() throws Exception {
        // Given
        WarehouseInEntity warehouseIn = new WarehouseInEntity();
        warehouseIn.setId(1L);
        warehouseIn.setWarehouseNo("WH202604070001");
        warehouseIn.setCollateralName("测试抵押物");

        when(warehouseInService.createWarehouseIn(any())).thenReturn(warehouseIn);

        // When & Then
        mockMvc.perform(post("/api/warehouse-in")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(warehouseIn)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.warehouseNo").value("WH202604070001"));

        verify(warehouseInService, times(1)).createWarehouseIn(any());
    }

    @Test
    @DisplayName("测试查询入库列表 API - 分页")
    void testQueryWarehouseInList() throws Exception {
        // Given
        when(warehouseInService.queryWarehouseInList(anyInt(), anyInt(), any(), any(), any()))
                .thenReturn(new com.baomidou.mybatisplus.extension.plugins.pagination.Page<>(1, 10));

        // When & Then
        mockMvc.perform(get("/api/warehouse-in")
                .param("page", "1")
                .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(warehouseInService, times(1)).queryWarehouseInList(anyInt(), anyInt(), any(), any(), any());
    }

    @Test
    @DisplayName("测试查询入库详情 API")
    void testGetWarehouseInDetail() throws Exception {
        // Given
        WarehouseInEntity warehouseIn = new WarehouseInEntity();
        warehouseIn.setId(1L);
        warehouseIn.setWarehouseNo("WH202604070001");

        when(warehouseInService.getWarehouseInById(1L)).thenReturn(warehouseIn);

        // When & Then
        mockMvc.perform(get("/api/warehouse-in/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.warehouseNo").value("WH202604070001"));

        verify(warehouseInService, times(1)).getWarehouseInById(1L);
    }

    @Test
    @DisplayName("测试更新入库申请 API")
    void testUpdateWarehouseIn() throws Exception {
        // Given
        WarehouseInEntity warehouseIn = new WarehouseInEntity();
        warehouseIn.setId(1L);
        warehouseIn.setCollateralName("更新后的抵押物");

        when(warehouseInService.updateWarehouseIn(eq(1L), any())).thenReturn(warehouseIn);

        // When & Then
        mockMvc.perform(put("/api/warehouse-in/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(warehouseIn)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(warehouseInService, times(1)).updateWarehouseIn(eq(1L), any());
    }

    @Test
    @DisplayName("测试删除入库申请 API")
    void testDeleteWarehouseIn() throws Exception {
        // Given
        when(warehouseInService.deleteWarehouseIn(1L)).thenReturn(true);

        // When & Then
        mockMvc.perform(delete("/api/warehouse-in/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(warehouseInService, times(1)).deleteWarehouseIn(1L);
    }

    @Test
    @DisplayName("测试提交入库申请 API")
    void testSubmitWarehouseIn() throws Exception {
        // Given
        WarehouseInEntity warehouseIn = new WarehouseInEntity();
        warehouseIn.setId(1L);
        warehouseIn.setStatus("SUBMITTED");

        when(warehouseInService.submitWarehouseIn(1L)).thenReturn(warehouseIn);

        // When & Then
        mockMvc.perform(post("/api/warehouse-in/1/submit"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.status").value("SUBMITTED"));

        verify(warehouseInService, times(1)).submitWarehouseIn(1L);
    }

    @Test
    @DisplayName("测试审批入库申请 API")
    void testApproveWarehouseIn() throws Exception {
        // Given
        WarehouseInEntity warehouseIn = new WarehouseInEntity();
        warehouseIn.setId(1L);
        warehouseIn.setStatus("APPROVED");

        when(warehouseInService.approveWarehouseIn(eq(1L), eq(1), anyString(), anyString())).thenReturn(warehouseIn);

        // When & Then
        mockMvc.perform(post("/api/warehouse-in/1/approve")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"step\":1,\"approvalStatus\":\"APPROVED\",\"opinion\":\"同意\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(warehouseInService, times(1)).approveWarehouseIn(eq(1L), eq(1), anyString(), anyString());
    }

    @Test
    @DisplayName("测试查询审批进度 API")
    void testGetApprovalProgress() throws Exception {
        // Given
        when(warehouseInService.getApprovalProgress(1L)).thenReturn(Arrays.asList(
                new java.util.HashMap<String, Object>() {{ put("step", 1); put("status", "APPROVED"); }}
        ));

        // When & Then
        mockMvc.perform(get("/api/warehouse-in/1/approval-progress"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data").isArray());

        verify(warehouseInService, times(1)).getApprovalProgress(1L);
    }
}
