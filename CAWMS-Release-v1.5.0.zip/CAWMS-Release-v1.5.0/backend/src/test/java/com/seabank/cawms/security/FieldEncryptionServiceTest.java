package com.seabank.cawms.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * FieldEncryptionService unit tests
 */
@DisplayName("FieldEncryptionService Tests")
class FieldEncryptionServiceTest {

    private FieldEncryptionService encryptionService;

    @BeforeEach
    void setUp() {
        encryptionService = new FieldEncryptionService();
        // Use empty secret key so it auto-generates one
        ReflectionTestUtils.setField(encryptionService, "secretKeyBase64", "");
        ReflectionTestUtils.setField(encryptionService, "encryptionEnabled", true);
    }

    @Test
    @DisplayName("encrypt returns non-null ciphertext for plaintext")
    void testEncrypt_ReturnsNonNull() {
        String plaintext = "sensitive data";
        String ciphertext = encryptionService.encrypt(plaintext);
        assertThat(ciphertext).isNotNull().isNotEmpty();
        assertThat(ciphertext).isNotEqualTo(plaintext);
    }

    @Test
    @DisplayName("decrypt returns original plaintext")
    void testDecrypt_ReturnsOriginal() {
        String plaintext = "sensitive data 123";
        String ciphertext = encryptionService.encrypt(plaintext);
        String decrypted = encryptionService.decrypt(ciphertext);
        assertThat(decrypted).isEqualTo(plaintext);
    }

    @Test
    @DisplayName("encrypt returns null for null input")
    void testEncrypt_NullInput() {
        String result = encryptionService.encrypt(null);
        assertThat(result).isNull();
    }

    @Test
    @DisplayName("encrypt returns empty string for empty input")
    void testEncrypt_EmptyInput() {
        String result = encryptionService.encrypt("");
        assertThat(result).isEmpty();
    }

    @Test
    @DisplayName("decrypt returns null for null input")
    void testDecrypt_NullInput() {
        String result = encryptionService.decrypt(null);
        assertThat(result).isNull();
    }

    @Test
    @DisplayName("isEncrypted returns true for encrypted data")
    void testIsEncrypted_EncryptedData() {
        String ciphertext = encryptionService.encrypt("test data");
        assertThat(encryptionService.isEncrypted(ciphertext)).isTrue();
    }

    @Test
    @DisplayName("isEncrypted returns false for plaintext")
    void testIsEncrypted_Plaintext() {
        // Short plaintext that is not valid Base64 with sufficient length
        assertThat(encryptionService.isEncrypted("hello")).isFalse();
    }

    @Test
    @DisplayName("isEncrypted returns false for null")
    void testIsEncrypted_Null() {
        assertThat(encryptionService.isEncrypted(null)).isFalse();
    }

    @Test
    @DisplayName("isEncrypted returns false for empty string")
    void testIsEncrypted_Empty() {
        assertThat(encryptionService.isEncrypted("")).isFalse();
    }

    @Test
    @DisplayName("encrypt/decrypt round trip with special characters")
    void testEncryptDecrypt_SpecialChars() {
        String plaintext = "Nguyen Van A - 001234567890 - +84 901234567";
        String ciphertext = encryptionService.encrypt(plaintext);
        String decrypted = encryptionService.decrypt(ciphertext);
        assertThat(decrypted).isEqualTo(plaintext);
    }

    @Test
    @DisplayName("encrypt/decrypt round trip with unicode")
    void testEncryptDecrypt_Unicode() {
        String plaintext = "Ho Chi Minh City - Thành phố Hồ Chí Minh";
        String ciphertext = encryptionService.encrypt(plaintext);
        String decrypted = encryptionService.decrypt(ciphertext);
        assertThat(decrypted).isEqualTo(plaintext);
    }

    @Test
    @DisplayName("when encryption disabled, encrypt returns plaintext")
    void testEncrypt_DisabledEncryption() {
        ReflectionTestUtils.setField(encryptionService, "encryptionEnabled", false);
        String plaintext = "sensitive data";
        String result = encryptionService.encrypt(plaintext);
        assertThat(result).isEqualTo(plaintext);
    }

    @Test
    @DisplayName("when encryption disabled, decrypt returns ciphertext as-is")
    void testDecrypt_DisabledEncryption() {
        ReflectionTestUtils.setField(encryptionService, "encryptionEnabled", false);
        String input = "some data";
        String result = encryptionService.decrypt(input);
        assertThat(result).isEqualTo(input);
    }

    @Test
    @DisplayName("isEncryptionEnabled returns current state")
    void testIsEncryptionEnabled() {
        assertThat(encryptionService.isEncryptionEnabled()).isTrue();
        encryptionService.setEncryptionEnabled(false);
        assertThat(encryptionService.isEncryptionEnabled()).isFalse();
    }

    @Test
    @DisplayName("generateNewKey returns valid Base64 key")
    void testGenerateNewKey() {
        String key = encryptionService.generateNewKey();
        assertThat(key).isNotNull().isNotEmpty();
        // Should be valid Base64
        assertThat(encryptionService.validateKey(key)).isTrue();
    }

    @Test
    @DisplayName("validateKey returns true for valid 256-bit key")
    void testValidateKey_ValidKey() {
        String key = encryptionService.generateNewKey();
        assertThat(encryptionService.validateKey(key)).isTrue();
    }

    @Test
    @DisplayName("validateKey returns false for invalid key")
    void testValidateKey_InvalidKey() {
        assertThat(encryptionService.validateKey("not-a-valid-key")).isFalse();
    }

    @Test
    @DisplayName("getAlgorithmInfo returns non-null string")
    void testGetAlgorithmInfo() {
        String info = encryptionService.getAlgorithmInfo();
        assertThat(info).isNotNull().isNotEmpty();
    }

    @Test
    @DisplayName("secureErase clears key without exception")
    void testSecureErase_NoException() {
        // First encrypt something to initialize the key
        encryptionService.encrypt("test");
        // Then erase - should not throw
        encryptionService.secureErase();
    }

    @Test
    @DisplayName("two encryptions of same plaintext produce different ciphertexts (due to random IV)")
    void testEncrypt_RandomIV() {
        String plaintext = "same plaintext";
        String cipher1 = encryptionService.encrypt(plaintext);
        String cipher2 = encryptionService.encrypt(plaintext);
        // Due to random IV, ciphertexts should differ
        assertThat(cipher1).isNotEqualTo(cipher2);
        // But both should decrypt to the same plaintext
        assertThat(encryptionService.decrypt(cipher1)).isEqualTo(plaintext);
        assertThat(encryptionService.decrypt(cipher2)).isEqualTo(plaintext);
    }
}
