package com.seabank.cawms.service;

import com.seabank.cawms.entity.LoanReturnApprovalEntity;
import com.seabank.cawms.mapper.LoanReturnApprovalMapper;
import com.seabank.cawms.service.impl.LoanReturnApprovalWorkflow;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * LoanReturnApprovalWorkflow 单元测试
 * 测试4步骤归还流程状态机
 */
@ExtendWith(MockitoExtension.class)
class LoanReturnApprovalWorkflowTest {

    @Mock
    private LoanReturnApprovalMapper loanReturnApprovalMapper;

    @InjectMocks
    private LoanReturnApprovalWorkflow loanReturnApprovalWorkflow;

    private LoanReturnApprovalEntity testReturnEntity1;
    private LoanReturnApprovalEntity testReturnEntity2;
    private LoanReturnApprovalEntity testReturnEntity3;

    @BeforeEach
    void setUp() {
        // 准备测试数据 - 第1步：申请归还
        testReturnEntity1 = new LoanReturnApprovalEntity();
        testReturnEntity1.setId(1L);
        testReturnEntity1.setLoanOutId(1L);
        testReturnEntity1.setStepNumber(1);
        testReturnEntity1.setStepName("申请归还");
        testReturnEntity1.setApproverRole("APPLICANT");
        testReturnEntity1.setStatus("PENDING");
        testReturnEntity1.setCreatedAt(LocalDateTime.now());

        // 第2步：仓库确认
        testReturnEntity2 = new LoanReturnApprovalEntity();
        testReturnEntity2.setId(2L);
        testReturnEntity2.setLoanOutId(1L);
        testReturnEntity2.setStepNumber(2);
        testReturnEntity2.setStepName("仓库确认");
        testReturnEntity2.setApproverRole("WAREHOUSE_MANAGER");
        testReturnEntity2.setStatus("WAITING");
        testReturnEntity2.setCreatedAt(LocalDateTime.now());

        // 第3步：财务结算
        testReturnEntity3 = new LoanReturnApprovalEntity();
        testReturnEntity3.setId(3L);
        testReturnEntity3.setLoanOutId(1L);
        testReturnEntity3.setStepNumber(3);
        testReturnEntity3.setStepName("财务结算");
        testReturnEntity3.setApproverRole("FINANCE_OFFICER");
        testReturnEntity3.setStatus("WAITING");
        testReturnEntity3.setCreatedAt(LocalDateTime.now());
    }

    @Test
    void testInitReturnProcess_Success() {
        // 准备
        Long loanOutId = 1L;
        String applicant = "test_applicant";
        String returnReason = "业务完成";
        
        when(loanReturnApprovalMapper.insert(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.initReturnProcess(loanOutId, applicant, returnReason);

        // 验证
        assertTrue(result);
        verify(loanReturnApprovalMapper, times(4)).insert(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testInitReturnProcess_WithAssetCondition() {
        // 准备
        Long loanOutId = 1L;
        String applicant = "test_applicant";
        String returnReason = "业务完成";
        String assetCondition = "GOOD";
        String conditionDescription = "资产状况良好";
        
        when(loanReturnApprovalMapper.insert(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.initReturnProcess(
            loanOutId, applicant, returnReason, assetCondition, conditionDescription);

        // 验证
        assertTrue(result);
        verify(loanReturnApprovalMapper, times(4)).insert(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testApproveStep_Success() {
        // 准备
        Long loanOutId = 1L;
        String approver = "test_approver";
        String comments = "审批通过";
        
        List<LoanReturnApprovalEntity> pendingSteps = new ArrayList<>();
        testReturnEntity1.setStatus("PENDING");
        pendingSteps.add(testReturnEntity1);
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            testReturnEntity1, testReturnEntity2, testReturnEntity3
        );
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanReturnApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);
        when(loanReturnApprovalMapper.updateById(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.approveStep(loanOutId, approver, comments);

        // 验证
        assertTrue(result);
        assertEquals("APPROVED", testReturnEntity1.getStatus());
        assertNotNull(testReturnEntity1.getApprovedAt());
        assertEquals(approver, testReturnEntity1.getApproverUser());
        assertEquals(comments, testReturnEntity1.getComments());
        
        // 验证下一步被激活
        assertEquals("PENDING", testReturnEntity2.getStatus());
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanReturnApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanReturnApprovalMapper, times(2)).updateById(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testApproveStep_LastStep() {
        // 准备
        Long loanOutId = 1L;
        String approver = "test_approver";
        String comments = "最终审批通过";
        
        // 模拟最后一步（第4步）
        LoanReturnApprovalEntity lastStep = new LoanReturnApprovalEntity();
        lastStep.setId(4L);
        lastStep.setLoanOutId(1L);
        lastStep.setStepNumber(4);
        lastStep.setStepName("完成归还");
        lastStep.setApproverRole("SYSTEM");
        lastStep.setStatus("PENDING");
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            createReturnStep(1, "APPROVED"),
            createReturnStep(2, "APPROVED"),
            createReturnStep(3, "APPROVED"),
            lastStep
        );
        
        List<LoanReturnApprovalEntity> pendingSteps = Arrays.asList(lastStep);
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanReturnApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);
        when(loanReturnApprovalMapper.updateById(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.approveStep(loanOutId, approver, comments);

        // 验证
        assertTrue(result);
        assertEquals("APPROVED", lastStep.getStatus());
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanReturnApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanReturnApprovalMapper, times(1)).updateById(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testApproveStep_WithSettlementInfo() {
        // 准备
        Long loanOutId = 1L;
        String approver = "finance_officer";
        String comments = "财务结算完成";
        String settlementMethod = "BANK_TRANSFER";
        String settlementReference = "REF20240001";
        
        // 模拟第3步（财务结算）
        LoanReturnApprovalEntity financeStep = createReturnStep(3, "PENDING");
        financeStep.setApproverRole("FINANCE_OFFICER");
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            createReturnStep(1, "APPROVED"),
            createReturnStep(2, "APPROVED"),
            financeStep,
            createReturnStep(4, "WAITING")
        );
        
        List<LoanReturnApprovalEntity> pendingSteps = Arrays.asList(financeStep);
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanReturnApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);
        when(loanReturnApprovalMapper.updateById(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.approveStep(
            loanOutId, approver, comments, settlementMethod, settlementReference);

        // 验证
        assertTrue(result);
        assertEquals("APPROVED", financeStep.getStatus());
        assertEquals(settlementMethod, financeStep.getSettlementMethod());
        assertEquals(settlementReference, financeStep.getSettlementReference());
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanReturnApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanReturnApprovalMapper, times(2)).updateById(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testRejectStep_Success() {
        // 准备
        Long loanOutId = 1L;
        String rejector = "test_rejector";
        String comments = "审批不通过";
        
        List<LoanReturnApprovalEntity> pendingSteps = new ArrayList<>();
        testReturnEntity1.setStatus("PENDING");
        pendingSteps.add(testReturnEntity1);
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            testReturnEntity1, testReturnEntity2, testReturnEntity3
        );
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanReturnApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);
        when(loanReturnApprovalMapper.updateById(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.rejectStep(loanOutId, rejector, comments);

        // 验证
        assertTrue(result);
        assertEquals("REJECTED", testReturnEntity1.getStatus());
        assertEquals(rejector, testReturnEntity1.getApproverUser());
        assertEquals(comments, testReturnEntity1.getComments());
        
        // 验证后续步骤被取消
        assertEquals("CANCELLED", testReturnEntity2.getStatus());
        assertEquals("CANCELLED", testReturnEntity3.getStatus());
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanReturnApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanReturnApprovalMapper, times(3)).updateById(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testReturnStep_Success() {
        // 准备
        Long loanOutId = 1L;
        String returner = "test_returner";
        String comments = "退回修改";
        Integer returnToStep = 1;
        
        // 模拟当前在第3步，要退回到第1步
        testReturnEntity1.setStatus("APPROVED");
        testReturnEntity2.setStatus("APPROVED");
        testReturnEntity3.setStatus("PENDING");
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            testReturnEntity1, testReturnEntity2, testReturnEntity3
        );
        
        List<LoanReturnApprovalEntity> pendingSteps = Arrays.asList(testReturnEntity3);
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanReturnApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);
        when(loanReturnApprovalMapper.updateById(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.returnStep(loanOutId, returner, comments, returnToStep);

        // 验证
        assertTrue(result);
        
        // 验证当前步骤被标记为RETURNED
        assertEquals("RETURNED", testReturnEntity3.getStatus());
        assertEquals(returner, testReturnEntity3.getApproverUser());
        assertEquals(comments, testReturnEntity3.getComments());
        
        // 验证指定步骤被重置为PENDING
        assertEquals("PENDING", testReturnEntity1.getStatus());
        
        // 验证中间步骤被重置为WAITING
        assertEquals("WAITING", testReturnEntity2.getStatus());
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanReturnApprovalMapper, times(1)).selectPendingSteps(loanOutId);
        verify(loanReturnApprovalMapper, times(3)).updateById(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testGetReturnProgress_Success() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            createReturnStep(1, "APPROVED"),
            createReturnStep(2, "APPROVED"),
            createReturnStep(3, "PENDING"),
            createReturnStep(4, "WAITING")
        );
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        Map<String, Object> progress = loanReturnApprovalWorkflow.getReturnProgress(loanOutId);

        // 验证
        assertNotNull(progress);
        assertEquals(3, progress.get("currentStep")); // 当前在第3步
        assertEquals(4, progress.get("totalSteps"));
        assertEquals(50.0, (Double) progress.get("progress"), 0.01); // 2/4 = 50%
        assertEquals(2, progress.get("completedSteps"));
        assertEquals(1, progress.get("pendingSteps"));
        assertEquals(1, progress.get("waitingSteps"));
        assertEquals(0, progress.get("rejectedSteps"));
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    @Test
    void testGetCurrentPendingReturnStep_Success() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanReturnApprovalEntity> pendingSteps = Arrays.asList(testReturnEntity2);
        
        when(loanReturnApprovalMapper.selectPendingSteps(loanOutId))
            .thenReturn(pendingSteps);

        // 执行
        Map<String, Object> pendingStep = loanReturnApprovalWorkflow.getCurrentPendingReturnStep(loanOutId);

        // 验证
        assertNotNull(pendingStep);
        assertEquals(2, pendingStep.get("stepNumber"));
        assertEquals("仓库确认", pendingStep.get("stepName"));
        assertEquals("WAREHOUSE_MANAGER", pendingStep.get("approverRole"));
        
        verify(loanReturnApprovalMapper, times(1)).selectPendingSteps(loanOutId);
    }

    @Test
    void testIsProcessCompleted_AllApproved() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            createReturnStep(1, "APPROVED"),
            createReturnStep(2, "APPROVED"),
            createReturnStep(3, "APPROVED"),
            createReturnStep(4, "APPROVED")
        );
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        boolean result = loanReturnApprovalWorkflow.isProcessCompleted(loanOutId);

        // 验证
        assertTrue(result);
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    @Test
    void testIsProcessCompleted_NotCompleted() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            createReturnStep(1, "APPROVED"),
            createReturnStep(2, "APPROVED"),
            createReturnStep(3, "PENDING"), // 还有待处理步骤
            createReturnStep(4, "WAITING")
        );
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        boolean result = loanReturnApprovalWorkflow.isProcessCompleted(loanOutId);

        // 验证
        assertFalse(result);
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    @Test
    void testGetStepDetails_Success() {
        // 准备
        Long loanOutId = 1L;
        Integer stepNumber = 2;
        
        LoanReturnApprovalEntity step = createReturnStep(2, "APPROVED");
        step.setAssetCondition("GOOD");
        step.setConditionDescription("资产状况良好");
        step.setSettlementMethod("BANK_TRANSFER");
        step.setSettlementReference("REF20240001");
        
        when(loanReturnApprovalMapper.selectByLoanOutIdAndStep(loanOutId, stepNumber))
            .thenReturn(step);

        // 执行
        Map<String, Object> stepDetails = loanReturnApprovalWorkflow.getStepDetails(loanOutId, stepNumber);

        // 验证
        assertNotNull(stepDetails);
        assertEquals(2, stepDetails.get("stepNumber"));
        assertEquals("APPROVED", stepDetails.get("status"));
        assertEquals("GOOD", stepDetails.get("assetCondition"));
        assertEquals("资产状况良好", stepDetails.get("conditionDescription"));
        assertEquals("BANK_TRANSFER", stepDetails.get("settlementMethod"));
        
        verify(loanReturnApprovalMapper, times(1))
            .selectByLoanOutIdAndStep(loanOutId, stepNumber);
    }

    @Test
    void testGetAllReturnSteps_Success() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            createReturnStep(1, "APPROVED"),
            createReturnStep(2, "PENDING"),
            createReturnStep(3, "WAITING"),
            createReturnStep(4, "WAITING")
        );
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        List<Map<String, Object>> steps = loanReturnApprovalWorkflow.getAllReturnSteps(loanOutId);

        // 验证
        assertNotNull(steps);
        assertEquals(4, steps.size());
        
        Map<String, Object> firstStep = steps.get(0);
        assertEquals(1, firstStep.get("stepNumber"));
        assertEquals("APPROVED", firstStep.get("status"));
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    @Test
    void testUpdateAssetCondition_Success() {
        // 准备
        Long loanOutId = 1L;
        Integer stepNumber = 2;
        String assetCondition = "DAMAGED";
        String conditionDescription = "资产有轻微损坏";
        
        LoanReturnApprovalEntity step = createReturnStep(2, "PENDING");
        
        when(loanReturnApprovalMapper.selectByLoanOutIdAndStep(loanOutId, stepNumber))
            .thenReturn(step);
        when(loanReturnApprovalMapper.updateById(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.updateAssetCondition(
            loanOutId, stepNumber, assetCondition, conditionDescription);

        // 验证
        assertTrue(result);
        assertEquals(assetCondition, step.getAssetCondition());
        assertEquals(conditionDescription, step.getConditionDescription());
        
        verify(loanReturnApprovalMapper, times(1))
            .selectByLoanOutIdAndStep(loanOutId, stepNumber);
        verify(loanReturnApprovalMapper, times(1))
            .updateById(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testUpdateSettlementInfo_Success() {
        // 准备
        Long loanOutId = 1L;
        Integer stepNumber = 3;
        String settlementMethod = "CASH";
        String settlementReference = "CASH_RECEIPT_001";
        
        LoanReturnApprovalEntity step = createReturnStep(3, "PENDING");
        
        when(loanReturnApprovalMapper.selectByLoanOutIdAndStep(loanOutId, stepNumber))
            .thenReturn(step);
        when(loanReturnApprovalMapper.updateById(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.updateSettlementInfo(
            loanOutId, stepNumber, settlementMethod, settlementReference);

        // 验证
        assertTrue(result);
        assertEquals(settlementMethod, step.getSettlementMethod());
        assertEquals(settlementReference, step.getSettlementReference());
        
        verify(loanReturnApprovalMapper, times(1))
            .selectByLoanOutIdAndStep(loanOutId, stepNumber);
        verify(loanReturnApprovalMapper, times(1))
            .updateById(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testCancelReturnProcess_Success() {
        // 准备
        Long loanOutId = 1L;
        String canceller = "test_canceller";
        String reason = "申请取消";
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            createReturnStep(1, "PENDING"),
            createReturnStep(2, "WAITING"),
            createReturnStep(3, "WAITING"),
            createReturnStep(4, "WAITING")
        );
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);
        when(loanReturnApprovalMapper.updateById(any(LoanReturnApprovalEntity.class)))
            .thenReturn(1);

        // 执行
        boolean result = loanReturnApprovalWorkflow.cancelReturnProcess(loanOutId, canceller, reason);

        // 验证
        assertTrue(result);
        
        // 验证所有步骤都被取消
        for (LoanReturnApprovalEntity step : allSteps) {
            assertEquals("CANCELLED", step.getStatus());
        }
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
        verify(loanReturnApprovalMapper, times(4)).updateById(any(LoanReturnApprovalEntity.class));
    }

    @Test
    void testGetReturnStatistics_Success() {
        // 准备
        Long loanOutId = 1L;
        
        List<LoanReturnApprovalEntity> allSteps = Arrays.asList(
            createReturnStep(1, "APPROVED"),
            createReturnStep(2, "APPROVED"),
            createReturnStep(3, "PENDING"),
            createReturnStep(4, "WAITING")
        );
        allSteps.get(2).setAssetCondition("GOOD"); // 第3步有资产状况
        
        when(loanReturnApprovalMapper.selectByLoanOutId(loanOutId))
            .thenReturn(allSteps);

        // 执行
        Map<String, Object> statistics = loanReturnApprovalWorkflow.getReturnStatistics(loanOutId);

        // 验证
        assertNotNull(statistics);
        assertEquals(4, statistics.get("totalSteps"));
        assertEquals(2, statistics.get("completedSteps"));
        assertEquals(1, statistics.get("pendingSteps"));
        assertEquals(1, statistics.get("waitingSteps"));
        assertEquals("GOOD", statistics.get("assetCondition"));
        
        verify(loanReturnApprovalMapper, times(1)).selectByLoanOutId(loanOutId);
    }

    // 辅助方法：创建归还步骤
    private LoanReturnApprovalEntity createReturnStep(int stepNumber, String status) {
        LoanReturnApprovalEntity step = new LoanReturnApprovalEntity();
        step.setId((long) stepNumber);
        step.setLoanOutId(1L);
        step.setStepNumber(stepNumber);
        step.setStepName("归还步骤 " + stepNumber);
        step.setApproverRole("ROLE_" + stepNumber);
        step.setStatus(status);
        step.setCreatedAt(LocalDateTime.now());
        return step;
    }
}