package com.seabank.cawms.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.seabank.cawms.entity.LoanOutEntity;
import com.seabank.cawms.service.LoanOutService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.autoconfigure.web.servlet.*;
import org.springframework.boot.test.context.*;
import org.springframework.boot.test.mock.mockito.*;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * LoanOutController 集成测试
 * 测试借出管理 REST API 端点
 */
@WebMvcTest(LoanOutController.class)
@ExtendWith(SpringExtension.class)
@DisplayName("LoanOutController 集成测试")
class LoanOutControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private LoanOutService loanOutService;

    @Test
    @DisplayName("测试创建借出申请 API")
    void testCreateLoanOut() throws Exception {
        // Given
        LoanOutEntity loanOut = new LoanOutEntity();
        loanOut.setId(1L);
        loanOut.setLoanNo("LO202604070001");
        loanOut.setLoanAmount(new BigDecimal("1000000.00"));

        when(loanOutService.createLoanOut(any())).thenReturn(loanOut);

        // When & Then
        mockMvc.perform(post("/api/loan-out")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loanOut)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.loanNo").value("LO202604070001"));

        verify(loanOutService, times(1)).createLoanOut(any());
    }

    @Test
    @DisplayName("测试查询借出列表 API - 分页")
    void testQueryLoanOutList() throws Exception {
        // Given
        when(loanOutService.queryLoanOutList(anyInt(), anyInt(), any(), any(), any()))
                .thenReturn(new com.baomidou.mybatisplus.extension.plugins.pagination.Page<>(1, 10));

        // When & Then
        mockMvc.perform(get("/api/loan-out")
                .param("page", "1")
                .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(loanOutService, times(1)).queryLoanOutList(anyInt(), anyInt(), any(), any(), any());
    }

    @Test
    @DisplayName("测试查询借出详情 API")
    void testGetLoanOutDetail() throws Exception {
        // Given
        LoanOutEntity loanOut = new LoanOutEntity();
        loanOut.setId(1L);
        loanOut.setLoanNo("LO202604070001");

        when(loanOutService.getLoanOutById(1L)).thenReturn(loanOut);

        // When & Then
        mockMvc.perform(get("/api/loan-out/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.loanNo").value("LO202604070001"));

        verify(loanOutService, times(1)).getLoanOutById(1L);
    }

    @Test
    @DisplayName("测试计算释放金额 API")
    void testCalculateReleaseAmount() throws Exception {
        // Given
        when(loanOutService.calculateReleaseAmount(1L, 30))
                .thenReturn(new BigDecimal("300000.00"));

        // When & Then
        mockMvc.perform(get("/api/loan-out/1/calculate-release")
                .param("releasePercentage", "30"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(loanOutService, times(1)).calculateReleaseAmount(1L, 30);
    }

    @Test
    @DisplayName("测试归还借出资产 API")
    void testReturnLoan() throws Exception {
        // Given
        LoanOutEntity loanOut = new LoanOutEntity();
        loanOut.setId(1L);
        loanOut.setStatus("RETURNED");

        when(loanOutService.returnLoan(eq(1L), anyString())).thenReturn(loanOut);

        // When & Then
        mockMvc.perform(post("/api/loan-out/1/return")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"condition\":\"良好\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(loanOutService, times(1)).returnLoan(eq(1L), anyString());
    }

    @Test
    @DisplayName("测试更新借出申请 API")
    void testUpdateLoanOut() throws Exception {
        // Given
        LoanOutEntity loanOut = new LoanOutEntity();
        loanOut.setId(1L);
        loanOut.setLoanAmount(new BigDecimal("2000000.00"));

        when(loanOutService.updateLoanOut(eq(1L), any())).thenReturn(loanOut);

        // When & Then
        mockMvc.perform(put("/api/loan-out/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loanOut)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(loanOutService, times(1)).updateLoanOut(eq(1L), any());
    }

    @Test
    @DisplayName("测试删除借出申请 API")
    void testDeleteLoanOut() throws Exception {
        // Given
        when(loanOutService.deleteLoanOut(1L)).thenReturn(true);

        // When & Then
        mockMvc.perform(delete("/api/loan-out/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(loanOutService, times(1)).deleteLoanOut(1L);
    }

    @Test
    @DisplayName("测试提交借出申请 API")
    void testSubmitLoanOut() throws Exception {
        // Given
        LoanOutEntity loanOut = new LoanOutEntity();
        loanOut.setId(1L);
        loanOut.setStatus("SUBMITTED");

        when(loanOutService.submitLoanOut(1L)).thenReturn(loanOut);

        // When & Then
        mockMvc.perform(post("/api/loan-out/1/submit"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        verify(loanOutService, times(1)).submitLoanOut(1L);
    }
}
