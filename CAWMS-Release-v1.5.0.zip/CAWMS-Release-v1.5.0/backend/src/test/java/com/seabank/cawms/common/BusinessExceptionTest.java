package com.seabank.cawms.common;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * BusinessException unit tests
 */
@DisplayName("BusinessException Tests")
class BusinessExceptionTest {

    @Test
    @DisplayName("constructor(message) sets default business error code")
    void testConstructor_MessageOnly() {
        BusinessException ex = new BusinessException("test error");
        assertThat(ex.getMessage()).isEqualTo("test error");
        assertThat(ex.getCode()).isEqualTo(ResponseCode.BUSINESS_ERROR.getCode());
    }

    @Test
    @DisplayName("constructor(code, message) sets custom code")
    void testConstructor_CodeAndMessage() {
        BusinessException ex = new BusinessException(1234, "custom error");
        assertThat(ex.getCode()).isEqualTo(1234);
        assertThat(ex.getMessage()).isEqualTo("custom error");
    }

    @Test
    @DisplayName("constructor(ResponseCode) uses enum code and message")
    void testConstructor_ResponseCode() {
        BusinessException ex = new BusinessException(ResponseCode.NOT_FOUND);
        assertThat(ex.getCode()).isEqualTo(404);
        assertThat(ex.getMessage()).isEqualTo(ResponseCode.NOT_FOUND.getMessage());
    }

    @Test
    @DisplayName("constructor(ResponseCode, message) uses enum code with custom message")
    void testConstructor_ResponseCodeAndMessage() {
        BusinessException ex = new BusinessException(ResponseCode.FORBIDDEN, "Custom forbidden message");
        assertThat(ex.getCode()).isEqualTo(403);
        assertThat(ex.getMessage()).isEqualTo("Custom forbidden message");
    }

    @Test
    @DisplayName("constructor(message, cause) sets cause")
    void testConstructor_MessageAndCause() {
        RuntimeException cause = new RuntimeException("root cause");
        BusinessException ex = new BusinessException("wrapped error", cause);
        assertThat(ex.getMessage()).isEqualTo("wrapped error");
        assertThat(ex.getCause()).isEqualTo(cause);
        assertThat(ex.getCode()).isEqualTo(ResponseCode.BUSINESS_ERROR.getCode());
    }

    @Test
    @DisplayName("constructor(code, message, cause) sets all fields")
    void testConstructor_CodeMessageAndCause() {
        RuntimeException cause = new RuntimeException("root cause");
        BusinessException ex = new BusinessException(9999, "full error", cause);
        assertThat(ex.getCode()).isEqualTo(9999);
        assertThat(ex.getMessage()).isEqualTo("full error");
        assertThat(ex.getCause()).isEqualTo(cause);
    }

    @Test
    @DisplayName("BusinessException is a RuntimeException")
    void testIsRuntimeException() {
        BusinessException ex = new BusinessException("test");
        assertThat(ex).isInstanceOf(RuntimeException.class);
    }

    @Test
    @DisplayName("all ResponseCode constructors work correctly")
    void testAllResponseCodeConstructors() {
        for (ResponseCode code : ResponseCode.values()) {
            BusinessException ex = new BusinessException(code);
            assertThat(ex.getCode()).isEqualTo(code.getCode());
        }
    }
}
