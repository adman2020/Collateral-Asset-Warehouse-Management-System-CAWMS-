package com.seabank.cawms.common;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * ResponseCode enum unit tests
 */
@DisplayName("ResponseCode Tests")
class ResponseCodeTest {

    @Test
    @DisplayName("getByCode returns correct enum for known code")
    void testGetByCode_KnownCode() {
        assertThat(ResponseCode.getByCode(200)).isEqualTo(ResponseCode.SUCCESS);
        assertThat(ResponseCode.getByCode(400)).isEqualTo(ResponseCode.BAD_REQUEST);
        assertThat(ResponseCode.getByCode(401)).isEqualTo(ResponseCode.UNAUTHORIZED);
        assertThat(ResponseCode.getByCode(403)).isEqualTo(ResponseCode.FORBIDDEN);
        assertThat(ResponseCode.getByCode(404)).isEqualTo(ResponseCode.NOT_FOUND);
        assertThat(ResponseCode.getByCode(500)).isEqualTo(ResponseCode.ERROR);
    }

    @Test
    @DisplayName("getByCode returns null for unknown code")
    void testGetByCode_UnknownCode() {
        assertThat(ResponseCode.getByCode(999)).isNull();
    }

    @Test
    @DisplayName("getByCode returns null for null input")
    void testGetByCode_NullInput() {
        assertThat(ResponseCode.getByCode(null)).isNull();
    }

    @Test
    @DisplayName("isSuccess returns true for 2xx codes")
    void testIsSuccess_SuccessCodes() {
        assertThat(ResponseCode.isSuccess(200)).isTrue();
        assertThat(ResponseCode.isSuccess(201)).isTrue();
        assertThat(ResponseCode.isSuccess(204)).isTrue();
        assertThat(ResponseCode.isSuccess(299)).isTrue();
    }

    @Test
    @DisplayName("isSuccess returns false for non-2xx codes")
    void testIsSuccess_NonSuccessCodes() {
        assertThat(ResponseCode.isSuccess(400)).isFalse();
        assertThat(ResponseCode.isSuccess(500)).isFalse();
        assertThat(ResponseCode.isSuccess(null)).isFalse();
    }

    @Test
    @DisplayName("isClientError returns true for 4xx codes")
    void testIsClientError_ClientErrorCodes() {
        assertThat(ResponseCode.isClientError(400)).isTrue();
        assertThat(ResponseCode.isClientError(401)).isTrue();
        assertThat(ResponseCode.isClientError(403)).isTrue();
        assertThat(ResponseCode.isClientError(404)).isTrue();
        assertThat(ResponseCode.isClientError(499)).isTrue();
    }

    @Test
    @DisplayName("isClientError returns false for non-4xx codes")
    void testIsClientError_NonClientErrorCodes() {
        assertThat(ResponseCode.isClientError(200)).isFalse();
        assertThat(ResponseCode.isClientError(500)).isFalse();
        assertThat(ResponseCode.isClientError(null)).isFalse();
    }

    @Test
    @DisplayName("isServerError returns true for 5xx codes")
    void testIsServerError_ServerErrorCodes() {
        assertThat(ResponseCode.isServerError(500)).isTrue();
        assertThat(ResponseCode.isServerError(503)).isTrue();
        assertThat(ResponseCode.isServerError(599)).isTrue();
    }

    @Test
    @DisplayName("isServerError returns false for non-5xx codes")
    void testIsServerError_NonServerErrorCodes() {
        assertThat(ResponseCode.isServerError(200)).isFalse();
        assertThat(ResponseCode.isServerError(400)).isFalse();
        assertThat(ResponseCode.isServerError(null)).isFalse();
    }

    @Test
    @DisplayName("enum values have correct codes")
    void testEnumValues_CorrectCodes() {
        assertThat(ResponseCode.SUCCESS.getCode()).isEqualTo(200);
        assertThat(ResponseCode.ERROR.getCode()).isEqualTo(500);
        assertThat(ResponseCode.BUSINESS_ERROR.getCode()).isEqualTo(1000);
        assertThat(ResponseCode.VALIDATION_ERROR.getCode()).isEqualTo(1001);
        assertThat(ResponseCode.TOKEN_EXPIRED.getCode()).isEqualTo(2001);
        assertThat(ResponseCode.FILE_UPLOAD_FAILED.getCode()).isEqualTo(3001);
    }

    @Test
    @DisplayName("enum values have non-null messages")
    void testEnumValues_NonNullMessages() {
        for (ResponseCode code : ResponseCode.values()) {
            assertThat(code.getMessage()).isNotNull().isNotEmpty();
            assertThat(code.getCode()).isNotNull();
        }
    }

    @Test
    @DisplayName("getByCode returns business error codes")
    void testGetByCode_BusinessErrorCodes() {
        assertThat(ResponseCode.getByCode(1000)).isEqualTo(ResponseCode.BUSINESS_ERROR);
        assertThat(ResponseCode.getByCode(1001)).isEqualTo(ResponseCode.VALIDATION_ERROR);
        assertThat(ResponseCode.getByCode(1002)).isEqualTo(ResponseCode.DATA_NOT_FOUND);
        assertThat(ResponseCode.getByCode(2001)).isEqualTo(ResponseCode.TOKEN_EXPIRED);
        assertThat(ResponseCode.getByCode(3001)).isEqualTo(ResponseCode.FILE_UPLOAD_FAILED);
    }
}
