package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.LoanOutEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * LoanOutService unit tests using mock
 */
@ExtendWith(SpringExtension.class)
@DisplayName("LoanOutService Tests")
class LoanOutServiceTest {

    @Mock
    private LoanOutService loanOutService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    private LoanOutService.LoanOutDetail buildDetail(Long id, String status) {
        LoanOutService.LoanOutDetail detail = new LoanOutService.LoanOutDetail();
        detail.setId(id);
        detail.setWhInId(1L);
        detail.setLoanPurpose("Audit purpose");
        detail.setLoanDuration(30);
        detail.setExpectedReturnDate(LocalDate.now().plusDays(30));
        detail.setStatus(status);
        detail.setT24SyncStatus("PENDING");
        detail.setCustomerName("Test Customer");
        detail.setCreatedBy("testuser");
        detail.setCreatedAt(LocalDateTime.now());
        return detail;
    }

    @Test
    @DisplayName("createDraft returns created detail")
    void testCreateDraft_Success() {
        LoanOutService.LoanOutDetail detail = buildDetail(1L, "DRAFT");
        when(loanOutService.createDraft(any(), eq("testuser"))).thenReturn(detail);

        LoanOutService.LoanOutDetail result = loanOutService.createDraft(detail, "testuser");

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("DRAFT");
        assertThat(result.getWhInId()).isEqualTo(1L);
        verify(loanOutService).createDraft(any(), eq("testuser"));
    }

    @Test
    @DisplayName("getById returns detail for existing id")
    void testGetById_Found() {
        LoanOutService.LoanOutDetail detail = buildDetail(1L, "DRAFT");
        when(loanOutService.getById(1L)).thenReturn(detail);

        LoanOutService.LoanOutDetail result = loanOutService.getById(1L);

        assertThat(result).isNotNull();
        assertThat(result.getWhInId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getById returns null for non-existent id")
    void testGetById_NotFound() {
        when(loanOutService.getById(999L)).thenReturn(null);

        LoanOutService.LoanOutDetail result = loanOutService.getById(999L);

        assertThat(result).isNull();
    }

    @Test
    @DisplayName("update returns updated detail")
    void testUpdate_Success() {
        LoanOutService.LoanOutDetail updated = buildDetail(1L, "DRAFT");
        updated.setLoanPurpose("Updated purpose");
        when(loanOutService.update(eq(1L), any(), eq("updater"))).thenReturn(updated);

        LoanOutService.LoanOutDetail result = loanOutService.update(1L, updated, "updater");

        assertThat(result).isNotNull();
        assertThat(result.getLoanPurpose()).isEqualTo("Updated purpose");
    }

    @Test
    @DisplayName("delete returns true on success")
    void testDelete_Success() {
        when(loanOutService.delete(1L, "deleter")).thenReturn(true);

        boolean result = loanOutService.delete(1L, "deleter");

        assertThat(result).isTrue();
        verify(loanOutService).delete(1L, "deleter");
    }

    @Test
    @DisplayName("submitForApproval changes status to PENDING")
    void testSubmitForApproval() {
        LoanOutService.LoanOutDetail pending = buildDetail(1L, "PENDING");
        LoanOutService.ApprovalRequest request = new LoanOutService.ApprovalRequest();
        request.setApproverId("approver1");
        when(loanOutService.submitForApproval(eq(1L), any(), eq("submitter"))).thenReturn(pending);

        LoanOutService.LoanOutDetail result = loanOutService.submitForApproval(1L, request, "submitter");

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("PENDING");
    }

    @Test
    @DisplayName("approve processes approval")
    void testApprove_Success() {
        LoanOutService.LoanOutDetail approved = buildDetail(1L, "APPROVED");
        when(loanOutService.approve(1L, "Approved", "approver")).thenReturn(approved);

        LoanOutService.LoanOutDetail result = loanOutService.approve(1L, "Approved", "approver");

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("APPROVED");
    }

    @Test
    @DisplayName("reject processes rejection")
    void testReject_Success() {
        LoanOutService.LoanOutDetail rejected = buildDetail(1L, "REJECTED");
        when(loanOutService.reject(1L, "Not valid", "rejector")).thenReturn(rejected);

        LoanOutService.LoanOutDetail result = loanOutService.reject(1L, "Not valid", "rejector");

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("REJECTED");
    }

    @Test
    @DisplayName("confirmLoan changes status to LOANED")
    void testConfirmLoan() {
        LoanOutService.LoanOutDetail loaned = buildDetail(1L, "LOANED");
        when(loanOutService.confirmLoan(1L, "confirmer")).thenReturn(loaned);

        LoanOutService.LoanOutDetail result = loanOutService.confirmLoan(1L, "confirmer");

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("LOANED");
    }

    @Test
    @DisplayName("returnCollateral changes status to RETURNED")
    void testReturnCollateral() {
        LoanOutService.LoanOutDetail returned = buildDetail(1L, "RETURNED");
        returned.setActualReturnDate(LocalDate.now());
        when(loanOutService.returnCollateral(eq(1L), any(), anyString(), eq("returner"))).thenReturn(returned);

        LoanOutService.LoanOutDetail result = loanOutService.returnCollateral(1L, LocalDate.now(), "Good condition", "returner");

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("RETURNED");
        assertThat(result.getActualReturnDate()).isNotNull();
    }

    @Test
    @DisplayName("query returns paginated results")
    void testQuery_WithPagination() {
        Page<LoanOutService.LoanOutDetail> mockPage = new Page<>(1, 10);
        mockPage.setRecords(Arrays.asList(buildDetail(1L, "DRAFT"), buildDetail(2L, "LOANED")));
        mockPage.setTotal(2);

        LoanOutService.LoanOutQuery query = new LoanOutService.LoanOutQuery();
        query.setPageNum(1);
        query.setPageSize(10);
        when(loanOutService.query(any())).thenReturn(mockPage);

        Page<LoanOutService.LoanOutDetail> result = loanOutService.query(query);

        assertThat(result).isNotNull();
        assertThat(result.getRecords()).hasSize(2);
        assertThat(result.getTotal()).isEqualTo(2);
    }

    @Test
    @DisplayName("getStatistics returns statistics object")
    void testGetStatistics() {
        LoanOutService.LoanOutStatistics stats = new LoanOutService.LoanOutStatistics();
        stats.setTotalCount(50);
        stats.setLoanedCount(20);
        stats.setReturnedCount(25);
        stats.setOverdueCount(5);
        when(loanOutService.getStatistics()).thenReturn(stats);

        LoanOutService.LoanOutStatistics result = loanOutService.getStatistics();

        assertThat(result).isNotNull();
        assertThat(result.getTotalCount()).isEqualTo(50);
        assertThat(result.getLoanedCount()).isEqualTo(20);
        assertThat(result.getOverdueCount()).isEqualTo(5);
    }

    @Test
    @DisplayName("getOverdueLoans returns overdue list")
    void testGetOverdueLoans() {
        Page<LoanOutService.LoanOutDetail> mockPage = new Page<>(1, 10);
        LoanOutService.LoanOutDetail overdue = buildDetail(1L, "OVERDUE");
        overdue.setOverdue(true);
        overdue.setRemainingDays(-5);
        mockPage.setRecords(List.of(overdue));
        mockPage.setTotal(1);
        when(loanOutService.getOverdueLoans(1, 10)).thenReturn(mockPage);

        Page<LoanOutService.LoanOutDetail> result = loanOutService.getOverdueLoans(1, 10);

        assertThat(result).isNotNull();
        assertThat(result.getRecords()).hasSize(1);
        assertThat(result.getRecords().get(0).getOverdue()).isTrue();
    }

    @Test
    @DisplayName("getExpiringLoans returns expiring list")
    void testGetExpiringLoans() {
        Page<LoanOutService.LoanOutDetail> mockPage = new Page<>(1, 10);
        mockPage.setRecords(List.of(buildDetail(1L, "LOANED")));
        mockPage.setTotal(1);
        when(loanOutService.getExpiringLoans(7, 1, 10)).thenReturn(mockPage);

        Page<LoanOutService.LoanOutDetail> result = loanOutService.getExpiringLoans(7, 1, 10);

        assertThat(result).isNotNull();
        assertThat(result.getRecords()).hasSize(1);
    }

    @Test
    @DisplayName("sendOverdueAlert returns success result")
    void testSendOverdueAlert() {
        LoanOutService.AlertSendResult alertResult = new LoanOutService.AlertSendResult();
        alertResult.setSuccess(true);
        alertResult.setAlertId("ALERT-001");
        alertResult.setMessage("Alert sent successfully");
        alertResult.setSentTime(LocalDateTime.now());
        when(loanOutService.sendOverdueAlert(1L, "OVERDUE")).thenReturn(alertResult);

        LoanOutService.AlertSendResult result = loanOutService.sendOverdueAlert(1L, "OVERDUE");

        assertThat(result).isNotNull();
        assertThat(result.getSuccess()).isTrue();
        assertThat(result.getAlertId()).isEqualTo("ALERT-001");
    }

    @Test
    @DisplayName("LoanOutDetail inner class getters and setters work correctly")
    void testLoanOutDetail_GettersSetters() {
        LoanOutService.LoanOutDetail detail = new LoanOutService.LoanOutDetail();
        detail.setLoanCode("LO-001");
        detail.setWhCode("WH-001");
        detail.setStatus("DRAFT");
        detail.setOverdue(false);
        detail.setRemainingDays(10);

        assertThat(detail.getLoanCode()).isEqualTo("LO-001");
        assertThat(detail.getWhCode()).isEqualTo("WH-001");
        assertThat(detail.getStatus()).isEqualTo("DRAFT");
        assertThat(detail.getOverdue()).isFalse();
        assertThat(detail.getRemainingDays()).isEqualTo(10);
    }

    @Test
    @DisplayName("LoanOutQuery inner class getters and setters work correctly")
    void testLoanOutQuery_GettersSetters() {
        LoanOutService.LoanOutQuery query = new LoanOutService.LoanOutQuery();
        query.setStatus("LOANED");
        query.setBuCode("BU001");
        query.setPageNum(1);
        query.setPageSize(20);
        query.setSortField("createdAt");
        query.setSortOrder("DESC");

        assertThat(query.getStatus()).isEqualTo("LOANED");
        assertThat(query.getBuCode()).isEqualTo("BU001");
        assertThat(query.getPageNum()).isEqualTo(1);
        assertThat(query.getPageSize()).isEqualTo(20);
    }

    @Test
    @DisplayName("LoanOutStatistics inner class getters and setters work correctly")
    void testLoanOutStatistics_GettersSetters() {
        LoanOutService.LoanOutStatistics stats = new LoanOutService.LoanOutStatistics();
        stats.setTotalCount(100);
        stats.setDraftCount(10);
        stats.setPendingCount(20);
        stats.setLoanedCount(40);
        stats.setReturnedCount(25);
        stats.setOverdueCount(5);
        stats.setTodayLoans(3);
        stats.setMonthLoans(15);

        assertThat(stats.getTotalCount()).isEqualTo(100);
        assertThat(stats.getDraftCount()).isEqualTo(10);
        assertThat(stats.getPendingCount()).isEqualTo(20);
        assertThat(stats.getLoanedCount()).isEqualTo(40);
        assertThat(stats.getReturnedCount()).isEqualTo(25);
        assertThat(stats.getOverdueCount()).isEqualTo(5);
        assertThat(stats.getTodayLoans()).isEqualTo(3);
        assertThat(stats.getMonthLoans()).isEqualTo(15);
    }
}
