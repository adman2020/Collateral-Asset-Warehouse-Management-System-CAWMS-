package com.seabank.cawms.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * JwtTokenProvider unit tests
 */
@DisplayName("JwtTokenProvider Tests")
class JwtTokenProviderTest {

    private JwtTokenProvider jwtTokenProvider;

    // Base64-encoded 64-byte key for HS512
    private static final String TEST_SECRET =
            "dGVzdFNlY3JldEtleUZvckp3dFRva2VuUHJvdmlkZXJUZXN0aW5nMTIzNDU2Nzg5MDEyMzQ1Njc4OTA=";
    private static final long TEST_EXPIRATION = 86400000L; // 24 hours
    private static final long TEST_REFRESH_EXPIRATION = 604800000L; // 7 days

    @BeforeEach
    void setUp() {
        jwtTokenProvider = new JwtTokenProvider();
        ReflectionTestUtils.setField(jwtTokenProvider, "jwtSecret", TEST_SECRET);
        ReflectionTestUtils.setField(jwtTokenProvider, "jwtExpirationMs", TEST_EXPIRATION);
        ReflectionTestUtils.setField(jwtTokenProvider, "refreshExpirationMs", TEST_REFRESH_EXPIRATION);
    }

    @Test
    @DisplayName("generateToken(Authentication) returns non-null token")
    void testGenerateToken_FromAuthentication() {
        Authentication auth = createAuthentication("testuser", "ROLE_USER");
        String token = jwtTokenProvider.generateToken(auth);
        assertThat(token).isNotNull().isNotEmpty();
    }

    @Test
    @DisplayName("generateToken(username, authorities) returns valid token")
    void testGenerateToken_FromUsernameAndAuthorities() {
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_ADMIN"));
        String token = jwtTokenProvider.generateToken("admin", authorities);
        assertThat(token).isNotNull().isNotEmpty();
    }

    @Test
    @DisplayName("getUsernameFromToken returns correct username")
    void testGetUsernameFromToken() {
        String username = "testuser";
        List<GrantedAuthority> authorities = Collections.emptyList();
        String token = jwtTokenProvider.generateToken(username, authorities);

        String extracted = jwtTokenProvider.getUsernameFromToken(token);
        assertThat(extracted).isEqualTo(username);
    }

    @Test
    @DisplayName("validateToken returns true for valid token")
    void testValidateToken_ValidToken() {
        String token = jwtTokenProvider.generateToken("user", Collections.emptyList());
        assertThat(jwtTokenProvider.validateToken(token)).isTrue();
    }

    @Test
    @DisplayName("validateToken returns false for invalid token")
    void testValidateToken_InvalidToken() {
        assertThat(jwtTokenProvider.validateToken("invalid.token.here")).isFalse();
    }

    @Test
    @DisplayName("validateToken returns false for empty token")
    void testValidateToken_EmptyToken() {
        assertThat(jwtTokenProvider.validateToken("")).isFalse();
    }

    @Test
    @DisplayName("getAuthentication returns Authentication with correct username")
    void testGetAuthentication() {
        String username = "testuser";
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_USER"));
        String token = jwtTokenProvider.generateToken(username, authorities);

        Authentication auth = jwtTokenProvider.getAuthentication(token);
        assertThat(auth).isNotNull();
        assertThat(auth.getName()).isEqualTo(username);
    }

    @Test
    @DisplayName("getAuthoritiesFromToken returns correct authorities")
    void testGetAuthoritiesFromToken() {
        List<GrantedAuthority> authorities = Arrays.asList(
                new SimpleGrantedAuthority("ROLE_USER"),
                new SimpleGrantedAuthority("ROLE_ADMIN")
        );
        String token = jwtTokenProvider.generateToken("user", authorities);

        List<GrantedAuthority> extracted = jwtTokenProvider.getAuthoritiesFromToken(token);
        assertThat(extracted).hasSize(2);
        assertThat(extracted.stream().map(GrantedAuthority::getAuthority))
                .containsExactlyInAnyOrder("ROLE_USER", "ROLE_ADMIN");
    }

    @Test
    @DisplayName("getAuthoritiesFromToken returns empty list when no authorities")
    void testGetAuthoritiesFromToken_NoAuthorities() {
        String token = jwtTokenProvider.generateToken("user", Collections.emptyList());
        List<GrantedAuthority> extracted = jwtTokenProvider.getAuthoritiesFromToken(token);
        assertThat(extracted).isEmpty();
    }

    @Test
    @DisplayName("generateRefreshToken returns valid refresh token")
    void testGenerateRefreshToken() {
        String refreshToken = jwtTokenProvider.generateRefreshToken("testuser");
        assertThat(refreshToken).isNotNull().isNotEmpty();
        assertThat(jwtTokenProvider.validateToken(refreshToken)).isTrue();
    }

    @Test
    @DisplayName("validateRefreshToken returns true for valid refresh token")
    void testValidateRefreshToken_Valid() {
        String refreshToken = jwtTokenProvider.generateRefreshToken("testuser");
        assertThat(jwtTokenProvider.validateRefreshToken(refreshToken)).isTrue();
    }

    @Test
    @DisplayName("validateRefreshToken returns false for access token")
    void testValidateRefreshToken_AccessToken() {
        String accessToken = jwtTokenProvider.generateToken("testuser", Collections.emptyList());
        assertThat(jwtTokenProvider.validateRefreshToken(accessToken)).isFalse();
    }

    @Test
    @DisplayName("getUsernameFromRefreshToken returns username for valid refresh token")
    void testGetUsernameFromRefreshToken_Valid() {
        String refreshToken = jwtTokenProvider.generateRefreshToken("testuser");
        String username = jwtTokenProvider.getUsernameFromRefreshToken(refreshToken);
        assertThat(username).isEqualTo("testuser");
    }

    @Test
    @DisplayName("getUsernameFromRefreshToken returns null for invalid token")
    void testGetUsernameFromRefreshToken_Invalid() {
        String username = jwtTokenProvider.getUsernameFromRefreshToken("invalid.token");
        assertThat(username).isNull();
    }

    @Test
    @DisplayName("getRemainingExpirationMs returns positive value for valid token")
    void testGetRemainingExpirationMs_ValidToken() {
        String token = jwtTokenProvider.generateToken("user", Collections.emptyList());
        long remaining = jwtTokenProvider.getRemainingExpirationMs(token);
        assertThat(remaining).isPositive();
        assertThat(remaining).isLessThanOrEqualTo(TEST_EXPIRATION);
    }

    @Test
    @DisplayName("getRemainingExpirationMs returns 0 for invalid token")
    void testGetRemainingExpirationMs_InvalidToken() {
        long remaining = jwtTokenProvider.getRemainingExpirationMs("invalid.token");
        assertThat(remaining).isEqualTo(0);
    }

    @Test
    @DisplayName("isTokenAboutToExpire returns false for fresh token with large threshold")
    void testIsTokenAboutToExpire_FreshToken() {
        String token = jwtTokenProvider.generateToken("user", Collections.emptyList());
        // Token expires in 24h, threshold is 1 minute - should not be about to expire
        boolean aboutToExpire = jwtTokenProvider.isTokenAboutToExpire(token, 60000L);
        assertThat(aboutToExpire).isFalse();
    }

    @Test
    @DisplayName("isTokenAboutToExpire returns true when threshold exceeds remaining time")
    void testIsTokenAboutToExpire_LargeThreshold() {
        String token = jwtTokenProvider.generateToken("user", Collections.emptyList());
        // Threshold is 48 hours, token expires in 24h - should be about to expire
        boolean aboutToExpire = jwtTokenProvider.isTokenAboutToExpire(token, 172800000L);
        assertThat(aboutToExpire).isTrue();
    }

    private Authentication createAuthentication(String username, String... roles) {
        Collection<GrantedAuthority> authorities = Arrays.stream(roles)
                .map(SimpleGrantedAuthority::new)
                .collect(java.util.stream.Collectors.toList());
        return new UsernamePasswordAuthenticationToken(username, null, authorities);
    }
}
