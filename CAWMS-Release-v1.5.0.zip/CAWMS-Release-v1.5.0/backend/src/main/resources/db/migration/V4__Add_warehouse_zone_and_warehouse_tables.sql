-- 创建库区表
CREATE TABLE IF NOT EXISTS warehouse_zone (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    zone_code VARCHAR(50) NOT NULL UNIQUE,
    zone_name VARCHAR(100) NOT NULL,
    zone_type VARCHAR(20) NOT NULL COMMENT 'SUPERVISED:监管仓, SELF_MANAGED:银行自管仓',
    address VARCHAR(200) DEFAULT NULL,
    contact_person VARCHAR(50) DEFAULT NULL,
    contact_phone VARCHAR(20) DEFAULT NULL,
    status VARCHAR(20) DEFAULT 'ACTIVE',
    deleted INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='库区表';

-- 创建仓库表
CREATE TABLE IF NOT EXISTS warehouse (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    warehouse_code VARCHAR(50) NOT NULL UNIQUE,
    warehouse_name VARCHAR(100) NOT NULL,
    zone_id BIGINT NOT NULL,
    manager VARCHAR(50) DEFAULT NULL,
    capacity DECIMAL(18,2) DEFAULT NULL,
    status VARCHAR(20) DEFAULT 'ACTIVE',
    deleted INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_zone_id (zone_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='仓库表';

-- 为 collateral_warehouse_in 增加库区、仓库关联字段（MySQL 8.0 支持 IF NOT EXISTS）
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'collateral_warehouse_in'
    AND column_name = 'zone_id'
);
SET @sql := IF(@col_exists = 0, 'ALTER TABLE collateral_warehouse_in ADD COLUMN zone_id BIGINT DEFAULT NULL AFTER wh_code, ADD INDEX idx_zone_id (zone_id)', 'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists2 := (
    SELECT COUNT(*) FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'collateral_warehouse_in'
    AND column_name = 'warehouse_id'
);
SET @sql2 := IF(@col_exists2 = 0, 'ALTER TABLE collateral_warehouse_in ADD COLUMN warehouse_id BIGINT DEFAULT NULL AFTER zone_id, ADD INDEX idx_warehouse_id (warehouse_id)', 'SELECT 1');
PREPARE stmt2 FROM @sql2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2;

-- 插入示例数据
INSERT INTO warehouse_zone (zone_code, zone_name, zone_type, address, contact_person, contact_phone, status)
VALUES
    ('ZONE-SH-001', '上海监管库区', 'SUPERVISED', '上海市浦东新区XX路1号', '张三', '13800138001', 'ACTIVE'),
    ('ZONE-SZ-001', '深圳自管库区', 'SELF_MANAGED', '深圳市南山区YY路2号', '李四', '13800138002', 'ACTIVE')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

INSERT INTO warehouse (warehouse_code, warehouse_name, zone_id, manager, capacity, status)
SELECT 'WH-SH-001', '上海监管仓A库', z.id, '王五', 10000.00, 'ACTIVE'
FROM warehouse_zone z WHERE z.zone_code = 'ZONE-SH-001'
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

INSERT INTO warehouse (warehouse_code, warehouse_name, zone_id, manager, capacity, status)
SELECT 'WH-SH-002', '上海监管仓B库', z.id, '赵六', 8000.00, 'ACTIVE'
FROM warehouse_zone z WHERE z.zone_code = 'ZONE-SH-001'
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

INSERT INTO warehouse (warehouse_code, warehouse_name, zone_id, manager, capacity, status)
SELECT 'WH-SZ-001', '深圳自管仓主库', z.id, '孙七', 12000.00, 'ACTIVE'
FROM warehouse_zone z WHERE z.zone_code = 'ZONE-SZ-001'
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;
