-- Flyway migration script V1 - Initial schema
-- This script is a placeholder for the initial database schema
-- The actual schema was created by init.sql script
-- This migration marks the baseline for future migrations

-- Note: The actual table creation is done by the init.sql script
-- This migration ensures Flyway recognizes the current state as baseline

SELECT 'Baseline migration - Schema already exists via init.sql' AS migration_note;