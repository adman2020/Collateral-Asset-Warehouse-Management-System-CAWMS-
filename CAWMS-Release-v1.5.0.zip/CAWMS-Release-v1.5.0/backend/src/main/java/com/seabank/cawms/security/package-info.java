/**
 * Security package for CAWMS application
 * Contains security configuration, JWT handling, and authentication/authorization logic
 */
package com.seabank.cawms.security;
