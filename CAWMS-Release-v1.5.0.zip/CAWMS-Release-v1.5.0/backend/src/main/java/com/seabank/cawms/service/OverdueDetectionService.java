package com.seabank.cawms.service;

import com.seabank.cawms.entity.LoanOutEntity;
import com.seabank.cawms.entity.OverdueAlertLogEntity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 閫炬湡妫€娴嬫湇鍔℃帴鍙? * 璐熻矗妫€娴嬪€熷嚭璁板綍鐨勯€炬湡鐘舵€侊紝骞惰Е鍙戠浉搴旂殑棰勮鍜屽鐞? */
public interface OverdueDetectionService {
    
    /**
     * 检测即将到期的借出记录
     * @param daysBefore 鎻愬墠棰勮澶╂暟锛堜粠閫炬湡预警配置鑾峰彇鎴栬嚜瀹氫箟锛?     * @return 妫€娴嬬粨鏋滅粺璁?     */
    DetectionResult detectExpiringLoans(Integer daysBefore);
    
    /**
     * 检测已逾期的借出记录
     * @return 妫€娴嬬粨鏋滅粺璁?     */
    DetectionResult detectOverdueLoans();
    
    /**
     * 鎵归噺更新閫炬湡鐘舵€?     * @param loanOutIds 需要更新状态的借出记录ID列表
     * @return 更新结果统计
     */
    UpdateResult updateOverdueStatus(List<Long> loanOutIds);
    
    /**
     * 鑾峰彇褰撳墠閫炬湡缁熻
     * @return 閫炬湡缁熻淇℃伅
     */
    OverdueStatistics getOverdueStatistics();
    
    /**
     * 鎵嬪姩瑙﹀彂閫炬湡妫€娴?     * @param options 检测选项
     * @return 妫€娴嬬粨鏋?     */
    ManualDetectionResult manualTriggerDetection(Map<String, Object> options);
    
    /**
     * 鑾峰彇妫€娴嬮厤缃?     * @return 妫€娴嬮厤缃俊鎭?     */
    DetectionConfig getDetectionConfig();
    
    /**
     * 更新妫€娴嬮厤缃?     * @param config 妫€娴嬮厤缃?     * @return 更新结果
     */
    ConfigUpdateResult updateDetectionConfig(DetectionConfig config);
    
    /**
     * 妫€娴嬬粨鏋?     */
    class DetectionResult {
        private Boolean success;
        private LocalDate detectionDate;
        private Integer totalRecords;
        private Integer expiringCount;
        private Integer overdueCount;
        private Integer warningGenerated;
        private Integer statusUpdated;
        private String message;
        private List<LoanOutEntity> expiringLoans;
        private List<LoanOutEntity> overdueLoans;
        private List<OverdueAlertLogEntity> generatedAlerts;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public LocalDate getDetectionDate() { return detectionDate; }
        public void setDetectionDate(LocalDate detectionDate) { this.detectionDate = detectionDate; }
        public Integer getTotalRecords() { return totalRecords; }
        public void setTotalRecords(Integer totalRecords) { this.totalRecords = totalRecords; }
        public Integer getExpiringCount() { return expiringCount; }
        public void setExpiringCount(Integer expiringCount) { this.expiringCount = expiringCount; }
        public Integer getOverdueCount() { return overdueCount; }
        public void setOverdueCount(Integer overdueCount) { this.overdueCount = overdueCount; }
        public Integer getWarningGenerated() { return warningGenerated; }
        public void setWarningGenerated(Integer warningGenerated) { this.warningGenerated = warningGenerated; }
        public Integer getStatusUpdated() { return statusUpdated; }
        public void setStatusUpdated(Integer statusUpdated) { this.statusUpdated = statusUpdated; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public List<LoanOutEntity> getExpiringLoans() { return expiringLoans; }
        public void setExpiringLoans(List<LoanOutEntity> expiringLoans) { this.expiringLoans = expiringLoans; }
        public List<LoanOutEntity> getOverdueLoans() { return overdueLoans; }
        public void setOverdueLoans(List<LoanOutEntity> overdueLoans) { this.overdueLoans = overdueLoans; }
        public List<OverdueAlertLogEntity> getGeneratedAlerts() { return generatedAlerts; }
        public void setGeneratedAlerts(List<OverdueAlertLogEntity> generatedAlerts) { this.generatedAlerts = generatedAlerts; }
    }
    
    /**
     * 更新结果
     */
    class UpdateResult {
        private Boolean success;
        private Integer totalRecords;
        private Integer successCount;
        private Integer failCount;
        private String message;
        private List<Long> successfulIds;
        private List<Map<String, Object>> failureDetails;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Integer getTotalRecords() { return totalRecords; }
        public void setTotalRecords(Integer totalRecords) { this.totalRecords = totalRecords; }
        public Integer getSuccessCount() { return successCount; }
        public void setSuccessCount(Integer successCount) { this.successCount = successCount; }
        public Integer getFailCount() { return failCount; }
        public void setFailCount(Integer failCount) { this.failCount = failCount; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public List<Long> getSuccessfulIds() { return successfulIds; }
        public void setSuccessfulIds(List<Long> successfulIds) { this.successfulIds = successfulIds; }
        public List<Map<String, Object>> getFailureDetails() { return failureDetails; }
        public void setFailureDetails(List<Map<String, Object>> failureDetails) { this.failureDetails = failureDetails; }
    }
    
    /**
     * 閫炬湡缁熻
     */
    class OverdueStatistics {
        private Integer totalLoans;
        private Integer activeLoans;
        private Integer overdueLoans;
        private Integer expiringLoans;
        private Double totalOverdueValue;
        private Double averageOverdueDays;
        private Map<String, Integer> overdueByDepartment;
        private Map<String, Integer> overdueByCollateralType;
        private List<LoanOutEntity> topOverdueLoans;
        private LocalDate statisticsDate;
        
        public Integer getTotalLoans() { return totalLoans; }
        public void setTotalLoans(Integer totalLoans) { this.totalLoans = totalLoans; }
        public Integer getActiveLoans() { return activeLoans; }
        public void setActiveLoans(Integer activeLoans) { this.activeLoans = activeLoans; }
        public Integer getOverdueLoans() { return overdueLoans; }
        public void setOverdueLoans(Integer overdueLoans) { this.overdueLoans = overdueLoans; }
        public Integer getExpiringLoans() { return expiringLoans; }
        public void setExpiringLoans(Integer expiringLoans) { this.expiringLoans = expiringLoans; }
        public Double getTotalOverdueValue() { return totalOverdueValue; }
        public void setTotalOverdueValue(Double totalOverdueValue) { this.totalOverdueValue = totalOverdueValue; }
        public Double getAverageOverdueDays() { return averageOverdueDays; }
        public void setAverageOverdueDays(Double averageOverdueDays) { this.averageOverdueDays = averageOverdueDays; }
        public Map<String, Integer> getOverdueByDepartment() { return overdueByDepartment; }
        public void setOverdueByDepartment(Map<String, Integer> overdueByDepartment) { this.overdueByDepartment = overdueByDepartment; }
        public Map<String, Integer> getOverdueByCollateralType() { return overdueByCollateralType; }
        public void setOverdueByCollateralType(Map<String, Integer> overdueByCollateralType) { this.overdueByCollateralType = overdueByCollateralType; }
        public List<LoanOutEntity> getTopOverdueLoans() { return topOverdueLoans; }
        public void setTopOverdueLoans(List<LoanOutEntity> topOverdueLoans) { this.topOverdueLoans = topOverdueLoans; }
        public LocalDate getStatisticsDate() { return statisticsDate; }
        public void setStatisticsDate(LocalDate statisticsDate) { this.statisticsDate = statisticsDate; }
    }
    
    /**
     * 鎵嬪姩妫€娴嬬粨鏋?     */
    class ManualDetectionResult {
        private Boolean success;
        private DetectionResult detectionResult;
        private Long executionTimeMs;
        private String triggeredBy;
        private LocalDateTime triggeredAt;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public DetectionResult getDetectionResult() { return detectionResult; }
        public void setDetectionResult(DetectionResult detectionResult) { this.detectionResult = detectionResult; }
        public Long getExecutionTimeMs() { return executionTimeMs; }
        public void setExecutionTimeMs(Long executionTimeMs) { this.executionTimeMs = executionTimeMs; }
        public String getTriggeredBy() { return triggeredBy; }
        public void setTriggeredBy(String triggeredBy) { this.triggeredBy = triggeredBy; }
        public LocalDateTime getTriggeredAt() { return triggeredAt; }
        public void setTriggeredAt(LocalDateTime triggeredAt) { this.triggeredAt = triggeredAt; }
    }
    
    /**
     * 妫€娴嬮厤缃?     */
    class DetectionConfig {
        private Boolean enabled;
        private String cronExpression;
        private Integer defaultDaysBefore;
        private Boolean autoUpdateStatus;
        private Boolean generateWarnings;
        private Integer batchSize;
        private Integer retryCount;
        private String notificationMethod;
        private String alertTemplate;
        private Map<String, Object> additionalSettings;
        
        public Boolean getEnabled() { return enabled; }
        public void setEnabled(Boolean enabled) { this.enabled = enabled; }
        public String getCronExpression() { return cronExpression; }
        public void setCronExpression(String cronExpression) { this.cronExpression = cronExpression; }
        public Integer getDefaultDaysBefore() { return defaultDaysBefore; }
        public void setDefaultDaysBefore(Integer defaultDaysBefore) { this.defaultDaysBefore = defaultDaysBefore; }
        public Boolean getAutoUpdateStatus() { return autoUpdateStatus; }
        public void setAutoUpdateStatus(Boolean autoUpdateStatus) { this.autoUpdateStatus = autoUpdateStatus; }
        public Boolean getGenerateWarnings() { return generateWarnings; }
        public void setGenerateWarnings(Boolean generateWarnings) { this.generateWarnings = generateWarnings; }
        public Integer getBatchSize() { return batchSize; }
        public void setBatchSize(Integer batchSize) { this.batchSize = batchSize; }
        public Integer getRetryCount() { return retryCount; }
        public void setRetryCount(Integer retryCount) { this.retryCount = retryCount; }
        public String getNotificationMethod() { return notificationMethod; }
        public void setNotificationMethod(String notificationMethod) { this.notificationMethod = notificationMethod; }
        public String getAlertTemplate() { return alertTemplate; }
        public void setAlertTemplate(String alertTemplate) { this.alertTemplate = alertTemplate; }
        public Map<String, Object> getAdditionalSettings() { return additionalSettings; }
        public void setAdditionalSettings(Map<String, Object> additionalSettings) { this.additionalSettings = additionalSettings; }
    }
    
    /**
     * 配置更新结果
     */
    class ConfigUpdateResult {
        private Boolean success;
        private DetectionConfig oldConfig;
        private DetectionConfig newConfig;
        private String message;
        private LocalDateTime updatedAt;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public DetectionConfig getOldConfig() { return oldConfig; }
        public void setOldConfig(DetectionConfig oldConfig) { this.oldConfig = oldConfig; }
        public DetectionConfig getNewConfig() { return newConfig; }
        public void setNewConfig(DetectionConfig newConfig) { this.newConfig = newConfig; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public LocalDateTime getUpdatedAt() { return updatedAt; }
        public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    }
}