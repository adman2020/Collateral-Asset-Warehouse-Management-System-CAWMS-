package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

import java.math.BigDecimal;
import java.time.LocalDate;

@TableName("collateral_warehouse_out")
public class WarehouseOutEntity extends BaseEntity {

    private Long whInId;
    private String outType;
    private String outReason;
    private BigDecimal outAmount;
    private BigDecimal outPercentage;
    private String status;
    private Integer currentStep;

    @TableField(exist = false)
    private WarehouseInEntity warehouseIn;

    @TableField(exist = false)
    private String customerName;

    @TableField(exist = false)
    private String collateralType;

    @TableField(exist = false)
    private BigDecimal collateralValue;

    public Long getWhInId() {
        return whInId;
    }
    public void setWhInId(Long whInId) {
        this.whInId = whInId;
    }

    public String getOutType() {
        return outType;
    }
    public void setOutType(String outType) {
        this.outType = outType;
    }

    public String getOutReason() {
        return outReason;
    }
    public void setOutReason(String outReason) {
        this.outReason = outReason;
    }

    public BigDecimal getOutAmount() {
        return outAmount;
    }
    public void setOutAmount(BigDecimal outAmount) {
        this.outAmount = outAmount;
    }

    public BigDecimal getOutPercentage() {
        return outPercentage;
    }
    public void setOutPercentage(BigDecimal outPercentage) {
        this.outPercentage = outPercentage;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getCurrentStep() {
        return currentStep;
    }
    public void setCurrentStep(Integer currentStep) {
        this.currentStep = currentStep;
    }

    public WarehouseInEntity getWarehouseIn() {
        return warehouseIn;
    }
    public void setWarehouseIn(WarehouseInEntity warehouseIn) {
        this.warehouseIn = warehouseIn;
    }

    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCollateralType() {
        return collateralType;
    }
    public void setCollateralType(String collateralType) {
        this.collateralType = collateralType;
    }

    public BigDecimal getCollateralValue() {
        return collateralValue;
    }
    public void setCollateralValue(BigDecimal collateralValue) {
        this.collateralValue = collateralValue;
    }
}
