package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.TransferApprovalEntity;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface TransferApprovalMapper extends BaseMapper<TransferApprovalEntity> {

    @Select("SELECT * FROM transfer_approval WHERE transfer_id = #{transferId} AND status = 'PENDING' ORDER BY step_number LIMIT 1")
    TransferApprovalEntity selectCurrentPendingStep(@Param("transferId") Long transferId);

    @Select("SELECT * FROM transfer_approval WHERE transfer_id = #{transferId} ORDER BY step_number")
    List<TransferApprovalEntity> selectByTransferId(@Param("transferId") Long transferId);

    @Delete("DELETE FROM transfer_approval WHERE transfer_id = #{transferId}")
    void deleteByTransferId(@Param("transferId") Long transferId);
}
