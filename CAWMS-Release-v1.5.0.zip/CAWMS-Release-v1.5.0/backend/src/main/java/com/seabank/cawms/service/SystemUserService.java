package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.seabank.cawms.entity.SystemUserEntity;

import java.util.List;

/**
 * 绯荤粺鐢ㄦ埛鏈嶅姟鎺ュ彛
 */
public interface SystemUserService extends IService<SystemUserEntity> {
    
    /**
     * 鏍规嵁鐢ㄦ埛鍚嶆煡璇㈢敤鎴?     */

    SystemUserEntity findByUsername(String username);
    
    /**
     * 鑾峰彇用户角色鍒楄〃
     */
    List<String> getUserRoles(Long userId);
    
    /**
     * 检查用户名是否存在
     */
    boolean existsByUsername(String username);
    
    /**
     * 妫€鏌ラ偖绠辨槸鍚﹀瓨鍦?     */

    boolean existsByEmail(String email);
    
    /**
     * 更新鐢ㄦ埛鏈€鍚庣櫥褰曚俊鎭?     */

    void updateLastLoginInfo(Long userId, String ipAddress);
    
    /**
     * 閿佸畾鐢ㄦ埛璐︽埛
     */
    boolean lockUser(Long userId, String reason);
    
    /**
     * 瑙ｉ攣鐢ㄦ埛璐︽埛
     */
    boolean unlockUser(Long userId);
    
    /**
     * 閲嶇疆鐢ㄦ埛瀵嗙爜
     */
    boolean resetPassword(Long userId, String newPassword);
    
    /**
     * 楠岃瘉鐢ㄦ埛瀵嗙爜
     */
    boolean validatePassword(Long userId, String password);
}