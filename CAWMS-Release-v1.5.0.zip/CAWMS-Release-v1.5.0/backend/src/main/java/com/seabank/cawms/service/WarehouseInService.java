package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.WarehouseInEntity;
import java.util.List;
import java.util.Map;

public interface WarehouseInService {
    WarehouseInEntity createWarehouseIn(WarehouseInEntity entity);
    WarehouseInEntity updateWarehouseIn(Long id, WarehouseInEntity entity);
    boolean deleteWarehouseIn(Long id);
    WarehouseInEntity getWarehouseInById(Long id);
    Page<WarehouseInEntity> queryWarehouseInList(int page, int size, String status, String warehouseNo, String collateralName);
    WarehouseInEntity submitWarehouseIn(Long id);
    WarehouseInEntity approveWarehouseIn(Long id, Integer step, String approvalStatus, String opinion);
    WarehouseInEntity rejectWarehouseIn(Long id, Integer step, String reason);
    WarehouseInEntity returnWarehouseIn(Long id, String reason);
    Page<WarehouseInEntity> queryPendingApprovals(String role, int page, int size);
    Map<String, Object> getStatistics();
    Map<String, Object> generateSlip(Long id, String format);
    byte[] exportData(List<Long> ids, String format);
    List<String> getApprovalHistory(Long id);
    Map<String, Object> validateProof(Long id);
    String generateWarehouseNo();
}
