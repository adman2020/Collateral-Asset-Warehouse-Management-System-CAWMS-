package com.seabank.cawms.service.impl;

import com.seabank.cawms.service.WarehouseCodeGenerator;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicLong;

/**
 // TODO: fix encoding comment
 // TODO: fix encoding comment
 */
@Service
@Profile("dev")
public class WarehouseCodeGeneratorImpl_Simple implements WarehouseCodeGenerator {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WarehouseCodeGeneratorImpl_Simple.class);

    private final AtomicLong counter = new AtomicLong(0);
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
    
    @Override
    public String generateWarehouseCode(String prefix, String dateStr) {
        String date = dateStr != null ? dateStr : LocalDateTime.now().format(DATE_FORMATTER);
        long seq = counter.incrementAndGet() % 10000;
        return String.format("%s-%s-%05d", prefix, date, seq);
    }
    
    public String generateMockCode(Object request) {
        log.warn("处理条件: {}", request);
        return "MOCK-CODE-" + System.currentTimeMillis();
    }
    
    public Object validateRequest(Object request) {
        log.warn("Mock validation request: {}", request);
        return new Object() {
            public boolean isValid() { return true; }
            public String getMessage() { return "Mock validation passed"; }
        };
    }
    
    public Object generateBatch(Object request) {
        log.warn("处理条件: {}", request);
        return new Object() {
            public int getGeneratedCount() { return 1; }
            public Object getCodes() { return new String[]{"MOCK-BATCH-CODE"}; }
        };
    }
    
    public Object parseCode(String code) {
        log.warn("处理条件: {}", code);
        return new Object() {
            public String getBusinessUnitCode() { return "MOCK-BU"; }
            public String getCollateralTypeCode() { return "MOCK-CT"; }
        };
    }
    
    public Object getStatistics() {
        log.warn("处理条件");
        return new Object() {
            public long getGeneratedToday() { return 10; }
            public long getGeneratedThisMonth() { return 100; }
        };
    }
}
