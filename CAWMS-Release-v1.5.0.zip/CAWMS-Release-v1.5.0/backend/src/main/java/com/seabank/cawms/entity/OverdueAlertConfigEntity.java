package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 * 閫炬湡预警配置瀹炰綋绫? * 瀵瑰簲鏁版嵁搴撹〃锛歰verdue_alert_config
 */
@TableName("overdue_alert_config")
public class OverdueAlertConfigEntity extends BaseEntity {
    
    /**
     * 鎻愬墠棰勮澶╂暟
     * 渚嬪锛? 琛ㄧず鍦ㄥ埌鏈熷墠3澶╁紑濮嬮璀?     */

    private Integer alertDaysBefore;
    
    /**
     * 棰勮鎺ユ敹浜?     * JSON鏍煎紡锛歔"user1@seabank.com", "user2@seabank.com"]
     * 鎴栬鑹叉牸寮忥細["ROLE_WAREHOUSE_MANAGER", "ROLE_RISK_OFFICER"]
     */
    private String alertRecipients;
    
    /**
     * 鏄惁鍚敤
     */
    private Boolean enabled;
    
    /**
     * 棰勮鏂瑰紡
     * 鍙栧€硷細EMAIL锛堥偖浠讹級, SMS锛堢煭淇★級, SYSTEM_NOTIFICATION锛堢郴缁熼€氱煡锛? ALL锛堝叏閮級
     */
    private String alertMethod;
    
    /**
     * 棰勮妯℃澘ID
     */
    private String alertTemplateId;
    
    /**
     * 棰勮棰戠巼锛堝皬鏃讹級
     * 渚嬪锛?4 琛ㄧず姣忓ぉ棰勮涓€娆?     */

    private Integer alertFrequencyHours;
    
    /**
     * 鏈€澶ч璀︽鏁?     * 0 琛ㄧず鏃犻檺鍒?     */

    private Integer maxAlertCount;
    
    /**
     * 鎵╁睍鏁版嵁锛圝SON鏍煎紡锛?     * 瀛樺偍棰濆閰嶇疆锛屽閭欢涓婚銆佺煭淇℃ā鏉跨瓑
     */
    @TableField(exist = false)
    private String extData;


    public Integer getAlertDaysBefore() {
        return alertDaysBefore;
    }
    public void setAlertDaysBefore(Integer alertDaysBefore) {
        this.alertDaysBefore = alertDaysBefore;
    }

    public String getAlertRecipients() {
        return alertRecipients;
    }
    public void setAlertRecipients(String alertRecipients) {
        this.alertRecipients = alertRecipients;
    }

    public Boolean getEnabled() {
        return enabled;
    }
    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public String getAlertMethod() {
        return alertMethod;
    }
    public void setAlertMethod(String alertMethod) {
        this.alertMethod = alertMethod;
    }

    public String getAlertTemplateId() {
        return alertTemplateId;
    }
    public void setAlertTemplateId(String alertTemplateId) {
        this.alertTemplateId = alertTemplateId;
    }

    public Integer getAlertFrequencyHours() {
        return alertFrequencyHours;
    }
    public void setAlertFrequencyHours(Integer alertFrequencyHours) {
        this.alertFrequencyHours = alertFrequencyHours;
    }

    public Integer getMaxAlertCount() {
        return maxAlertCount;
    }
    public void setMaxAlertCount(Integer maxAlertCount) {
        this.maxAlertCount = maxAlertCount;
    }

    public String getExtData() {
        return extData;
    }
    public void setExtData(String extData) {
        this.extData = extData;
    }
}