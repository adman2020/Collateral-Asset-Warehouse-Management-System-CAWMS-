package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDate;

/**
 * 鎶垫娂璧勪骇杞Щ瀹炰綋绫?
 * 瀵瑰簲鏁版嵁搴撹〃锛歝ollateral_transfer
 */
@TableName("collateral_transfer")
public class TransferEntity extends BaseEntity {
    
    /**
     * 鍏宠仈鐨勫叆搴撹褰旾D
     */
    private Long whInId;
    
    /**
     * 鏉ユ簮浠撳簱缂栫爜
     */
    private String sourceWhCode;
    
    /**
     * 鏉ユ簮浣嶇疆
     */
    private String sourceLocation;
    
    /**
     * 鐩爣浠撳簱缂栫爜
     */
    private String targetWhCode;
    
    /**
     * 鐩爣浣嶇疆
     */
    private String targetLocation;
    
    /**
     * 杞Щ绫诲瀷
     * 鍙栧€硷細INTERNAL锛堝簱鍐呰浆绉伙級, CROSS_WAREHOUSE锛堣法搴撹浆绉伙級
     */
    private String transferType;
    
    /**
     * 杞Щ鍘熷洜
     */
    private String transferReason;
    
    /**
     * 杞Щ鏃ユ湡
     */
    private LocalDate transferDate;
    
    /**
     * 杞Щ鐘舵€?
     * 鍙栧€硷細PENDING锛堝緟澶勭悊锛? IN_TRANSIT锛堣浆绉讳腑锛? COMPLETED锛堝凡瀹屾垚锛? CANCELLED锛堝凡鍙栨秷锛?
     */
    private String status;
    
    /**
     * 鍏宠仈鐨勫叆搴撹褰曡鎯咃紙闈炴暟鎹簱瀛楁锛?
     */
    @TableField(exist = false)
    private WarehouseInEntity warehouseIn;
    
    /**
     * 瀹㈡埛鍚嶇О锛堜粠鍏宠仈鍏ュ簱璁板綍鑾峰彇锛岄潪鏁版嵁搴撳瓧娈碉級
     */
    @TableField(exist = false)
    private String customerName;
    
    /**
     * 鎶垫娂鐗╃被鍨嬶紙浠庡叧鑱斿叆搴撹褰曡幏鍙栵紝闈炴暟鎹簱瀛楁锛?
     */
    @TableField(exist = false)
    private String collateralType;
    
    /**
     * 鎶垫娂鐗╀环鍊硷紙浠庡叧鑱斿叆搴撹褰曡幏鍙栵紝闈炴暟鎹簱瀛楁锛?
     */
    @TableField(exist = false)
    private java.math.BigDecimal collateralValue;


    public Long getWhInId() {
        return whInId;
    }
    public void setWhInId(Long whInId) {
        this.whInId = whInId;
    }

    public String getSourceWhCode() {
        return sourceWhCode;
    }
    public void setSourceWhCode(String sourceWhCode) {
        this.sourceWhCode = sourceWhCode;
    }

    public String getSourceLocation() {
        return sourceLocation;
    }
    public void setSourceLocation(String sourceLocation) {
        this.sourceLocation = sourceLocation;
    }

    public String getTargetWhCode() {
        return targetWhCode;
    }
    public void setTargetWhCode(String targetWhCode) {
        this.targetWhCode = targetWhCode;
    }

    public String getTargetLocation() {
        return targetLocation;
    }
    public void setTargetLocation(String targetLocation) {
        this.targetLocation = targetLocation;
    }

    public String getTransferType() {
        return transferType;
    }
    public void setTransferType(String transferType) {
        this.transferType = transferType;
    }

    public String getTransferReason() {
        return transferReason;
    }
    public void setTransferReason(String transferReason) {
        this.transferReason = transferReason;
    }

    public LocalDate getTransferDate() {
        return transferDate;
    }
    public void setTransferDate(LocalDate transferDate) {
        this.transferDate = transferDate;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public WarehouseInEntity getWarehouseIn() {
        return warehouseIn;
    }
    public void setWarehouseIn(WarehouseInEntity warehouseIn) {
        this.warehouseIn = warehouseIn;
    }

    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCollateralType() {
        return collateralType;
    }
    public void setCollateralType(String collateralType) {
        this.collateralType = collateralType;
    }

    public java.math.BigDecimal getCollateralValue() {
        return collateralValue;
    }
    public void setCollateralValue(java.math.BigDecimal collateralValue) {
        this.collateralValue = collateralValue;
    }
}
