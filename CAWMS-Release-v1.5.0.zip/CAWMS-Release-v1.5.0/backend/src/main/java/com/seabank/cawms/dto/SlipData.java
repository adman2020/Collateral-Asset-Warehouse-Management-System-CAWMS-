package com.seabank.cawms.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class SlipData {
    private String slipType;
    private String slipNumber;
    private String slipId;
    private String businessDate;
    private String department;
    private String applicant;
    private String approver;
    private Map<String, Object> headerData;
    private Map<String, Object> bodyData;
    private Map<String, Object> footerData;
    private Map<String, Object> extraFields;
    private String templateName;
    private Boolean requireSignature;
    private Boolean requireStamp;
    private String language;
    private String currency;
    private String whCode;
    private String businessUnit;
    private String customerName;
    private String collateralType;
    private BigDecimal collateralValue;
    private LocalDateTime intakeDate;
    private String intakeType;
    private List<SlipItem> items;


    public SlipData() {
    }

    public SlipData(String slipType, String slipNumber, String slipId, String businessDate, String department, String applicant, String approver, Map<String, Object> headerData, Map<String, Object> bodyData, Map<String, Object> footerData, Map<String, Object> extraFields, String templateName, Boolean requireSignature, Boolean requireStamp, String language, String currency, String whCode, String businessUnit, String customerName, String collateralType, BigDecimal collateralValue, LocalDateTime intakeDate, String intakeType, List<SlipItem> items) {
        this.slipType = slipType;
        this.slipNumber = slipNumber;
        this.slipId = slipId;
        this.businessDate = businessDate;
        this.department = department;
        this.applicant = applicant;
        this.approver = approver;
        this.headerData = headerData;
        this.bodyData = bodyData;
        this.footerData = footerData;
        this.extraFields = extraFields;
        this.templateName = templateName;
        this.requireSignature = requireSignature;
        this.requireStamp = requireStamp;
        this.language = language;
        this.currency = currency;
        this.whCode = whCode;
        this.businessUnit = businessUnit;
        this.customerName = customerName;
        this.collateralType = collateralType;
        this.collateralValue = collateralValue;
        this.intakeDate = intakeDate;
        this.intakeType = intakeType;
        this.items = items;
    }

    public String getSlipType() {
        return slipType;
    }

    public void setSlipType(String slipType) {
        this.slipType = slipType;
    }

    public String getSlipNumber() {
        return slipNumber;
    }

    public void setSlipNumber(String slipNumber) {
        this.slipNumber = slipNumber;
    }

    public String getSlipId() {
        return slipId;
    }

    public void setSlipId(String slipId) {
        this.slipId = slipId;
    }

    public String getBusinessDate() {
        return businessDate;
    }

    public void setBusinessDate(String businessDate) {
        this.businessDate = businessDate;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getApplicant() {
        return applicant;
    }

    public void setApplicant(String applicant) {
        this.applicant = applicant;
    }

    public String getApprover() {
        return approver;
    }

    public void setApprover(String approver) {
        this.approver = approver;
    }

    public Map<String, Object> getHeaderData() {
        return headerData;
    }

    public void setHeaderData(Map<String, Object> headerData) {
        this.headerData = headerData;
    }

    public Map<String, Object> getBodyData() {
        return bodyData;
    }

    public void setBodyData(Map<String, Object> bodyData) {
        this.bodyData = bodyData;
    }

    public Map<String, Object> getFooterData() {
        return footerData;
    }

    public void setFooterData(Map<String, Object> footerData) {
        this.footerData = footerData;
    }

    public Map<String, Object> getExtraFields() {
        return extraFields;
    }

    public void setExtraFields(Map<String, Object> extraFields) {
        this.extraFields = extraFields;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public Boolean getRequireSignature() {
        return requireSignature;
    }

    public void setRequireSignature(Boolean requireSignature) {
        this.requireSignature = requireSignature;
    }

    public Boolean getRequireStamp() {
        return requireStamp;
    }

    public void setRequireStamp(Boolean requireStamp) {
        this.requireStamp = requireStamp;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getWhCode() {
        return whCode;
    }

    public void setWhCode(String whCode) {
        this.whCode = whCode;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCollateralType() {
        return collateralType;
    }

    public void setCollateralType(String collateralType) {
        this.collateralType = collateralType;
    }

    public BigDecimal getCollateralValue() {
        return collateralValue;
    }

    public void setCollateralValue(BigDecimal collateralValue) {
        this.collateralValue = collateralValue;
    }

    public LocalDateTime getIntakeDate() {
        return intakeDate;
    }

    public void setIntakeDate(LocalDateTime intakeDate) {
        this.intakeDate = intakeDate;
    }

    public String getIntakeType() {
        return intakeType;
    }

    public void setIntakeType(String intakeType) {
        this.intakeType = intakeType;
    }

    public List<SlipItem> getItems() {
        return items;
    }

    public void setItems(List<SlipItem> items) {
        this.items = items;
    }
}
