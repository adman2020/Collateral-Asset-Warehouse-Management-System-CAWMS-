/**
 * Transfer module package
 * Contains all components for collateral asset transfer management
 */
package com.seabank.cawms.module.transfer;
