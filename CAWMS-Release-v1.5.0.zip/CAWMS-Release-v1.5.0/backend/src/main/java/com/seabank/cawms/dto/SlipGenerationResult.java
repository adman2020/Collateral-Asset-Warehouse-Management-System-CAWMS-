package com.seabank.cawms.dto;

import java.util.Map;

/**
 * 鍗曟嵁鐢熸垚缁撴灉 DTO
 */
public class SlipGenerationResult {
    private Boolean success;
    private byte[] slipContent;
    private String slipFormat;
    private String fileName;
    private Long fileSize;
    private String downloadUrl;
    private String errorMessage;
    private Long generationTime;
    private String slipId;
    private String slipNumber;
    private String filePath;
    private String message;
    private String checksum;
    private Map<String, Object> metadata;


    public SlipGenerationResult() {
    }

    public SlipGenerationResult(Boolean success, byte[] slipContent, String slipFormat, String fileName, Long fileSize, String downloadUrl, String errorMessage, Long generationTime, String slipId, String slipNumber, String filePath, String message, String checksum, Map<String, Object> metadata) {
        this.success = success;
        this.slipContent = slipContent;
        this.slipFormat = slipFormat;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.downloadUrl = downloadUrl;
        this.errorMessage = errorMessage;
        this.generationTime = generationTime;
        this.slipId = slipId;
        this.slipNumber = slipNumber;
        this.filePath = filePath;
        this.message = message;
        this.checksum = checksum;
        this.metadata = metadata;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public byte[] getSlipContent() {
        return slipContent;
    }

    public void setSlipContent(byte[] slipContent) {
        this.slipContent = slipContent;
    }

    public String getSlipFormat() {
        return slipFormat;
    }

    public void setSlipFormat(String slipFormat) {
        this.slipFormat = slipFormat;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Long getGenerationTime() {
        return generationTime;
    }

    public void setGenerationTime(Long generationTime) {
        this.generationTime = generationTime;
    }

    public String getSlipId() {
        return slipId;
    }

    public void setSlipId(String slipId) {
        this.slipId = slipId;
    }

    public String getSlipNumber() {
        return slipNumber;
    }

    public void setSlipNumber(String slipNumber) {
        this.slipNumber = slipNumber;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getChecksum() {
        return checksum;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
}
