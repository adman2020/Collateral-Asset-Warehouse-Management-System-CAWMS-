package com.seabank.cawms.dto;


public class GenerationResult {
    private String code;
    private Boolean success;
    private String message;


    public GenerationResult() {
    }

    public GenerationResult(String code, Boolean success, String message) {
        this.code = code;
        this.success = success;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
