package com.seabank.cawms.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.common.PageResult;
import com.seabank.cawms.entity.SystemUserEntity;
import com.seabank.cawms.service.SystemUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * System User Management Controller
 */
@Validated
@RestController
@RequestMapping("/api/system/users")
@Tag(name = "UserController", description = "System User Management API")
public class UserController {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(UserController.class);

    private final SystemUserService systemUserService;
    private final PasswordEncoder passwordEncoder;

    public UserController(SystemUserService systemUserService, PasswordEncoder passwordEncoder) {
        this.systemUserService = systemUserService;
        this.passwordEncoder = passwordEncoder;
    }

    @Operation(summary = "Get User List")
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<PageResult<UserDto>> getUserList(
            @RequestParam(defaultValue = "1") @Min(1) Integer page,
            @RequestParam(defaultValue = "10") @Min(1) Integer size,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String realName,
            @RequestParam(required = false) String status) {

        LambdaQueryWrapper<SystemUserEntity> wrapper = new LambdaQueryWrapper<>();
        if (username != null && !username.isBlank()) {
            wrapper.like(SystemUserEntity::getUsername, username);
        }
        if (realName != null && !realName.isBlank()) {
            wrapper.like(SystemUserEntity::getFullName, realName);
        }
        if (status != null && !status.isBlank()) {
            wrapper.eq(SystemUserEntity::getStatus, status.toUpperCase());
        }
        wrapper.orderByDesc(SystemUserEntity::getCreatedAt);

        Page<SystemUserEntity> entityPage = systemUserService.page(new Page<>(page, size), wrapper);
        List<UserDto> records = entityPage.getRecords().stream()
                .map(this::toDto)
                .toList();

        PageResult<UserDto> result = PageResult.of(entityPage.getCurrent(), entityPage.getSize(),
                entityPage.getTotal(), records);
        return CommonResponse.success(result);
    }

    @Operation(summary = "Get User Detail")
    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<UserDto> getUserDetail(@PathVariable @NotNull Long id) {
        SystemUserEntity user = systemUserService.getById(id);
        if (user == null) {
            return CommonResponse.error(404, "User not found");
        }
        return CommonResponse.success(toDto(user));
    }

    @Operation(summary = "Create User")
    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<UserDto> createUser(@Valid @RequestBody UserCreateRequest request) {
        if (systemUserService.existsByUsername(request.getUsername())) {
            return CommonResponse.error(409, "Username already exists");
        }

        SystemUserEntity user = new SystemUserEntity();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setFullName(request.getRealName());
        user.setEmail(request.getEmail());
        user.setPhoneNumber(request.getPhone());
        user.setDepartment(request.getDepartmentName());
        user.setRole(request.getRoleNames() != null && !request.getRoleNames().isEmpty()
                ? request.getRoleNames().get(0) : "user");
        user.setStatus(request.getStatus() != null ? request.getStatus().toUpperCase() : "ACTIVE");
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        systemUserService.save(user);
        return CommonResponse.success(toDto(user), "User created successfully");
    }

    @Operation(summary = "Update User")
    @PutMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<UserDto> updateUser(@PathVariable @NotNull Long id,
                                               @Valid @RequestBody UserUpdateRequest request) {
        SystemUserEntity user = systemUserService.getById(id);
        if (user == null) {
            return CommonResponse.error(404, "User not found");
        }

        if (request.getRealName() != null) user.setFullName(request.getRealName());
        if (request.getEmail() != null) user.setEmail(request.getEmail());
        if (request.getPhone() != null) user.setPhoneNumber(request.getPhone());
        if (request.getDepartmentName() != null) user.setDepartment(request.getDepartmentName());
        if (request.getRoleNames() != null && !request.getRoleNames().isEmpty()) {
            user.setRole(request.getRoleNames().get(0));
        }
        if (request.getStatus() != null) user.setStatus(request.getStatus().toUpperCase());
        user.setUpdatedAt(LocalDateTime.now());

        systemUserService.updateById(user);
        return CommonResponse.success(toDto(user), "User updated successfully");
    }

    @Operation(summary = "Delete User")
    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<Boolean> deleteUser(@PathVariable @NotNull Long id) {
        boolean removed = systemUserService.removeById(id);
        if (!removed) {
            return CommonResponse.error(404, "User not found");
        }
        return CommonResponse.success(true, "User deleted successfully");
    }

    @Operation(summary = "Reset User Password")
    @PostMapping("/{id}/reset-password")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<Boolean> resetPassword(@PathVariable @NotNull Long id,
                                                  @Valid @RequestBody ResetPasswordRequest request) {
        SystemUserEntity user = systemUserService.getById(id);
        if (user == null) {
            return CommonResponse.error(404, "User not found");
        }
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        user.setUpdatedAt(LocalDateTime.now());
        systemUserService.updateById(user);
        return CommonResponse.success(true, "Password reset successfully");
    }

    private UserDto toDto(SystemUserEntity user) {
        UserDto dto = new UserDto();
        dto.setId(user.getId());
        dto.setUsername(user.getUsername());
        dto.setRealName(user.getFullName());
        dto.setEmail(user.getEmail());
        dto.setPhone(user.getPhoneNumber());
        dto.setDepartmentName(user.getDepartment());
        dto.setRoleNames(user.getRole() != null ? List.of(user.getRole()) : List.of());
        dto.setStatus(user.getStatus());
        dto.setCreateTime(user.getCreatedAt() != null ? user.getCreatedAt().toString() : null);
        dto.setLastLoginTime(user.getLastLoginTime() != null ? user.getLastLoginTime().toString() : null);
        return dto;
    }

    // ==================== DTOs ====================

    @Validated
    public static class UserCreateRequest {
        @NotBlank private String username;
        @NotBlank private String password;
        private String realName;
        private String email;
        private String phone;
        private String departmentName;
        private List<String> roleNames;
        private String status;

        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getRealName() { return realName; }
        public void setRealName(String realName) { this.realName = realName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }
        public String getDepartmentName() { return departmentName; }
        public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }
        public List<String> getRoleNames() { return roleNames; }
        public void setRoleNames(List<String> roleNames) { this.roleNames = roleNames; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    @Validated
    public static class UserUpdateRequest {
        private String realName;
        private String email;
        private String phone;
        private String departmentName;
        private List<String> roleNames;
        private String status;

        public String getRealName() { return realName; }
        public void setRealName(String realName) { this.realName = realName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }
        public String getDepartmentName() { return departmentName; }
        public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }
        public List<String> getRoleNames() { return roleNames; }
        public void setRoleNames(List<String> roleNames) { this.roleNames = roleNames; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    @Validated
    public static class ResetPasswordRequest {
        @NotBlank private String newPassword;
        public String getNewPassword() { return newPassword; }
        public void setNewPassword(String newPassword) { this.newPassword = newPassword; }
    }

    public static class UserDto {
        private Long id;
        private String username;
        private String realName;
        private String email;
        private String phone;
        private String departmentName;
        private List<String> roleNames;
        private String status;
        private String createTime;
        private String lastLoginTime;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getRealName() { return realName; }
        public void setRealName(String realName) { this.realName = realName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }
        public String getDepartmentName() { return departmentName; }
        public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }
        public List<String> getRoleNames() { return roleNames; }
        public void setRoleNames(List<String> roleNames) { this.roleNames = roleNames; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getCreateTime() { return createTime; }
        public void setCreateTime(String createTime) { this.createTime = createTime; }
        public String getLastLoginTime() { return lastLoginTime; }
        public void setLastLoginTime(String lastLoginTime) { this.lastLoginTime = lastLoginTime; }
    }
}
