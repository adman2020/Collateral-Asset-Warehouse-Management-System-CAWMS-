package com.seabank.cawms.service;

import com.seabank.cawms.dto.BatchSlipGenerationResult;
import com.seabank.cawms.dto.SlipData;
import com.seabank.cawms.dto.SlipGenerationResult;
import com.seabank.cawms.entity.WarehouseInEntity;

public interface SlipGenerationService {
    SlipGenerationResult generateWarehouseInSlip(WarehouseInEntity warehouseInEntity);
    SlipGenerationResult generateSlip(SlipData slipData);
    BatchSlipGenerationResult generateBatchSlips(java.util.List<SlipData> slipDataList);
}
