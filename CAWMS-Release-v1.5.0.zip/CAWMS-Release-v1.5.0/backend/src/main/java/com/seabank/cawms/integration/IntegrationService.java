package com.seabank.cawms.integration;

/**
 * 闆嗘垚鏈嶅姟鍩虹被鎺ュ彛
 * 瀹氫箟鎵€鏈夊閮ㄧ郴缁熼泦鎴愭湇鍔＄殑閫氱敤鏂规硶
 */
public interface IntegrationService {
    
    /**
     * 鏈嶅姟鍚嶇О
     */
    String getServiceName();
    
    /**
     * 妫€鏌ユ湇鍔℃槸鍚﹀彲鐢?     */

    boolean isAvailable();
    
    /**
     * 鑾峰彇鏈嶅姟鐘舵€?     */

    ServiceStatus getStatus();
    
    /**
     * 娴嬭瘯杩炴帴
     */
    ConnectionTestResult testConnection();
    
    /**
     * 鑾峰彇鏈€鍚庨敊璇俊鎭?     */

    String getLastError();
    
    /**
     * 鏈嶅姟鐘舵€佹灇涓?     */

    enum ServiceStatus {
        AVAILABLE("处理条件"),
        UNAVAILABLE("处理条件"),
        DEGRADED("闄嶇骇"),
        MAINTENANCE("处理条件");
        
        private final String description;
        
        ServiceStatus(String description) {
            this.description = description;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
    /**
     * 杩炴帴娴嬭瘯缁撴灉
     */
    class ConnectionTestResult {
        private boolean success;
        private long responseTime;
        private String message;
        private String version;
        
        public ConnectionTestResult(boolean success, long responseTime, String message) {
            this.success = success;
            this.responseTime = responseTime;
            this.message = message;
        }
        
        public ConnectionTestResult(boolean success, long responseTime, String message, String version) {
            this.success = success;
            this.responseTime = responseTime;
            this.message = message;
            this.version = version;
        }
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public long getResponseTime() {
            return responseTime;
        }
        
        public void setResponseTime(long responseTime) {
            this.responseTime = responseTime;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public String getVersion() {
            return version;
        }
        
        public void setVersion(String version) {
            this.version = version;
        }
    }
}