package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;

import java.time.LocalDateTime;

/**
 * 鍏ュ簱审批记录瀹炰綋绫? * 瀵瑰簲鏁版嵁搴撹〃锛歸arehouse_in_approval
 */
@TableName("warehouse_in_approval")
public class WarehouseInApprovalEntity {
    
    /**
     * 涓婚敭ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    
    /**
     * 入库记录ID锛堝閿級
     */
    private Long whInId;
    
    /**
     * 步骤编号锛?-5锛?     * 1: 涓氬姟部门鎻愪氦
     * 2: 椋庨櫓部门瀹℃牳
     * 3: 鍚堣部门瀹℃牳
     * 4: 浠撳簱绠＄悊鍛樼‘璁?     * 5: 瀹屾垚鍏ュ簱
     */
    private Integer stepNumber;
    
    /**
     * 姝ラ鍚嶇О
     */
    private String stepName;
    
    /**
     * 审批角色
     * 鍙栧€硷細BUSINESS_MANAGER锛堜笟鍔＄粡鐞嗭級, RISK_OFFICER锛堥闄╁畼锛? 
     * COMPLIANCE_OFFICER锛堝悎瑙勫畼锛? WAREHOUSE_MANAGER锛堜粨搴撶鐞嗗憳锛? SYSTEM锛堢郴缁燂級
     */
    private String approverRole;
    
    /**
     * 审批用户锛堢敤鎴稩D锛?     */

    private String approverUser;
    
    /**
     * 审批用户濮撳悕
     */
    private String approverName;
    
    /**
     * 瀹℃壒鐘舵€?     * 鍙栧€硷細PENDING锛堝緟瀹℃壒锛? APPROVED锛堝凡鎵瑰噯锛? REJECTED锛堝凡鎷掔粷锛? 
     * RETURNED锛堝凡閫€鍥烇級, CANCELLED锛堝凡鍙栨秷锛?     */

    private String status;
    
    /**
     * 瀹℃壒鎰忚
     */
    private String comments;
    
    /**
     * 瀹℃壒鏃堕棿
     */
    private LocalDateTime approvedAt;
    
    /**
     * 创建鏃堕棿
     */
    private LocalDateTime createdAt;
    
    /**
     * 更新鏃堕棿
     */
    private LocalDateTime updatedAt;
    
    /**
     * 棰勮瀹屾垚鏃堕棿
     */
    private LocalDateTime dueDate;
    
    /**
     * 瀹為檯瀹屾垚鏃堕棿
     */
    private LocalDateTime completedAt;
    
    /**
     * 澶勭悊鏃堕暱锛堝垎閽燂級
     */
    private Integer processingMinutes;
    
    /**
     * 鏄惁鑷姩瀹℃壒
     */
    private Boolean autoApproved;
    
    /**
     * 瀹℃壒闄勪欢锛圝SON鏍煎紡锛屽瓨鍌ㄧ浉鍏虫枃浠禝D锛?     */

    private String approvalAttachments;
    
    /**
     * 鎵╁睍瀛楁 - JSON鏍煎紡瀛樺偍棰濆淇℃伅
     */
    private String extData;
    
    /**
     * 鐗堟湰鍙凤紙涔愯閿侊級
     */
    @Version
    private Integer version;


    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Long getWhInId() {
        return whInId;
    }
    public void setWhInId(Long whInId) {
        this.whInId = whInId;
    }

    public Integer getStepNumber() {
        return stepNumber;
    }
    public void setStepNumber(Integer stepNumber) {
        this.stepNumber = stepNumber;
    }

    public String getStepName() {
        return stepName;
    }
    public void setStepName(String stepName) {
        this.stepName = stepName;
    }

    public String getApproverRole() {
        return approverRole;
    }
    public void setApproverRole(String approverRole) {
        this.approverRole = approverRole;
    }

    public String getApproverUser() {
        return approverUser;
    }
    public void setApproverUser(String approverUser) {
        this.approverUser = approverUser;
    }

    public String getApproverName() {
        return approverName;
    }
    public void setApproverName(String approverName) {
        this.approverName = approverName;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getComments() {
        return comments;
    }
    public void setComments(String comments) {
        this.comments = comments;
    }

    public LocalDateTime getApprovedAt() {
        return approvedAt;
    }
    public void setApprovedAt(LocalDateTime approvedAt) {
        this.approvedAt = approvedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public LocalDateTime getDueDate() {
        return dueDate;
    }
    public void setDueDate(LocalDateTime dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }
    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public Integer getProcessingMinutes() {
        return processingMinutes;
    }
    public void setProcessingMinutes(Integer processingMinutes) {
        this.processingMinutes = processingMinutes;
    }

    public Boolean getAutoApproved() {
        return autoApproved;
    }
    public void setAutoApproved(Boolean autoApproved) {
        this.autoApproved = autoApproved;
    }

    public String getApprovalAttachments() {
        return approvalAttachments;
    }
    public void setApprovalAttachments(String approvalAttachments) {
        this.approvalAttachments = approvalAttachments;
    }

    public String getExtData() {
        return extData;
    }
    public void setExtData(String extData) {
        this.extData = extData;
    }

    public Integer getVersion() {
        return version;
    }
    public void setVersion(Integer version) {
        this.version = version;
    }
}