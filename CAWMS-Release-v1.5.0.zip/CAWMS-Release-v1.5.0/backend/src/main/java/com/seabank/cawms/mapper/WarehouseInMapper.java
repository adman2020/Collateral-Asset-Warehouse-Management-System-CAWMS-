package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.WarehouseInEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 鎶垫娂璧勪骇鍏ュ簱Mapper鎺ュ彛
 */
@Mapper
public interface WarehouseInMapper extends BaseMapper<WarehouseInEntity> {
    
    /**
     * 鏍规嵁鐘舵€佹煡璇㈠叆搴撹褰?     * @param status 鐘舵€?     * @return 鍏ュ簱璁板綍鍒楄〃
     */
    List<WarehouseInEntity> selectByStatus(@Param("status") String status);
    
    /**
     * 鏍规嵁瀹㈡埛ID鏌ヨ鍏ュ簱璁板綍
     * @param customerId 瀹㈡埛ID
     * @return 鍏ュ簱璁板綍鍒楄〃
     */
    List<WarehouseInEntity> selectByCustomerId(@Param("customerId") String customerId);
    
    /**
     * 鏍规嵁鍏ュ簱绫诲瀷鏌ヨ鍏ュ簱璁板綍
     * @param intakeType 鍏ュ簱绫诲瀷
     * @return 鍏ュ簱璁板綍鍒楄〃
     */
    List<WarehouseInEntity> selectByIntakeType(@Param("intakeType") String intakeType);
    
    /**
     * 鏌ヨ鎸囧畾鏃堕棿娈靛唴鐨勫叆搴撹褰?     * @param startTime 寮€濮嬫椂闂?     * @param endTime 结束时间
     * @return 鍏ュ簱璁板綍鍒楄〃
     */
    List<WarehouseInEntity> selectByTimeRange(
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);
    
    /**
     * 鏍规嵁涓氬姟部门缂栫爜鏌ヨ鍏ュ簱璁板綍
     * @param buCode 涓氬姟部门缂栫爜
     * @return 鍏ュ簱璁板綍鍒楄〃
     */
    List<WarehouseInEntity> selectByBuCode(@Param("buCode") String buCode);
    
    /**
     * 鏍规嵁浠撳簱鍏ュ簱缂栫爜鏌ヨ
     * @param whCode 浠撳簱鍏ュ簱缂栫爜
     * @return 鍏ュ簱璁板綍
     */
    WarehouseInEntity selectByWhCode(@Param("whCode") String whCode);
    
    /**
     * 更新鍏ュ簱鐘舵€?     * @param id 璁板綍ID
     * @param status 鏂扮姸鎬?     * @param updatedBy 更新浜?     * @return 褰卞搷琛屾暟
     */
    int updateStatus(@Param("id") Long id, 
                     @Param("status") String status,
                     @Param("updatedBy") String updatedBy);
    
    /**
     * 更新当前步骤
     * @param id 璁板綍ID
     * @param currentStep 鏂版楠?     * @param updatedBy 更新浜?     * @return 褰卞搷琛屾暟
     */
    int updateCurrentStep(@Param("id") Long id,
                         @Param("currentStep") Integer currentStep,
                         @Param("updatedBy") String updatedBy);
    
    /**
     * 缁熻鍚勭姸鎬佸叆搴撹褰曟暟閲?     * @return 鐘舵€佺粺璁″垪琛?     */

    @Select("SELECT status, COUNT(*) as count FROM collateral_warehouse_in WHERE deleted = 0 GROUP BY status")
    List<StatusCount> countByStatus();
    
    /**
     * 缁熻鍚勭被鍨嬫姷鎶肩墿鏁伴噺
     * @return 鎶垫娂鐗╃被鍨嬬粺璁″垪琛?     */

    @Select("SELECT collateral_type, COUNT(*) as count FROM collateral_warehouse_in WHERE deleted = 0 GROUP BY collateral_type")
    List<CollateralTypeCount> countByCollateralType();
    
    /**
     * 获取待处理入库记录（当前步骤为指定步骤且状态为审批中）
     * @param currentStep 褰撳墠姝ラ
     * @return 鍏ュ簱璁板綍鍒楄〃
     */
    List<WarehouseInEntity> selectPendingByStep(@Param("currentStep") Integer currentStep);
    
    /**
     * 缁熻鐢熸垚鐨勭紪鐮佹€绘暟
     * @return 缂栫爜鎬绘暟
     */
    @Select("SELECT COUNT(*) FROM collateral_warehouse_in WHERE deleted = 0 AND wh_code IS NOT NULL")
    Long countGeneratedCodes();
    
    /**
     * 鎸夋棩鏈熺粺璁＄紪鐮佹暟閲?     * @param date 鏃ユ湡锛坹yyyMMdd鏍煎紡锛?     * @return 缂栫爜鏁伴噺
     */
    @Select("SELECT COUNT(*) FROM collateral_warehouse_in WHERE deleted = 0 AND wh_code LIKE CONCAT('%', #{date}, '%')")
    Long countCodesByDate(@Param("date") String date);
    
    /**
     * 鎸夋湀浠界粺璁＄紪鐮佹暟閲?     * @param monthPrefix 鏈堜唤鍓嶇紑锛坹yyyMM鏍煎紡锛?     * @return 缂栫爜鏁伴噺
     */
    @Select("SELECT COUNT(*) FROM collateral_warehouse_in WHERE deleted = 0 AND wh_code LIKE CONCAT('%', #{monthPrefix}, '%')")
    Long countCodesByMonth(@Param("monthPrefix") String monthPrefix);
    
    /**
     * 鎸変笟鍔￠儴闂ㄧ粺璁＄紪鐮佹暟閲?     * @return 涓氬姟部门缁熻鏄犲皠
     */
    @Select("SELECT bu_code, COUNT(*) as count FROM collateral_warehouse_in WHERE deleted = 0 AND wh_code IS NOT NULL GROUP BY bu_code")
    Map<String, Long> countCodesByBusinessUnit();
    
    /**
     * 按抵押物类型统计编码数量
     * @return 鎶垫娂鐗╃被鍨嬬粺璁℃槧灏?     */

    @Select("SELECT collateral_type, COUNT(*) as count FROM collateral_warehouse_in WHERE deleted = 0 AND wh_code IS NOT NULL GROUP BY collateral_type")
    Map<String, Long> countCodesByCollateralType();
    
    /**
     * 获取最后生成的编码记录
     * @return 鏈€鍚庣敓鎴愮殑鍏ュ簱璁板綍
     */
    @Select("SELECT * FROM collateral_warehouse_in WHERE deleted = 0 AND wh_code IS NOT NULL ORDER BY created_at DESC LIMIT 1")
    WarehouseInEntity selectLastGenerated();
    
    /**
     * 妫€鏌ユ寚瀹氱紪鐮佹槸鍚﹀瓨鍦?     * @param whCode 浠撳簱缂栫爜
     * @return 瀛樺湪鏁伴噺
     */
    @Select("SELECT COUNT(*) FROM collateral_warehouse_in WHERE deleted = 0 AND wh_code = #{whCode}")
    Long countByWhCode(@Param("whCode") String whCode);
    
    /**
     * 查询待我审批的入库单
     */
    @Select("SELECT DISTINCT w.* FROM collateral_warehouse_in w " +
            "JOIN warehouse_in_approval a ON w.id = a.wh_in_id " +
            "WHERE w.deleted = 0 AND a.status = 'PENDING' " +
            "AND a.approver_role = #{approverRole} " +
            "ORDER BY w.created_at DESC")
    List<WarehouseInEntity> selectPendingByApproverRole(@Param("approverRole") String approverRole);
    
    /**
     * 查询所有待审批的入库单（管理员用）
     */
    @Select("SELECT DISTINCT w.* FROM collateral_warehouse_in w " +
            "JOIN warehouse_in_approval a ON w.id = a.wh_in_id " +
            "WHERE w.deleted = 0 AND a.status = 'PENDING' " +
            "ORDER BY w.created_at DESC")
    List<WarehouseInEntity> selectAllPending();
    
    /**
     * 查询我已审批但还在进行中的入库单
     */
    @Select("SELECT DISTINCT w.* FROM collateral_warehouse_in w " +
            "JOIN warehouse_in_approval a ON w.id = a.wh_in_id " +
            "WHERE w.deleted = 0 AND w.status IN ('SUBMITTED', 'IN_REVIEW', 'APPROVED') " +
            "AND a.status = 'APPROVED' AND a.approver_user = #{approverUser} " +
            "ORDER BY w.created_at DESC")
    List<WarehouseInEntity> selectMyApprovedOngoing(@Param("approverUser") String approverUser);
    
    /**
     * 查询我已审批且已完结的入库单（审批记录）
     */
    @Select("SELECT DISTINCT w.* FROM collateral_warehouse_in w " +
            "JOIN warehouse_in_approval a ON w.id = a.wh_in_id " +
            "WHERE w.deleted = 0 AND w.status IN ('COMPLETED', 'REJECTED') " +
            "AND a.status = 'APPROVED' AND a.approver_user = #{approverUser} " +
            "ORDER BY w.created_at DESC")
    List<WarehouseInEntity> selectMyHistory(@Param("approverUser") String approverUser);
    
    /**
     * 鐘舵€佺粺璁＄粨鏋?     */

    class StatusCount {
        private String status;
        private Integer count;
        
        // Getters and Setters
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public Integer getCount() {
            return count;
        }
        
        public void setCount(Integer count) {
            this.count = count;
        }
    }
    
    /**
     * 鎶垫娂鐗╃被鍨嬬粺璁＄粨鏋?     */

    class CollateralTypeCount {
        private String collateralType;
        private Integer count;
        
        // Getters and Setters
        public String getCollateralType() {
            return collateralType;
        }
        
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }
        
        public Integer getCount() {
            return count;
        }
        
        public void setCount(Integer count) {
            this.count = count;
        }
    }
}