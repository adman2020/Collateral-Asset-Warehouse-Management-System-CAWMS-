package com.seabank.cawms.integration.los;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * LOS Mock鏈嶅姟瀹炵幇
 * 鐢ㄤ簬寮€鍙戝拰娴嬭瘯鐜锛屾ā鎷熻捶娆惧彂璧风郴缁熺殑琛屼负
 */
@Service
@Profile("demo")
public class LOSMockService implements LOSIntegrationService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(LOSMockService.class);

    private final Random random = new Random();
    private final Map<String, LoanApplication> loanApplications = new ConcurrentHashMap<>();
    private final Map<String, LoanApplicationStatus> applicationStatuses = new ConcurrentHashMap<>();
    private final Map<String, LoanAccountInfo> loanAccounts = new ConcurrentHashMap<>();
    private final Map<String, List<LoanHistory>> customerLoanHistories = new ConcurrentHashMap<>();
    private final Map<String, CreditScore> creditScores = new ConcurrentHashMap<>();
    private final Map<String, LoanProduct> loanProducts = new ConcurrentHashMap<>();
    private String lastError;
    
    public LOSMockService() {
        initializeMockData();
    }
    
    private void initializeMockData() {
        log.info("处理条件");
        
        // TODO: fix encoding comment
        initializeLoanProducts();
        
        // TODO: fix encoding comment
        initializeCreditScores();
        
        // TODO: fix encoding comment
        initializeLoanApplications();
        
        // TODO: fix encoding comment
        initializeLoanAccounts();
        
        // TODO: fix encoding comment
        initializeLoanHistories();
        
        log.info("处理条件");
    }
    
    private void initializeLoanProducts() {
        // TODO: fix encoding comment
        LoanProduct personalLoan = createLoanProduct("PL001", "Personal Loan", "PERSONAL", 
                new BigDecimal("10000000"), new BigDecimal("500000000"), "VND", 6, 60,
                new BigDecimal("0.12"), "FIXED", "REDUCING_BALANCE", new BigDecimal("1000000"),
                "Minimum income: 15M VND/month, Age: 21-60", 
                List.of("ID Card", "Income Proof", "Bank Statement"), "ACTIVE");
        loanProducts.put("PL001", personalLoan);
        
        // TODO: fix encoding comment
        LoanProduct businessLoan = createLoanProduct("BL001", "Business Loan", "BUSINESS", 
                new BigDecimal("100000000"), new BigDecimal("5000000000"), "VND", 12, 120,
                new BigDecimal("0.10"), "VARIABLE", "FLAT_RATE", new BigDecimal("5000000"),
                "Business registration, Minimum 2 years operation", 
                List.of("Business License", "Financial Statements", "Tax Records"), "ACTIVE");
        loanProducts.put("BL001", businessLoan);
        
        // TODO: fix encoding comment
        LoanProduct mortgageLoan = createLoanProduct("ML001", "Mortgage Loan", "MORTGAGE", 
                new BigDecimal("1000000000"), new BigDecimal("20000000000"), "VND", 60, 360,
                new BigDecimal("0.08"), "FIXED", "ANNUITY", new BigDecimal("10000000"),
                "Property collateral required, LTV up to 70%", 
                List.of("Property Documents", "Valuation Report", "ID Card"), "ACTIVE");
        loanProducts.put("ML001", mortgageLoan);
        
        // TODO: fix encoding comment
        LoanProduct autoLoan = createLoanProduct("AL001", "Auto Loan", "AUTO", 
                new BigDecimal("50000000"), new BigDecimal("1000000000"), "VND", 12, 84,
                new BigDecimal("0.09"), "FIXED", "REDUCING_BALANCE", new BigDecimal("2000000"),
                "Vehicle collateral required, Maximum 7 years old", 
                List.of("Vehicle Registration", "Insurance", "ID Card"), "ACTIVE");
        loanProducts.put("AL001", autoLoan);
    }
    
    private LoanProduct createLoanProduct(String productCode, String productName, String productType,
                                          BigDecimal minAmount, BigDecimal maxAmount, String currency,
                                          Integer minTerm, Integer maxTerm, BigDecimal interestRate,
                                          String interestType, String calculationMethod, BigDecimal processingFee,
                                          String eligibilityCriteria, List<String> requiredDocuments, String status) {
        LoanProduct product = new LoanProduct();
        product.setProductCode(productCode);
        product.setProductName(productName);
        product.setProductType(productType);
        product.setMinAmount(minAmount);
        product.setMaxAmount(maxAmount);
        product.setCurrency(currency);
        product.setMinTerm(minTerm);
        product.setMaxTerm(maxTerm);
        product.setInterestRate(interestRate);
        product.setInterestType(interestType);
        product.setCalculationMethod(calculationMethod);
        product.setProcessingFee(processingFee);
        product.setEligibilityCriteria(eligibilityCriteria);
        product.setRequiredDocuments(requiredDocuments);
        product.setStatus(status);
        return product;
    }
    
    private void initializeCreditScores() {
        // TODO: fix encoding comment
        creditScores.put("CUST001", createCreditScore("CUST001", 750, "EXCELLENT", 
                "SeABank Score v2.0", "Recommendation: Eligible for all loan products"));
        creditScores.put("CUST002", createCreditScore("CUST002", 680, "GOOD", 
                "SeABank Score v2.0", "Recommendation: Eligible for most loan products"));
        creditScores.put("CUST003", createCreditScore("CUST003", 580, "FAIR", 
                "SeABank Score v2.0", "Recommendation: Eligible with higher interest rate"));
        creditScores.put("CUST004", createCreditScore("CUST004", 420, "POOR", 
                "SeABank Score v2.0", "Recommendation: Not eligible for unsecured loans"));
    }
    
    private CreditScore createCreditScore(String customerId, Integer score, String scoreBand,
                                          String scoringModel, String recommendation) {
        CreditScore creditScore = new CreditScore();
        creditScore.setCustomerId(customerId);
        creditScore.setScore(score);
        creditScore.setScoreBand(scoreBand);
        creditScore.setScoreDate(LocalDateTime.now().minusDays(random.nextInt(30)));
        creditScore.setScoringModel(scoringModel);
        creditScore.setRecommendation(recommendation);
        creditScore.setMaxScore(850);
        
        // TODO: fix encoding comment
        List<ScoreFactor> scoreFactors = new ArrayList<>();
        scoreFactors.add(createScoreFactor("Payment History", random.nextInt(40) + 30, 40, "Timely payment of previous loans"));
        scoreFactors.add(createScoreFactor("Credit Utilization", random.nextInt(30) + 20, 30, "Current credit utilization ratio"));
        scoreFactors.add(createScoreFactor("Credit History Length", random.nextInt(15) + 10, 15, "Length of credit history"));
        scoreFactors.add(createScoreFactor("New Credit", random.nextInt(10) + 5, 10, "Recent credit inquiries"));
        scoreFactors.add(createScoreFactor("Credit Mix", random.nextInt(10) + 5, 10, "Types of credit accounts"));
        creditScore.setScoreFactors(scoreFactors);
        
        return creditScore;
    }
    
    private ScoreFactor createScoreFactor(String factorName, Integer score, Integer maxScore, String description) {
        ScoreFactor factor = new ScoreFactor();
        factor.setFactorName(factorName);
        factor.setScore(score);
        factor.setMaxScore(maxScore);
        factor.setDescription(description);
        return factor;
    }
    
    private void initializeLoanApplications() {
        // TODO: fix encoding comment
        LoanApplication app1 = createLoanApplication("APP001", "CUST001", "Nguyen Van A", "ML001",
                new BigDecimal("5000000000"), "VND", 240, "HOME_PURCHASE", "PROPERTY", "PROP001",
                new BigDecimal("8000000000"), "BRANCH", "LOAN_OFFICER_001", LocalDateTime.now().minusDays(10));
        loanApplications.put("APP001", app1);
        
        LoanApplication app2 = createLoanApplication("APP002", "CUST002", "Tran Thi B", "PL001",
                new BigDecimal("200000000"), "VND", 36, "EDUCATION", null, null,
                BigDecimal.ZERO, "ONLINE", null, LocalDateTime.now().minusDays(5));
        loanApplications.put("APP002", app2);
        
        LoanApplication app3 = createLoanApplication("APP003", "CUST003", "Le Van C", "AL001",
                new BigDecimal("300000000"), "VND", 60, "VEHICLE_PURCHASE", "VEHICLE", "VEH001",
                new BigDecimal("500000000"), "MOBILE", "LOAN_OFFICER_002", LocalDateTime.now().minusDays(3));
        loanApplications.put("APP003", app3);
        
        // TODO: fix encoding comment
        applicationStatuses.put("APP001", createApplicationStatus("APP001", "UNDER_REVIEW", 
                "CREDIT_ASSESSMENT", "CREDIT_OFFICER_001", List.of("Verify Property Documents", "Check Valuation Report")));
        applicationStatuses.put("APP002", createApplicationStatus("APP002", "SUBMITTED", 
                "INITIAL_REVIEW", "SYSTEM", List.of("Verify Income Documents", "Check Credit History")));
        applicationStatuses.put("APP003", createApplicationStatus("APP003", "APPROVED", 
                "DISBURSEMENT_PENDING", "LOAN_OFFICER_002", List.of("Prepare Loan Agreement", "Schedule Disbursement")));
    }
    
    private LoanApplication createLoanApplication(String applicationId, String customerId, String customerName,
                                                  String loanProductCode, BigDecimal requestedAmount, String currency,
                                                  Integer loanTerm, String loanPurpose, String collateralType,
                                                  String collateralId, BigDecimal collateralValue,
                                                  String applicationChannel, String assignedOfficer, LocalDateTime applicationDate) {
        LoanApplication application = new LoanApplication();
        application.setApplicationId(applicationId);
        application.setCustomerId(customerId);
        application.setCustomerName(customerName);
        application.setLoanProductCode(loanProductCode);
        application.setRequestedAmount(requestedAmount);
        application.setCurrency(currency);
        application.setLoanTerm(loanTerm);
        application.setLoanPurpose(loanPurpose);
        application.setCollateralType(collateralType);
        application.setCollateralId(collateralId);
        application.setCollateralValue(collateralValue);
        application.setApplicationChannel(applicationChannel);
        application.setAssignedOfficer(assignedOfficer);
        application.setApplicationDate(applicationDate);
        
        // TODO: fix encoding comment
        Map<String, Object> additionalData = new HashMap<>();
        additionalData.put("applicationSource", "CAWMS System");
        additionalData.put("priorityLevel", collateralType != null ? "HIGH" : "NORMAL");
        additionalData.put("riskCategory", collateralType != null ? "SECURED" : "UNSECURED");
        application.setAdditionalData(additionalData);
        
        return application;
    }
    
    private LoanApplicationStatus createApplicationStatus(String applicationId, String status, String currentStage,
                                                          String assignedTo, List<String> pendingTasks) {
        LoanApplicationStatus appStatus = new LoanApplicationStatus();
        appStatus.setApplicationId(applicationId);
        appStatus.setStatus(status);
        appStatus.setCurrentStage(currentStage);
        appStatus.setAssignedTo(assignedTo);
        appStatus.setStatusDate(LocalDateTime.now());
        appStatus.setRemarks("Application is currently at " + currentStage + " stage");
        appStatus.setPendingTasks(pendingTasks);
        
        // TODO: fix encoding comment
        List<StatusHistory> statusHistory = new ArrayList<>();
        LocalDateTime historyDate = LocalDateTime.now().minusDays(10);
        
        String[] stages = {"SUBMITTED", "INITIAL_REVIEW", "DOCUMENT_VERIFICATION", "CREDIT_ASSESSMENT", "UNDER_REVIEW", "APPROVED"};
        for (String stage : stages) {
            if (stage.equals(status)) break;
            
            StatusHistory history = new StatusHistory();
            history.setStatus(stage);
            history.setTimestamp(historyDate);
            history.setChangedBy(stage.equals("SUBMITTED") ? "SYSTEM" : "LOAN_OFFICER_" + (random.nextInt(3) + 1));
            history.setRemarks("Moved to " + stage + " stage");
            statusHistory.add(history);
            
            historyDate = historyDate.plusDays(random.nextInt(2) + 1);
        }
        
        appStatus.setStatusHistory(statusHistory);
        return appStatus;
    }
    
    private void initializeLoanAccounts() {
        // TODO: fix encoding comment
        LoanAccountInfo account1 = createLoanAccountInfo("LA001", "CUST001", "Nguyen Van A", "ML001",
                new BigDecimal("3000000000"), new BigDecimal("2800000000"), new BigDecimal("2750000000"),
                new BigDecimal("50000000"), new BigDecimal("0"), LocalDateTime.now().minusYears(2),
                LocalDateTime.now().plusYears(18), "ACTIVE", 0, new BigDecimal("0.08"), "VND");
        loanAccounts.put("LA001", account1);
        
        LoanAccountInfo account2 = createLoanAccountInfo("LA002", "CUST002", "Tran Thi B", "PL001",
                new BigDecimal("150000000"), new BigDecimal("120000000"), new BigDecimal("118000000"),
                new BigDecimal("2000000"), new BigDecimal("0"), LocalDateTime.now().minusMonths(6),
                LocalDateTime.now().plusMonths(30), "ACTIVE", 0, new BigDecimal("0.12"), "VND");
        loanAccounts.put("LA002", account2);
    }
    
    private LoanAccountInfo createLoanAccountInfo(String loanAccountNumber, String customerId, String customerName,
                                                  String loanProductCode, BigDecimal originalAmount, BigDecimal currentBalance,
                                                  BigDecimal outstandingPrincipal, BigDecimal accruedInterest, BigDecimal overdueAmount,
                                                  LocalDateTime disbursementDate, LocalDateTime maturityDate, String accountStatus,
                                                  Integer daysPastDue, BigDecimal interestRate, String currency) {
        LoanAccountInfo account = new LoanAccountInfo();
        account.setLoanAccountNumber(loanAccountNumber);
        account.setCustomerId(customerId);
        account.setCustomerName(customerName);
        account.setLoanProductCode(loanProductCode);
        account.setOriginalAmount(originalAmount);
        account.setCurrentBalance(currentBalance);
        account.setOutstandingPrincipal(outstandingPrincipal);
        account.setAccruedInterest(accruedInterest);
        account.setOverdueAmount(overdueAmount);
        account.setDisbursementDate(disbursementDate);
        account.setMaturityDate(maturityDate);
        account.setAccountStatus(accountStatus);
        account.setDaysPastDue(daysPastDue);
        account.setInterestRate(interestRate);
        account.setCurrency(currency);
        return account;
    }
    
    private void initializeLoanHistories() {
        // TODO: fix encoding comment
        List<LoanHistory> cust1History = new ArrayList<>();
        cust1History.add(createLoanHistory("LA001", "ML001", new BigDecimal("3000000000"), "VND",
                LocalDateTime.now().minusYears(2), LocalDateTime.now().plusYears(18), "ACTIVE",
                new BigDecimal("2800000000"), 0));
        customerLoanHistories.put("CUST001", cust1History);
        
        List<LoanHistory> cust2History = new ArrayList<>();
        cust2History.add(createLoanHistory("LA002", "PL001", new BigDecimal("150000000"), "VND",
                LocalDateTime.now().minusMonths(6), LocalDateTime.now().plusMonths(30), "ACTIVE",
                new BigDecimal("120000000"), 0));
        customerLoanHistories.put("CUST002", cust2History);
        
        List<LoanHistory> cust3History = new ArrayList<>();
        cust3History.add(createLoanHistory("LA003", "AL001", new BigDecimal("200000000"), "VND",
                LocalDateTime.now().minusYears(1), LocalDateTime.now().plusYears(4), "CLOSED",
                BigDecimal.ZERO, 0));
        customerLoanHistories.put("CUST003", cust3History);
    }
    
    private LoanHistory createLoanHistory(String loanId, String loanProductCode, BigDecimal loanAmount, String currency,
                                          LocalDateTime disbursementDate, LocalDateTime maturityDate, String loanStatus,
                                          BigDecimal outstandingBalance, Integer daysPastDue) {
        LoanHistory history = new LoanHistory();
        history.setLoanId(loanId);
        history.setLoanProductCode(loanProductCode);
        history.setLoanAmount(loanAmount);
        history.setCurrency(currency);
        history.setDisbursementDate(disbursementDate);
        history.setMaturityDate(maturityDate);
        history.setLoanStatus(loanStatus);
        history.setOutstandingBalance(outstandingBalance);
        history.setDaysPastDue(daysPastDue);
        return history;
    }
    
    @Override
    public String getServiceName() {
        return "LOS Mock Service";
    }
    
    @Override
    public boolean isAvailable() {
        return true;
    }
    
    @Override
    public ServiceStatus getStatus() {
        return ServiceStatus.AVAILABLE;
    }
    
    @Override
    public ConnectionTestResult testConnection() {
        long startTime = System.currentTimeMillis();
        
        try {
            Thread.sleep(random.nextInt(150) + 50); // TODO: encoding issue
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        long responseTime = System.currentTimeMillis() - startTime;
        return new ConnectionTestResult(true, responseTime, "LOS Mock service connection successful", "Mock v1.0");
    }
    
    @Override
    public String getLastError() {
        return lastError;
    }
    
    @Override
    public LoanApplicationResponse submitLoanApplication(LoanApplication application) {
        log.debug("处理条件", 
                application.getApplicationId(), application.getCustomerId(), application.getLoanProductCode());
        
        LoanApplicationResponse response = new LoanApplicationResponse();
        
        // TODO: fix encoding comment
        LoanProduct product = loanProducts.get(application.getLoanProductCode());
        if (product == null || !"ACTIVE".equals(product.getStatus())) {
            lastError = "Invalid or inactive loan product: " + application.getLoanProductCode();
            response.setSuccess(false);
            response.setMessage("Invalid loan product");
            return response;
        }
        
        // TODO: fix encoding comment
        if (application.getRequestedAmount().compareTo(product.getMinAmount()) < 0 || 
            application.getRequestedAmount().compareTo(product.getMaxAmount()) > 0) {
            lastError = "Requested amount outside product limits. Min: " + product.getMinAmount() + ", Max: " + product.getMaxAmount();
            response.setSuccess(false);
            response.setMessage("Amount outside product limits");
            return response;
        }
        
        // TODO: fix encoding comment
        if (application.getLoanTerm() < product.getMinTerm() || application.getLoanTerm() > product.getMaxTerm()) {
            lastError = "Loan term outside product limits. Min: " + product.getMinTerm() + ", Max: " + product.getMaxTerm();
            response.setSuccess(false);
            response.setMessage("Term outside product limits");
            return response;
        }
        
        // TODO: fix encoding comment
        String applicationId = application.getApplicationId();
        if (applicationId == null || applicationId.isEmpty()) {
            applicationId = "APP" + System.currentTimeMillis();
            application.setApplicationId(applicationId);
        }
        
        // TODO: fix encoding comment
        loanApplications.put(applicationId, application);
        
        // TODO: fix encoding comment
        LoanApplicationStatus status = new LoanApplicationStatus();
        status.setApplicationId(applicationId);
        status.setStatus("SUBMITTED");
        status.setCurrentStage("INITIAL_REVIEW");
        status.setAssignedTo("SYSTEM");
        status.setStatusDate(LocalDateTime.now());
        status.setRemarks("New application submitted via " + application.getApplicationChannel());
        
        List<StatusHistory> history = new ArrayList<>();
        StatusHistory historyEntry = new StatusHistory();
        historyEntry.setStatus("SUBMITTED");
        historyEntry.setTimestamp(LocalDateTime.now());
        historyEntry.setChangedBy("SYSTEM");
        historyEntry.setRemarks("Application submitted successfully");
        history.add(historyEntry);
        status.setStatusHistory(history);
        
        status.setPendingTasks(List.of("Verify customer identity", "Check basic eligibility"));
        applicationStatuses.put(applicationId, status);
        
        // TODO: fix encoding comment
        try {
            Thread.sleep(random.nextInt(500) + 200); // TODO: encoding issue
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // TODO: fix encoding comment
        response.setSuccess(true);
        response.setApplicationId(applicationId);
        response.setReferenceNumber("REF" + (100000 + random.nextInt(900000)));
        response.setSubmissionDate(LocalDateTime.now());
        response.setStatus("SUBMITTED");
        response.setMessage("Loan application submitted successfully");
        response.setNextStep("Initial review by loan officer");
        response.setEstimatedProcessingTime(LocalDateTime.now().plusDays(random.nextInt(3) + 2));
        response.setRequiredDocuments(product.getRequiredDocuments());
        
        log.info("处理条件", 
                applicationId, application.getCustomerId(), application.getRequestedAmount(), application.getCurrency());
        
        return response;
    }
    
    @Override
    public LoanApplicationStatus queryApplicationStatus(String applicationId) {
        log.debug("处理条件", applicationId);
        
        LoanApplicationStatus status = applicationStatuses.get(applicationId);
        if (status == null) {
            lastError = "Application not found: " + applicationId;
            return null;
        }
        
        // TODO: fix encoding comment
        updateApplicationStatus(status);
        
        return status;
    }
    
    private void updateApplicationStatus(LoanApplicationStatus status) {
        String[] stages = {"SUBMITTED", "INITIAL_REVIEW", "DOCUMENT_VERIFICATION", "CREDIT_ASSESSMENT", "UNDER_REVIEW", "APPROVED", "REJECTED"};
        String currentStatus = status.getStatus();
        int currentIndex = -1;
        
        for (int i = 0; i < stages.length; i++) {
            if (stages[i].equals(currentStatus)) {
                currentIndex = i;
                break;
            }
        }
        
        // TODO: fix encoding comment
        if (currentIndex >= 0 && currentIndex < stages.length - 1 && random.nextInt(10) < 3) {
            String newStatus = stages[currentIndex + 1];
            
            // TODO: fix encoding comment
            if ("UNDER_REVIEW".equals(currentStatus) && random.nextBoolean()) {
                newStatus = random.nextBoolean() ? "APPROVED" : "REJECTED";
            }
            
            status.setStatus(newStatus);
            status.setCurrentStage(newStatus);
            status.setStatusDate(LocalDateTime.now());
            
            // TODO: fix encoding comment
            StatusHistory historyEntry = new StatusHistory();
            historyEntry.setStatus(newStatus);
            historyEntry.setTimestamp(LocalDateTime.now());
            historyEntry.setChangedBy("LOAN_OFFICER_" + (random.nextInt(3) + 1));
            historyEntry.setRemarks("Status updated to " + newStatus);
            
            if (status.getStatusHistory() == null) {
                status.setStatusHistory(new ArrayList<>());
            }
            status.getStatusHistory().add(historyEntry);
            
            // TODO: fix encoding comment
            updatePendingTasks(status, newStatus);
            
            log.debug("处理条件", status.getApplicationId(), newStatus);
        }
    }
    
    private void updatePendingTasks(LoanApplicationStatus status, String newStatus) {
        List<String> pendingTasks = new ArrayList<>();
        
        switch (newStatus) {
            case "INITIAL_REVIEW":
                pendingTasks.add("Verify customer identity");
                pendingTasks.add("Check basic eligibility");
                break;
            case "DOCUMENT_VERIFICATION":
                pendingTasks.add("Verify income documents");
                pendingTasks.add("Check collateral documents");
                pendingTasks.add("Validate customer information");
                break;
            case "CREDIT_ASSESSMENT":
                pendingTasks.add("Calculate credit score");
                pendingTasks.add("Assess repayment capacity");
                pendingTasks.add("Evaluate collateral value");
                break;
            case "UNDER_REVIEW":
                pendingTasks.add("Final review by senior officer");
                pendingTasks.add("Prepare approval memo");
                break;
            case "APPROVED":
                pendingTasks.add("Prepare loan agreement");
                pendingTasks.add("Schedule disbursement");
                break;
            case "REJECTED":
                pendingTasks.add("Prepare rejection letter");
                pendingTasks.add("Notify customer");
                break;
        }
        
        status.setPendingTasks(pendingTasks);
    }
    
    @Override
    public List<LoanProduct> queryLoanProducts(String customerType) {
        log.debug("处理条件", customerType);
        
        List<LoanProduct> filteredProducts = new ArrayList<>();
        
        for (LoanProduct product : loanProducts.values()) {
            if ("ACTIVE".equals(product.getStatus())) {
                if (customerType == null || customerType.isEmpty() || 
                    product.getProductType().equals(customerType.toUpperCase())) {
                    filteredProducts.add(product);
                }
            }
        }
        
        return filteredProducts;
    }
    
    @Override
    public CreditScore queryCreditScore(String customerId) {
        log.debug("处理条件", customerId);
        
        CreditScore creditScore = creditScores.get(customerId);
        if (creditScore == null) {
            // TODO: fix encoding comment
            creditScore = createCreditScore(customerId, random.nextInt(400) + 400, 
                    getScoreBand(random.nextInt(400) + 400), "SeABank Score v2.0", 
                    "New customer, limited credit history");
            creditScores.put(customerId, creditScore);
        }
        
        // TODO: fix encoding comment
        creditScore.setScoreDate(LocalDateTime.now());
        
        // TODO: fix encoding comment
        if (random.nextInt(10) < 2) { // TODO: encoding issue
            int change = random.nextInt(20) - 10; // TODO: encoding issue
            int newScore = creditScore.getScore() + change;
            creditScore.setScore(newScore);
            creditScore.setScoreBand(getScoreBand(newScore));
        }
        
        return creditScore;
    }
    
    private String getScoreBand(int score) {
        if (score >= 750) return "EXCELLENT";
        if (score >= 650) return "GOOD";
        if (score >= 550) return "FAIR";
        return "POOR";
    }
    
    @Override
    public RepaymentSchedule queryRepaymentSchedule(String loanId) {
        log.debug("处理条件", loanId);
        
        // TODO: fix encoding comment
        LoanAccountInfo account = loanAccounts.values().stream()
                .filter(acc -> loanId.equals(acc.getLoanAccountNumber()))
                .findFirst()
                .orElse(null);
        
        if (account == null) {
            lastError = "Loan account not found: " + loanId;
            return null;
        }
        
        // TODO: fix encoding comment
        RepaymentSchedule schedule = new RepaymentSchedule();
        schedule.setLoanId(loanId);
        schedule.setLoanAmount(account.getOriginalAmount());
        schedule.setCurrency(account.getCurrency());
        schedule.setInterestRate(account.getInterestRate());
        schedule.setLoanTerm(36); // TODO: fix encoding comment
        schedule.setRepaymentFrequency("MONTHLY");
        
        // TODO: fix encoding comment
        BigDecimal monthlyRate = account.getInterestRate().divide(new BigDecimal("12"), 10, java.math.RoundingMode.HALF_UP);
        BigDecimal factor = monthlyRate.add(BigDecimal.ONE).pow(schedule.getLoanTerm());
        BigDecimal installment = account.getOriginalAmount()
                .multiply(monthlyRate)
                .multiply(factor)
                .divide(factor.subtract(BigDecimal.ONE), 2, java.math.RoundingMode.HALF_UP);
        
        schedule.setInstallmentAmount(installment);
        schedule.setFirstPaymentDate(account.getDisbursementDate().plusMonths(1));
        schedule.setMaturityDate(account.getMaturityDate());
        
        // TODO: fix encoding comment
        List<Installment> installments = new ArrayList<>();
        BigDecimal remainingBalance = account.getOriginalAmount();
        
        for (int i = 1; i <= schedule.getLoanTerm(); i++) {
            Installment installmentEntry = new Installment();
            installmentEntry.setInstallmentNumber(i);
            installmentEntry.setDueDate(account.getDisbursementDate().plusMonths(i));
            
            // TODO: fix encoding comment
            BigDecimal interest = remainingBalance.multiply(monthlyRate);
            
            // TODO: fix encoding comment
            BigDecimal principal = installment.subtract(interest);
            
            // TODO: fix encoding comment
            if (i == schedule.getLoanTerm()) {
                principal = remainingBalance;
                installment = principal.add(interest);
            }
            
            remainingBalance = remainingBalance.subtract(principal);
            
            installmentEntry.setPrincipalAmount(principal);
            installmentEntry.setInterestAmount(interest);
            installmentEntry.setTotalAmount(installment);
            installmentEntry.setRemainingBalance(remainingBalance);
            
            // TODO: fix encoding comment
            if (installmentEntry.getDueDate().isBefore(LocalDateTime.now())) {
                installmentEntry.setStatus(random.nextBoolean() ? "PAID" : "OVERDUE");
            } else {
                installmentEntry.setStatus("PENDING");
            }
            
            installments.add(installmentEntry);
        }
        
        schedule.setInstallments(installments);
        
        // TODO: fix encoding comment
        BigDecimal totalInterest = installments.stream()
                .map(Installment::getInterestAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalRepayment = account.getOriginalAmount().add(totalInterest);
        
        schedule.setTotalInterest(totalInterest);
        schedule.setTotalRepayment(totalRepayment);
        
        return schedule;
    }
    
    @Override
    public LoanAccountInfo queryLoanAccountInfo(String loanAccountNumber) {
        log.debug("处理条件", loanAccountNumber);
        
        LoanAccountInfo account = loanAccounts.get(loanAccountNumber);
        if (account == null) {
            lastError = "Loan account not found: " + loanAccountNumber;
            return null;
        }
        
        // TODO: fix encoding comment
        updateAccountBalance(account);
        
        return account;
    }
    
    private void updateAccountBalance(LoanAccountInfo account) {
        // TODO: fix encoding comment
        BigDecimal dailyInterest = account.getOutstandingPrincipal()
                .multiply(account.getInterestRate())
                .divide(new BigDecimal("365"), 10, java.math.RoundingMode.HALF_UP);
        
        BigDecimal interestAccrued = dailyInterest.multiply(new BigDecimal(random.nextInt(30) + 1));
        account.setAccruedInterest(account.getAccruedInterest().add(interestAccrued));
        
        // TODO: fix encoding comment
        if (random.nextInt(10) < 1) { // TODO: encoding issue
            account.setOverdueAmount(account.getOverdueAmount().add(new BigDecimal(random.nextInt(10000000) + 1000000)));
            account.setDaysPastDue(random.nextInt(30) + 1);
        } else {
            account.setDaysPastDue(0);
        }
        
        account.setCurrentBalance(account.getOutstandingPrincipal().add(account.getAccruedInterest()).add(account.getOverdueAmount()));
    }
    
    @Override
    public LoanDisbursementResponse processLoanDisbursement(LoanDisbursementRequest disbursementRequest) {
        log.debug("处理条件", 
                disbursementRequest.getLoanId(), disbursementRequest.getApplicationId(), 
                disbursementRequest.getDisbursementAmount(), disbursementRequest.getCurrency());
        
        LoanDisbursementResponse response = new LoanDisbursementResponse();
        
        // TODO: fix encoding comment
        LoanApplicationStatus status = applicationStatuses.get(disbursementRequest.getApplicationId());
        if (status == null || !"APPROVED".equals(status.getStatus())) {
            lastError = "Application not approved: " + disbursementRequest.getApplicationId();
            response.setSuccess(false);
            response.setMessage("Application not approved");
            return response;
        }
        
        // TODO: fix encoding comment
        try {
            Thread.sleep(random.nextInt(1000) + 500); // TODO: encoding issue
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // TODO: fix encoding comment
        String disbursementId = "DISB" + System.currentTimeMillis();
        
        // TODO: fix encoding comment
        LoanAccountInfo account = loanAccounts.get(disbursementRequest.getLoanId());
        if (account == null) {
            // TODO: fix encoding comment
            LoanApplication application = loanApplications.get(disbursementRequest.getApplicationId());
            if (application == null) {
                lastError = "Application not found: " + disbursementRequest.getApplicationId();
                response.setSuccess(false);
                response.setMessage("Application not found");
                return response;
            }
            
            // TODO: fix encoding comment
            account = createLoanAccountInfo(disbursementRequest.getLoanId(), application.getCustomerId(), 
                    application.getCustomerName(), application.getLoanProductCode(), 
                    disbursementRequest.getDisbursementAmount(), disbursementRequest.getDisbursementAmount(),
                    disbursementRequest.getDisbursementAmount(), BigDecimal.ZERO, BigDecimal.ZERO,
                    LocalDateTime.now(), LocalDateTime.now().plusMonths(application.getLoanTerm()),
                    "ACTIVE", 0, new BigDecimal("0.12"), application.getCurrency());
            loanAccounts.put(disbursementRequest.getLoanId(), account);
            
            // TODO: fix encoding comment
            List<LoanHistory> history = customerLoanHistories.getOrDefault(application.getCustomerId(), new ArrayList<>());
            history.add(createLoanHistory(disbursementRequest.getLoanId(), application.getLoanProductCode(),
                    disbursementRequest.getDisbursementAmount(), application.getCurrency(),
                    LocalDateTime.now(), LocalDateTime.now().plusMonths(application.getLoanTerm()),
                    "ACTIVE", disbursementRequest.getDisbursementAmount(), 0));
            customerLoanHistories.put(application.getCustomerId(), history);
        }
        
        // TODO: fix encoding comment
        status.setStatus("DISBURSED");
        status.setCurrentStage("DISBURSED");
        status.setStatusDate(LocalDateTime.now());
        
        StatusHistory historyEntry = new StatusHistory();
        historyEntry.setStatus("DISBURSED");
        historyEntry.setTimestamp(LocalDateTime.now());
        historyEntry.setChangedBy("DISBURSEMENT_OFFICER");
        historyEntry.setRemarks("Loan disbursed successfully");
        status.getStatusHistory().add(historyEntry);
        
        status.setPendingTasks(List.of("Send confirmation to customer", "Update loan records"));
        
        // TODO: fix encoding comment
        response.setSuccess(true);
        response.setDisbursementId(disbursementId);
        response.setLoanId(disbursementRequest.getLoanId());
        response.setDisbursedAmount(disbursementRequest.getDisbursementAmount());
        response.setCurrency(disbursementRequest.getCurrency());
        response.setDisbursementDate(LocalDateTime.now());
        response.setStatus("COMPLETED");
        response.setMessage("Loan disbursement completed successfully");
        response.setTransactionReference("TXN" + (1000000 + random.nextInt(9000000)));
        response.setConfirmationNumber("CONF" + (100000 + random.nextInt(900000)));
        
        log.info("处理条件", 
                disbursementId, disbursementRequest.getLoanId(), 
                disbursementRequest.getDisbursementAmount(), disbursementRequest.getCurrency());
        
        return response;
    }
    
    @Override
    public List<LoanHistory> queryLoanHistory(String customerId) {
        log.debug("处理条件", customerId);
        return customerLoanHistories.getOrDefault(customerId, new ArrayList<>());
    }
    
    @Override
    public EligibilityResult checkEligibility(EligibilityRequest eligibilityRequest) {
        log.debug("妫€鏌ヨ捶娆捐祫鏍? customerId={}, productCode={}, amount={}", 
                eligibilityRequest.getCustomerId(), eligibilityRequest.getLoanProductCode(),
                eligibilityRequest.getRequestedAmount());
        
        EligibilityResult result = new EligibilityResult();
        result.setCustomerId(eligibilityRequest.getCustomerId());
        result.setLoanProductCode(eligibilityRequest.getLoanProductCode());
        
        // TODO: fix encoding comment
        CreditScore creditScore = queryCreditScore(eligibilityRequest.getCustomerId());
        
        // TODO: fix encoding comment
        LoanProduct product = loanProducts.get(eligibilityRequest.getLoanProductCode());
        
        boolean eligible = true;
        List<String> reasons = new ArrayList<>();
        List<String> criteria = new ArrayList<>();
        
        // TODO: fix encoding comment
        if (creditScore.getScore() < 600) {
            eligible = false;
            reasons.add("Credit score below minimum requirement (600)");
        }
        criteria.add("Minimum credit score: 600");
        
        // TODO: fix encoding comment
        if (product == null || !"ACTIVE".equals(product.getStatus())) {
            eligible = false;
            reasons.add("Loan product not available");
        } else {
            // TODO: fix encoding comment
            if (eligibilityRequest.getRequestedAmount().compareTo(product.getMinAmount()) < 0) {
                eligible = false;
                reasons.add("Requested amount below minimum: " + product.getMinAmount());
            }
            if (eligibilityRequest.getRequestedAmount().compareTo(product.getMaxAmount()) > 0) {
                eligible = false;
                reasons.add("Requested amount above maximum: " + product.getMaxAmount());
            }
            criteria.add("Amount range: " + product.getMinAmount() + " to " + product.getMaxAmount());
            
            // TODO: fix encoding comment
            if (eligibilityRequest.getRequestedTerm() < product.getMinTerm() || 
                eligibilityRequest.getRequestedTerm() > product.getMaxTerm()) {
                eligible = false;
                reasons.add("Loan term outside allowed range: " + product.getMinTerm() + " to " + product.getMaxTerm() + " months");
            }
            criteria.add("Term range: " + product.getMinTerm() + " to " + product.getMaxTerm() + " months");
        }
        
        // TODO: fix encoding comment
        result.setEligible(eligible);
        result.setEligibilityStatus(eligible ? "ELIGIBLE" : "NOT_ELIGIBLE");
        result.setEligibilityCriteria(criteria);
        result.setReasonsForIneligibility(reasons);
        
        if (eligible) {
            // TODO: fix encoding comment
            BigDecimal maxAmountBasedOnScore = eligibilityRequest.getRequestedAmount();
            if (creditScore.getScore() < 700) {
                maxAmountBasedOnScore = maxAmountBasedOnScore.multiply(new BigDecimal("0.8")); // TODO: encoding issue
            }
            
            result.setEligibleAmount(maxAmountBasedOnScore);
            result.setEligibleTerm(eligibilityRequest.getRequestedTerm());
            result.setMaximumLoanAmount(maxAmountBasedOnScore);
            result.setDebtToIncomeRatio(new BigDecimal("0.35")); // TODO: encoding issue
        } else {
            result.setRecommendation("Customer is not eligible for the requested loan. Consider alternative products or provide additional collateral.");
        }
        
        // TODO: fix encoding comment
        try {
            Thread.sleep(random.nextInt(300) + 100); // TODO: encoding issue
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        return result;
    }
}