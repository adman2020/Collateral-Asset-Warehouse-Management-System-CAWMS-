package com.seabank.cawms.dto;

import java.util.Map;

/**
 * 鍗曟嵁妯℃澘 DTO
 */
public class SlipTemplate {
    private String templateId;
    private String templateName;
    private String templateType;
    private String templatePath;
    private String description;
    private String content;
    private Map<String, Object> variables;
    private Map<String, Object> templateConfig;
    private SlipFormat format;
    private Boolean isDefault;
    private String version;
    private Boolean active;
    private String createdBy;
    private String createdAt;


    public SlipTemplate() {
    }

    public SlipTemplate(String templateId, String templateName, String templateType, String templatePath, String description, String content, Map<String, Object> variables, Map<String, Object> templateConfig, SlipFormat format, Boolean isDefault, String version, Boolean active, String createdBy, String createdAt) {
        this.templateId = templateId;
        this.templateName = templateName;
        this.templateType = templateType;
        this.templatePath = templatePath;
        this.description = description;
        this.content = content;
        this.variables = variables;
        this.templateConfig = templateConfig;
        this.format = format;
        this.isDefault = isDefault;
        this.version = version;
        this.active = active;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getTemplateType() {
        return templateType;
    }

    public void setTemplateType(String templateType) {
        this.templateType = templateType;
    }

    public String getTemplatePath() {
        return templatePath;
    }

    public void setTemplatePath(String templatePath) {
        this.templatePath = templatePath;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Map<String, Object> getVariables() {
        return variables;
    }

    public void setVariables(Map<String, Object> variables) {
        this.variables = variables;
    }

    public Map<String, Object> getTemplateConfig() {
        return templateConfig;
    }

    public void setTemplateConfig(Map<String, Object> templateConfig) {
        this.templateConfig = templateConfig;
    }

    public SlipFormat getFormat() {
        return format;
    }

    public void setFormat(SlipFormat format) {
        this.format = format;
    }

    public Boolean getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Boolean isDefault) {
        this.isDefault = isDefault;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
