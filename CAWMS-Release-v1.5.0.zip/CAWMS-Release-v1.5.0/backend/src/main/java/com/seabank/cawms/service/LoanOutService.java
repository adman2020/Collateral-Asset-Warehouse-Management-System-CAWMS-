package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.LoanOutEntity;
import com.seabank.cawms.entity.LoanOutApprovalEntity;
import com.seabank.cawms.entity.LoanReturnApprovalEntity;
import com.seabank.cawms.entity.OverdueAlertLogEntity;
import com.seabank.cawms.service.impl.LoanOutApprovalWorkflow;
import com.seabank.cawms.workflow.LoanReturnApprovalWorkflow;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 鎶垫娂璧勪骇鍊熷嚭鏈嶅姟鎺ュ彛
 */
public interface LoanOutService {
    
    /**
     * 创建鍊熷嚭鐢宠锛堣崏绋匡級
     * @param detail 鍊熷嚭璇︽儏
     * @param creator 创建浜?     * @return 创建鐨勫€熷嚭璁板綍璇︽儏
     */
    LoanOutDetail createDraft(LoanOutDetail detail, String creator);
    
    /**
     * 根据ID查询借出申请详情
     * @param id 借出记录ID
     * @return 鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail getById(Long id);
    
    /**
     * 鏍规嵁鍊熷嚭缂栫爜鏌ヨ鍊熷嚭鐢宠璇︽儏
     * @param loanCode 鍊熷嚭缂栫爜
     * @return 鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail getByLoanCode(String loanCode);
    
    /**
     * 更新借出申请
     * @param id 借出记录ID
     * @param detail 鍊熷嚭璇︽儏
     * @param updater 更新浜?     * @return 更新鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail update(Long id, LoanOutDetail detail, String updater);
    
    /**
     * 删除借出申请
     * @param id 借出记录ID
     * @param deleter 删除浜?     * @return 删除缁撴灉
     */
    boolean delete(Long id, String deleter);
    
    /**
     * 提交借出申请
     * @param id 借出记录ID
     * @param request 鎻愪氦璇锋眰
     * @param submitter 鎻愪氦浜?     * @return 鎻愪氦鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail submitForApproval(Long id, ApprovalRequest request, String submitter, String submitterName);
    
    /**
     * 审批借出申请
     * @param id 借出记录ID
     * @param comments 瀹℃壒鎰忚
     * @param approver 瀹℃壒浜?     * @return 瀹℃壒鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail approve(Long id, String comments, String approver, String approverName);
    
    /**
     * 拒绝借出申请
     * @param id 借出记录ID
     * @param comments 拒绝意见
     * @param rejector 鎷掔粷浜?     * @return 鎷掔粷鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail reject(Long id, String comments, String rejector, String rejectorName);
    
    /**
     * 确认借出锛堝畬鎴愬€熷嚭娴佺▼锛?     * @param id 借出记录ID
     * @param confirmer 纭浜?     * @return 纭鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail confirmLoan(Long id, String confirmer, String confirmerName);
    
    /**
     * 褰掕繕鎶垫娂璧勪骇
     * @param id 借出记录ID
     * @param actualReturnDate 瀹為檯褰掕繕鏃ユ湡
     * @param remarks 褰掕繕澶囨敞
     * @param returner 褰掕繕浜?     * @return 褰掕繕鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail returnCollateral(Long id, LocalDate actualReturnDate, String remarks, String returner, String returnerName);
    
    /**
     * 鏌ヨ鍊熷嚭鐢宠鍒楄〃
     * @param query 鏌ヨ鏉′欢
     * @return 鍒嗛〉缁撴灉
     */
    Page<LoanOutDetail> query(LoanOutQuery query);
    
    /**
     * 鑾峰彇鍊熷嚭缁熻淇℃伅
     * @param startDate 寮€濮嬫棩鏈燂紙鍙€夛級
     * @param endDate 缁撴潫鏃ユ湡锛堝彲閫夛級
     * @return 缁熻淇℃伅
     */
    LoanOutStatistics getStatistics(java.time.LocalDate startDate, java.time.LocalDate endDate);

    /**
     * 获取我的审批列表
     * @param approverUser 审批用户
     * @param approverRole 审批角色
     * @param type 类型: pending, ongoing, history
     * @param pageNum 页码
     * @param pageSize 每页大小
     * @return 分页结果
     */
    Page<LoanOutDetail> getMyApprovals(String approverUser, String approverRole, String type, Integer pageNum, Integer pageSize);
    
    /**
     * 导出借出数据
     * @param request 导出璇锋眰
     * @return 导出缁撴灉
     */
    ExportResult exportData(ExportRequest request);
    
    /**
     * 导入借出数据
     * @param importList 导入数据列表
     * @param options 导入閫夐」
     * @param importer 导入浜?     * @return 导入缁撴灉
     */
    ImportResult importData(List<LoanOutDetail> importList, Map<String, Object> options, String importer);
    
    /**
     * 获取待办审批列表
     * @param approver 瀹℃壒浜?     * @param pageNum 椤电爜
     * @param pageSize 每页大小
     * @return 寰呭姙瀹℃壒鍒楄〃
     */
    Page<LoanOutDetail> getPendingApprovals(String approver, Integer pageNum, Integer pageSize);
    
    /**
     * 获取逾期借出列表
     * @param pageNum 椤电爜
     * @param pageSize 每页大小
     * @return 閫炬湡鍊熷嚭鍒楄〃
     */
    Page<LoanOutDetail> getOverdueLoans(Integer pageNum, Integer pageSize);
    
    /**
     * 获取即将到期借出列表
     * @param days 鍒版湡澶╂暟
     * @param pageNum 椤电爜
     * @param pageSize 每页大小
     * @return 鍗冲皢鍒版湡鍊熷嚭鍒楄〃
     */
    Page<LoanOutDetail> getExpiringLoans(Integer days, Integer pageNum, Integer pageSize);
    
    /**
     * 同步T24状态?     * @param id 借出记录ID
     * @param syncResult 鍚屾缁撴灉
     * @param syncer 鍚屾浜?     * @return 鍚屾鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail syncT24Status(Long id, T24SyncResult syncResult, String syncer);
    
    /**
     * 鍙戦€侀€炬湡棰勮
     * @param loanOutId 借出记录ID
     * @param alertType 预警类型
     * @return 棰勮鍙戦€佺粨鏋?     */
    AlertSendResult sendOverdueAlert(Long loanOutId, String alertType);
    
    // TODO: fix encoding comment
    
    /**
     * 鍊熷嚭璇︽儏
     */
    class LoanOutDetail {
        private Long id;
        private String loanCode;
        private Long whInId;
        private String whCode;
        private String loanPurpose;
        private Integer loanDuration;
        private LocalDate expectedReturnDate;
        private LocalDate actualReturnDate;
        private String status;
        private String t24SyncStatus;
        private LocalDateTime t24SyncTime;
        private String customerName;
        private String collateralType;
        private BigDecimal collateralValue;
        private String buCode;
        private String buName;
        private String remarks;
        private LocalDateTime createdAt;
        private String createdBy;
        private LocalDateTime updatedAt;
        private String updatedBy;
        private Boolean overdue;
        private Integer remainingDays;
        private List<LoanOutApprovalEntity> approvals;
        private List<LoanReturnApprovalEntity> returnApprovals;
        private List<OverdueAlertLogEntity> alertLogs;
        private Map<String, Object> extData;
        
        // TODO: fix encoding comment
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getLoanCode() { return loanCode; }
        public void setLoanCode(String loanCode) { this.loanCode = loanCode; }
        public Long getWhInId() { return whInId; }
        public void setWhInId(Long whInId) { this.whInId = whInId; }
        public String getWhCode() { return whCode; }
        public void setWhCode(String whCode) { this.whCode = whCode; }
        public String getLoanPurpose() { return loanPurpose; }
        public void setLoanPurpose(String loanPurpose) { this.loanPurpose = loanPurpose; }
        public Integer getLoanDuration() { return loanDuration; }
        public void setLoanDuration(Integer loanDuration) { this.loanDuration = loanDuration; }
        public LocalDate getExpectedReturnDate() { return expectedReturnDate; }
        public void setExpectedReturnDate(LocalDate expectedReturnDate) { this.expectedReturnDate = expectedReturnDate; }
        public LocalDate getActualReturnDate() { return actualReturnDate; }
        public void setActualReturnDate(LocalDate actualReturnDate) { this.actualReturnDate = actualReturnDate; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getT24SyncStatus() { return t24SyncStatus; }
        public void setT24SyncStatus(String t24SyncStatus) { this.t24SyncStatus = t24SyncStatus; }
        public LocalDateTime getT24SyncTime() { return t24SyncTime; }
        public void setT24SyncTime(LocalDateTime t24SyncTime) { this.t24SyncTime = t24SyncTime; }
        public String getCustomerName() { return customerName; }
        public void setCustomerName(String customerName) { this.customerName = customerName; }
        public String getCollateralType() { return collateralType; }
        public void setCollateralType(String collateralType) { this.collateralType = collateralType; }
        public BigDecimal getCollateralValue() { return collateralValue; }
        public void setCollateralValue(BigDecimal collateralValue) { this.collateralValue = collateralValue; }
        public String getBuCode() { return buCode; }
        public void setBuCode(String buCode) { this.buCode = buCode; }
        public String getBuName() { return buName; }
        public void setBuName(String buName) { this.buName = buName; }
        public String getRemarks() { return remarks; }
        public void setRemarks(String remarks) { this.remarks = remarks; }
        public LocalDateTime getCreatedAt() { return createdAt; }
        public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
        public String getCreatedBy() { return createdBy; }
        public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }
        public LocalDateTime getUpdatedAt() { return updatedAt; }
        public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
        public String getUpdatedBy() { return updatedBy; }
        public void setUpdatedBy(String updatedBy) { this.updatedBy = updatedBy; }
        public Boolean getOverdue() { return overdue; }
        public void setOverdue(Boolean overdue) { this.overdue = overdue; }
        public Integer getRemainingDays() { return remainingDays; }
        public void setRemainingDays(Integer remainingDays) { this.remainingDays = remainingDays; }
        public List<LoanOutApprovalEntity> getApprovals() { return approvals; }
        public void setApprovals(List<LoanOutApprovalEntity> approvals) { this.approvals = approvals; }
        public List<LoanReturnApprovalEntity> getReturnApprovals() { return returnApprovals; }
        public void setReturnApprovals(List<LoanReturnApprovalEntity> returnApprovals) { this.returnApprovals = returnApprovals; }
        public List<OverdueAlertLogEntity> getAlertLogs() { return alertLogs; }
        public void setAlertLogs(List<OverdueAlertLogEntity> alertLogs) { this.alertLogs = alertLogs; }
        public Map<String, Object> getExtData() { return extData; }
        public void setExtData(Map<String, Object> extData) { this.extData = extData; }
    }
    
    /**
     * 鍊熷嚭鏌ヨ鏉′欢
     */
    class LoanOutQuery {
        private String loanCode;
        private String customerName;
        private String loanPurpose;
        private String status;
        private String buCode;
        private LocalDate startDate;
        private LocalDate endDate;
        private LocalDate expectedReturnStart;
        private LocalDate expectedReturnEnd;
        private String t24SyncStatus;
        private Integer pageNum;
        private Integer pageSize;
        private String sortField;
        private String sortOrder;
        
        // TODO: fix encoding comment
        public String getLoanCode() { return loanCode; }
        public void setLoanCode(String loanCode) { this.loanCode = loanCode; }
        public String getCustomerName() { return customerName; }
        public void setCustomerName(String customerName) { this.customerName = customerName; }
        public String getLoanPurpose() { return loanPurpose; }
        public void setLoanPurpose(String loanPurpose) { this.loanPurpose = loanPurpose; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getBuCode() { return buCode; }
        public void setBuCode(String buCode) { this.buCode = buCode; }
        public LocalDate getStartDate() { return startDate; }
        public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
        public LocalDate getEndDate() { return endDate; }
        public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
        public LocalDate getExpectedReturnStart() { return expectedReturnStart; }
        public void setExpectedReturnStart(LocalDate expectedReturnStart) { this.expectedReturnStart = expectedReturnStart; }
        public LocalDate getExpectedReturnEnd() { return expectedReturnEnd; }
        public void setExpectedReturnEnd(LocalDate expectedReturnEnd) { this.expectedReturnEnd = expectedReturnEnd; }
        public String getT24SyncStatus() { return t24SyncStatus; }
        public void setT24SyncStatus(String t24SyncStatus) { this.t24SyncStatus = t24SyncStatus; }
        public Integer getPageNum() { return pageNum; }
        public void setPageNum(Integer pageNum) { this.pageNum = pageNum; }
        public Integer getPageSize() { return pageSize; }
        public void setPageSize(Integer pageSize) { this.pageSize = pageSize; }
        public String getSortField() { return sortField; }
        public void setSortField(String sortField) { this.sortField = sortField; }
        public String getSortOrder() { return sortOrder; }
        public void setSortOrder(String sortOrder) { this.sortOrder = sortOrder; }
    }
    
    /**
     * 瀹℃壒璇锋眰
     */
    class ApprovalRequest {
        private String approverId;
        private String approverName;
        private String approverRole;
        private String comments;
        
        public String getApproverId() { return approverId; }
        public void setApproverId(String approverId) { this.approverId = approverId; }
        public String getApproverName() { return approverName; }
        public void setApproverName(String approverName) { this.approverName = approverName; }
        public String getApproverRole() { return approverRole; }
        public void setApproverRole(String approverRole) { this.approverRole = approverRole; }
        public String getComments() { return comments; }
        public void setComments(String comments) { this.comments = comments; }
    }
    
    /**
     * 鍊熷嚭缁熻淇℃伅
     */
    class LoanOutStatistics {
        private Integer totalCount;
        private Integer draftCount;
        private Integer pendingCount;
        private Integer loanedCount;
        private Integer returnedCount;
        private Integer overdueCount;
        private BigDecimal totalLoanValue;
        private BigDecimal overdueValue;
        private Map<String, Integer> statusDistribution;
        private Map<String, Integer> collateralTypeDistribution;
        private Map<String, Integer> businessUnitDistribution;
        private Integer todayLoans;
        private Integer monthLoans;
        private Integer expiringLoans;
        
        // TODO: fix encoding comment
        public Integer getTotalCount() { return totalCount; }
        public void setTotalCount(Integer totalCount) { this.totalCount = totalCount; }
        public Integer getDraftCount() { return draftCount; }
        public void setDraftCount(Integer draftCount) { this.draftCount = draftCount; }
        public Integer getPendingCount() { return pendingCount; }
        public void setPendingCount(Integer pendingCount) { this.pendingCount = pendingCount; }
        public Integer getLoanedCount() { return loanedCount; }
        public void setLoanedCount(Integer loanedCount) { this.loanedCount = loanedCount; }
        public Integer getReturnedCount() { return returnedCount; }
        public void setReturnedCount(Integer returnedCount) { this.returnedCount = returnedCount; }
        public Integer getOverdueCount() { return overdueCount; }
        public void setOverdueCount(Integer overdueCount) { this.overdueCount = overdueCount; }
        public BigDecimal getTotalLoanValue() { return totalLoanValue; }
        public void setTotalLoanValue(BigDecimal totalLoanValue) { this.totalLoanValue = totalLoanValue; }
        public BigDecimal getOverdueValue() { return overdueValue; }
        public void setOverdueValue(BigDecimal overdueValue) { this.overdueValue = overdueValue; }
        public Map<String, Integer> getStatusDistribution() { return statusDistribution; }
        public void setStatusDistribution(Map<String, Integer> statusDistribution) { this.statusDistribution = statusDistribution; }
        public Map<String, Integer> getCollateralTypeDistribution() { return collateralTypeDistribution; }
        public void setCollateralTypeDistribution(Map<String, Integer> collateralTypeDistribution) { this.collateralTypeDistribution = collateralTypeDistribution; }
        public Map<String, Integer> getBusinessUnitDistribution() { return businessUnitDistribution; }
        public void setBusinessUnitDistribution(Map<String, Integer> businessUnitDistribution) { this.businessUnitDistribution = businessUnitDistribution; }
        public Integer getTodayLoans() { return todayLoans; }
        public void setTodayLoans(Integer todayLoans) { this.todayLoans = todayLoans; }
        public Integer getMonthLoans() { return monthLoans; }
        public void setMonthLoans(Integer monthLoans) { this.monthLoans = monthLoans; }
        public Integer getExpiringLoans() { return expiringLoans; }
        public void setExpiringLoans(Integer expiringLoans) { this.expiringLoans = expiringLoans; }
    }
    
    /**
     * 导出璇锋眰
     */
    class ExportRequest {
        private String format; // EXCEL, CSV, PDF
        private Boolean includeDetails;
        private Boolean includeAttachments;
        private LocalDate startDate;
        private LocalDate endDate;
        private List<String> statuses;
        private Map<String, Object> options;
        
        // TODO: fix encoding comment
        public String getFormat() { return format; }
        public void setFormat(String format) { this.format = format; }
        public Boolean getIncludeDetails() { return includeDetails; }
        public void setIncludeDetails(Boolean includeDetails) { this.includeDetails = includeDetails; }
        public Boolean getIncludeAttachments() { return includeAttachments; }
        public void setIncludeAttachments(Boolean includeAttachments) { this.includeAttachments = includeAttachments; }
        public LocalDate getStartDate() { return startDate; }
        public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
        public LocalDate getEndDate() { return endDate; }
        public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
        public List<String> getStatuses() { return statuses; }
        public void setStatuses(List<String> statuses) { this.statuses = statuses; }
        public Map<String, Object> getOptions() { return options; }
        public void setOptions(Map<String, Object> options) { this.options = options; }
    }
    
    /**
     * 导出缁撴灉
     */
    class ExportResult {
        private String format;
        private Integer recordCount;
        private String fileName;
        private String fileUrl;
        private Long fileSize;
        private LocalDateTime exportedAt;
        
        public String getFormat() { return format; }
        public void setFormat(String format) { this.format = format; }
        public Integer getRecordCount() { return recordCount; }
        public void setRecordCount(Integer recordCount) { this.recordCount = recordCount; }
        public String getFileName() { return fileName; }
        public void setFileName(String fileName) { this.fileName = fileName; }
        public String getFileUrl() { return fileUrl; }
        public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }
        public Long getFileSize() { return fileSize; }
        public void setFileSize(Long fileSize) { this.fileSize = fileSize; }
        public LocalDateTime getExportedAt() { return exportedAt; }
        public void setExportedAt(LocalDateTime exportedAt) { this.exportedAt = exportedAt; }
    }
    
    /**
     * 导入缁撴灉
     */
    class ImportResult {
        private Boolean success;
        private Integer totalRecords;
        private Integer successCount;
        private Integer failCount;
        private String message;
        private List<ImportRecordResult> recordResults;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Integer getTotalRecords() { return totalRecords; }
        public void setTotalRecords(Integer totalRecords) { this.totalRecords = totalRecords; }
        public Integer getSuccessCount() { return successCount; }
        public void setSuccessCount(Integer successCount) { this.successCount = successCount; }
        public Integer getFailCount() { return failCount; }
        public void setFailCount(Integer failCount) { this.failCount = failCount; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public List<ImportRecordResult> getRecordResults() { return recordResults; }
        public void setRecordResults(List<ImportRecordResult> recordResults) { this.recordResults = recordResults; }
    }
    
    /**
     * 导入璁板綍缁撴灉
     */
    class ImportRecordResult {
        private Integer rowNumber;
        private Boolean success;
        private String recordId;
        private String message;
        private List<String> errors;
        
        public Integer getRowNumber() { return rowNumber; }
        public void setRowNumber(Integer rowNumber) { this.rowNumber = rowNumber; }
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getRecordId() { return recordId; }
        public void setRecordId(String recordId) { this.recordId = recordId; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public List<String> getErrors() { return errors; }
        public void setErrors(List<String> errors) { this.errors = errors; }
    }
    
    /**
     * T24鍚屾缁撴灉
     */
    class T24SyncResult {
        private Boolean success;
        private String t24Reference;
        private String syncMessage;
        private LocalDateTime syncTime;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getT24Reference() { return t24Reference; }
        public void setT24Reference(String t24Reference) { this.t24Reference = t24Reference; }
        public String getSyncMessage() { return syncMessage; }
        public void setSyncMessage(String syncMessage) { this.syncMessage = syncMessage; }
        public LocalDateTime getSyncTime() { return syncTime; }
        public void setSyncTime(LocalDateTime syncTime) { this.syncTime = syncTime; }
    }
    
    /**
     * 棰勮鍙戦€佺粨鏋?     */
    class AlertSendResult {
        private Boolean success;
        private String alertId;
        private String message;
        private LocalDateTime sentTime;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getAlertId() { return alertId; }
        public void setAlertId(String alertId) { this.alertId = alertId; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public LocalDateTime getSentTime() { return sentTime; }
        public void setSentTime(LocalDateTime sentTime) { this.sentTime = sentTime; }
    }
    
    // TODO: fix encoding comment
    
    /**
     * 閫€鍥炲鎵规楠?     * @param id 借出记录ID
     * @param comments 閫€鍥炴剰瑙?     * @param returner 閫€鍥炰汉
     * @param returnToStep 閫€鍥炲埌鐨勬楠ょ紪鍙?     * @return 閫€鍥炲悗鐨勫€熷嚭鐢宠璇︽儏
     */
    LoanOutDetail returnStep(Long id, String comments, String returner, String returnerName, Integer returnToStep);
    
    /**
     * 鑾峰彇审批进度
     * @param id 借出记录ID
     * @return 审批进度淇℃伅
     */
    LoanOutApprovalWorkflow.ApprovalProgress getApprovalProgress(Long id);
    
    /**
     * 鑾峰彇褰撳墠寰呭鎵规楠?     * @param id 借出记录ID
     * @return 褰撳墠寰呭鎵规楠よ鎯?     */
    LoanOutApprovalEntity getCurrentPendingStep(Long id);
    
    // TODO: fix encoding comment
    
    /**
     * 申请归还鎶垫娂璧勪骇锛堝惎鍔?姝ラ褰掕繕娴佺▼锛?     * @param id 借出记录ID
     * @param returnRemarks 褰掕繕澶囨敞
     * @param returnDate 褰掕繕鏃ユ湡
     * @param applicant 鐢宠浜?     * @return 褰掕繕娴佺▼鍚姩鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail applyForReturn(Long id, String returnRemarks, java.time.LocalDateTime returnDate, String applicant, String applicantName);
    
    /**
     * 瀹℃壒閫氳繃褰撳墠褰掕繕姝ラ
     * @param id 借出记录ID
     * @param approvalId 褰掕繕审批记录ID
     * @param comments 瀹℃壒鎰忚
     * @param approver 瀹℃壒浜?     * @param approverName 瀹℃壒浜哄鍚?     * @param assetCondition 璧勪骇鐘跺喌锛堜粎浠撳簱纭姝ラ闇€瑕侊級
     * @param conditionDescription 璧勪骇鐘跺喌鎻忚堪锛堜粎浠撳簱纭姝ラ闇€瑕侊級
     * @param settlementAmount 缁撶畻閲戦锛堜粎璐㈠姟缁撶畻姝ラ闇€瑕侊級
     * @param settlementMethod 缁撶畻鏂瑰紡锛堜粎璐㈠姟缁撶畻姝ラ闇€瑕侊級
     * @param settlementReference 缁撶畻鍑瘉鍙凤紙浠呰储鍔＄粨绠楁楠ら渶瑕侊級
     * @return 瀹℃壒鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail approveReturnStep(
            Long id, Long approvalId, String comments, String approver, String approverName,
            String assetCondition, String conditionDescription,
            Double settlementAmount, String settlementMethod, String settlementReference);
    
    /**
     * 鎷掔粷褰撳墠褰掕繕姝ラ
     * @param id 借出记录ID
     * @param approvalId 褰掕繕审批记录ID
     * @param comments 拒绝意见
     * @param rejector 鎷掔粷浜?     * @param rejectorName 鎷掔粷浜哄鍚?     * @return 鎷掔粷鍚庣殑鍊熷嚭鐢宠璇︽儏
     */
    LoanOutDetail rejectReturnStep(Long id, Long approvalId, String comments, String rejector, String rejectorName);
    
    /**
     * 閫€鍥炲綋鍓嶅綊杩樻楠?     * @param id 借出记录ID
     * @param approvalId 褰掕繕审批记录ID
     * @param comments 閫€鍥炴剰瑙?     * @param returner 閫€鍥炰汉
     * @param returnerName 閫€鍥炰汉濮撳悕
     * @param returnToStep 閫€鍥炲埌鐨勬楠ょ紪鍙?     * @return 閫€鍥炲悗鐨勫€熷嚭鐢宠璇︽儏
     */
    LoanOutDetail returnReturnStep(Long id, Long approvalId, String comments, String returner, 
                                  String returnerName, Integer returnToStep);
    
    /**
     * 获取归还审批进度
     * @param id 借出记录ID
     * @return 褰掕繕审批进度淇℃伅
     */
    LoanReturnApprovalWorkflow.ReturnApprovalProgress getReturnApprovalProgress(Long id);
    
    /**
     * 获取当前待审批的归还步骤
     * @param id 借出记录ID
     * @return 当前待审批的归还步骤详情
     */
    LoanReturnApprovalEntity getCurrentPendingReturnStep(Long id);
    
    /**
     * 检查归还流程是否完成?     * @param id 借出记录ID
     * @return 鏄惁瀹屾垚
     */
    Boolean isReturnProcessCompleted(Long id);
    
    /**
     * 获取归还流程统计信息
     * @return 褰掕繕娴佺▼缁熻
     */
    ReturnProcessStatistics getReturnProcessStatistics();
    
    /**
     * 褰掕繕娴佺▼缁熻淇℃伅
     */
    class ReturnProcessStatistics {
        private Integer totalReturnProcesses;
        private Integer completedReturns;
        private Integer inProgressReturns;
        private Integer rejectedReturns;
        private Map<String, Integer> stepDistribution;
        private Map<String, Integer> assetConditionDistribution;
        private Map<String, Integer> settlementMethodDistribution;
        
        // Getters and Setters
        public Integer getTotalReturnProcesses() { return totalReturnProcesses; }
        public void setTotalReturnProcesses(Integer totalReturnProcesses) { this.totalReturnProcesses = totalReturnProcesses; }
        public Integer getCompletedReturns() { return completedReturns; }
        public void setCompletedReturns(Integer completedReturns) { this.completedReturns = completedReturns; }
        public Integer getInProgressReturns() { return inProgressReturns; }
        public void setInProgressReturns(Integer inProgressReturns) { this.inProgressReturns = inProgressReturns; }
        public Integer getRejectedReturns() { return rejectedReturns; }
        public void setRejectedReturns(Integer rejectedReturns) { this.rejectedReturns = rejectedReturns; }
        public Map<String, Integer> getStepDistribution() { return stepDistribution; }
        public void setStepDistribution(Map<String, Integer> stepDistribution) { this.stepDistribution = stepDistribution; }
        public Map<String, Integer> getAssetConditionDistribution() { return assetConditionDistribution; }
        public void setAssetConditionDistribution(Map<String, Integer> assetConditionDistribution) { this.assetConditionDistribution = assetConditionDistribution; }
        public Map<String, Integer> getSettlementMethodDistribution() { return settlementMethodDistribution; }
        public void setSettlementMethodDistribution(Map<String, Integer> settlementMethodDistribution) { this.settlementMethodDistribution = settlementMethodDistribution; }
    }
}