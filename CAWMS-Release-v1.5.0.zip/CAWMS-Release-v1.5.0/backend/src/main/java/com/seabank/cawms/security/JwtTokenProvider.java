package com.seabank.cawms.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * JWT浠ょ墝鎻愪緵鑰? */


@Component
public class JwtTokenProvider {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(JwtTokenProvider.class);

    @Value("${jwt.secret}")
    private String jwtSecret;

    @Value("${jwt.expiration:86400000}") // TODO: fix encoding comment
    private long jwtExpirationMs;

    // TODO: fix encoding comment
    private long refreshExpirationMs;

    /**
     * 鐢熸垚JWT浠ょ墝
     */
    public String generateToken(Authentication authentication) {
        return generateToken(authentication.getName(), authentication.getAuthorities());
    }

    /**
     * 鐢熸垚JWT浠ょ墝
     */
    public String generateToken(String username, Collection<? extends GrantedAuthority> authorities) {
        Map<String, Object> claims = new HashMap<>();
        
        // TODO: fix encoding comment
        String authoritiesStr = authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));
        claims.put("authorities", authoritiesStr);
        
        // TODO: fix encoding comment
        claims.put("username", username);
        
        return buildToken(claims, username, jwtExpirationMs);
    }

    /**
     * 鐢熸垚鍒锋柊浠ょ墝
     */
    public String generateRefreshToken(String username) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("type", "refresh");
        return buildToken(claims, username, refreshExpirationMs);
    }

    /**
     * 浠庝护鐗屼腑鑾峰彇鐢ㄦ埛鍚?     */


    public String getUsernameFromToken(String token) {
        return getClaimsFromToken(token).getSubject();
    }

    /**
     * 从令牌中获取权限
     */
    public List<GrantedAuthority> getAuthoritiesFromToken(String token) {
        Claims claims = getClaimsFromToken(token);
        
        if (claims.get("authorities") == null) {
            return List.of();
        }
        
        String authoritiesStr = claims.get("authorities", String.class);
        return Arrays.stream(authoritiesStr.split(","))
                .filter(auth -> !auth.trim().isEmpty())
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
    }

    /**
     * 验证JWT令牌
     */
    public boolean validateToken(String token) {
        try {
            Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token);
            return true;
        } catch (SignatureException e) {
            log.error("无效的JWT签名: {}", e.getMessage());
        } catch (MalformedJwtException e) {
            log.error("鏃犳晥鐨凧WT浠ょ墝: {}", e.getMessage());
        } catch (ExpiredJwtException e) {
            log.error("JWT浠ょ墝宸茶繃鏈? {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            log.error("涓嶆敮鎸佺殑JWT浠ょ墝: {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            log.error("JWT浠ょ墝涓虹┖鎴栧弬鏁伴敊璇? {}", e.getMessage());
        }
        return false;
    }

    /**
     * 鑾峰彇璁よ瘉淇℃伅
     */
    public Authentication getAuthentication(String token) {
        Claims claims = getClaimsFromToken(token);
        
        String username = claims.getSubject();
        List<GrantedAuthority> authorities = getAuthoritiesFromToken(token);
        
        UserDetails principal = new User(username, "", authorities);
        return new UsernamePasswordAuthenticationToken(principal, token, authorities);
    }

    /**
     * 鑾峰彇浠ょ墝鍓╀綑鏈夋晥鏈燂紙姣锛?     */


    public long getRemainingExpirationMs(String token) {
        try {
            Claims claims = getClaimsFromToken(token);
            Date expiration = claims.getExpiration();
            return expiration.getTime() - System.currentTimeMillis();
        } catch (Exception e) {
            log.warn("鑾峰彇浠ょ墝鍓╀綑鏈夋晥鏈熷け璐? {}", e.getMessage());
            return 0;
        }
    }

    /**
     * 判断令牌是否即将过期（在指定时间内过期）
     */
    public boolean isTokenAboutToExpire(String token, long thresholdMs) {
        long remainingMs = getRemainingExpirationMs(token);
        return remainingMs > 0 && remainingMs < thresholdMs;
    }

    /**
     * 鏋勫缓浠ょ墝
     */
    private String buildToken(Map<String, Object> claims, String subject, long expirationMs) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + expirationMs);
        
        return Jwts.builder()
                .claims(claims)
                .subject(subject)
                .issuedAt(now)
                .expiration(expiryDate)
                .signWith(getSigningKey(), Jwts.SIG.HS256)
                .compact();
    }

    /**
     * 浠庝护鐗屼腑鑾峰彇澹版槑
     */
    private Claims getClaimsFromToken(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    /**
     * 鑾峰彇绛惧悕瀵嗛挜
     */
    private SecretKey getSigningKey() {
        byte[] keyBytes = jwtSecret.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * 验证刷新令牌
     */
    public boolean validateRefreshToken(String token) {
        if (!validateToken(token)) {
            return false;
        }
        
        try {
            Claims claims = getClaimsFromToken(token);
            return "refresh".equals(claims.get("type", String.class));
        } catch (Exception e) {
            log.error("验证刷新令牌失败: {}", e.getMessage());
            return false;
        }
    }

    /**
     * 浠庡埛鏂颁护鐗岃幏鍙栫敤鎴峰悕
     */
    public String getUsernameFromRefreshToken(String token) {
        if (validateRefreshToken(token)) {
            return getUsernameFromToken(token);
        }
        return null;
    }
}