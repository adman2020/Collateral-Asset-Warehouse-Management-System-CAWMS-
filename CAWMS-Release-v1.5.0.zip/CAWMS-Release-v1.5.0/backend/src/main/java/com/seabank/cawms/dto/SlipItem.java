package com.seabank.cawms.dto;


import java.math.BigDecimal;

/**
 * 鍑瘉椤圭洰椤? */

public class SlipItem {
    /**
     * 椤圭洰缂栧彿
     */
    private String itemNo;
    
    /**
     * 椤圭洰鍚嶇О
     */
    private String itemName;
    
    /**
     * 椤圭洰绫诲瀷
     */
    private String itemType;
    
    /**
     * 鏁伴噺
     */
    private Integer quantity;
    
    /**
     * 鍗曚綅
     */
    private String unit;
    
    /**
     * 鍗曚环
     */
    private BigDecimal unitPrice;
    
    /**
     * 鎬婚噾棰?     */

    private BigDecimal amount;
    
    /**
     * 澶囨敞
     */
    private String remarks;


    public SlipItem() {
    }

    public SlipItem(String itemNo, String itemName, String itemType, Integer quantity, String unit, BigDecimal unitPrice, BigDecimal amount, String remarks) {
        this.itemNo = itemNo;
        this.itemName = itemName;
        this.itemType = itemType;
        this.quantity = quantity;
        this.unit = unit;
        this.unitPrice = unitPrice;
        this.amount = amount;
        this.remarks = remarks;
    }

    public String getItemNo() {
        return itemNo;
    }

    public void setItemNo(String itemNo) {
        this.itemNo = itemNo;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
