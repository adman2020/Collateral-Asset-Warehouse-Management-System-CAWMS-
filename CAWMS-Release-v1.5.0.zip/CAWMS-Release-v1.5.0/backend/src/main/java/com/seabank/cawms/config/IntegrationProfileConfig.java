package com.seabank.cawms.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * 集成服务Profile配置
 * 用于控制Mock服务的启用和禁用
 */
@Configuration
public class IntegrationProfileConfig {
    
    /**
     * demo鐜閰嶇疆
     * 浣跨敤@Profile("demo")娉ㄨВ鐨勬湇鍔″皢鍦ㄦ鐜涓嬪惎鐢?     */

    @Configuration
    @Profile("demo")
    public static class DemoProfileConfig {
        // TODO: fix encoding comment
        // TODO: fix encoding comment
    }
    
    /**
     * prod鐜閰嶇疆
     * 浣跨敤@Profile("prod")娉ㄨВ鐨勬湇鍔″皢鍦ㄦ鐜涓嬪惎鐢?     */

    @Configuration
    @Profile("prod")
    public static class ProdProfileConfig {
        // TODO: fix encoding comment
        // TODO: fix encoding comment
    }
    
    /**
     * test鐜閰嶇疆
     * 浣跨敤@Profile("test")娉ㄨВ鐨勬湇鍔″皢鍦ㄦ鐜涓嬪惎鐢?     */

    @Configuration
    @Profile("test")
    public static class TestProfileConfig {
        // TODO: fix encoding comment
        // TODO: fix encoding comment
    }
}