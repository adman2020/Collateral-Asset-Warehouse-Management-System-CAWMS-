package com.seabank.cawms.service;

import com.seabank.cawms.entity.OverdueAlertLogEntity;
import com.seabank.cawms.entity.OverdueAlertConfigEntity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 逾期预警通知服务接口
 * 璐熻矗鍙戦€侀€炬湡棰勮閫氱煡鍒颁笉鍚屾笭閬擄紙閭欢銆佺煭淇°€佺郴缁熼€氱煡绛夛級
 */
public interface OverdueAlertService {
    
    /**
     * 鍙戦€佸崟涓璀﹂€氱煡
     * @param alertLog 预警记录
     * @param config 预警配置
     * @return 鍙戦€佺粨鏋?     */
    SendResult sendAlert(OverdueAlertLogEntity alertLog, OverdueAlertConfigEntity config);
    
    /**
     * 鎵归噺鍙戦€侀璀﹂€氱煡
     * @param alertLogs 预警记录列表
     * @param config 预警配置
     * @return 鎵归噺鍙戦€佺粨鏋?     */
    BatchSendResult sendAlerts(List<OverdueAlertLogEntity> alertLogs, OverdueAlertConfigEntity config);
    
    /**
     * 发送待处理的预警通知
     * @return 鍙戦€佺粨鏋滅粺璁?     */
    SendStatistics sendPendingAlerts();
    
    /**
     * 閲嶈瘯鍙戦€佸け璐ョ殑棰勮閫氱煡
     * @param maxRetryCount 鏈€澶ч噸璇曟鏁?     * @return 閲嶈瘯缁撴灉缁熻
     */
    RetryResult retryFailedAlerts(Integer maxRetryCount);
    
    /**
     * 根据预警类型发送通知
     * @param alertType 预警类型锛圵ARNING, OVERDUE, REMINDER锛?     * @param config 预警配置
     * @return 鍙戦€佺粨鏋?     */
    TypeSendResult sendAlertsByType(String alertType, OverdueAlertConfigEntity config);
    
    /**
     * 娴嬭瘯鍙戦€侀€氱煡
     * @param testConfig 娴嬭瘯閰嶇疆
     * @return 娴嬭瘯缁撴灉
     */
    TestSendResult testSend(TestConfig testConfig);
    
    /**
     * 鑾峰彇鍙戦€佺粺璁′俊鎭?     * @return 鍙戦€佺粺璁?     */
    AlertStatistics getAlertStatistics();
    
    /**
     * 更新预警配置
     * @param config 预警配置
     * @return 更新结果
     */
    ConfigUpdateResult updateAlertConfig(OverdueAlertConfigEntity config);
    
    /**
     * 鑾峰彇预警配置
     * @return 预警配置
     */
    OverdueAlertConfigEntity getAlertConfig();
    
    /**
     * 鍙戦€佺粨鏋?     */
    class SendResult {
        private Boolean success;
        private Long alertLogId;
        private String alertType;
        private String sendMethod;
        private String recipient;
        private LocalDateTime sentTime;
        private String message;
        private String errorDetails;
        private Map<String, Object> additionalInfo;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Long getAlertLogId() { return alertLogId; }
        public void setAlertLogId(Long alertLogId) { this.alertLogId = alertLogId; }
        public String getAlertType() { return alertType; }
        public void setAlertType(String alertType) { this.alertType = alertType; }
        public String getSendMethod() { return sendMethod; }
        public void setSendMethod(String sendMethod) { this.sendMethod = sendMethod; }
        public String getRecipient() { return recipient; }
        public void setRecipient(String recipient) { this.recipient = recipient; }
        public LocalDateTime getSentTime() { return sentTime; }
        public void setSentTime(LocalDateTime sentTime) { this.sentTime = sentTime; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getErrorDetails() { return errorDetails; }
        public void setErrorDetails(String errorDetails) { this.errorDetails = errorDetails; }
        public Map<String, Object> getAdditionalInfo() { return additionalInfo; }
        public void setAdditionalInfo(Map<String, Object> additionalInfo) { this.additionalInfo = additionalInfo; }
    }
    
    /**
     * 鎵归噺鍙戦€佺粨鏋?     */
    class BatchSendResult {
        private Boolean success;
        private Integer totalCount;
        private Integer successCount;
        private Integer failCount;
        private Long executionTimeMs;
        private String message;
        private List<SendResult> detailedResults;
        private List<Long> successfulIds;
        private List<Long> failedIds;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Integer getTotalCount() { return totalCount; }
        public void setTotalCount(Integer totalCount) { this.totalCount = totalCount; }
        public Integer getSuccessCount() { return successCount; }
        public void setSuccessCount(Integer successCount) { this.successCount = successCount; }
        public Integer getFailCount() { return failCount; }
        public void setFailCount(Integer failCount) { this.failCount = failCount; }
        public Long getExecutionTimeMs() { return executionTimeMs; }
        public void setExecutionTimeMs(Long executionTimeMs) { this.executionTimeMs = executionTimeMs; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public List<SendResult> getDetailedResults() { return detailedResults; }
        public void setDetailedResults(List<SendResult> detailedResults) { this.detailedResults = detailedResults; }
        public List<Long> getSuccessfulIds() { return successfulIds; }
        public void setSuccessfulIds(List<Long> successfulIds) { this.successfulIds = successfulIds; }
        public List<Long> getFailedIds() { return failedIds; }
        public void setFailedIds(List<Long> failedIds) { this.failedIds = failedIds; }
    }
    
    /**
     * 鍙戦€佺粺璁?     */
    class SendStatistics {
        private Integer totalAlerts;
        private Integer pendingAlerts;
        private Integer sentAlerts;
        private Integer failedAlerts;
        private Integer todayAlerts;
        private Integer monthAlerts;
        private Map<String, Integer> alertsByType;
        private Map<String, Integer> alertsByMethod;
        private List<OverdueAlertLogEntity> recentAlerts;
        private LocalDateTime statisticsTime;
        
        public Integer getTotalAlerts() { return totalAlerts; }
        public void setTotalAlerts(Integer totalAlerts) { this.totalAlerts = totalAlerts; }
        public Integer getPendingAlerts() { return pendingAlerts; }
        public void setPendingAlerts(Integer pendingAlerts) { this.pendingAlerts = pendingAlerts; }
        public Integer getSentAlerts() { return sentAlerts; }
        public void setSentAlerts(Integer sentAlerts) { this.sentAlerts = sentAlerts; }
        public Integer getFailedAlerts() { return failedAlerts; }
        public void setFailedAlerts(Integer failedAlerts) { this.failedAlerts = failedAlerts; }
        public Integer getTodayAlerts() { return todayAlerts; }
        public void setTodayAlerts(Integer todayAlerts) { this.todayAlerts = todayAlerts; }
        public Integer getMonthAlerts() { return monthAlerts; }
        public void setMonthAlerts(Integer monthAlerts) { this.monthAlerts = monthAlerts; }
        public Map<String, Integer> getAlertsByType() { return alertsByType; }
        public void setAlertsByType(Map<String, Integer> alertsByType) { this.alertsByType = alertsByType; }
        public Map<String, Integer> getAlertsByMethod() { return alertsByMethod; }
        public void setAlertsByMethod(Map<String, Integer> alertsByMethod) { this.alertsByMethod = alertsByMethod; }
        public List<OverdueAlertLogEntity> getRecentAlerts() { return recentAlerts; }
        public void setRecentAlerts(List<OverdueAlertLogEntity> recentAlerts) { this.recentAlerts = recentAlerts; }
        public LocalDateTime getStatisticsTime() { return statisticsTime; }
        public void setStatisticsTime(LocalDateTime statisticsTime) { this.statisticsTime = statisticsTime; }
    }
    
    /**
     * 閲嶈瘯缁撴灉
     */
    class RetryResult {
        private Boolean success;
        private Integer totalRetried;
        private Integer retrySuccessCount;
        private Integer retryFailCount;
        private Long executionTimeMs;
        private String message;
        private List<Long> retriedIds;
        private List<SendResult> detailedResults;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Integer getTotalRetried() { return totalRetried; }
        public void setTotalRetried(Integer totalRetried) { this.totalRetried = totalRetried; }
        public Integer getRetrySuccessCount() { return retrySuccessCount; }
        public void setRetrySuccessCount(Integer retrySuccessCount) { this.retrySuccessCount = retrySuccessCount; }
        public Integer getRetryFailCount() { return retryFailCount; }
        public void setRetryFailCount(Integer retryFailCount) { this.retryFailCount = retryFailCount; }
        public Long getExecutionTimeMs() { return executionTimeMs; }
        public void setExecutionTimeMs(Long executionTimeMs) { this.executionTimeMs = executionTimeMs; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public List<Long> getRetriedIds() { return retriedIds; }
        public void setRetriedIds(List<Long> retriedIds) { this.retriedIds = retriedIds; }
        public List<SendResult> getDetailedResults() { return detailedResults; }
        public void setDetailedResults(List<SendResult> detailedResults) { this.detailedResults = detailedResults; }
    }
    
    /**
     * 鎸夌被鍨嬪彂閫佺粨鏋?     */
    class TypeSendResult {
        private Boolean success;
        private String alertType;
        private Integer totalCount;
        private Integer successCount;
        private Integer failCount;
        private Long executionTimeMs;
        private String message;
        private List<SendResult> detailedResults;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getAlertType() { return alertType; }
        public void setAlertType(String alertType) { this.alertType = alertType; }
        public Integer getTotalCount() { return totalCount; }
        public void setTotalCount(Integer totalCount) { this.totalCount = totalCount; }
        public Integer getSuccessCount() { return successCount; }
        public void setSuccessCount(Integer successCount) { this.successCount = successCount; }
        public Integer getFailCount() { return failCount; }
        public void setFailCount(Integer failCount) { this.failCount = failCount; }
        public Long getExecutionTimeMs() { return executionTimeMs; }
        public void setExecutionTimeMs(Long executionTimeMs) { this.executionTimeMs = executionTimeMs; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public List<SendResult> getDetailedResults() { return detailedResults; }
        public void setDetailedResults(List<SendResult> detailedResults) { this.detailedResults = detailedResults; }
    }
    
    /**
     * 娴嬭瘯鍙戦€佺粨鏋?     */
    class TestSendResult {
        private Boolean success;
        private String testMethod;
        private String testRecipient;
        private String testMessage;
        private LocalDateTime testTime;
        private String resultMessage;
        private String errorDetails;
        private Map<String, Object> testDetails;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getTestMethod() { return testMethod; }
        public void setTestMethod(String testMethod) { this.testMethod = testMethod; }
        public String getTestRecipient() { return testRecipient; }
        public void setTestRecipient(String testRecipient) { this.testRecipient = testRecipient; }
        public String getTestMessage() { return testMessage; }
        public void setTestMessage(String testMessage) { this.testMessage = testMessage; }
        public LocalDateTime getTestTime() { return testTime; }
        public void setTestTime(LocalDateTime testTime) { this.testTime = testTime; }
        public String getResultMessage() { return resultMessage; }
        public void setResultMessage(String resultMessage) { this.resultMessage = resultMessage; }
        public String getErrorDetails() { return errorDetails; }
        public void setErrorDetails(String errorDetails) { this.errorDetails = errorDetails; }
        public Map<String, Object> getTestDetails() { return testDetails; }
        public void setTestDetails(Map<String, Object> testDetails) { this.testDetails = testDetails; }
    }
    
    /**
     * 棰勮缁熻
     */
    class AlertStatistics {
        private Integer totalAlerts;
        private Integer warningAlerts;
        private Integer overdueAlerts;
        private Integer reminderAlerts;
        private Map<String, Integer> alertsByMethod;
        private Map<String, Integer> alertsByStatus;
        private Map<String, Integer> alertsByHour;
        private Map<String, Integer> alertsByDay;
        private Double averageSendTimeMs;
        private Double successRate;
        private List<OverdueAlertLogEntity> topAlerts;
        private LocalDateTime statisticsTime;
        
        public Integer getTotalAlerts() { return totalAlerts; }
        public void setTotalAlerts(Integer totalAlerts) { this.totalAlerts = totalAlerts; }
        public Integer getWarningAlerts() { return warningAlerts; }
        public void setWarningAlerts(Integer warningAlerts) { this.warningAlerts = warningAlerts; }
        public Integer getOverdueAlerts() { return overdueAlerts; }
        public void setOverdueAlerts(Integer overdueAlerts) { this.overdueAlerts = overdueAlerts; }
        public Integer getReminderAlerts() { return reminderAlerts; }
        public void setReminderAlerts(Integer reminderAlerts) { this.reminderAlerts = reminderAlerts; }
        public Map<String, Integer> getAlertsByMethod() { return alertsByMethod; }
        public void setAlertsByMethod(Map<String, Integer> alertsByMethod) { this.alertsByMethod = alertsByMethod; }
        public Map<String, Integer> getAlertsByStatus() { return alertsByStatus; }
        public void setAlertsByStatus(Map<String, Integer> alertsByStatus) { this.alertsByStatus = alertsByStatus; }
        public Map<String, Integer> getAlertsByHour() { return alertsByHour; }
        public void setAlertsByHour(Map<String, Integer> alertsByHour) { this.alertsByHour = alertsByHour; }
        public Map<String, Integer> getAlertsByDay() { return alertsByDay; }
        public void setAlertsByDay(Map<String, Integer> alertsByDay) { this.alertsByDay = alertsByDay; }
        public Double getAverageSendTimeMs() { return averageSendTimeMs; }
        public void setAverageSendTimeMs(Double averageSendTimeMs) { this.averageSendTimeMs = averageSendTimeMs; }
        public Double getSuccessRate() { return successRate; }
        public void setSuccessRate(Double successRate) { this.successRate = successRate; }
        public List<OverdueAlertLogEntity> getTopAlerts() { return topAlerts; }
        public void setTopAlerts(List<OverdueAlertLogEntity> topAlerts) { this.topAlerts = topAlerts; }
        public LocalDateTime getStatisticsTime() { return statisticsTime; }
        public void setStatisticsTime(LocalDateTime statisticsTime) { this.statisticsTime = statisticsTime; }
    }
    
    /**
     * 配置更新结果
     */
    class ConfigUpdateResult {
        private Boolean success;
        private OverdueAlertConfigEntity oldConfig;
        private OverdueAlertConfigEntity newConfig;
        private String message;
        private LocalDateTime updatedAt;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public OverdueAlertConfigEntity getOldConfig() { return oldConfig; }
        public void setOldConfig(OverdueAlertConfigEntity oldConfig) { this.oldConfig = oldConfig; }
        public OverdueAlertConfigEntity getNewConfig() { return newConfig; }
        public void setNewConfig(OverdueAlertConfigEntity newConfig) { this.newConfig = newConfig; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public LocalDateTime getUpdatedAt() { return updatedAt; }
        public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    }
    
    /**
     * 娴嬭瘯閰嶇疆
     */
    class TestConfig {
        private String testMethod;
        private String testRecipient;
        private String testMessage;
        private String alertType;
        private Map<String, Object> additionalParams;
        
        public String getTestMethod() { return testMethod; }
        public void setTestMethod(String testMethod) { this.testMethod = testMethod; }
        public String getTestRecipient() { return testRecipient; }
        public void setTestRecipient(String testRecipient) { this.testRecipient = testRecipient; }
        public String getTestMessage() { return testMessage; }
        public void setTestMessage(String testMessage) { this.testMessage = testMessage; }
        public String getAlertType() { return alertType; }
        public void setAlertType(String alertType) { this.alertType = alertType; }
        public Map<String, Object> getAdditionalParams() { return additionalParams; }
        public void setAdditionalParams(Map<String, Object> additionalParams) { this.additionalParams = additionalParams; }
    }
}