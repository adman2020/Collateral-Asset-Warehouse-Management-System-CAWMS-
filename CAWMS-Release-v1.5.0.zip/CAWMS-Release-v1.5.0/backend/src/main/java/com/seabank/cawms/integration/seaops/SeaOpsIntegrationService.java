package com.seabank.cawms.integration.seaops;

import com.seabank.cawms.integration.IntegrationService;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * SeaOps杩愯惀绯荤粺闆嗘垚鏈嶅姟鎺ュ彛
 * SeaOps鍙兘鏄捣娲嬭繍钀ャ€佺墿娴佹垨渚涘簲閾剧鐞嗙郴缁? */

public interface SeaOpsIntegrationService extends IntegrationService {
    
    /**
     * 鏌ヨ璐х墿淇℃伅
     * @param cargoId 璐х墿ID
     * @return 璐х墿璇︾粏淇℃伅
     */
    CargoInfo queryCargoInfo(String cargoId);
    
    /**
     * 鏌ヨ鑸硅埗淇℃伅
     * @param vesselId 鑸硅埗ID
     * @return 鑸硅埗璇︾粏淇℃伅
     */
    VesselInfo queryVesselInfo(String vesselId);
    
    /**
     * 鏌ヨ鑸嚎淇℃伅
     * @param routeId 鑸嚎ID
     * @return 鑸嚎璇︾粏淇℃伅
     */
    RouteInfo queryRouteInfo(String routeId);
    
    /**
     * 鏌ヨ娓彛淇℃伅
     * @param portCode 娓彛浠ｇ爜
     * @return 娓彛璇︾粏淇℃伅
     */
    PortInfo queryPortInfo(String portCode);
    
    /**
     * 鏌ヨ杩愯緭璁″垝
     * @param planId 璁″垝ID
     * @return 杩愯緭璁″垝淇℃伅
     */
    TransportPlan queryTransportPlan(String planId);
    
    /**
     * 创建杩愯緭璁㈠崟
     * @param request 杩愯緭璇锋眰
     * @return 杩愯緭璁㈠崟鍝嶅簲
     */
    TransportOrderResponse createTransportOrder(TransportOrderRequest request);
    
    /**
     * 鏌ヨ杩愯緭鐘舵€?     * @param trackingNumber 璺熻釜鍙风爜
     * @return 杩愯緭鐘舵€佷俊鎭?     */

    TransportStatus queryTransportStatus(String trackingNumber);
    
    /**
     * 鎵归噺鏌ヨ璐х墿浣嶇疆
     * @param cargoIds 璐х墿ID鍒楄〃
     * @return 璐х墿浣嶇疆淇℃伅鍒楄〃
     */
    List<CargoLocation> batchQueryCargoLocations(List<String> cargoIds);
    
    /**
     * 鏌ヨ澶╂皵淇℃伅
     * @param location 浣嶇疆锛堢粡绾害鎴栨腐鍙ｄ唬鐮侊級
     * @return 澶╂皵淇℃伅
     */
    WeatherInfo queryWeatherInfo(String location);
    
    /**
     * 璐х墿淇℃伅
     */
    class CargoInfo {
        private String cargoId;
        private String cargoType;
        private String description;
        private BigDecimal weight;
        private String weightUnit;
        private BigDecimal volume;
        private String volumeUnit;
        private String cargoOwner;
        private String storageLocation;
        private LocalDateTime storageDate;
        private String insuranceStatus;
        private BigDecimal insuredValue;
        private String cargoStatus;
        private Map<String, Object> customsInfo;
        private List<String> specialRequirements;
        
        // Getters and Setters
        public String getCargoId() {
            return cargoId;
        }
        
        public void setCargoId(String cargoId) {
            this.cargoId = cargoId;
        }
        
        public String getCargoType() {
            return cargoType;
        }
        
        public void setCargoType(String cargoType) {
            this.cargoType = cargoType;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
        
        public BigDecimal getWeight() {
            return weight;
        }
        
        public void setWeight(BigDecimal weight) {
            this.weight = weight;
        }
        
        public String getWeightUnit() {
            return weightUnit;
        }
        
        public void setWeightUnit(String weightUnit) {
            this.weightUnit = weightUnit;
        }
        
        public BigDecimal getVolume() {
            return volume;
        }
        
        public void setVolume(BigDecimal volume) {
            this.volume = volume;
        }
        
        public String getVolumeUnit() {
            return volumeUnit;
        }
        
        public void setVolumeUnit(String volumeUnit) {
            this.volumeUnit = volumeUnit;
        }
        
        public String getCargoOwner() {
            return cargoOwner;
        }
        
        public void setCargoOwner(String cargoOwner) {
            this.cargoOwner = cargoOwner;
        }
        
        public String getStorageLocation() {
            return storageLocation;
        }
        
        public void setStorageLocation(String storageLocation) {
            this.storageLocation = storageLocation;
        }
        
        public LocalDateTime getStorageDate() {
            return storageDate;
        }
        
        public void setStorageDate(LocalDateTime storageDate) {
            this.storageDate = storageDate;
        }
        
        public String getInsuranceStatus() {
            return insuranceStatus;
        }
        
        public void setInsuranceStatus(String insuranceStatus) {
            this.insuranceStatus = insuranceStatus;
        }
        
        public BigDecimal getInsuredValue() {
            return insuredValue;
        }
        
        public void setInsuredValue(BigDecimal insuredValue) {
            this.insuredValue = insuredValue;
        }
        
        public String getCargoStatus() {
            return cargoStatus;
        }
        
        public void setCargoStatus(String cargoStatus) {
            this.cargoStatus = cargoStatus;
        }
        
        public Map<String, Object> getCustomsInfo() {
            return customsInfo;
        }
        
        public void setCustomsInfo(Map<String, Object> customsInfo) {
            this.customsInfo = customsInfo;
        }
        
        public List<String> getSpecialRequirements() {
            return specialRequirements;
        }
        
        public void setSpecialRequirements(List<String> specialRequirements) {
            this.specialRequirements = specialRequirements;
        }
    }
    
    /**
     * 鑸硅埗淇℃伅
     */
    class VesselInfo {
        private String vesselId;
        private String vesselName;
        private String vesselType;
        private String imoNumber;
        private String flag;
        private BigDecimal grossTonnage;
        private BigDecimal deadweightTonnage;
        private Integer length;
        private Integer width;
        private Integer draft;
        private String owner;
        private String operator;
        private String currentLocation;
        private LocalDateTime eta; // TODO: fix encoding comment
        private LocalDateTime etd; // TODO: fix encoding comment
        private String vesselStatus;
        private List<String> certifications;
        
        // Getters and Setters
        public String getVesselId() {
            return vesselId;
        }
        
        public void setVesselId(String vesselId) {
            this.vesselId = vesselId;
        }
        
        public String getVesselName() {
            return vesselName;
        }
        
        public void setVesselName(String vesselName) {
            this.vesselName = vesselName;
        }
        
        public String getVesselType() {
            return vesselType;
        }
        
        public void setVesselType(String vesselType) {
            this.vesselType = vesselType;
        }
        
        public String getImoNumber() {
            return imoNumber;
        }
        
        public void setImoNumber(String imoNumber) {
            this.imoNumber = imoNumber;
        }
        
        public String getFlag() {
            return flag;
        }
        
        public void setFlag(String flag) {
            this.flag = flag;
        }
        
        public BigDecimal getGrossTonnage() {
            return grossTonnage;
        }
        
        public void setGrossTonnage(BigDecimal grossTonnage) {
            this.grossTonnage = grossTonnage;
        }
        
        public BigDecimal getDeadweightTonnage() {
            return deadweightTonnage;
        }
        
        public void setDeadweightTonnage(BigDecimal deadweightTonnage) {
            this.deadweightTonnage = deadweightTonnage;
        }
        
        public Integer getLength() {
            return length;
        }
        
        public void setLength(Integer length) {
            this.length = length;
        }
        
        public Integer getWidth() {
            return width;
        }
        
        public void setWidth(Integer width) {
            this.width = width;
        }
        
        public Integer getDraft() {
            return draft;
        }
        
        public void setDraft(Integer draft) {
            this.draft = draft;
        }
        
        public String getOwner() {
            return owner;
        }
        
        public void setOwner(String owner) {
            this.owner = owner;
        }
        
        public String getOperator() {
            return operator;
        }
        
        public void setOperator(String operator) {
            this.operator = operator;
        }
        
        public String getCurrentLocation() {
            return currentLocation;
        }
        
        public void setCurrentLocation(String currentLocation) {
            this.currentLocation = currentLocation;
        }
        
        public LocalDateTime getEta() {
            return eta;
        }
        
        public void setEta(LocalDateTime eta) {
            this.eta = eta;
        }
        
        public LocalDateTime getEtd() {
            return etd;
        }
        
        public void setEtd(LocalDateTime etd) {
            this.etd = etd;
        }
        
        public String getVesselStatus() {
            return vesselStatus;
        }
        
        public void setVesselStatus(String vesselStatus) {
            this.vesselStatus = vesselStatus;
        }
        
        public List<String> getCertifications() {
            return certifications;
        }
        
        public void setCertifications(List<String> certifications) {
            this.certifications = certifications;
        }
    }
    
    /**
     * 鑸嚎淇℃伅
     */
    class RouteInfo {
        private String routeId;
        private String routeName;
        private String originPort;
        private String destinationPort;
        private Integer distanceNauticalMiles;
        private Integer estimatedDays;
        private List<String> intermediatePorts;
        private String routeType; // DIRECT, MULTIPORT
        private BigDecimal standardFreightRate;
        private String currency;
        private String routeStatus;
        private List<String> supportedVesselTypes;
        
        // Getters and Setters
        public String getRouteId() {
            return routeId;
        }
        
        public void setRouteId(String routeId) {
            this.routeId = routeId;
        }
        
        public String getRouteName() {
            return routeName;
        }
        
        public void setRouteName(String routeName) {
            this.routeName = routeName;
        }
        
        public String getOriginPort() {
            return originPort;
        }
        
        public void setOriginPort(String originPort) {
            this.originPort = originPort;
        }
        
        public String getDestinationPort() {
            return destinationPort;
        }
        
        public void setDestinationPort(String destinationPort) {
            this.destinationPort = destinationPort;
        }
        
        public Integer getDistanceNauticalMiles() {
            return distanceNauticalMiles;
        }
        
        public void setDistanceNauticalMiles(Integer distanceNauticalMiles) {
            this.distanceNauticalMiles = distanceNauticalMiles;
        }
        
        public Integer getEstimatedDays() {
            return estimatedDays;
        }
        
        public void setEstimatedDays(Integer estimatedDays) {
            this.estimatedDays = estimatedDays;
        }
        
        public List<String> getIntermediatePorts() {
            return intermediatePorts;
        }
        
        public void setIntermediatePorts(List<String> intermediatePorts) {
            this.intermediatePorts = intermediatePorts;
        }
        
        public String getRouteType() {
            return routeType;
        }
        
        public void setRouteType(String routeType) {
            this.routeType = routeType;
        }
        
        public BigDecimal getStandardFreightRate() {
            return standardFreightRate;
        }
        
        public void setStandardFreightRate(BigDecimal standardFreightRate) {
            this.standardFreightRate = standardFreightRate;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public String getRouteStatus() {
            return routeStatus;
        }
        
        public void setRouteStatus(String routeStatus) {
            this.routeStatus = routeStatus;
        }
        
        public List<String> getSupportedVesselTypes() {
            return supportedVesselTypes;
        }
        
        public void setSupportedVesselTypes(List<String> supportedVesselTypes) {
            this.supportedVesselTypes = supportedVesselTypes;
        }
    }
    
    /**
     * 娓彛淇℃伅
     */
    class PortInfo {
        private String portCode;
        private String portName;
        private String country;
        private String city;
        private BigDecimal latitude;
        private BigDecimal longitude;
        private String portType; // SEAPORT, RIVERPORT, INLAND
        private Integer maxDraft;
        private Integer berths;
        private List<String> handlingCapabilities;
        private String portOperator;
        private String contactNumber;
        private String email;
        private String portStatus;
        
        // Getters and Setters
        public String getPortCode() {
            return portCode;
        }
        
        public void setPortCode(String portCode) {
            this.portCode = portCode;
        }
        
        public String getPortName() {
            return portName;
        }
        
        public void setPortName(String portName) {
            this.portName = portName;
        }
        
        public String getCountry() {
            return country;
        }
        
        public void setCountry(String country) {
            this.country = country;
        }
        
        public String getCity() {
            return city;
        }
        
        public void setCity(String city) {
            this.city = city;
        }
        
        public BigDecimal getLatitude() {
            return latitude;
        }
        
        public void setLatitude(BigDecimal latitude) {
            this.latitude = latitude;
        }
        
        public BigDecimal getLongitude() {
            return longitude;
        }
        
        public void setLongitude(BigDecimal longitude) {
            this.longitude = longitude;
        }
        
        public String getPortType() {
            return portType;
        }
        
        public void setPortType(String portType) {
            this.portType = portType;
        }
        
        public Integer getMaxDraft() {
            return maxDraft;
        }
        
        public void setMaxDraft(Integer maxDraft) {
            this.maxDraft = maxDraft;
        }
        
        public Integer getBerths() {
            return berths;
        }
        
        public void setBerths(Integer berths) {
            this.berths = berths;
        }
        
        public List<String> getHandlingCapabilities() {
            return handlingCapabilities;
        }
        
        public void setHandlingCapabilities(List<String> handlingCapabilities) {
            this.handlingCapabilities = handlingCapabilities;
        }
        
        public String getPortOperator() {
            return portOperator;
        }
        
        public void setPortOperator(String portOperator) {
            this.portOperator = portOperator;
        }
        
        public String getContactNumber() {
            return contactNumber;
        }
        
        public void setContactNumber(String contactNumber) {
            this.contactNumber = contactNumber;
        }
        
        public String getEmail() {
            return email;
        }
        
        public void setEmail(String email) {
            this.email = email;
        }
        
        public String getPortStatus() {
            return portStatus;
        }
        
        public void setPortStatus(String portStatus) {
            this.portStatus = portStatus;
        }
    }
    
    /**
     * 杩愯緭璁″垝
     */
    class TransportPlan {
        private String planId;
        private String planName;
        private LocalDateTime plannedDate;
        private String vesselId;
        private String routeId;
        private List<String> cargoIds;
        private BigDecimal estimatedCost;
        private String currency;
        private String planStatus;
        private LocalDateTime createdAt;
        private String createdBy;
        
        // Getters and Setters
        public String getPlanId() {
            return planId;
        }
        
        public void setPlanId(String planId) {
            this.planId = planId;
        }
        
        public String getPlanName() {
            return planName;
        }
        
        public void setPlanName(String planName) {
            this.planName = planName;
        }
        
        public LocalDateTime getPlannedDate() {
            return plannedDate;
        }
        
        public void setPlannedDate(LocalDateTime plannedDate) {
            this.plannedDate = plannedDate;
        }
        
        public String getVesselId() {
            return vesselId;
        }
        
        public void setVesselId(String vesselId) {
            this.vesselId = vesselId;
        }
        
        public String getRouteId() {
            return routeId;
        }
        
        public void setRouteId(String routeId) {
            this.routeId = routeId;
        }
        
        public List<String> getCargoIds() {
            return cargoIds;
        }
        
        public void setCargoIds(List<String> cargoIds) {
            this.cargoIds = cargoIds;
        }
        
        public BigDecimal getEstimatedCost() {
            return estimatedCost;
        }
        
        public void setEstimatedCost(BigDecimal estimatedCost) {
            this.estimatedCost = estimatedCost;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public String getPlanStatus() {
            return planStatus;
        }
        
        public void setPlanStatus(String planStatus) {
            this.planStatus = planStatus;
        }
        
        public LocalDateTime getCreatedAt() {
            return createdAt;
        }
        
        public void setCreatedAt(LocalDateTime createdAt) {
            this.createdAt = createdAt;
        }
        
        public String getCreatedBy() {
            return createdBy;
        }
        
        public void setCreatedBy(String createdBy) {
            this.createdBy = createdBy;
        }
    }
    
    /**
     * 杩愯緭璁㈠崟璇锋眰
     */
    class TransportOrderRequest {
        private String cargoId;
        private String originPort;
        private String destinationPort;
        private LocalDateTime requestedPickupDate;
        private LocalDateTime requestedDeliveryDate;
        private String transportType; // SEA, LAND, AIR, MULTIMODAL
        private String cargoOwner;
        private String consignee;
        private String specialInstructions;
        private boolean insuranceRequired;
        private BigDecimal declaredValue;
        private String valueCurrency;
        
        // Getters and Setters
        public String getCargoId() {
            return cargoId;
        }
        
        public void setCargoId(String cargoId) {
            this.cargoId = cargoId;
        }
        
        public String getOriginPort() {
            return originPort;
        }
        
        public void setOriginPort(String originPort) {
            this.originPort = originPort;
        }
        
        public String getDestinationPort() {
            return destinationPort;
        }
        
        public void setDestinationPort(String destinationPort) {
            this.destinationPort = destinationPort;
        }
        
        public LocalDateTime getRequestedPickupDate() {
            return requestedPickupDate;
        }
        
        public void setRequestedPickupDate(LocalDateTime requestedPickupDate) {
            this.requestedPickupDate = requestedPickupDate;
        }
        
        public LocalDateTime getRequestedDeliveryDate() {
            return requestedDeliveryDate;
        }
        
        public void setRequestedDeliveryDate(LocalDateTime requestedDeliveryDate) {
            this.requestedDeliveryDate = requestedDeliveryDate;
        }
        
        public String getTransportType() {
            return transportType;
        }
        
        public void setTransportType(String transportType) {
            this.transportType = transportType;
        }
        
        public String getCargoOwner() {
            return cargoOwner;
        }
        
        public void setCargoOwner(String cargoOwner) {
            this.cargoOwner = cargoOwner;
        }
        
        public String getConsignee() {
            return consignee;
        }
        
        public void setConsignee(String consignee) {
            this.consignee = consignee;
        }
        
        public String getSpecialInstructions() {
            return specialInstructions;
        }
        
        public void setSpecialInstructions(String specialInstructions) {
            this.specialInstructions = specialInstructions;
        }
        
        public boolean isInsuranceRequired() {
            return insuranceRequired;
        }
        
        public void setInsuranceRequired(boolean insuranceRequired) {
            this.insuranceRequired = insuranceRequired;
        }
        
        public BigDecimal getDeclaredValue() {
            return declaredValue;
        }
        
        public void setDeclaredValue(BigDecimal declaredValue) {
            this.declaredValue = declaredValue;
        }
        
        public String getValueCurrency() {
            return valueCurrency;
        }
        
        public void setValueCurrency(String valueCurrency) {
            this.valueCurrency = valueCurrency;
        }
    }
    
    /**
     * 杩愯緭璁㈠崟鍝嶅簲
     */
    class TransportOrderResponse {
        private boolean success;
        private String orderId;
        private String trackingNumber;
        private LocalDateTime orderDate;
        private BigDecimal totalCost;
        private String currency;
        private String status;
        private String message;
        private String assignedVessel;
        private LocalDateTime estimatedPickupDate;
        private LocalDateTime estimatedDeliveryDate;
        private String insurancePolicyNumber;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public String getOrderId() {
            return orderId;
        }
        
        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }
        
        public String getTrackingNumber() {
            return trackingNumber;
        }
        
        public void setTrackingNumber(String trackingNumber) {
            this.trackingNumber = trackingNumber;
        }
        
        public LocalDateTime getOrderDate() {
            return orderDate;
        }
        
        public void setOrderDate(LocalDateTime orderDate) {
            this.orderDate = orderDate;
        }
        
        public BigDecimal getTotalCost() {
            return totalCost;
        }
        
        public void setTotalCost(BigDecimal totalCost) {
            this.totalCost = totalCost;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public String getAssignedVessel() {
            return assignedVessel;
        }
        
        public void setAssignedVessel(String assignedVessel) {
            this.assignedVessel = assignedVessel;
        }
        
        public LocalDateTime getEstimatedPickupDate() {
            return estimatedPickupDate;
        }
        
        public void setEstimatedPickupDate(LocalDateTime estimatedPickupDate) {
            this.estimatedPickupDate = estimatedPickupDate;
        }
        
        public LocalDateTime getEstimatedDeliveryDate() {
            return estimatedDeliveryDate;
        }
        
        public void setEstimatedDeliveryDate(LocalDateTime estimatedDeliveryDate) {
            this.estimatedDeliveryDate = estimatedDeliveryDate;
        }
        
        public String getInsurancePolicyNumber() {
            return insurancePolicyNumber;
        }
        
        public void setInsurancePolicyNumber(String insurancePolicyNumber) {
            this.insurancePolicyNumber = insurancePolicyNumber;
        }
    }
    
    /**
     * 杩愯緭鐘舵€?     */

    class TransportStatus {
        private String trackingNumber;
        private String currentLocation;
        private LocalDateTime locationTimestamp;
        private String status; // PICKUP_SCHEDULED, IN_TRANSIT, AT_PORT, DELIVERED
        private String nextLocation;
        private LocalDateTime estimatedArrival;
        private LocalDateTime actualPickupDate;
        private LocalDateTime actualDeliveryDate;
        private List<StatusHistory> statusHistory;
        
        // Getters and Setters
        public String getTrackingNumber() {
            return trackingNumber;
        }
        
        public void setTrackingNumber(String trackingNumber) {
            this.trackingNumber = trackingNumber;
        }
        
        public String getCurrentLocation() {
            return currentLocation;
        }
        
        public void setCurrentLocation(String currentLocation) {
            this.currentLocation = currentLocation;
        }
        
        public LocalDateTime getLocationTimestamp() {
            return locationTimestamp;
        }
        
        public void setLocationTimestamp(LocalDateTime locationTimestamp) {
            this.locationTimestamp = locationTimestamp;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public String getNextLocation() {
            return nextLocation;
        }
        
        public void setNextLocation(String nextLocation) {
            this.nextLocation = nextLocation;
        }
        
        public LocalDateTime getEstimatedArrival() {
            return estimatedArrival;
        }
        
        public void setEstimatedArrival(LocalDateTime estimatedArrival) {
            this.estimatedArrival = estimatedArrival;
        }
        
        public LocalDateTime getActualPickupDate() {
            return actualPickupDate;
        }
        
        public void setActualPickupDate(LocalDateTime actualPickupDate) {
            this.actualPickupDate = actualPickupDate;
        }
        
        public LocalDateTime getActualDeliveryDate() {
            return actualDeliveryDate;
        }
        
        public void setActualDeliveryDate(LocalDateTime actualDeliveryDate) {
            this.actualDeliveryDate = actualDeliveryDate;
        }
        
        public List<StatusHistory> getStatusHistory() {
            return statusHistory;
        }
        
        public void setStatusHistory(List<StatusHistory> statusHistory) {
            this.statusHistory = statusHistory;
        }
    }
    
    /**
     * 璐х墿浣嶇疆
     */
    class CargoLocation {
        private String cargoId;
        private String location;
        private LocalDateTime timestamp;
        private String locationType; // PORT, VESSEL, WAREHOUSE, IN_TRANSIT
        private String vesselId;
        private String portCode;
        private BigDecimal latitude;
        private BigDecimal longitude;
        
        // Getters and Setters
        public String getCargoId() {
            return cargoId;
        }
        
        public void setCargoId(String cargoId) {
            this.cargoId = cargoId;
        }
        
        public String getLocation() {
            return location;
        }
        
        public void setLocation(String location) {
            this.location = location;
        }
        
        public LocalDateTime getTimestamp() {
            return timestamp;
        }
        
        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }
        
        public String getLocationType() {
            return locationType;
        }
        
        public void setLocationType(String locationType) {
            this.locationType = locationType;
        }
        
        public String getVesselId() {
            return vesselId;
        }
        
        public void setVesselId(String vesselId) {
            this.vesselId = vesselId;
        }
        
        public String getPortCode() {
            return portCode;
        }
        
        public void setPortCode(String portCode) {
            this.portCode = portCode;
        }
        
        public BigDecimal getLatitude() {
            return latitude;
        }
        
        public void setLatitude(BigDecimal latitude) {
            this.latitude = latitude;
        }
        
        public BigDecimal getLongitude() {
            return longitude;
        }
        
        public void setLongitude(BigDecimal longitude) {
            this.longitude = longitude;
        }
    }
    
    /**
     * 澶╂皵淇℃伅
     */
    class WeatherInfo {
        private String location;
        private LocalDateTime observationTime;
        private BigDecimal temperature;
        private String temperatureUnit;
        private Integer humidity;
        private BigDecimal windSpeed;
        private String windDirection;
        private String weatherCondition;
        private BigDecimal precipitation;
        private BigDecimal visibility;
        private BigDecimal pressure;
        private LocalDateTime sunrise;
        private LocalDateTime sunset;
        private List<WeatherForecast> forecast;
        
        // Getters and Setters
        public String getLocation() {
            return location;
        }
        
        public void setLocation(String location) {
            this.location = location;
        }
        
        public LocalDateTime getObservationTime() {
            return observationTime;
        }
        
        public void setObservationTime(LocalDateTime observationTime) {
            this.observationTime = observationTime;
        }
        
        public BigDecimal getTemperature() {
            return temperature;
        }
        
        public void setTemperature(BigDecimal temperature) {
            this.temperature = temperature;
        }
        
        public String getTemperatureUnit() {
            return temperatureUnit;
        }
        
        public void setTemperatureUnit(String temperatureUnit) {
            this.temperatureUnit = temperatureUnit;
        }
        
        public Integer getHumidity() {
            return humidity;
        }
        
        public void setHumidity(Integer humidity) {
            this.humidity = humidity;
        }
        
        public BigDecimal getWindSpeed() {
            return windSpeed;
        }
        
        public void setWindSpeed(BigDecimal windSpeed) {
            this.windSpeed = windSpeed;
        }
        
        public String getWindDirection() {
            return windDirection;
        }
        
        public void setWindDirection(String windDirection) {
            this.windDirection = windDirection;
        }
        
        public String getWeatherCondition() {
            return weatherCondition;
        }
        
        public void setWeatherCondition(String weatherCondition) {
            this.weatherCondition = weatherCondition;
        }
        
        public BigDecimal getPrecipitation() {
            return precipitation;
        }
        
        public void setPrecipitation(BigDecimal precipitation) {
            this.precipitation = precipitation;
        }
        
        public BigDecimal getVisibility() {
            return visibility;
        }
        
        public void setVisibility(BigDecimal visibility) {
            this.visibility = visibility;
        }
        
        public BigDecimal getPressure() {
            return pressure;
        }
        
        public void setPressure(BigDecimal pressure) {
            this.pressure = pressure;
        }
        
        public LocalDateTime getSunrise() {
            return sunrise;
        }
        
        public void setSunrise(LocalDateTime sunrise) {
            this.sunrise = sunrise;
        }
        
        public LocalDateTime getSunset() {
            return sunset;
        }
        
        public void setSunset(LocalDateTime sunset) {
            this.sunset = sunset;
        }
        
        public List<WeatherForecast> getForecast() {
            return forecast;
        }
        
        public void setForecast(List<WeatherForecast> forecast) {
            this.forecast = forecast;
        }
    }
    
    /**
     * 鐘舵€佸巻鍙?     */

    class StatusHistory {
        private String status;
        private LocalDateTime timestamp;
        private String location;
        private String remarks;
        
        // Getters and Setters
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public LocalDateTime getTimestamp() {
            return timestamp;
        }
        
        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }
        
        public String getLocation() {
            return location;
        }
        
        public void setLocation(String location) {
            this.location = location;
        }
        
        public String getRemarks() {
            return remarks;
        }
        
        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }
    }
    
    /**
     * 澶╂皵棰勬姤
     */
    class WeatherForecast {
        private LocalDateTime forecastDate;
        private BigDecimal highTemperature;
        private BigDecimal lowTemperature;
        private String weatherCondition;
        private BigDecimal precipitationProbability;
        private BigDecimal windSpeed;
        private String windDirection;
        
        // Getters and Setters
        public LocalDateTime getForecastDate() {
            return forecastDate;
        }
        
        public void setForecastDate(LocalDateTime forecastDate) {
            this.forecastDate = forecastDate;
        }
        
        public BigDecimal getHighTemperature() {
            return highTemperature;
        }
        
        public void setHighTemperature(BigDecimal highTemperature) {
            this.highTemperature = highTemperature;
        }
        
        public BigDecimal getLowTemperature() {
            return lowTemperature;
        }
        
        public void setLowTemperature(BigDecimal lowTemperature) {
            this.lowTemperature = lowTemperature;
        }
        
        public String getWeatherCondition() {
            return weatherCondition;
        }
        
        public void setWeatherCondition(String weatherCondition) {
            this.weatherCondition = weatherCondition;
        }
        
        public BigDecimal getPrecipitationProbability() {
            return precipitationProbability;
        }
        
        public void setPrecipitationProbability(BigDecimal precipitationProbability) {
            this.precipitationProbability = precipitationProbability;
        }
        
        public BigDecimal getWindSpeed() {
            return windSpeed;
        }
        
        public void setWindSpeed(BigDecimal windSpeed) {
            this.windSpeed = windSpeed;
        }
        
        public String getWindDirection() {
            return windDirection;
        }
        
        public void setWindDirection(String windDirection) {
            this.windDirection = windDirection;
        }
    }
}