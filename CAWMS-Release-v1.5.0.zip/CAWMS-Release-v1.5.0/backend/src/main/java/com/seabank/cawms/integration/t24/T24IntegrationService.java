package com.seabank.cawms.integration.t24;

import com.seabank.cawms.integration.IntegrationService;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * T24银行核心系统集成服务接口
 * T24是Temenos的银行核心系统，处理账户、交易、客户等核心银行业务
 */
public interface T24IntegrationService extends IntegrationService {
    
    /**
     * 查询账户余额
     * @param accountNumber 璐︽埛鍙风爜
     * @param currency 甯佺
     * @return 璐︽埛浣欓淇℃伅
     */
    AccountBalance queryAccountBalance(String accountNumber, String currency);
    
    /**
     * 查询账户交易明细
     * @param accountNumber 璐︽埛鍙风爜
     * @param startDate 寮€濮嬫棩鏈?     * @param endDate 缁撴潫鏃ユ湡
     * @return 交易明细列表
     */
    List<TransactionDetail> queryAccountTransactions(String accountNumber, LocalDateTime startDate, LocalDateTime endDate);
    
    /**
     * 鍙戣捣璧勯噾杞处
     * @param request 转账请求
     * @return 转账响应
     */
    FundTransferResponse fundTransfer(FundTransferRequest request);
    
    /**
     * 查询客户信息
     * @param customerId 瀹㈡埛ID
     * @return 瀹㈡埛淇℃伅
     */
    CustomerInfo queryCustomerInfo(String customerId);
    
    /**
     * 验证交易密码
     * @param accountNumber 璐︽埛鍙风爜
     * @param transactionPassword 交易密码
     * @return 验证结果
     */
    PasswordValidationResult validateTransactionPassword(String accountNumber, String transactionPassword);
    
    /**
     * 查询产品信息
     * @param productCode 产品代码
     * @return 浜у搧淇℃伅
     */
    ProductInfo queryProductInfo(String productCode);
    
    /**
     * 批量查询账户余额
     * @param accountNumbers 账户号码列表
     * @return 余额信息列表
     */
    List<AccountBalance> batchQueryAccountBalances(List<String> accountNumbers);
    
    /**
     * 查询汇率
     * @param fromCurrency 婧愬竵绉?     * @param toCurrency 目标币种
     * @return 姹囩巼淇℃伅
     */
    ExchangeRate queryExchangeRate(String fromCurrency, String toCurrency);
    
    /**
     * 璐︽埛浣欓淇℃伅
     */
    class AccountBalance {
        private String accountNumber;
        private String accountName;
        private String currency;
        private BigDecimal availableBalance;
        private BigDecimal ledgerBalance;
        private BigDecimal blockedAmount;
        private LocalDateTime balanceDate;
        private String accountStatus;
        
        // Getters and Setters
        public String getAccountNumber() {
            return accountNumber;
        }
        
        public void setAccountNumber(String accountNumber) {
            this.accountNumber = accountNumber;
        }
        
        public String getAccountName() {
            return accountName;
        }
        
        public void setAccountName(String accountName) {
            this.accountName = accountName;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public BigDecimal getAvailableBalance() {
            return availableBalance;
        }
        
        public void setAvailableBalance(BigDecimal availableBalance) {
            this.availableBalance = availableBalance;
        }
        
        public BigDecimal getLedgerBalance() {
            return ledgerBalance;
        }
        
        public void setLedgerBalance(BigDecimal ledgerBalance) {
            this.ledgerBalance = ledgerBalance;
        }
        
        public BigDecimal getBlockedAmount() {
            return blockedAmount;
        }
        
        public void setBlockedAmount(BigDecimal blockedAmount) {
            this.blockedAmount = blockedAmount;
        }
        
        public LocalDateTime getBalanceDate() {
            return balanceDate;
        }
        
        public void setBalanceDate(LocalDateTime balanceDate) {
            this.balanceDate = balanceDate;
        }
        
        public String getAccountStatus() {
            return accountStatus;
        }
        
        public void setAccountStatus(String accountStatus) {
            this.accountStatus = accountStatus;
        }
    }
    
    /**
     * 浜ゆ槗鏄庣粏
     */
    class TransactionDetail {
        private String transactionId;
        private String referenceNumber;
        private LocalDateTime transactionDate;
        private String description;
        private BigDecimal amount;
        private String currency;
        private String transactionType;
        private String debitCreditFlag; // TODO: encoding issue
        private BigDecimal balanceAfter;
        private String channel;
        
        // Getters and Setters
        public String getTransactionId() {
            return transactionId;
        }
        
        public void setTransactionId(String transactionId) {
            this.transactionId = transactionId;
        }
        
        public String getReferenceNumber() {
            return referenceNumber;
        }
        
        public void setReferenceNumber(String referenceNumber) {
            this.referenceNumber = referenceNumber;
        }
        
        public LocalDateTime getTransactionDate() {
            return transactionDate;
        }
        
        public void setTransactionDate(LocalDateTime transactionDate) {
            this.transactionDate = transactionDate;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
        
        public BigDecimal getAmount() {
            return amount;
        }
        
        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public String getTransactionType() {
            return transactionType;
        }
        
        public void setTransactionType(String transactionType) {
            this.transactionType = transactionType;
        }
        
        public String getDebitCreditFlag() {
            return debitCreditFlag;
        }
        
        public void setDebitCreditFlag(String debitCreditFlag) {
            this.debitCreditFlag = debitCreditFlag;
        }
        
        public BigDecimal getBalanceAfter() {
            return balanceAfter;
        }
        
        public void setBalanceAfter(BigDecimal balanceAfter) {
            this.balanceAfter = balanceAfter;
        }
        
        public String getChannel() {
            return channel;
        }
        
        public void setChannel(String channel) {
            this.channel = channel;
        }
    }
    
    /**
     * 转账请求
     */
    class FundTransferRequest {
        private String fromAccount;
        private String toAccount;
        private BigDecimal amount;
        private String currency;
        private String transactionReference;
        private String description;
        private String paymentMethod;
        private String beneficiaryName;
        private String beneficiaryBank;
        private String beneficiaryBranch;
        private String chargeBearer; // OUR, BEN, SHA
        
        // Getters and Setters
        public String getFromAccount() {
            return fromAccount;
        }
        
        public void setFromAccount(String fromAccount) {
            this.fromAccount = fromAccount;
        }
        
        public String getToAccount() {
            return toAccount;
        }
        
        public void setToAccount(String toAccount) {
            this.toAccount = toAccount;
        }
        
        public BigDecimal getAmount() {
            return amount;
        }
        
        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public String getTransactionReference() {
            return transactionReference;
        }
        
        public void setTransactionReference(String transactionReference) {
            this.transactionReference = transactionReference;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
        
        public String getPaymentMethod() {
            return paymentMethod;
        }
        
        public void setPaymentMethod(String paymentMethod) {
            this.paymentMethod = paymentMethod;
        }
        
        public String getBeneficiaryName() {
            return beneficiaryName;
        }
        
        public void setBeneficiaryName(String beneficiaryName) {
            this.beneficiaryName = beneficiaryName;
        }
        
        public String getBeneficiaryBank() {
            return beneficiaryBank;
        }
        
        public void setBeneficiaryBank(String beneficiaryBank) {
            this.beneficiaryBank = beneficiaryBank;
        }
        
        public String getBeneficiaryBranch() {
            return beneficiaryBranch;
        }
        
        public void setBeneficiaryBranch(String beneficiaryBranch) {
            this.beneficiaryBranch = beneficiaryBranch;
        }
        
        public String getChargeBearer() {
            return chargeBearer;
        }
        
        public void setChargeBearer(String chargeBearer) {
            this.chargeBearer = chargeBearer;
        }
    }
    
    /**
     * 转账响应
     */
    class FundTransferResponse {
        private boolean success;
        private String transactionId;
        private String referenceNumber;
        private LocalDateTime transactionDate;
        private String status;
        private String message;
        private BigDecimal fees;
        private String feesCurrency;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public String getTransactionId() {
            return transactionId;
        }
        
        public void setTransactionId(String transactionId) {
            this.transactionId = transactionId;
        }
        
        public String getReferenceNumber() {
            return referenceNumber;
        }
        
        public void setReferenceNumber(String referenceNumber) {
            this.referenceNumber = referenceNumber;
        }
        
        public LocalDateTime getTransactionDate() {
            return transactionDate;
        }
        
        public void setTransactionDate(LocalDateTime transactionDate) {
            this.transactionDate = transactionDate;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public BigDecimal getFees() {
            return fees;
        }
        
        public void setFees(BigDecimal fees) {
            this.fees = fees;
        }
        
        public String getFeesCurrency() {
            return feesCurrency;
        }
        
        public void setFeesCurrency(String feesCurrency) {
            this.feesCurrency = feesCurrency;
        }
    }
    
    /**
     * 瀹㈡埛淇℃伅
     */
    class CustomerInfo {
        private String customerId;
        private String customerName;
        private String customerType;
        private String idNumber;
        private LocalDateTime birthDate;
        private String nationality;
        private String address;
        private String phoneNumber;
        private String email;
        private String riskRating;
        private LocalDateTime customerSince;
        private String customerStatus;
        
        // Getters and Setters
        public String getCustomerId() {
            return customerId;
        }
        
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }
        
        public String getCustomerName() {
            return customerName;
        }
        
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }
        
        public String getCustomerType() {
            return customerType;
        }
        
        public void setCustomerType(String customerType) {
            this.customerType = customerType;
        }
        
        public String getIdNumber() {
            return idNumber;
        }
        
        public void setIdNumber(String idNumber) {
            this.idNumber = idNumber;
        }
        
        public LocalDateTime getBirthDate() {
            return birthDate;
        }
        
        public void setBirthDate(LocalDateTime birthDate) {
            this.birthDate = birthDate;
        }
        
        public String getNationality() {
            return nationality;
        }
        
        public void setNationality(String nationality) {
            this.nationality = nationality;
        }
        
        public String getAddress() {
            return address;
        }
        
        public void setAddress(String address) {
            this.address = address;
        }
        
        public String getPhoneNumber() {
            return phoneNumber;
        }
        
        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }
        
        public String getEmail() {
            return email;
        }
        
        public void setEmail(String email) {
            this.email = email;
        }
        
        public String getRiskRating() {
            return riskRating;
        }
        
        public void setRiskRating(String riskRating) {
            this.riskRating = riskRating;
        }
        
        public LocalDateTime getCustomerSince() {
            return customerSince;
        }
        
        public void setCustomerSince(LocalDateTime customerSince) {
            this.customerSince = customerSince;
        }
        
        public String getCustomerStatus() {
            return customerStatus;
        }
        
        public void setCustomerStatus(String customerStatus) {
            this.customerStatus = customerStatus;
        }
    }
    
    /**
     * 密码验证结果
     */
    class PasswordValidationResult {
        private boolean valid;
        private int remainingAttempts;
        private boolean locked;
        private String lockReason;
        private LocalDateTime unlockTime;
        
        // Getters and Setters
        public boolean isValid() {
            return valid;
        }
        
        public void setValid(boolean valid) {
            this.valid = valid;
        }
        
        public int getRemainingAttempts() {
            return remainingAttempts;
        }
        
        public void setRemainingAttempts(int remainingAttempts) {
            this.remainingAttempts = remainingAttempts;
        }
        
        public boolean isLocked() {
            return locked;
        }
        
        public void setLocked(boolean locked) {
            this.locked = locked;
        }
        
        public String getLockReason() {
            return lockReason;
        }
        
        public void setLockReason(String lockReason) {
            this.lockReason = lockReason;
        }
        
        public LocalDateTime getUnlockTime() {
            return unlockTime;
        }
        
        public void setUnlockTime(LocalDateTime unlockTime) {
            this.unlockTime = unlockTime;
        }
    }
    
    /**
     * 浜у搧淇℃伅
     */
    class ProductInfo {
        private String productCode;
        private String productName;
        private String productType;
        private String currency;
        private BigDecimal minimumBalance;
        private BigDecimal interestRate;
        private String interestCalculationMethod;
        private List<String> features;
        private Map<String, Object> termsAndConditions;
        private String status;
        
        // Getters and Setters
        public String getProductCode() {
            return productCode;
        }
        
        public void setProductCode(String productCode) {
            this.productCode = productCode;
        }
        
        public String getProductName() {
            return productName;
        }
        
        public void setProductName(String productName) {
            this.productName = productName;
        }
        
        public String getProductType() {
            return productType;
        }
        
        public void setProductType(String productType) {
            this.productType = productType;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public BigDecimal getMinimumBalance() {
            return minimumBalance;
        }
        
        public void setMinimumBalance(BigDecimal minimumBalance) {
            this.minimumBalance = minimumBalance;
        }
        
        public BigDecimal getInterestRate() {
            return interestRate;
        }
        
        public void setInterestRate(BigDecimal interestRate) {
            this.interestRate = interestRate;
        }
        
        public String getInterestCalculationMethod() {
            return interestCalculationMethod;
        }
        
        public void setInterestCalculationMethod(String interestCalculationMethod) {
            this.interestCalculationMethod = interestCalculationMethod;
        }
        
        public List<String> getFeatures() {
            return features;
        }
        
        public void setFeatures(List<String> features) {
            this.features = features;
        }
        
        public Map<String, Object> getTermsAndConditions() {
            return termsAndConditions;
        }
        
        public void setTermsAndConditions(Map<String, Object> termsAndConditions) {
            this.termsAndConditions = termsAndConditions;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
    }
    
    /**
     * 姹囩巼淇℃伅
     */
    class ExchangeRate {
        private String fromCurrency;
        private String toCurrency;
        private BigDecimal buyingRate;
        private BigDecimal sellingRate;
        private BigDecimal middleRate;
        private LocalDateTime rateDate;
        private String rateType; // SPOT, FORWARD, etc.
        
        // Getters and Setters
        public String getFromCurrency() {
            return fromCurrency;
        }
        
        public void setFromCurrency(String fromCurrency) {
            this.fromCurrency = fromCurrency;
        }
        
        public String getToCurrency() {
            return toCurrency;
        }
        
        public void setToCurrency(String toCurrency) {
            this.toCurrency = toCurrency;
        }
        
        public BigDecimal getBuyingRate() {
            return buyingRate;
        }
        
        public void setBuyingRate(BigDecimal buyingRate) {
            this.buyingRate = buyingRate;
        }
        
        public BigDecimal getSellingRate() {
            return sellingRate;
        }
        
        public void setSellingRate(BigDecimal sellingRate) {
            this.sellingRate = sellingRate;
        }
        
        public BigDecimal getMiddleRate() {
            return middleRate;
        }
        
        public void setMiddleRate(BigDecimal middleRate) {
            this.middleRate = middleRate;
        }
        
        public LocalDateTime getRateDate() {
            return rateDate;
        }
        
        public void setRateDate(LocalDateTime rateDate) {
            this.rateDate = rateDate;
        }
        
        public String getRateType() {
            return rateType;
        }
        
        public void setRateType(String rateType) {
            this.rateType = rateType;
        }
    }
}