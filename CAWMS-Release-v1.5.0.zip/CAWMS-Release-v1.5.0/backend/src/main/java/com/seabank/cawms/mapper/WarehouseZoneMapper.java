package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.WarehouseZoneEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface WarehouseZoneMapper extends BaseMapper<WarehouseZoneEntity> {

    @Select("SELECT * FROM warehouse_zone WHERE zone_code = #{zoneCode} AND deleted = 0 LIMIT 1")
    WarehouseZoneEntity selectByZoneCode(@Param("zoneCode") String zoneCode);

    @Select("SELECT * FROM warehouse_zone WHERE deleted = 0 ORDER BY created_at DESC")
    List<WarehouseZoneEntity> selectAllActive();
}
