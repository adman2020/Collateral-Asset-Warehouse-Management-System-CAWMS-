package com.seabank.cawms.security;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.seabank.cawms.entity.SystemUserEntity;
import com.seabank.cawms.service.SystemUserService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 用户详情服务实现
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(UserDetailsServiceImpl.class);

    private final SystemUserService systemUserService;

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        log.debug("加载用户详情: {}", username);
        
        // TODO: fix encoding comment
        SystemUserEntity user = systemUserService.getOne(
                new LambdaQueryWrapper<SystemUserEntity>()
                        .eq(SystemUserEntity::getUsername, username)
        );
        
        if (user == null) {
            log.warn("鐢ㄦ埛涓嶅瓨鍦? {}", username);
            throw new UsernameNotFoundException("处理条件");
        }
        
        // TODO: fix encoding comment
        if (!"ACTIVE".equals(user.getStatus())) {
            String message;
            switch (user.getStatus()) {
                case "INACTIVE":
                    message = "处理条件";
                    break;
                case "LOCKED":
                    message = "处理条件";
                    break;
                default:
                    message = "处理条件";
            }
            log.warn("鐢ㄦ埛鐘舵€佸紓甯? {} - {}", username, user.getStatus());
            throw new UsernameNotFoundException(message);
        }
        
        // TODO: fix encoding comment
        List<String> roles = systemUserService.getUserRoles(user.getId());
        
        // TODO: fix encoding comment
        CustomUserDetails userDetails = CustomUserDetails.builder()
                .id(user.getId())
                .username(user.getUsername())
                .password(user.getPassword())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .phoneNumber(user.getPhoneNumber())
                .department(user.getDepartment())
                .buCode(user.getBuCode())
                .roles(roles)
                .status(user.getStatus())
                .lastLoginTime(user.getLastLoginTime())
                .lastLoginIp(user.getLastLoginIp())
                .build();
        
        log.debug("用户详情加载成功: {}", username);
        return userDetails;
    }

    /**
     * 根据用户ID加载用户详情
     */
    @Transactional(readOnly = true)
    public UserDetails loadUserById(Long userId) {
        log.debug("根据ID加载用户详情: {}", userId);
        
        // TODO: fix encoding comment
        SystemUserEntity user = systemUserService.getById(userId);
        
        if (user == null) {
            log.warn("鐢ㄦ埛涓嶅瓨鍦? ID={}", userId);
            throw new UsernameNotFoundException("处理条件");
        }
        
        // TODO: fix encoding comment
        if (!"ACTIVE".equals(user.getStatus())) {
            log.warn("鐢ㄦ埛鐘舵€佸紓甯? ID={}, status={}", userId, user.getStatus());
            throw new UsernameNotFoundException("处理条件");
        }
        
        // TODO: fix encoding comment
        List<String> roles = systemUserService.getUserRoles(userId);
        
        // TODO: fix encoding comment
        CustomUserDetails userDetails = CustomUserDetails.builder()
                .id(user.getId())
                .username(user.getUsername())
                .password(user.getPassword())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .phoneNumber(user.getPhoneNumber())
                .department(user.getDepartment())
                .buCode(user.getBuCode())
                .roles(roles)
                .status(user.getStatus())
                .lastLoginTime(user.getLastLoginTime())
                .lastLoginIp(user.getLastLoginIp())
                .build();
        
        log.debug("用户详情加载成功: ID={}", userId);
        return userDetails;
    }

    /**
     * 更新鐢ㄦ埛鏈€鍚庣櫥褰曚俊鎭?     */
    @Transactional
    public void updateLastLoginInfo(String username, String ipAddress) {
        try {
            SystemUserEntity user = systemUserService.getOne(
                    new LambdaQueryWrapper<SystemUserEntity>()
                            .eq(SystemUserEntity::getUsername, username)
            );
            
            if (user != null) {
                user.setLastLoginTime(LocalDateTime.now());
                user.setLastLoginIp(ipAddress);
                systemUserService.updateById(user);
                log.debug("更新鐢ㄦ埛鏈€鍚庣櫥褰曚俊鎭? {}, IP={}", username, ipAddress);
            }
        } catch (Exception e) {
            log.error("处理条件", username, ipAddress, e);
            // TODO: fix encoding comment
        }
    }

    /**
     * 检查用户名是否存在
     */
    @Transactional(readOnly = true)
    public boolean existsByUsername(String username) {
        return systemUserService.count(
                new LambdaQueryWrapper<SystemUserEntity>()
                        .eq(SystemUserEntity::getUsername, username)
        ) > 0;
    }

    /**
     * 妫€鏌ラ偖绠辨槸鍚﹀瓨鍦?     */
    @Transactional(readOnly = true)
    public boolean existsByEmail(String email) {
        return systemUserService.count(
                new LambdaQueryWrapper<SystemUserEntity>()
                        .eq(SystemUserEntity::getEmail, email)
        ) > 0;
    }


    public UserDetailsServiceImpl(SystemUserService systemUserService) {
        this.systemUserService = systemUserService;
    }
}