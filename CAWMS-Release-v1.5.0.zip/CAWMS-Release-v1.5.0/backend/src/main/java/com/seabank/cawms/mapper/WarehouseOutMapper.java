package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.WarehouseOutEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface WarehouseOutMapper extends BaseMapper<WarehouseOutEntity> {

    List<WarehouseOutEntity> selectByStatus(@Param("status") String status);

    IPage<WarehouseOutEntity> selectWarehouseOutPage(
            Page<WarehouseOutEntity> page,
            @Param("params") Map<String, Object> params);

    @Select("SELECT status, COUNT(*) as count FROM collateral_warehouse_out WHERE deleted = 0 GROUP BY status")
    List<Map<String, Object>> countByStatus();

    @Select("SELECT COUNT(*) FROM collateral_warehouse_out WHERE deleted = 0 AND DATE(created_at) = CURDATE()")
    Long countToday();

    @Select("SELECT SUM(out_amount) FROM collateral_warehouse_out WHERE deleted = 0 AND status = 'COMPLETED'")
    java.math.BigDecimal sumTotalReleaseAmount();

    @Select("SELECT DISTINCT w.* FROM collateral_warehouse_out w " +
            "JOIN warehouse_out_approval a ON w.id = a.wh_out_id " +
            "WHERE w.deleted = 0 AND a.status = 'PENDING' " +
            "AND a.approver_role = #{approverRole} " +
            "AND NOT EXISTS (SELECT 1 FROM warehouse_out_approval a2 WHERE a2.wh_out_id = w.id AND a2.approver_user = #{approverUser} AND a2.status = 'APPROVED') " +
            "ORDER BY w.created_at DESC")
    List<WarehouseOutEntity> selectPendingByApproverRole(@Param("approverRole") String approverRole, @Param("approverUser") String approverUser);

    @Select("SELECT DISTINCT w.* FROM collateral_warehouse_out w " +
            "JOIN warehouse_out_approval a ON w.id = a.wh_out_id " +
            "WHERE w.deleted = 0 AND a.status = 'PENDING' " +
            "AND NOT EXISTS (SELECT 1 FROM warehouse_out_approval a2 WHERE a2.wh_out_id = w.id AND a2.approver_user = #{approverUser} AND a2.status = 'APPROVED') " +
            "ORDER BY w.created_at DESC")
    List<WarehouseOutEntity> selectAllPending(@Param("approverUser") String approverUser);

    @Select("SELECT DISTINCT w.* FROM collateral_warehouse_out w " +
            "JOIN warehouse_out_approval a ON w.id = a.wh_out_id " +
            "WHERE w.deleted = 0 AND w.status = 'SUBMITTED' " +
            "AND a.status = 'APPROVED' AND a.approver_user = #{approverUser} " +
            "ORDER BY w.created_at DESC")
    List<WarehouseOutEntity> selectMyApprovedOngoing(@Param("approverUser") String approverUser);

    @Select("SELECT DISTINCT w.* FROM collateral_warehouse_out w " +
            "JOIN warehouse_out_approval a ON w.id = a.wh_out_id " +
            "WHERE w.deleted = 0 AND w.status IN ('APPROVED', 'COMPLETED', 'REJECTED') " +
            "AND a.status = 'APPROVED' AND a.approver_user = #{approverUser} " +
            "ORDER BY w.created_at DESC")
    List<WarehouseOutEntity> selectMyHistory(@Param("approverUser") String approverUser);
}
