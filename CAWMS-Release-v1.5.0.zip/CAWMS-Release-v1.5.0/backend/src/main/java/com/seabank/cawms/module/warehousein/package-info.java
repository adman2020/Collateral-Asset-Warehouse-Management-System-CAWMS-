/**
 * Warehouse-In module package
 * Contains all components for collateral asset warehouse-in management
 */
package com.seabank.cawms.module.warehousein;
