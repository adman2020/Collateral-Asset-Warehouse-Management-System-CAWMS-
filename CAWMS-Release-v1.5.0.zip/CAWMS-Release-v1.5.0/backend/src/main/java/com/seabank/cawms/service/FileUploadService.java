package com.seabank.cawms.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * 文件上传服务接口
 * 负责处理文件的上传、存储、下载和管理
 */
public interface FileUploadService {
    
    /**
     * 涓婁紶鍗曚釜鏂囦欢
     * @param file 涓婁紶鐨勬枃浠?     * @param uploader 涓婁紶鑰?     * @param fileType 文件类型
     * @param description 文件描述
     * @return 文件上传结果
     */
    FileUploadResult uploadFile(MultipartFile file, String uploader, String fileType, String description);
    
    /**
     * 鎵归噺涓婁紶鏂囦欢
     * @param files 文件列表
     * @param uploader 涓婁紶鑰?     * @param fileType 文件类型
     * @param descriptions 文件描述列表
     * @return 批量上传结果
     */
    BatchUploadResult uploadFiles(List<MultipartFile> files, String uploader, 
                                  String fileType, List<String> descriptions);
    
    /**
     * 涓嬭浇鏂囦欢
     * @param fileId 鏂囦欢ID
     * @return 文件下载信息
     */
    FileDownloadInfo downloadFile(Long fileId);
    
    /**
     * 根据文件哈希查找文件
     * @param fileHash 文件MD5哈希
     * @return 文件信息鍒楄〃锛堝彲鑳芥湁澶氫唤鐩稿悓鏂囦欢锛?     */
    List<FileInfo> findFilesByHash(String fileHash);
    
    /**
     * 删除鏂囦欢锛堥€昏緫删除锛?     * @param fileId 鏂囦欢ID
     * @param deletedBy 删除鑰?     * @return 删除缁撴灉
     */
    boolean deleteFile(Long fileId, String deletedBy);
    
    /**
     * 永久删除文件（物理删除）
     * @param fileId 鏂囦欢ID
     * @return 删除缁撴灉
     */
    boolean permanentlyDeleteFile(Long fileId);
    
    /**
     * 鑾峰彇文件信息
     * @param fileId 鏂囦欢ID
     * @return 文件信息
     */
    FileInfo getFileInfo(Long fileId);
    
    /**
     * 更新文件信息
     * @param fileId 鏂囦欢ID
     * @param description 鏂版弿杩?     * @param updatedBy 更新鑰?     * @return 更新结果
     */
    boolean updateFileInfo(Long fileId, String description, String updatedBy);
    
    /**
     * 楠岃瘉文件类型
     * @param file 鏂囦欢
     * @param allowedTypes 鍏佽鐨勬枃浠剁被鍨?     * @return 验证结果
     */
    FileValidationResult validateFile(MultipartFile file, List<String> allowedTypes);
    
    /**
     * 楠岃瘉鏂囦欢澶у皬
     * @param file 鏂囦欢
     * @param maxSize 鏈€澶ф枃浠跺ぇ灏忥紙瀛楄妭锛?     * @return 验证结果
     */
    FileValidationResult validateFileSize(MultipartFile file, long maxSize);
    
    /**
     * 鑾峰彇文件存储统计信息
     * @return 瀛樺偍缁熻
     */
    StorageStatistics getStorageStatistics();
    
    /**
     * 清理过期临时文件
     * @return 娓呯悊缁撴灉
     */
    CleanupResult cleanupExpiredTempFiles();
    
    /**
     * 文件上传结果
     */
    class FileUploadResult {
        private boolean success;
        private Long fileId;
        private String fileName;
        private String filePath;
        private String fileHash;
        private Long fileSize;
        private String message;
        private Map<String, Object> metadata;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public Long getFileId() {
            return fileId;
        }
        
        public void setFileId(Long fileId) {
            this.fileId = fileId;
        }
        
        public String getFileName() {
            return fileName;
        }
        
        public void setFileName(String fileName) {
            this.fileName = fileName;
        }
        
        public String getFilePath() {
            return filePath;
        }
        
        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }
        
        public String getFileHash() {
            return fileHash;
        }
        
        public void setFileHash(String fileHash) {
            this.fileHash = fileHash;
        }
        
        public Long getFileSize() {
            return fileSize;
        }
        
        public void setFileSize(Long fileSize) {
            this.fileSize = fileSize;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public Map<String, Object> getMetadata() {
            return metadata;
        }
        
        public void setMetadata(Map<String, Object> metadata) {
            this.metadata = metadata;
        }
    }
    
    /**
     * 批量上传结果
     */
    class BatchUploadResult {
        private boolean success;
        private int totalFiles;
        private int successfulFiles;
        private int failedFiles;
        private List<FileUploadResult> results;
        private String message;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public int getTotalFiles() {
            return totalFiles;
        }
        
        public void setTotalFiles(int totalFiles) {
            this.totalFiles = totalFiles;
        }
        
        public int getSuccessfulFiles() {
            return successfulFiles;
        }
        
        public void setSuccessfulFiles(int successfulFiles) {
            this.successfulFiles = successfulFiles;
        }
        
        public int getFailedFiles() {
            return failedFiles;
        }
        
        public void setFailedFiles(int failedFiles) {
            this.failedFiles = failedFiles;
        }
        
        public List<FileUploadResult> getResults() {
            return results;
        }
        
        public void setResults(List<FileUploadResult> results) {
            this.results = results;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
    }
    
    /**
     * 文件下载信息
     */
    class FileDownloadInfo {
        private String fileName;
        private String filePath;
        private String contentType;
        private Long fileSize;
        private String downloadUrl;
        private boolean requiresAuthentication;
        private Long expiresAt; // TODO: encoding issue
        // Getters and Setters
        public String getFileName() {
            return fileName;
        }
        
        public void setFileName(String fileName) {
            this.fileName = fileName;
        }
        
        public String getFilePath() {
            return filePath;
        }
        
        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }
        
        public String getContentType() {
            return contentType;
        }
        
        public void setContentType(String contentType) {
            this.contentType = contentType;
        }
        
        public Long getFileSize() {
            return fileSize;
        }
        
        public void setFileSize(Long fileSize) {
            this.fileSize = fileSize;
        }
        
        public String getDownloadUrl() {
            return downloadUrl;
        }
        
        public void setDownloadUrl(String downloadUrl) {
            this.downloadUrl = downloadUrl;
        }
        
        public boolean isRequiresAuthentication() {
            return requiresAuthentication;
        }
        
        public void setRequiresAuthentication(boolean requiresAuthentication) {
            this.requiresAuthentication = requiresAuthentication;
        }
        
        public Long getExpiresAt() {
            return expiresAt;
        }
        
        public void setExpiresAt(Long expiresAt) {
            this.expiresAt = expiresAt;
        }
    }
    
    /**
     * 文件信息
     */
    class FileInfo {
        private Long fileId;
        private String fileName;
        private String fileType;
        private String filePath;
        private String fileHash;
        private Long fileSize;
        private String contentType;
        private String uploader;
        private Long uploadTime;
        private String description;
        private String status;
        private Integer downloadCount;
        private Long lastDownloadTime;
        private Map<String, Object> metadata;
        
        // Getters and Setters
        public Long getFileId() {
            return fileId;
        }
        
        public void setFileId(Long fileId) {
            this.fileId = fileId;
        }
        
        public String getFileName() {
            return fileName;
        }
        
        public void setFileName(String fileName) {
            this.fileName = fileName;
        }
        
        public String getFileType() {
            return fileType;
        }
        
        public void setFileType(String fileType) {
            this.fileType = fileType;
        }
        
        public String getFilePath() {
            return filePath;
        }
        
        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }
        
        public String getFileHash() {
            return fileHash;
        }
        
        public void setFileHash(String fileHash) {
            this.fileHash = fileHash;
        }
        
        public Long getFileSize() {
            return fileSize;
        }
        
        public void setFileSize(Long fileSize) {
            this.fileSize = fileSize;
        }
        
        public String getContentType() {
            return contentType;
        }
        
        public void setContentType(String contentType) {
            this.contentType = contentType;
        }
        
        public String getUploader() {
            return uploader;
        }
        
        public void setUploader(String uploader) {
            this.uploader = uploader;
        }
        
        public Long getUploadTime() {
            return uploadTime;
        }
        
        public void setUploadTime(Long uploadTime) {
            this.uploadTime = uploadTime;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public Integer getDownloadCount() {
            return downloadCount;
        }
        
        public void setDownloadCount(Integer downloadCount) {
            this.downloadCount = downloadCount;
        }
        
        public Long getLastDownloadTime() {
            return lastDownloadTime;
        }
        
        public void setLastDownloadTime(Long lastDownloadTime) {
            this.lastDownloadTime = lastDownloadTime;
        }
        
        public Map<String, Object> getMetadata() {
            return metadata;
        }
        
        public void setMetadata(Map<String, Object> metadata) {
            this.metadata = metadata;
        }
    }
    
    /**
     * 文件验证结果
     */
    class FileValidationResult {
        private boolean valid;
        private String message;
        private List<String> errors;
        private List<String> warnings;
        
        // Getters and Setters
        public boolean isValid() {
            return valid;
        }
        
        public void setValid(boolean valid) {
            this.valid = valid;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public List<String> getErrors() {
            return errors;
        }
        
        public void setErrors(List<String> errors) {
            this.errors = errors;
        }
        
        public List<String> getWarnings() {
            return warnings;
        }
        
        public void setWarnings(List<String> warnings) {
            this.warnings = warnings;
        }
    }
    
    /**
     * 瀛樺偍缁熻淇℃伅
     */
    class StorageStatistics {
        private Long totalFiles;
        private Long totalSize; // TODO: encoding issue
        private Long usedSpace; // TODO: encoding issue
        private Long availableSpace; // TODO: encoding issue
        private Map<String, Long> sizeByFileType;
        private Map<String, Long> countByFileType;
        private Map<String, Long> sizeByMonth;
        private Double averageFileSize;
        
        // Getters and Setters
        public Long getTotalFiles() {
            return totalFiles;
        }
        
        public void setTotalFiles(Long totalFiles) {
            this.totalFiles = totalFiles;
        }
        
        public Long getTotalSize() {
            return totalSize;
        }
        
        public void setTotalSize(Long totalSize) {
            this.totalSize = totalSize;
        }
        
        public Long getUsedSpace() {
            return usedSpace;
        }
        
        public void setUsedSpace(Long usedSpace) {
            this.usedSpace = usedSpace;
        }
        
        public Long getAvailableSpace() {
            return availableSpace;
        }
        
        public void setAvailableSpace(Long availableSpace) {
            this.availableSpace = availableSpace;
        }
        
        public Map<String, Long> getSizeByFileType() {
            return sizeByFileType;
        }
        
        public void setSizeByFileType(Map<String, Long> sizeByFileType) {
            this.sizeByFileType = sizeByFileType;
        }
        
        public Map<String, Long> getCountByFileType() {
            return countByFileType;
        }
        
        public void setCountByFileType(Map<String, Long> countByFileType) {
            this.countByFileType = countByFileType;
        }
        
        public Map<String, Long> getSizeByMonth() {
            return sizeByMonth;
        }
        
        public void setSizeByMonth(Map<String, Long> sizeByMonth) {
            this.sizeByMonth = sizeByMonth;
        }
        
        public Double getAverageFileSize() {
            return averageFileSize;
        }
        
        public void setAverageFileSize(Double averageFileSize) {
            this.averageFileSize = averageFileSize;
        }
    }
    
    /**
     * 娓呯悊缁撴灉
     */
    class CleanupResult {
        private boolean success;
        private int deletedFiles;
        private Long freedSpace; // TODO: encoding issue
        private String message;
        private List<String> deletedFileNames;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public int getDeletedFiles() {
            return deletedFiles;
        }
        
        public void setDeletedFiles(int deletedFiles) {
            this.deletedFiles = deletedFiles;
        }
        
        public Long getFreedSpace() {
            return freedSpace;
        }
        
        public void setFreedSpace(Long freedSpace) {
            this.freedSpace = freedSpace;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public List<String> getDeletedFileNames() {
            return deletedFileNames;
        }
        
        public void setDeletedFileNames(List<String> deletedFileNames) {
            this.deletedFileNames = deletedFileNames;
        }
    }
}