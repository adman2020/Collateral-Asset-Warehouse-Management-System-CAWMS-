package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.SystemUserEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 系统用户Mapper接口
 */
@Mapper
public interface SystemUserMapper extends BaseMapper<SystemUserEntity> {
    
}