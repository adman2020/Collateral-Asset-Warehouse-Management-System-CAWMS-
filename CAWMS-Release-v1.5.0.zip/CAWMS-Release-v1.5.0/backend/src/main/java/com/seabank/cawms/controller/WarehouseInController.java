package com.seabank.cawms.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.common.PageResult;
import com.seabank.cawms.entity.WarehouseInEntity;
import com.seabank.cawms.entity.WarehouseInFileEntity;
import com.seabank.cawms.service.FileUploadService;
import com.seabank.cawms.service.impl.WarehouseInServiceImpl;
import static com.seabank.cawms.service.impl.WarehouseInServiceImpl.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 鎶垫娂璧勪骇入库管理鎺у埗鍣? * 提供完整的REST API接口
 */
@Validated
@RestController
@RequestMapping("/api/warehouse-in")
@Tag(name = "WarehouseInController", description = "抵押资产入库管理API")
public class WarehouseInController {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WarehouseInController.class);

    private final WarehouseInServiceImpl warehouseInService;
    private final FileUploadService fileUploadService;
    
    @Autowired
    public WarehouseInController(WarehouseInServiceImpl warehouseInService,
                                 FileUploadService fileUploadService) {
        this.warehouseInService = warehouseInService;
        this.fileUploadService = fileUploadService;
    }
    
    // TODO: fix encoding comment
    
    @Operation(summary = "Create Draft")
    @PostMapping(value = "/draft", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public CommonResponse<Long> createDraft(
            @Valid @ModelAttribute CreateDraftRequest request,
            @RequestParam(value = "files", required = false) List<MultipartFile> files) {
        log.info("Creating draft with files: customer={}, type={}",
                request.getCustomerName(), request.getCollateralType());

        WarehouseInEntity entity = convertToEntity(request);
        List<WarehouseInFileEntity> fileEntities = processUploadedFiles(files, request.getUploader());
        Long id = warehouseInService.createDraft(entity, fileEntities);

        return CommonResponse.success(id, "草稿创建成功");
    }

    @Operation(summary = "Create Draft (JSON)")
    @PostMapping(value = "/draft", consumes = MediaType.APPLICATION_JSON_VALUE)
    public CommonResponse<Long> createDraftJson(
            @Valid @RequestBody CreateDraftRequest request) {
        log.info("Creating draft via JSON: customer={}, type={}",
                request.getCustomerName(), request.getCollateralType());

        WarehouseInEntity entity = convertToEntity(request);
        Long id = warehouseInService.createDraft(entity, List.of());

        return CommonResponse.success(id, "草稿创建成功");
    }
    
    @Operation(summary = "Submit Application")
    @PutMapping("/{id}/submit")
    public CommonResponse<Boolean> submitApplication(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank String submitter) {
        log.info("处理条件", id, submitter);
        
        boolean result = warehouseInService.submitApplication(id, submitter);
        
        return CommonResponse.success(result, "处理条件");
    }
    
    @Operation(summary = "Update Application")
    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public CommonResponse<Boolean> updateApplication(
            @PathVariable @NotNull Long id,
            @Valid @ModelAttribute UpdateApplicationRequest request,
            @RequestParam(value = "files", required = false) List<MultipartFile> files) {
        log.info("处理条件", id, request.getWhCode());
        
        // TODO: fix encoding comment
        WarehouseInEntity entity = convertToEntity(request);
        entity.setId(id);
        
        // TODO: fix encoding comment
        List<WarehouseInFileEntity> fileEntities = processUploadedFiles(files, request.getUpdater());
        
        boolean result = warehouseInService.updateApplication(entity, fileEntities);
        
        return CommonResponse.success(result, "处理条件");
    }
    
    @Operation(summary = "Delete Application")
    @DeleteMapping("/{id}")
    public CommonResponse<Boolean> deleteApplication(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank String deletedBy) {
        log.info("处理条件", id, deletedBy);
        
        boolean result = warehouseInService.deleteApplication(id, deletedBy);
        
        return CommonResponse.success(result, "处理条件");
    }
    
    @Operation(summary = "Get Detail By Id")
    @GetMapping("/{id}")
    public CommonResponse<WarehouseInDetail> getDetailById(@PathVariable @NotNull Long id) {
        log.debug("处理条件", id);
        
        WarehouseInDetail detail = warehouseInService.getDetailById(id);
        
        return CommonResponse.success(detail, "处理条件");
    }
    
    @Operation(summary = "Get Detail By Wh Code")
    @GetMapping("/by-wh-code/{whCode}")
    public CommonResponse<WarehouseInDetail> getDetailByWhCode(
            @PathVariable @NotBlank String whCode) {
        log.debug("处理条件", whCode);
        
        WarehouseInDetail detail = warehouseInService.getDetailByWhCode(whCode);
        
        return CommonResponse.success(detail, "处理条件");
    }
    
    @Operation(summary = "Query List")
    @GetMapping("/list")
    public CommonResponse<PageResult<WarehouseInEntity>> queryList(
            @Valid WarehouseInQueryParams params,
            @RequestParam(defaultValue = "1") @Min(1) Integer pageNum,
            @RequestParam(defaultValue = "10") @Min(1) Integer pageSize) {
        log.debug("处理条件", 
                params, pageNum, pageSize);
        
        Page<WarehouseInEntity> page = new Page<>(pageNum, pageSize);
        WarehouseInQuery query = convertToQuery(params);
        
        Page<WarehouseInEntity> resultPage = warehouseInService.queryList(query, page);
        
        PageResult<WarehouseInEntity> pageResult = PageResult.of(resultPage);
        
        return CommonResponse.success(pageResult, "处理条件");
    }
    
    // TODO: fix encoding comment
    
    @Operation(summary = "Approve Application")
    @PostMapping("/{id}/approve")
    public CommonResponse<ApprovalResult> approveApplication(
            @PathVariable @NotNull Long id,
            @RequestParam @NotNull Integer stepNumber,
            @Valid @RequestBody ApprovalRequest request) {
        log.info("处理条件", 
                id, stepNumber, request.getApproverUser());
        
        ApprovalResult result = warehouseInService.approveApplication(id, stepNumber, request);
        
        return CommonResponse.success(result, "审批成功");
    }
    
    @Operation(summary = "Reject Application")
    @PostMapping("/{id}/reject")
    public CommonResponse<RejectionResult> rejectApplication(
            @PathVariable @NotNull Long id,
            @RequestParam @NotNull Integer stepNumber,
            @Valid @RequestBody RejectionRequest request) {
        log.info("处理条件", 
                id, stepNumber, request.getApproverUser());
        
        RejectionResult result = warehouseInService.rejectApplication(id, stepNumber, request);
        
        return CommonResponse.success(result, "拒绝成功");
    }
    
    @Operation(summary = "Return Application")
    @PostMapping("/{id}/return")
    public CommonResponse<ReturnResult> returnApplication(
            @PathVariable @NotNull Long id,
            @RequestParam @NotNull Integer stepNumber,
            @Valid @RequestBody ReturnRequest request) {
        log.info("閫€鍥炲叆搴撶敵璇? id={}, stepNumber={}, approver={}, returnToStep={}", 
                id, stepNumber, request.getApproverUser(), request.getReturnToStep());
        
        ReturnResult result = warehouseInService.returnApplication(id, stepNumber, request);
        
        return CommonResponse.success(result, "处理条件");
    }
    
    @Operation(summary = "获取待办审批列表")
    @GetMapping("/pending-approvals")
    public CommonResponse<PageResult<PendingApproval>> getPendingApprovals(
            @RequestParam(required = false) String approverRole,
            @RequestParam(required = false) String approverUser,
            @RequestParam(defaultValue = "1") @Min(1) Integer pageNum,
            @RequestParam(defaultValue = "10") @Min(1) Integer pageSize) {
        log.debug("获取待办审批列表: approverRole={}, approverUser={}, pageNum={}, pageSize={}", 
                approverRole, approverUser, pageNum, pageSize);
        
        if (approverRole == null && approverUser == null) {
            return CommonResponse.error("处理条件");
        }
        
        Page<PendingApproval> page = new Page<>(pageNum, pageSize);
        Page<PendingApproval> resultPage = warehouseInService.getPendingApprovals(approverRole, approverUser, page);
        
        PageResult<PendingApproval> pageResult = PageResult.of(resultPage);
        
        return CommonResponse.success(pageResult, "处理条件");
    }
    
    @Operation(summary = "获取我的审批列表")
    @GetMapping("/my-approvals")
    public CommonResponse<PageResult<WarehouseInEntity>> getMyApprovals(
            @RequestParam(required = false) String approverUser,
            @RequestParam(required = false) String approverRole,
            @RequestParam String type,
            @RequestParam(defaultValue = "1") @Min(1) Integer pageNum,
            @RequestParam(defaultValue = "10") @Min(1) Integer pageSize) {
        log.debug("获取我的审批列表: type={}, approverUser={}, approverRole={}, pageNum={}, pageSize={}", 
                type, approverUser, approverRole, pageNum, pageSize);
        
        String role = (approverRole == null || approverRole.isBlank()) ? "ALL" : approverRole;
        Page<WarehouseInEntity> page = new Page<>(pageNum, pageSize);
        Page<WarehouseInEntity> resultPage = warehouseInService.getMyApprovals(approverUser, role, type, page);
        
        PageResult<WarehouseInEntity> pageResult = PageResult.of(resultPage);
        return CommonResponse.success(pageResult, "查询成功");
    }
    
    // TODO: fix encoding comment
    
    @Operation(summary = "Get Statistics")
    @GetMapping("/statistics")
    public CommonResponse<WarehouseInStatistics> getStatistics(
            @Valid StatisticsQueryParams params) {
        log.debug("处理条件", params);
        
        StatisticsQuery query = convertToStatisticsQuery(params);
        WarehouseInStatistics statistics = warehouseInService.getStatistics(query);
        
        return CommonResponse.success(statistics, "处理条件");
    }
    
    @Operation(summary = "Generate Slip")
    @PostMapping("/{id}/generate-slip")
    public CommonResponse<Map<String, Object>> generateSlip(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank String generator) {
        log.info("鐢熸垚鍏ュ簱鍗? id={}, generator={}", id, generator);
        
        Map<String, Object> slip = warehouseInService.generateSlip(id, generator);
        
        return CommonResponse.success(slip, "处理条件");
    }
    
    @Operation(summary = "导出入库数据")
    @PostMapping("/export")
    public CommonResponse<ExportData> exportData(@Valid @RequestBody ExportQueryParams params) {
        log.info("导出入库数据: params={}", params);
        
        ExportQuery query = convertToExportQuery(params);
        ExportData exportData = warehouseInService.exportData(query);
        
        return CommonResponse.success(exportData, "处理条件");
    }
    
    @Operation(summary = "批量导入入库数据")
    @PostMapping("/import")
    public CommonResponse<ImportResult> importData(
            @Valid @RequestBody List<WarehouseInEntity> importData,
            @RequestParam @NotBlank String importer) {
        log.info("批量导入入库数据: recordCount={}, importer={}", importData.size(), importer);
        
        ImportResult result = warehouseInService.importData(importData, importer);
        
        return CommonResponse.success(result, "导入完成");
    }
    
    @Operation(summary = "Get History")
    @GetMapping("/{id}/history")
    public CommonResponse<List<HistoryRecord>> getHistory(@PathVariable @NotNull Long id) {
        log.debug("处理条件", id);
        
        List<HistoryRecord> history = warehouseInService.getHistory(id);
        
        return CommonResponse.success(history, "处理条件");
    }
    
    @Operation(summary = "Validate Application")
    @PostMapping("/validate")
    public CommonResponse<ValidationResult> validateApplication(
            @Valid @RequestBody WarehouseInEntity entity) {
        log.debug("处理条件", 
                entity.getWhCode(), entity.getCustomerName());
        
        ValidationResult result = warehouseInService.validateApplication(entity);
        
        return CommonResponse.success(result, "验证完成");
    }
    
    // TODO: fix encoding comment
    
    private WarehouseInEntity convertToEntity(CreateDraftRequest request) {
        WarehouseInEntity entity = new WarehouseInEntity();
        entity.setBuCode(request.getBuCode());
        entity.setBuName(request.getBuName());
        entity.setCustomerId(request.getCustomerId());
        entity.setCustomerName(request.getCustomerName());
        entity.setCollateralType(request.getCollateralType());
        entity.setCollateralValue(request.getCollateralValue());
        entity.setCreditAgreementNo(request.getCreditAgreementNo());
        entity.setIntakeType(request.getIntakeType());
        entity.setRemarks(request.getRemarks());
        entity.setZoneId(request.getZoneId());
        entity.setWarehouseId(request.getWarehouseId());
        entity.setCreatedBy(request.getUploader());
        entity.setCreatedAt(LocalDateTime.now());
        return entity;
    }
    
    private WarehouseInEntity convertToEntity(UpdateApplicationRequest request) {
        WarehouseInEntity entity = new WarehouseInEntity();
        entity.setWhCode(request.getWhCode());
        entity.setBuCode(request.getBuCode());
        entity.setBuName(request.getBuName());
        entity.setCustomerId(request.getCustomerId());
        entity.setCustomerName(request.getCustomerName());
        entity.setCollateralType(request.getCollateralType());
        entity.setCollateralValue(request.getCollateralValue());
        entity.setCreditAgreementNo(request.getCreditAgreementNo());
        entity.setIntakeType(request.getIntakeType());
        entity.setRemarks(request.getRemarks());
        entity.setZoneId(request.getZoneId());
        entity.setWarehouseId(request.getWarehouseId());
        entity.setUpdatedBy(request.getUpdater());
        entity.setUpdatedAt(LocalDateTime.now());
        return entity;
    }
    
    private WarehouseInQuery convertToQuery(WarehouseInQueryParams params) {
        WarehouseInQuery query = new WarehouseInQuery();
        query.setBuCode(params.getBuCode());
        query.setCustomerId(params.getCustomerId());
        query.setCustomerName(params.getCustomerName());
        query.setCollateralType(params.getCollateralType());
        query.setIntakeType(params.getIntakeType());
        query.setStatus(params.getStatus());
        query.setCurrentStep(params.getCurrentStep());
        query.setStartTime(params.getStartTime());
        query.setEndTime(params.getEndTime());
        query.setKeyword(params.getKeyword());
        return query;
    }
    
    private StatisticsQuery convertToStatisticsQuery(StatisticsQueryParams params) {
        StatisticsQuery query = new StatisticsQuery();
        query.setStartTime(params.getStartTime());
        query.setEndTime(params.getEndTime());
        query.setBuCode(params.getBuCode());
        query.setCollateralType(params.getCollateralType());
        query.setIntakeType(params.getIntakeType());
        return query;
    }
    
    private ExportQuery convertToExportQuery(ExportQueryParams params) {
        ExportQuery query = new ExportQuery();
        query.setFilter(convertToQuery(params.getFilter()));
        query.setColumns(params.getColumns());
        query.setExportFormat(params.getExportFormat());
        query.setIncludeFiles(params.getIncludeFiles());
        query.setIncludeApprovals(params.getIncludeApprovals());
        return query;
    }
    
    private List<WarehouseInFileEntity> processUploadedFiles(List<MultipartFile> files, String uploader) {
        if (files == null || files.isEmpty()) {
            return List.of();
        }
        log.info("Processing uploaded files: fileCount={}, uploader={}", files.size(), uploader);
        
        FileUploadService.BatchUploadResult batchResult = fileUploadService.uploadFiles(
                files, uploader, "WAREHOUSE_IN", null);
        
        List<WarehouseInFileEntity> result = new java.util.ArrayList<>();
        List<String> failedMessages = new java.util.ArrayList<>();
        
        for (FileUploadService.FileUploadResult uploadResult : batchResult.getResults()) {
            if (uploadResult.isSuccess()) {
                WarehouseInFileEntity entity = new WarehouseInFileEntity();
                entity.setId(uploadResult.getFileId());
                entity.setFileName(uploadResult.getFileName());
                entity.setFilePath(uploadResult.getFilePath());
                entity.setFileSize(uploadResult.getFileSize());
                entity.setFileHash(uploadResult.getFileHash());
                entity.setUploadUser(uploader);
                entity.setUploadTime(java.time.LocalDateTime.now());
                entity.setStatus("ACTIVE");
                result.add(entity);
            } else {
                failedMessages.add(uploadResult.getFileName() + ": " + uploadResult.getMessage());
                log.error("File upload failed: fileName={}, message={}", 
                        uploadResult.getFileName(), uploadResult.getMessage());
            }
        }
        
        if (!failedMessages.isEmpty()) {
            throw new IllegalStateException("附件上传失败: " + String.join("; ", failedMessages));
        }
        
        return result;
    }
    
    // TODO: fix encoding comment
    
    @Operation(summary = "Download Attachment")
    @GetMapping("/files/{fileId}")
    public org.springframework.http.ResponseEntity<org.springframework.core.io.Resource> downloadFile(
            @PathVariable @NotNull Long fileId) {
        log.info("Downloading file: fileId={}", fileId);
        
        FileUploadService.FileDownloadInfo downloadInfo = fileUploadService.downloadFile(fileId);
        java.nio.file.Path filePath = java.nio.file.Paths.get("./uploads").resolve(downloadInfo.getFilePath());
        org.springframework.core.io.Resource resource = new org.springframework.core.io.PathResource(filePath);
        
        return org.springframework.http.ResponseEntity.ok()
                .contentType(org.springframework.http.MediaType.parseMediaType(downloadInfo.getContentType()))
                .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION, 
                        "attachment; filename=\"" + downloadInfo.getFileName() + "\"")
                .body(resource);
    }
    
    @Validated
    static class CreateDraftRequest {
        @NotBlank(message = "业务部门编码不能为空")
        private String buCode;
        
        private String buName;
        
        private String customerId;
        
        @NotBlank(message = "客户名称不能为空")
        private String customerName;
        
        @NotBlank(message = "处理条件")
        private String collateralType;
        
        @NotNull(message = "处理条件")
        private BigDecimal collateralValue;
        
        private String creditAgreementNo;
        
        @NotBlank(message = "入库类型不能为空")
        private String intakeType;
        
        private String remarks;

        private Long zoneId;

        private Long warehouseId;
        
        @NotBlank(message = "处理条件")
        private String uploader;
        
        // Getters and Setters
        public String getBuCode() {
            return buCode;
        }
        
        public void setBuCode(String buCode) {
            this.buCode = buCode;
        }
        
        public String getBuName() {
            return buName;
        }
        
        public void setBuName(String buName) {
            this.buName = buName;
        }
        
        public String getCustomerId() {
            return customerId;
        }
        
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }
        
        public String getCustomerName() {
            return customerName;
        }
        
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }
        
        public String getCollateralType() {
            return collateralType;
        }
        
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }
        
        public BigDecimal getCollateralValue() {
            return collateralValue;
        }
        
        public void setCollateralValue(BigDecimal collateralValue) {
            this.collateralValue = collateralValue;
        }
        
        public String getCreditAgreementNo() {
            return creditAgreementNo;
        }
        
        public void setCreditAgreementNo(String creditAgreementNo) {
            this.creditAgreementNo = creditAgreementNo;
        }
        
        public String getIntakeType() {
            return intakeType;
        }
        
        public void setIntakeType(String intakeType) {
            this.intakeType = intakeType;
        }
        
        public String getRemarks() {
            return remarks;
        }
        
        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }
        
        public String getUploader() {
            return uploader;
        }

        public void setUploader(String uploader) {
            this.uploader = uploader;
        }

        public Long getZoneId() {
            return zoneId;
        }

        public void setZoneId(Long zoneId) {
            this.zoneId = zoneId;
        }

        public Long getWarehouseId() {
            return warehouseId;
        }

        public void setWarehouseId(Long warehouseId) {
            this.warehouseId = warehouseId;
        }
    }
    
    @Validated
    static class UpdateApplicationRequest {
        private String whCode;
        
        @NotBlank(message = "业务部门编码不能为空")
        private String buCode;
        
        private String buName;
        
        private String customerId;
        
        @NotBlank(message = "客户名称不能为空")
        private String customerName;
        
        @NotBlank(message = "处理条件")
        private String collateralType;
        
        @NotNull(message = "处理条件")
        private BigDecimal collateralValue;
        
        private String creditAgreementNo;
        
        @NotBlank(message = "入库类型不能为空")
        private String intakeType;
        
        private String remarks;

        private Long zoneId;

        private Long warehouseId;
        
        @NotBlank(message = "处理条件")
        private String updater;
        
        // Getters and Setters
        public String getWhCode() {
            return whCode;
        }
        
        public void setWhCode(String whCode) {
            this.whCode = whCode;
        }
        
        public String getBuCode() {
            return buCode;
        }
        
        public void setBuCode(String buCode) {
            this.buCode = buCode;
        }
        
        public String getBuName() {
            return buName;
        }
        
        public void setBuName(String buName) {
            this.buName = buName;
        }
        
        public String getCustomerId() {
            return customerId;
        }
        
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }
        
        public String getCustomerName() {
            return customerName;
        }
        
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }
        
        public String getCollateralType() {
            return collateralType;
        }
        
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }
        
        public BigDecimal getCollateralValue() {
            return collateralValue;
        }
        
        public void setCollateralValue(BigDecimal collateralValue) {
            this.collateralValue = collateralValue;
        }
        
        public String getCreditAgreementNo() {
            return creditAgreementNo;
        }
        
        public void setCreditAgreementNo(String creditAgreementNo) {
            this.creditAgreementNo = creditAgreementNo;
        }
        
        public String getIntakeType() {
            return intakeType;
        }
        
        public void setIntakeType(String intakeType) {
            this.intakeType = intakeType;
        }
        
        public String getRemarks() {
            return remarks;
        }
        
        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }
        
        public String getUpdater() {
            return updater;
        }

        public void setUpdater(String updater) {
            this.updater = updater;
        }

        public Long getZoneId() {
            return zoneId;
        }

        public void setZoneId(Long zoneId) {
            this.zoneId = zoneId;
        }

        public Long getWarehouseId() {
            return warehouseId;
        }

        public void setWarehouseId(Long warehouseId) {
            this.warehouseId = warehouseId;
        }
    }
    
    @Validated
    static class WarehouseInQueryParams {
        private String buCode;
        private String customerId;
        private String customerName;
        private String collateralType;
        private String intakeType;
        private String status;
        private Integer currentStep;
        
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime startTime;
        
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime endTime;
        
        private String keyword;
        
        // Getters and Setters
        public String getBuCode() {
            return buCode;
        }
        
        public void setBuCode(String buCode) {
            this.buCode = buCode;
        }
        
        public String getCustomerId() {
            return customerId;
        }
        
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }
        
        public String getCustomerName() {
            return customerName;
        }
        
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }
        
        public String getCollateralType() {
            return collateralType;
        }
        
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }
        
        public String getIntakeType() {
            return intakeType;
        }
        
        public void setIntakeType(String intakeType) {
            this.intakeType = intakeType;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public Integer getCurrentStep() {
            return currentStep;
        }
        
        public void setCurrentStep(Integer currentStep) {
            this.currentStep = currentStep;
        }
        
        public LocalDateTime getStartTime() {
            return startTime;
        }
        
        public void setStartTime(LocalDateTime startTime) {
            this.startTime = startTime;
        }
        
        public LocalDateTime getEndTime() {
            return endTime;
        }
        
        public void setEndTime(LocalDateTime endTime) {
            this.endTime = endTime;
        }
        
        public String getKeyword() {
            return keyword;
        }
        
        public void setKeyword(String keyword) {
            this.keyword = keyword;
        }
    }
    
    @Validated
    static class StatisticsQueryParams {
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime startTime;
        
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime endTime;
        
        private String buCode;
        private String collateralType;
        private String intakeType;
        
        // Getters and Setters
        public LocalDateTime getStartTime() {
            return startTime;
        }
        
        public void setStartTime(LocalDateTime startTime) {
            this.startTime = startTime;
        }
        
        public LocalDateTime getEndTime() {
            return endTime;
        }
        
        public void setEndTime(LocalDateTime endTime) {
            this.endTime = endTime;
        }
        
        public String getBuCode() {
            return buCode;
        }
        
        public void setBuCode(String buCode) {
            this.buCode = buCode;
        }
        
        public String getCollateralType() {
            return collateralType;
        }
        
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }
        
        public String getIntakeType() {
            return intakeType;
        }
        
        public void setIntakeType(String intakeType) {
            this.intakeType = intakeType;
        }
    }
    
    @Validated
    static class ExportQueryParams {
        private WarehouseInQueryParams filter;
        private List<String> columns;
        private String exportFormat;
        private Boolean includeFiles;
        private Boolean includeApprovals;
        
        // Getters and Setters
        public WarehouseInQueryParams getFilter() {
            return filter;
        }
        
        public void setFilter(WarehouseInQueryParams filter) {
            this.filter = filter;
        }
        
        public List<String> getColumns() {
            return columns;
        }
        
        public void setColumns(List<String> columns) {
            this.columns = columns;
        }
        
        public String getExportFormat() {
            return exportFormat;
        }
        
        public void setExportFormat(String exportFormat) {
            this.exportFormat = exportFormat;
        }
        
        public Boolean getIncludeFiles() {
            return includeFiles;
        }
        
        public void setIncludeFiles(Boolean includeFiles) {
            this.includeFiles = includeFiles;
        }
        
        public Boolean getIncludeApprovals() {
            return includeApprovals;
        }
        
        public void setIncludeApprovals(Boolean includeApprovals) {
            this.includeApprovals = includeApprovals;
        }
    }
}
