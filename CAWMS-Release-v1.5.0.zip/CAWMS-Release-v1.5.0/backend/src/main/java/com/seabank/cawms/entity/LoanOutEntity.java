package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@TableName("collateral_loan_out")
public class LoanOutEntity extends BaseEntity {
    
        private Long whInId;
    
        private String loanPurpose;
    
    
    private Integer loanDuration;
    
        private LocalDate expectedReturnDate;
    
        private LocalDate actualReturnDate;
    
    
    private String status;
    
        private String t24SyncStatus;
    
        private LocalDateTime t24SyncTime;
    
        @TableField(exist = false)
    private String extData;
    
    
    @TableField(exist = false)
    private WarehouseInEntity warehouseIn;
    
    
    @TableField(exist = false)
    private BigDecimal loanValue;
    
        @TableField(exist = false)
    private String customerName;
    
    
    @TableField(exist = false)
    private String collateralType;
    
    
    @TableField(exist = false)
    private Boolean overdue;
    
    
    @TableField(exist = false)
    private Integer remainingDays;


    public Long getWhInId() {
        return whInId;
    }
    public void setWhInId(Long whInId) {
        this.whInId = whInId;
    }

    public String getLoanPurpose() {
        return loanPurpose;
    }
    public void setLoanPurpose(String loanPurpose) {
        this.loanPurpose = loanPurpose;
    }

    public Integer getLoanDuration() {
        return loanDuration;
    }
    public void setLoanDuration(Integer loanDuration) {
        this.loanDuration = loanDuration;
    }

    public LocalDate getExpectedReturnDate() {
        return expectedReturnDate;
    }
    public void setExpectedReturnDate(LocalDate expectedReturnDate) {
        this.expectedReturnDate = expectedReturnDate;
    }

    public LocalDate getActualReturnDate() {
        return actualReturnDate;
    }
    public void setActualReturnDate(LocalDate actualReturnDate) {
        this.actualReturnDate = actualReturnDate;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getT24SyncStatus() {
        return t24SyncStatus;
    }
    public void setT24SyncStatus(String t24SyncStatus) {
        this.t24SyncStatus = t24SyncStatus;
    }

    public LocalDateTime getT24SyncTime() {
        return t24SyncTime;
    }
    public void setT24SyncTime(LocalDateTime t24SyncTime) {
        this.t24SyncTime = t24SyncTime;
    }

    public String getExtData() {
        return extData;
    }
    public void setExtData(String extData) {
        this.extData = extData;
    }

    public WarehouseInEntity getWarehouseIn() {
        return warehouseIn;
    }
    public void setWarehouseIn(WarehouseInEntity warehouseIn) {
        this.warehouseIn = warehouseIn;
    }

    public BigDecimal getLoanValue() {
        return loanValue;
    }
    public void setLoanValue(BigDecimal loanValue) {
        this.loanValue = loanValue;
    }

    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCollateralType() {
        return collateralType;
    }
    public void setCollateralType(String collateralType) {
        this.collateralType = collateralType;
    }

    public Boolean getOverdue() {
        return overdue;
    }
    public void setOverdue(Boolean overdue) {
        this.overdue = overdue;
    }

    public Integer getRemainingDays() {
        return remainingDays;
    }
    public void setRemainingDays(Integer remainingDays) {
        this.remainingDays = remainingDays;
    }
}