package com.seabank.cawms.service;

/**
 * 浠撳簱缂栫爜鐢熸垚鍣ㄦ帴鍙? */

public interface WarehouseCodeGenerator {
    
    /**
     * 鐢熸垚浠撳簱缂栫爜
     * @param prefix 缂栫爜鍓嶇紑
     * @param dateStr 鏃ユ湡瀛楃涓?     * @return 鐢熸垚鐨勪粨搴撶紪鐮?     */

    String generateWarehouseCode(String prefix, String dateStr);
}