package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.seabank.cawms.entity.OverdueAlertConfigEntity;
import com.seabank.cawms.entity.OverdueAlertLogEntity;
import com.seabank.cawms.mapper.OverdueAlertConfigMapper;
import com.seabank.cawms.mapper.OverdueAlertLogMapper;
import com.seabank.cawms.service.OverdueAlertService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 閫炬湡棰勮閫氱煡鏈嶅姟瀹炵幇绫? * 鏀寔閭欢銆佺煭淇°€佺郴缁熼€氱煡绛夊绉嶆笭閬? */
@Service
public class OverdueAlertServiceImpl implements OverdueAlertService {
    private static final Logger log = LoggerFactory.getLogger(OverdueAlertServiceImpl.class);

    private final OverdueAlertLogMapper overdueAlertLogMapper;
    private final OverdueAlertConfigMapper overdueAlertConfigMapper;
    private final ObjectMapper objectMapper;
    
    @Value("${overdue.alert.email.enabled:false}")
    private Boolean emailEnabled;
    
    @Value("${overdue.alert.sms.enabled:false}")
    private Boolean smsEnabled;
    
    @Value("${overdue.alert.system-notification.enabled:true}")
    private Boolean systemNotificationEnabled;
    
    @Value("${overdue.alert.default-recipients:warehouse_manager@seabank.com,risk_officer@seabank.com}")
    private String defaultRecipients;
    
    @Value("${overdue.alert.max-retry-count:3}")
    private Integer maxRetryCount;
    
    @Value("${overdue.alert.batch-size:50}")
    private Integer batchSize;
    
    @Autowired
    public OverdueAlertServiceImpl(
            OverdueAlertLogMapper overdueAlertLogMapper,
            OverdueAlertConfigMapper overdueAlertConfigMapper,
            ObjectMapper objectMapper) {
        this.overdueAlertLogMapper = overdueAlertLogMapper;
        this.overdueAlertConfigMapper = overdueAlertConfigMapper;
        this.objectMapper = objectMapper;
    }
    
    /**
     * 瀹氭椂鍙戦€佷换鍔?- 姣?0鍒嗛挓鎵ц涓€娆?     */
    @Scheduled(cron = "${overdue.alert.send.cron:0 */30 * * * ?}")
    @Transactional(rollbackFor = Exception.class)
    public void scheduledSendAlerts() {
        log.info("处理条件");
        
        try {
            // TODO: fix encoding comment
            OverdueAlertConfigEntity config = getAlertConfig();
            if (config == null || !config.getEnabled()) {
                log.info("处理条件");
                return;
            }
            
            // TODO: fix encoding comment
            SendStatistics statistics = sendPendingAlerts();
            
            log.info("处理条件", 
                    statistics.getPendingAlerts(), 
                    statistics.getSentAlerts(), 
                    statistics.getFailedAlerts());
            
        } catch (Exception e) {
            log.error("处理条件", e);
        }
    }
    
    /**
     * 瀹氭椂閲嶈瘯浠诲姟 - 姣忓皬鏃舵墽琛屼竴娆?     */
    @Scheduled(cron = "${overdue.alert.retry.cron:0 0 * * * ?}")
    @Transactional(rollbackFor = Exception.class)
    public void scheduledRetryFailedAlerts() {
        log.info("处理条件");
        
        try {
            OverdueAlertConfigEntity config = getAlertConfig();
            if (config == null || !config.getEnabled()) {
                log.info("处理条件");
                return;
            }
            
            // TODO: fix encoding comment
            RetryResult result = retryFailedAlerts(maxRetryCount);
            
            log.info("瀹氭椂閲嶈瘯浠诲姟瀹屾垚: 閲嶈瘯鎬绘暟={}, 鎴愬姛={}, 澶辫触={}", 
                    result.getTotalRetried(), 
                    result.getRetrySuccessCount(), 
                    result.getRetryFailCount());
            
        } catch (Exception e) {
            log.error("处理条件", e);
        }
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public SendResult sendAlert(OverdueAlertLogEntity alertLog, OverdueAlertConfigEntity config) {
        log.debug("处理条件", alertLog.getId(), alertLog.getAlertType());
        
        SendResult result = new SendResult();
        result.setAlertLogId(alertLog.getId());
        result.setAlertType(alertLog.getAlertType());
        
        long startTime = System.currentTimeMillis();
        
        try {
            // TODO: fix encoding comment
            String sendMethod = determineSendMethod(alertLog, config);
            result.setSendMethod(sendMethod);
            
            // TODO: fix encoding comment
            String recipient = determineRecipient(alertLog, config);
            result.setRecipient(recipient);
            
            // TODO: fix encoding comment
            String message = buildAlertMessage(alertLog, config);
            
            // TODO: fix encoding comment
            boolean sendSuccess = false;
            Map<String, Object> sendDetails = new HashMap<>();
            
            switch (sendMethod.toUpperCase()) {
                case "EMAIL":
                    sendSuccess = sendByEmail(recipient, message, alertLog, config, sendDetails);
                    break;
                case "SMS":
                    sendSuccess = sendBySms(recipient, message, alertLog, config, sendDetails);
                    break;
                case "SYSTEM_NOTIFICATION":
                default:
                    sendSuccess = sendBySystemNotification(recipient, message, alertLog, config, sendDetails);
                    break;
            }
            
            // TODO: fix encoding comment
            LocalDateTime sentTime = LocalDateTime.now();
            String sentStatus = sendSuccess ? "SENT" : "FAILED";
            String detailsJson = objectMapper.writeValueAsString(sendDetails);
            
            overdueAlertLogMapper.updateSentStatus(
                    alertLog.getId(), sentStatus, sentTime, detailsJson);
            
            result.setSuccess(sendSuccess);
            result.setSentTime(sentTime);
            result.setMessage(sendSuccess ? "处理条件" : "处理条件");
            result.setAdditionalInfo(sendDetails);
            
            if (!sendSuccess) {
                result.setErrorDetails("鍙戦€佸け璐ワ紝璇︽儏璇锋煡鐪媋dditionalInfo");
            }
            
            log.debug("处理条件", 
                    alertLog.getId(), sendSuccess, sendMethod, System.currentTimeMillis() - startTime);
            
        } catch (Exception e) {
            log.error("处理条件", alertLog.getId(), e);
            
            result.setSuccess(false);
            result.setMessage("处理条件" + e.getMessage());
            result.setErrorDetails(e.toString());
            
            // TODO: fix encoding comment
            try {
                overdueAlertLogMapper.updateSentStatus(
                        alertLog.getId(), "FAILED", LocalDateTime.now(), 
                        "{\"error\": \"" + e.getMessage() + "\"}");
            } catch (Exception ex) {
                log.error("处理条件", ex);
            }
        }
        
        return result;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public BatchSendResult sendAlerts(List<OverdueAlertLogEntity> alertLogs, OverdueAlertConfigEntity config) {
        log.info("处理条件", alertLogs.size());
        
        BatchSendResult result = new BatchSendResult();
        result.setTotalCount(alertLogs.size());
        
        if (alertLogs == null || alertLogs.isEmpty()) {
            result.setSuccess(true);
            result.setSuccessCount(0);
            result.setFailCount(0);
            result.setMessage("处理条件");
            return result;
        }
        
        long startTime = System.currentTimeMillis();
        List<SendResult> detailedResults = new ArrayList<>();
        List<Long> successfulIds = new ArrayList<>();
        List<Long> failedIds = new ArrayList<>();
        
        // TODO: fix encoding comment
        for (int i = 0; i < alertLogs.size(); i += batchSize) {
            int end = Math.min(i + batchSize, alertLogs.size());
            List<OverdueAlertLogEntity> batch = alertLogs.subList(i, end);
            
            for (OverdueAlertLogEntity alertLog : batch) {
                SendResult sendResult = sendAlert(alertLog, config);
                detailedResults.add(sendResult);
                
                if (sendResult.getSuccess()) {
                    successfulIds.add(alertLog.getId());
                } else {
                    failedIds.add(alertLog.getId());
                }
            }
        }
        
        result.setSuccess(failedIds.isEmpty());
        result.setSuccessCount(successfulIds.size());
        result.setFailCount(failedIds.size());
        result.setDetailedResults(detailedResults);
        result.setSuccessfulIds(successfulIds);
        result.setFailedIds(failedIds);
        result.setExecutionTimeMs(System.currentTimeMillis() - startTime);
        result.setMessage(String.format("鎵归噺鍙戦€佸畬鎴? 鎴愬姛 %d 鏉? 澶辫触 %d 鏉?", 
                successfulIds.size(), failedIds.size()));
        
        log.info("处理条件", 
                result.getTotalCount(), result.getSuccessCount(), 
                result.getFailCount(), result.getExecutionTimeMs());
        
        return result;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public SendStatistics sendPendingAlerts() {
        log.debug("处理条件");
        
        SendStatistics statistics = new SendStatistics();
        statistics.setStatisticsTime(LocalDateTime.now());
        
        try {
            // TODO: fix encoding comment
            List<OverdueAlertLogEntity> pendingAlerts = overdueAlertLogMapper.selectPendingAlerts();
            
            if (pendingAlerts.isEmpty()) {
                statistics.setPendingAlerts(0);
                statistics.setSentAlerts(0);
                statistics.setFailedAlerts(0);
                // TODO: fix encoding comment
                return statistics;
            }
            
            statistics.setPendingAlerts(pendingAlerts.size());
            
            // TODO: fix encoding comment
            OverdueAlertConfigEntity config = getAlertConfig();
            if (config == null || !config.getEnabled()) {
                // TODO: fix encoding comment
                return statistics;
            }
            
            // TODO: fix encoding comment
            BatchSendResult batchResult = sendAlerts(pendingAlerts, config);
            
            statistics.setSentAlerts(batchResult.getSuccessCount());
            statistics.setFailedAlerts(batchResult.getFailCount());
            // statistics.setMessage(batchResult.getMessage()); // TODO: Add setMessage method
            
            // TODO: fix encoding comment
            Map<String, Integer> alertsByType = new HashMap<>();
            Map<String, Integer> alertsByMethod = new HashMap<>();
            
            for (SendResult sendResult : batchResult.getDetailedResults()) {
                if (sendResult.getSuccess()) {
                    String alertType = sendResult.getAlertType();
                    String sendMethod = sendResult.getSendMethod();
                    
                    alertsByType.merge(alertType, 1, Integer::sum);
                    alertsByMethod.merge(sendMethod, 1, Integer::sum);
                }
            }
            
            statistics.setAlertsByType(alertsByType);
            statistics.setAlertsByMethod(alertsByMethod);
            
            // TODO: fix encoding comment
            List<OverdueAlertLogEntity> recentAlerts = pendingAlerts.stream()
                    .sorted((a, b) -> b.getAlertTime().compareTo(a.getAlertTime()))
                    .limit(10)
                    .collect(Collectors.toList());
            statistics.setRecentAlerts(recentAlerts);
            
            // TODO: fix encoding comment
            statistics.setTodayAlerts(overdueAlertLogMapper.countTodayAlerts().intValue());
            statistics.setMonthAlerts(overdueAlertLogMapper.countMonthAlerts().intValue());
            
            // TODO: fix encoding comment
            List<Map<String, Object>> statusCounts = overdueAlertLogMapper.countBySentStatus();
            int totalAlerts = 0;
            int sentAlerts = 0;
            int failedAlerts = 0;
            
            for (Map<String, Object> statusCount : statusCounts) {
                String status = (String) statusCount.get("sent_status");
                Long count = (Long) statusCount.get("count");
                totalAlerts += count.intValue();
                
                if ("SENT".equals(status)) {
                    sentAlerts = count.intValue();
                } else if ("FAILED".equals(status)) {
                    failedAlerts = count.intValue();
                }
            }
            
            statistics.setTotalAlerts(totalAlerts);
            statistics.setSentAlerts(sentAlerts);
            statistics.setFailedAlerts(failedAlerts);
            
        } catch (Exception e) {
            log.error("处理条件", e);
            // TODO: fix encoding comment
        }
        
        return statistics;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public RetryResult retryFailedAlerts(Integer maxRetryCount) {
        log.info("处理条件", maxRetryCount);
        
        RetryResult result = new RetryResult();
        
        if (maxRetryCount == null) {
            maxRetryCount = this.maxRetryCount;
        }
        
        try {
            // TODO: fix encoding comment
            List<OverdueAlertLogEntity> failedAlerts = overdueAlertLogMapper.selectFailedAlerts();
            
            if (failedAlerts.isEmpty()) {
                result.setSuccess(true);
                result.setTotalRetried(0);
                result.setRetrySuccessCount(0);
                result.setRetryFailCount(0);
                result.setMessage("处理条件");
                return result;
            }
            
            result.setTotalRetried(failedAlerts.size());
            
            // TODO: fix encoding comment
            List<OverdueAlertLogEntity> alertsToRetry = new ArrayList<>();
            List<Long> retriedIds = new ArrayList<>();
            
            for (OverdueAlertLogEntity alert : failedAlerts) {
                // TODO: fix encoding comment
                int retryCount = getRetryCountFromDetails(alert);
                if (retryCount < maxRetryCount) {
                    alertsToRetry.add(alert);
                    retriedIds.add(alert.getId());
                }
            }
            
            result.setRetriedIds(retriedIds);
            
            if (alertsToRetry.isEmpty()) {
                result.setSuccess(true);
                result.setRetrySuccessCount(0);
                result.setRetryFailCount(0);
                result.setMessage("处理条件");
                return result;
            }
            
            // TODO: fix encoding comment
            OverdueAlertConfigEntity config = getAlertConfig();
            
            long startTime = System.currentTimeMillis();
            List<SendResult> detailedResults = new ArrayList<>();
            int successCount = 0;
            int failCount = 0;
            
            // TODO: fix encoding comment
            for (OverdueAlertLogEntity alert : alertsToRetry) {
                SendResult sendResult = sendAlert(alert, config);
                detailedResults.add(sendResult);
                
                if (sendResult.getSuccess()) {
                    successCount++;
                } else {
                    failCount++;
                }
            }
            
            result.setSuccess(failCount == 0);
            result.setRetrySuccessCount(successCount);
            result.setRetryFailCount(failCount);
            result.setDetailedResults(detailedResults);
            result.setExecutionTimeMs(System.currentTimeMillis() - startTime);
            result.setMessage(String.format("处理条件", successCount, failCount));
            
            log.info("处理条件", 
                    result.getTotalRetried(), successCount, failCount);
            
        } catch (Exception e) {
            log.error("处理条件", e);
            result.setSuccess(false);
            result.setMessage("处理条件" + e.getMessage());
        }
        
        return result;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TypeSendResult sendAlertsByType(String alertType, OverdueAlertConfigEntity config) {
        log.info("处理条件", alertType);
        
        TypeSendResult result = new TypeSendResult();
        result.setAlertType(alertType);
        
        try {
            // TODO: fix encoding comment
            LambdaQueryWrapper<OverdueAlertLogEntity> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(OverdueAlertLogEntity::getAlertType, alertType)
                  .eq(OverdueAlertLogEntity::getSentStatus, "PENDING");
            
            List<OverdueAlertLogEntity> alerts = overdueAlertLogMapper.selectList(wrapper);
            
            if (alerts.isEmpty()) {
                result.setSuccess(true);
                result.setTotalCount(0);
                result.setSuccessCount(0);
                result.setFailCount(0);
                result.setMessage("处理条件");
                return result;
            }
            
            result.setTotalCount(alerts.size());
            
            long startTime = System.currentTimeMillis();
            List<SendResult> detailedResults = new ArrayList<>();
            int successCount = 0;
            int failCount = 0;
            
            // TODO: fix encoding comment
            for (OverdueAlertLogEntity alert : alerts) {
                SendResult sendResult = sendAlert(alert, config);
                detailedResults.add(sendResult);
                
                if (sendResult.getSuccess()) {
                    successCount++;
                } else {
                    failCount++;
                }
            }
            
            result.setSuccess(failCount == 0);
            result.setSuccessCount(successCount);
            result.setFailCount(failCount);
            result.setDetailedResults(detailedResults);
            result.setExecutionTimeMs(System.currentTimeMillis() - startTime);
            result.setMessage(String.format("处理条件", successCount, failCount));
            
            log.info("处理条件", 
                    alertType, alerts.size(), successCount, failCount);
            
        } catch (Exception e) {
            log.error("处理条件", alertType, e);
            result.setSuccess(false);
            result.setMessage("处理条件" + e.getMessage());
        }
        
        return result;
    }
    
    @Override
    public TestSendResult testSend(TestConfig testConfig) {
        log.info("处理条件", 
                testConfig.getTestMethod(), testConfig.getTestRecipient());
        
        TestSendResult result = new TestSendResult();
        result.setTestMethod(testConfig.getTestMethod());
        result.setTestRecipient(testConfig.getTestRecipient());
        result.setTestMessage(testConfig.getTestMessage());
        result.setTestTime(LocalDateTime.now());
        
        try {
            // TODO: fix encoding comment
            OverdueAlertLogEntity testAlert = new OverdueAlertLogEntity();
            testAlert.setAlertType(testConfig.getAlertType() != null ? testConfig.getAlertType() : "TEST");
            testAlert.setAlertMessage(testConfig.getTestMessage() != null ? testConfig.getTestMessage() : "处理条件");
            testAlert.setAlertTime(LocalDateTime.now());
            testAlert.setSentStatus("PENDING");
            testAlert.setCreatedAt(LocalDateTime.now());
            testAlert.setUpdatedAt(LocalDateTime.now());
            
            // TODO: fix encoding comment
            OverdueAlertConfigEntity testConfigEntity = new OverdueAlertConfigEntity();
            testConfigEntity.setAlertMethod(testConfig.getTestMethod());
            testConfigEntity.setEnabled(true);
            testConfigEntity.setAlertRecipients("[\"" + testConfig.getTestRecipient() + "\"]");
            
            // TODO: fix encoding comment
            SendResult sendResult = sendAlert(testAlert, testConfigEntity);
            
            result.setSuccess(sendResult.getSuccess());
            result.setResultMessage(sendResult.getMessage());
            result.setErrorDetails(sendResult.getErrorDetails());
            
            Map<String, Object> testDetails = new HashMap<>();
            testDetails.put("sendResult", sendResult);
            testDetails.put("testConfig", testConfig);
            result.setTestDetails(testDetails);
            
            log.info("处理条件", sendResult.getSuccess());
            
        } catch (Exception e) {
            log.error("处理条件", e);
            result.setSuccess(false);
            result.setResultMessage("娴嬭瘯鍙戦€佸け璐? " + e.getMessage());
            result.setErrorDetails(e.toString());
        }
        
        return result;
    }
    
    @Override
    public AlertStatistics getAlertStatistics() {
        log.debug("处理条件");
        
        AlertStatistics statistics = new AlertStatistics();
        statistics.setStatisticsTime(LocalDateTime.now());
        
        try {
            // TODO: fix encoding comment
            List<Map<String, Object>> typeCounts = overdueAlertLogMapper.countByAlertType();
            Map<String, Integer> alertsByType = new HashMap<>();
            int totalAlerts = 0;
            
            for (Map<String, Object> typeCount : typeCounts) {
                String alertType = (String) typeCount.get("alert_type");
                Long count = (Long) typeCount.get("count");
                alertsByType.put(alertType, count.intValue());
                totalAlerts += count.intValue();
                
                switch (alertType) {
                    case "WARNING":
                        statistics.setWarningAlerts(count.intValue());
                        break;
                    case "OVERDUE":
                        statistics.setOverdueAlerts(count.intValue());
                        break;
                    case "REMINDER":
                        statistics.setReminderAlerts(count.intValue());
                        break;
                }
            }
            
            statistics.setTotalAlerts(totalAlerts);
            
            // TODO: fix encoding comment
            List<Map<String, Object>> statusCounts = overdueAlertLogMapper.countBySentStatus();
            Map<String, Integer> alertsByStatus = new HashMap<>();
            
            for (Map<String, Object> statusCount : statusCounts) {
                String status = (String) statusCount.get("sent_status");
                Long count = (Long) statusCount.get("count");
                alertsByStatus.put(status, count.intValue());
            }
            
            statistics.setAlertsByStatus(alertsByStatus);
            
            // TODO: fix encoding comment
            LocalDateTime endTime = LocalDateTime.now();
            LocalDateTime startTime = endTime.minusDays(1);
            List<OverdueAlertLogEntity> recentAlerts = overdueAlertLogMapper.selectByTimeRange(startTime, endTime);
            
            // TODO: fix encoding comment
            Map<String, Integer> alertsByHour = new HashMap<>();
            Map<String, Integer> alertsByDay = new HashMap<>();
            
            for (OverdueAlertLogEntity alert : recentAlerts) {
                // TODO: fix encoding comment
                String hourKey = alert.getAlertTime().getHour() + ":00";
                alertsByHour.merge(hourKey, 1, Integer::sum);
                
                // TODO: fix encoding comment
                String dayKey = alert.getAlertTime().toLocalDate().toString();
                alertsByDay.merge(dayKey, 1, Integer::sum);
            }
            
            statistics.setAlertsByHour(alertsByHour);
            statistics.setAlertsByDay(alertsByDay);
            
            // TODO: fix encoding comment
            long sentCount = alertsByStatus.getOrDefault("SENT", 0);
            long failedCount = alertsByStatus.getOrDefault("FAILED", 0);
            double successRate = (sentCount + failedCount) > 0 ? 
                    (double) sentCount / (sentCount + failedCount) * 100 : 100.0;
            
            statistics.setSuccessRate(successRate);
            
            // TODO: fix encoding comment
            List<OverdueAlertLogEntity> topAlerts = recentAlerts.stream()
                    .sorted((a, b) -> b.getAlertTime().compareTo(a.getAlertTime()))
                    .limit(20)
                    .collect(Collectors.toList());
            statistics.setTopAlerts(topAlerts);
            
            log.debug("处理条件", 
                    totalAlerts, statistics.getWarningAlerts(), statistics.getOverdueAlerts());
            
        } catch (Exception e) {
            log.error("处理条件", e);
        }
        
        return statistics;
    }
    
    @Override
    public ConfigUpdateResult updateAlertConfig(OverdueAlertConfigEntity config) {
        log.info("处理条件");
        
        ConfigUpdateResult result = new ConfigUpdateResult();
        
        try {
            OverdueAlertConfigEntity oldConfig = getAlertConfig();
            
            if (oldConfig == null) {
                // TODO: fix encoding comment
                config.setCreatedAt(LocalDateTime.now());
                config.setUpdatedAt(LocalDateTime.now());
                overdueAlertConfigMapper.insert(config);
            } else {
                // TODO: fix encoding comment
                config.setId(oldConfig.getId());
                config.setUpdatedAt(LocalDateTime.now());
                overdueAlertConfigMapper.updateById(config);
            }
            
            result.setSuccess(true);
            result.setOldConfig(oldConfig);
            result.setNewConfig(config);
            result.setUpdatedAt(LocalDateTime.now());
            result.setMessage("处理条件");
            
            log.info("处理条件");
            
        } catch (Exception e) {
            log.error("处理条件", e);
            result.setSuccess(false);
            result.setMessage("处理条件" + e.getMessage());
        }
        
        return result;
    }
    
    @Override
    public OverdueAlertConfigEntity getAlertConfig() {
        log.debug("处理条件");
        
        try {
            // TODO: fix encoding comment
            OverdueAlertConfigEntity config = overdueAlertConfigMapper.selectDefaultConfig();
            
            if (config == null) {
                // TODO: fix encoding comment
                config = createDefaultConfig();
            }
            
            return config;
            
        } catch (Exception e) {
            log.warn("处理条件", e);
            return createDefaultConfig();
        }
    }
    
    // TODO: fix encoding comment
    
    /**
     * 纭畾鍙戦€佹柟寮?     */

    private String determineSendMethod(OverdueAlertLogEntity alertLog, OverdueAlertConfigEntity config) {
        if (config != null && StringUtils.hasText(config.getAlertMethod())) {
            return config.getAlertMethod();
        }
        
        // TODO: fix encoding comment
        if ("OVERDUE".equals(alertLog.getAlertType())) {
            return "EMAIL"; // TODO: fix encoding comment
        } else if ("WARNING".equals(alertLog.getAlertType())) {
            return "SYSTEM_NOTIFICATION"; // TODO: fix encoding comment
        } else {
            return "SYSTEM_NOTIFICATION"; // TODO: fix encoding comment
        }
    }
    
    /**
     * 纭畾鎺ユ敹浜?     */

    private String determineRecipient(OverdueAlertLogEntity alertLog, OverdueAlertConfigEntity config) {
        if (config != null && StringUtils.hasText(config.getAlertRecipients())) {
            try {
                // TODO: fix encoding comment
                String[] recipients = objectMapper.readValue(config.getAlertRecipients(), String[].class);
                if (recipients.length > 0) {
                    return recipients[0]; // TODO: fix encoding comment
                }
            } catch (Exception e) {
                log.warn("处理条件", e);
            }
        }
        
        return defaultRecipients.split(",")[0]; // TODO: fix encoding comment
    }
    
    /**
     * 鏋勫缓棰勮娑堟伅
     */
    private String buildAlertMessage(OverdueAlertLogEntity alertLog, OverdueAlertConfigEntity config) {
        String baseMessage = alertLog.getAlertMessage();
        
        if (!StringUtils.hasText(baseMessage)) {
            baseMessage = "处理条件";
        }
        
        // TODO: fix encoding comment
        if (config != null && StringUtils.hasText(config.getAlertTemplateId())) {
            baseMessage = "[" + config.getAlertTemplateId() + "] " + baseMessage;
        }
        
        return baseMessage;
    }
    
    /**
     * 閭欢鍙戦€侊紙妯℃嫙瀹炵幇锛?     */

    private boolean sendByEmail(String recipient, String message, 
                               OverdueAlertLogEntity alertLog, OverdueAlertConfigEntity config,
                               Map<String, Object> sendDetails) {
        if (!emailEnabled) {
            log.debug("处理条件");
            sendDetails.put("skipped", true);
            sendDetails.put("reason", "处理条件");
            return false;
        }
        
        try {
            log.info("妯℃嫙鍙戦€侀偖浠? to={}, message={}", recipient, message);
            
            // TODO: fix encoding comment
            // TODO: fix encoding comment
            sendDetails.put("method", "EMAIL");
            sendDetails.put("recipient", recipient);
            sendDetails.put("subject", "处理条件");
            sendDetails.put("content", message);
            sendDetails.put("simulated", true);
            sendDetails.put("success", true);
            
            // TODO: fix encoding comment
            Thread.sleep(100);
            
            return true;
        } catch (Exception e) {
            log.error("处理条件", e);
            sendDetails.put("error", e.getMessage());
            return false;
        }
    }
    
    /**
     * 鐭俊鍙戦€侊紙妯℃嫙瀹炵幇锛?     */

    private boolean sendBySms(String recipient, String message,
                             OverdueAlertLogEntity alertLog, OverdueAlertConfigEntity config,
                             Map<String, Object> sendDetails) {
        if (!smsEnabled) {
            log.debug("处理条件");
            sendDetails.put("skipped", true);
            sendDetails.put("reason", "处理条件");
            return false;
        }
        
        try {
            log.info("妯℃嫙鍙戦€佺煭淇? to={}, message={}", recipient, message);
            
            // TODO: fix encoding comment
            // TODO: fix encoding comment
            sendDetails.put("method", "SMS");
            sendDetails.put("recipient", recipient);
            sendDetails.put("content", message.substring(0, Math.min(message.length(), 140)));
            sendDetails.put("simulated", true);
            sendDetails.put("success", true);
            
            // TODO: fix encoding comment
            Thread.sleep(50);
            
            return true;
        } catch (Exception e) {
            log.error("处理条件", e);
            sendDetails.put("error", e.getMessage());
            return false;
        }
    }
    
    /**
     * 绯荤粺閫氱煡鍙戦€侊紙瀹為檯瀹炵幇锛?     */

    private boolean sendBySystemNotification(String recipient, String message,
                                           OverdueAlertLogEntity alertLog, OverdueAlertConfigEntity config,
                                           Map<String, Object> sendDetails) {
        if (!systemNotificationEnabled) {
            log.debug("处理条件");
            sendDetails.put("skipped", true);
            sendDetails.put("reason", "处理条件");
            return false;
        }
        
        try {
            log.info("鍙戦€佺郴缁熼€氱煡: recipient={}, message={}", recipient, message);
            
            // TODO: fix encoding comment
            sendDetails.put("method", "SYSTEM_NOTIFICATION");
            sendDetails.put("recipient", recipient);
            sendDetails.put("content", message);
            sendDetails.put("alertTime", alertLog.getAlertTime());
            sendDetails.put("alertType", alertLog.getAlertType());
            sendDetails.put("loanOutId", alertLog.getLoanOutId());
            sendDetails.put("success", true);
            
            // TODO: fix encoding comment
            // TODO: fix encoding comment
            
            return true;
        } catch (Exception e) {
            log.error("处理条件", e);
            sendDetails.put("error", e.getMessage());
            return false;
        }
    }
    
    /**
     * 浠庡彂閫佽鎯呬腑鑾峰彇閲嶈瘯娆℃暟
     */
    private int getRetryCountFromDetails(OverdueAlertLogEntity alert) {
        if (!StringUtils.hasText(alert.getSendDetails())) {
            return 0;
        }
        
        try {
            Map<String, Object> details = objectMapper.readValue(alert.getSendDetails(), Map.class);
            Object retryCount = details.get("retryCount");
            return retryCount != null ? Integer.parseInt(retryCount.toString()) : 0;
        } catch (Exception e) {
            log.warn("处理条件", e);
            return 0;
        }
    }
    
    /**
     * 创建榛樿閰嶇疆
     */
    private OverdueAlertConfigEntity createDefaultConfig() {
        OverdueAlertConfigEntity config = new OverdueAlertConfigEntity();
        config.setAlertDaysBefore(3);
        config.setAlertRecipients("[\"warehouse_manager@seabank.com\", \"risk_officer@seabank.com\"]");
        config.setEnabled(true);
        config.setAlertMethod("SYSTEM_NOTIFICATION");
        config.setAlertTemplateId("DEFAULT_OVERDUE_ALERT");
        config.setAlertFrequencyHours(24);
        config.setMaxAlertCount(0);
        config.setCreatedAt(LocalDateTime.now());
        config.setUpdatedAt(LocalDateTime.now());
        
        try {
            overdueAlertConfigMapper.insert(config);
            log.info("处理条件");
        } catch (Exception e) {
            log.error("处理条件", e);
        }
        
        return config;
    }
    
    /**
     * 寮傛鍙戦€佹柟娉?     */
    @Async
    public void sendAlertAsync(OverdueAlertLogEntity alertLog, OverdueAlertConfigEntity config) {
        sendAlert(alertLog, config);
    }
    
    /**
     * 寮傛鎵归噺鍙戦€佹柟娉?     */
    @Async
    public void sendAlertsAsync(List<OverdueAlertLogEntity> alertLogs, OverdueAlertConfigEntity config) {
        sendAlerts(alertLogs, config);
    }
}