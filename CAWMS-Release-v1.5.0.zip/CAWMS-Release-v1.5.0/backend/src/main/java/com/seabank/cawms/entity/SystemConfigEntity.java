package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.TableName;

/**
 * 系统配置实体类
 */
@TableName("system_config")
public class SystemConfigEntity extends BaseEntity {

    private String configKey;
    private String configValue;
    private String configType;
    private String description;
    private Integer editable;

    public String getConfigKey() {
        return configKey;
    }

    public void setConfigKey(String configKey) {
        this.configKey = configKey;
    }

    public String getConfigValue() {
        return configValue;
    }

    public void setConfigValue(String configValue) {
        this.configValue = configValue;
    }

    public String getConfigType() {
        return configType;
    }

    public void setConfigType(String configType) {
        this.configType = configType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getEditable() {
        return editable;
    }

    public void setEditable(Integer editable) {
        this.editable = editable;
    }
}
