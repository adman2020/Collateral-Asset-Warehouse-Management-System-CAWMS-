/**
 * DTO package for CAWMS application
 * Contains Data Transfer Objects for API requests and responses
 */
package com.seabank.cawms.dto;
