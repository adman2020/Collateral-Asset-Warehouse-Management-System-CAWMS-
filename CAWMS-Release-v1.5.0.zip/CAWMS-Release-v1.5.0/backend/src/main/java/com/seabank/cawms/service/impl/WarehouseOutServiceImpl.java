package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.SystemUserEntity;
import com.seabank.cawms.entity.WarehouseEntity;
import com.seabank.cawms.entity.WarehouseInEntity;
import com.seabank.cawms.entity.WarehouseOutApprovalEntity;
import com.seabank.cawms.entity.WarehouseOutEntity;
import com.seabank.cawms.mapper.SystemUserMapper;
import com.seabank.cawms.mapper.WarehouseInMapper;
import com.seabank.cawms.mapper.WarehouseMapper;
import com.seabank.cawms.mapper.WarehouseOutApprovalMapper;
import com.seabank.cawms.mapper.WarehouseOutMapper;
import com.seabank.cawms.service.WarehouseOutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class WarehouseOutServiceImpl implements WarehouseOutService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WarehouseOutServiceImpl.class);

    private final WarehouseOutMapper warehouseOutMapper;
    private final WarehouseOutApprovalMapper warehouseOutApprovalMapper;
    private final WarehouseInMapper warehouseInMapper;
    private final WarehouseMapper warehouseMapper;
    private final SystemUserMapper systemUserMapper;

    @Autowired
    public WarehouseOutServiceImpl(
            WarehouseOutMapper warehouseOutMapper,
            WarehouseOutApprovalMapper warehouseOutApprovalMapper,
            WarehouseInMapper warehouseInMapper,
            WarehouseMapper warehouseMapper,
            SystemUserMapper systemUserMapper) {
        this.warehouseOutMapper = warehouseOutMapper;
        this.warehouseOutApprovalMapper = warehouseOutApprovalMapper;
        this.warehouseInMapper = warehouseInMapper;
        this.warehouseMapper = warehouseMapper;
        this.systemUserMapper = systemUserMapper;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseOutDetail create(WarehouseOutCreateRequest request, String creator) {
        log.info("创建出库申请: creator={}, warehouseInId={}", creator, request.getWarehouseInId());

        WarehouseInEntity warehouseIn = warehouseInMapper.selectById(request.getWarehouseInId());
        if (warehouseIn == null) {
            throw new IllegalArgumentException("入库记录不存在: " + request.getWarehouseInId());
        }

        WarehouseEntity warehouse = warehouseMapper.selectById(warehouseIn.getWarehouseId());

        WarehouseOutEntity entity = new WarehouseOutEntity();
        entity.setWhInId(request.getWarehouseInId());
        entity.setOutType(request.getReleaseType());
        entity.setOutReason(request.getReleaseReason());
        
        // 全部释放时自动计算释放金额和比例
        BigDecimal releaseAmount = request.getReleaseAmount();
        BigDecimal releasePercentage = request.getReleasePercentage();
        if ("FULL".equals(request.getReleaseType()) && warehouseIn.getCollateralValue() != null) {
            if (releaseAmount == null) {
                releaseAmount = warehouseIn.getCollateralValue();
            }
            if (releasePercentage == null) {
                releasePercentage = new BigDecimal("100");
            }
        }
        entity.setOutAmount(releaseAmount);
        entity.setOutPercentage(releasePercentage);
        entity.setStatus("DRAFT");
        entity.setCurrentStep(1);
        entity.setCreatedBy(creator);
        entity.setCreatedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(creator);

        warehouseOutMapper.insert(entity);

        return convertToDetail(entity, warehouseIn, warehouse);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseOutDetail update(Long id, WarehouseOutUpdateRequest request, String updater) {
        log.info("更新出库申请: id={}, updater={}", id, updater);

        WarehouseOutEntity entity = warehouseOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("出库记录不存在: " + id);
        }
        if (!"DRAFT".equals(entity.getStatus())) {
            throw new IllegalStateException("只有草稿状态可以编辑");
        }

        if (StringUtils.hasText(request.getReleaseType())) {
            entity.setOutType(request.getReleaseType());
        }
        if (StringUtils.hasText(request.getReleaseReason())) {
            entity.setOutReason(request.getReleaseReason());
        }
        // 全部释放时自动计算释放金额和比例
        BigDecimal releaseAmount = request.getReleaseAmount();
        BigDecimal releasePercentage = request.getReleasePercentage();
        if ("FULL".equals(request.getReleaseType())) {
            WarehouseInEntity whIn = warehouseInMapper.selectById(entity.getWhInId());
            if (whIn != null && whIn.getCollateralValue() != null) {
                if (releaseAmount == null) {
                    releaseAmount = whIn.getCollateralValue();
                }
                if (releasePercentage == null) {
                    releasePercentage = new BigDecimal("100");
                }
            }
        }
        if (releaseAmount != null) {
            entity.setOutAmount(releaseAmount);
        }
        if (releasePercentage != null) {
            entity.setOutPercentage(releasePercentage);
        }
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(updater);

        warehouseOutMapper.updateById(entity);
        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(Long id, String deleter) {
        log.info("删除出库申请: id={}, deleter={}", id, deleter);

        WarehouseOutEntity entity = warehouseOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("出库记录不存在: " + id);
        }
        if (!"DRAFT".equals(entity.getStatus()) && !"CANCELLED".equals(entity.getStatus())) {
            throw new IllegalStateException("只有草稿或已取消状态可以删除");
        }

        entity.setDeleted(1);
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(deleter);
        return warehouseOutMapper.updateById(entity) > 0;
    }

    @Override
    public WarehouseOutDetail getById(Long id) {
        log.debug("查询出库详情: id={}", id);

        WarehouseOutEntity entity = warehouseOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("出库记录不存在: " + id);
        }

        WarehouseInEntity warehouseIn = warehouseInMapper.selectById(entity.getWhInId());
        WarehouseEntity warehouse = null;
        if (warehouseIn != null && warehouseIn.getWarehouseId() != null) {
            warehouse = warehouseMapper.selectById(warehouseIn.getWarehouseId());
        }

        return convertToDetail(entity, warehouseIn, warehouse);
    }

    @Override
    public Page<WarehouseOutDetail> query(WarehouseOutQuery query) {
        log.debug("查询出库列表: query={}", query);

        int pageNum = query.getPage() != null && query.getPage() > 0 ? query.getPage() : 1;
        int pageSize = query.getSize() != null && query.getSize() > 0 ? query.getSize() : 10;
        Page<WarehouseOutEntity> page = new Page<>(pageNum, pageSize);

        LambdaQueryWrapper<WarehouseOutEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(WarehouseOutEntity::getDeleted, 0);
        if (StringUtils.hasText(query.getStatus())) {
            wrapper.eq(WarehouseOutEntity::getStatus, query.getStatus());
        }
        if (StringUtils.hasText(query.getReleaseType())) {
            wrapper.eq(WarehouseOutEntity::getOutType, query.getReleaseType());
        }
        if (StringUtils.hasText(query.getStartDate()) && StringUtils.hasText(query.getEndDate())) {
            wrapper.ge(WarehouseOutEntity::getCreatedAt, query.getStartDate() + " 00:00:00");
            wrapper.le(WarehouseOutEntity::getCreatedAt, query.getEndDate() + " 23:59:59");
        }
        wrapper.orderByDesc(WarehouseOutEntity::getCreatedAt);

        Page<WarehouseOutEntity> resultPage = warehouseOutMapper.selectPage(page, wrapper);

        List<WarehouseOutDetail> details = resultPage.getRecords().stream()
                .map(e -> {
                    try {
                        return getById(e.getId());
                    } catch (Exception ex) {
                        log.warn("转换出库记录失败: id={}", e.getId(), ex);
                        return convertToDetail(e, null, null);
                    }
                })
                .collect(Collectors.toList());

        Page<WarehouseOutDetail> detailPage = new Page<>(resultPage.getCurrent(), resultPage.getSize(), resultPage.getTotal());
        detailPage.setRecords(details);
        return detailPage;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseOutDetail submit(Long id, String submitter) {
        log.info("提交出库申请: id={}, submitter={}", id, submitter);

        WarehouseOutEntity entity = warehouseOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("出库记录不存在: " + id);
        }
        if (!"DRAFT".equals(entity.getStatus()) && !"CANCELLED".equals(entity.getStatus())) {
            throw new IllegalStateException("只有草稿或已取消状态可以提交");
        }

        // 清理旧的审批记录（支持取消后重新提交）
        warehouseOutApprovalMapper.deleteByWarehouseOutId(id);

        entity.setStatus("SUBMITTED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(submitter);
        warehouseOutMapper.updateById(entity);

        // Step 1: 风险审核
        WarehouseOutApprovalEntity approval = new WarehouseOutApprovalEntity();
        approval.setWarehouseOutId(id);
        approval.setStepNumber(1);
        approval.setStepName("风险审核");
        approval.setApproverRole("RISK_OFFICER");
        approval.setStatus("PENDING");
        warehouseOutApprovalMapper.insert(approval);

        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseOutDetail approve(Long id, String approverId, String approverName, String comments) {
        log.info("审批通过出库申请: id={}, approver={}", id, approverId);

        WarehouseOutEntity entity = warehouseOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("出库记录不存在: " + id);
        }
        if (!"SUBMITTED".equals(entity.getStatus()) && !"PENDING".equals(entity.getStatus())) {
            throw new IllegalStateException("当前状态不可审批");
        }

        WarehouseOutApprovalEntity pendingStep = warehouseOutApprovalMapper.selectCurrentPendingStep(id);
        if (pendingStep == null) {
            throw new IllegalStateException("没有待审批步骤");
        }

        // 检查审批人是否已经审批过该申请的先前步骤
        List<WarehouseOutApprovalEntity> approvedSteps = warehouseOutApprovalMapper.selectList(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<WarehouseOutApprovalEntity>()
                        .eq(WarehouseOutApprovalEntity::getWarehouseOutId, id)
                        .eq(WarehouseOutApprovalEntity::getStatus, "APPROVED"));
        boolean alreadyApproved = approvedSteps.stream()
                .anyMatch(a -> approverName.equals(a.getApproverUser()));
        if (alreadyApproved) {
            throw new IllegalStateException("您已审批过该申请的先前步骤，不能重复审批");
        }

        pendingStep.setApproverUser(approverName);
        pendingStep.setApproverName(approverName);
        pendingStep.setStatus("APPROVED");
        pendingStep.setApprovalOpinion(comments);
        pendingStep.setApprovalTime(LocalDateTime.now());
        warehouseOutApprovalMapper.updateById(pendingStep);

        int currentStep = pendingStep.getStepNumber();
        if (currentStep == 1) {
            // Step 2: 合规复核
            WarehouseOutApprovalEntity step2 = new WarehouseOutApprovalEntity();
            step2.setWarehouseOutId(id);
            step2.setStepNumber(2);
            step2.setStepName("合规复核");
            step2.setApproverRole("COMPLIANCE_OFFICER");
            step2.setStatus("PENDING");
            warehouseOutApprovalMapper.insert(step2);
            entity.setStatus("SUBMITTED");
        } else if (currentStep == 2) {
            // Step 3: 仓库主管出库确认
            WarehouseOutApprovalEntity step3 = new WarehouseOutApprovalEntity();
            step3.setWarehouseOutId(id);
            step3.setStepNumber(3);
            step3.setStepName("仓库主管出库确认");
            step3.setApproverRole("WAREHOUSE_MANAGER");
            step3.setStatus("PENDING");
            warehouseOutApprovalMapper.insert(step3);
            entity.setStatus("SUBMITTED");
        } else if (currentStep == 3) {
            // Step 4: 业务最后核实
            WarehouseOutApprovalEntity step4 = new WarehouseOutApprovalEntity();
            step4.setWarehouseOutId(id);
            step4.setStepNumber(4);
            step4.setStepName("业务最后核实");
            step4.setApproverRole("BUSINESS_MANAGER");
            step4.setStatus("PENDING");
            warehouseOutApprovalMapper.insert(step4);
            entity.setStatus("SUBMITTED");
        } else if (currentStep == 4) {
            // 全部审批完成
            entity.setStatus("APPROVED");
        }

        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(approverId);
        warehouseOutMapper.updateById(entity);

        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseOutDetail reject(Long id, String rejectorId, String rejectorName, String comments) {
        log.info("拒绝出库申请: id={}, rejector={}", id, rejectorId);

        WarehouseOutEntity entity = warehouseOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("出库记录不存在: " + id);
        }
        if (!"SUBMITTED".equals(entity.getStatus()) && !"PENDING".equals(entity.getStatus())) {
            throw new IllegalStateException("当前状态不可拒绝");
        }

        WarehouseOutApprovalEntity pendingStep = warehouseOutApprovalMapper.selectCurrentPendingStep(id);
        if (pendingStep != null) {
            pendingStep.setApproverUser(rejectorId);
            pendingStep.setApproverName(rejectorName);
            pendingStep.setStatus("REJECTED");
            pendingStep.setApprovalOpinion(comments);
            pendingStep.setApprovalTime(LocalDateTime.now());
            warehouseOutApprovalMapper.updateById(pendingStep);
        }

        entity.setStatus("CANCELLED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(rejectorId);
        warehouseOutMapper.updateById(entity);

        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseOutDetail complete(Long id, String operator) {
        log.info("完成出库: id={}, operator={}", id, operator);

        WarehouseOutEntity entity = warehouseOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("出库记录不存在: " + id);
        }
        if (!"APPROVED".equals(entity.getStatus())) {
            throw new IllegalStateException("只有已审批状态可以完成");
        }

        entity.setStatus("COMPLETED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(operator);
        warehouseOutMapper.updateById(entity);

        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseOutDetail cancel(Long id, String operator) {
        log.info("取消出库: id={}, operator={}", id, operator);

        WarehouseOutEntity entity = warehouseOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("出库记录不存在: " + id);
        }
        if ("COMPLETED".equals(entity.getStatus())) {
            throw new IllegalStateException("已完成状态不可取消");
        }

        entity.setStatus("CANCELLED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(operator);
        warehouseOutMapper.updateById(entity);

        // 记录取消操作到审批历史
        WarehouseOutApprovalEntity cancelRecord = new WarehouseOutApprovalEntity();
        cancelRecord.setWarehouseOutId(id);
        cancelRecord.setStepNumber(0);
        cancelRecord.setStepName("取消申请");
        cancelRecord.setApproverRole("OPERATOR");
        cancelRecord.setApproverUser(operator);
        cancelRecord.setStatus("CANCELLED");
        cancelRecord.setApprovalOpinion("用户取消申请");
        cancelRecord.setApprovalTime(LocalDateTime.now());
        warehouseOutApprovalMapper.insert(cancelRecord);

        return getById(id);
    }

    @Override
    public List<WarehouseOutApproval> getApprovalProgress(Long warehouseOutId) {
        log.debug("查询审批进度: warehouseOutId={}", warehouseOutId);

        List<WarehouseOutApprovalEntity> entities = warehouseOutApprovalMapper.selectList(
                new LambdaQueryWrapper<WarehouseOutApprovalEntity>()
                        .eq(WarehouseOutApprovalEntity::getWarehouseOutId, warehouseOutId));
        return entities.stream().map(this::convertToApprovalDto).collect(Collectors.toList());
    }

    @Override
    public WarehouseOutApproval getCurrentPendingStep(Long warehouseOutId) {
        log.debug("查询当前待审批步骤: warehouseOutId={}", warehouseOutId);

        WarehouseOutApprovalEntity entity = warehouseOutApprovalMapper.selectCurrentPendingStep(warehouseOutId);
        if (entity == null) {
            return null;
        }
        return convertToApprovalDto(entity);
    }

    @Override
    public WarehouseOutStatistics getStatistics() {
        log.debug("查询出库统计");

        WarehouseOutStatistics stats = new WarehouseOutStatistics();
        List<Map<String, Object>> statusCounts = warehouseOutMapper.countByStatus();

        Map<String, Integer> byStatus = new HashMap<>();
        int total = 0;
        int pendingApprovals = 0;
        for (Map<String, Object> row : statusCounts) {
            String status = (String) row.get("status");
            Integer count = ((Number) row.get("count")).intValue();
            byStatus.put(status != null ? status : "UNKNOWN", count);
            total += count;
            if ("SUBMITTED".equals(status) || "PENDING".equals(status)) {
                pendingApprovals += count;
            }
        }

        Map<String, Integer> byReleaseType = new HashMap<>();
        byReleaseType.put("PARTIAL", 0);
        byReleaseType.put("FULL", 0);

        Map<String, Integer> byReasonType = new HashMap<>();
        byReasonType.put("LOAN_REPAYMENT", 0);
        byReasonType.put("CREDIT_LINE_REDUCTION", 0);
        byReasonType.put("COLLATERAL_REPLACEMENT", 0);
        byReasonType.put("OTHER", 0);

        stats.setTotal(total);
        stats.setByStatus(byStatus);
        stats.setByReleaseType(byReleaseType);
        stats.setByReasonType(byReasonType);
        stats.setPendingApprovals(pendingApprovals);

        Long todayCount = warehouseOutMapper.countToday();
        stats.setCompletedToday(todayCount != null ? todayCount.intValue() : 0);

        BigDecimal totalRelease = warehouseOutMapper.sumTotalReleaseAmount();
        stats.setTotalReleaseAmount(totalRelease != null ? totalRelease : BigDecimal.ZERO);

        return stats;
    }

    @Override
    public Page<WarehouseOutDetail> getPendingApprovals(String approverRole, String approverUser, Integer pageNum, Integer pageSize) {
        log.debug("查询待审批列表: approverRole={}, approverUser={}", approverRole, approverUser);

        int pn = pageNum != null && pageNum > 0 ? pageNum : 1;
        int ps = pageSize != null && pageSize > 0 ? pageSize : 10;
        Page<WarehouseOutEntity> page = new Page<>(pn, ps);

        LambdaQueryWrapper<WarehouseOutEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(WarehouseOutEntity::getDeleted, 0);
        wrapper.in(WarehouseOutEntity::getStatus, "SUBMITTED", "PENDING");
        wrapper.orderByDesc(WarehouseOutEntity::getCreatedAt);

        Page<WarehouseOutEntity> resultPage = warehouseOutMapper.selectPage(page, wrapper);
        List<WarehouseOutDetail> details = resultPage.getRecords().stream()
                .map(e -> {
                    try {
                        return getById(e.getId());
                    } catch (Exception ex) {
                        return convertToDetail(e, null, null);
                    }
                })
                .collect(Collectors.toList());

        Page<WarehouseOutDetail> detailPage = new Page<>(resultPage.getCurrent(), resultPage.getSize(), resultPage.getTotal());
        detailPage.setRecords(details);
        return detailPage;
    }

    @Override
    public Page<WarehouseOutDetail> getMyApplications(String userId, String status, Integer pageNum, Integer pageSize) {
        log.debug("查询我的申请: userId={}, status={}", userId, status);

        int pn = pageNum != null && pageNum > 0 ? pageNum : 1;
        int ps = pageSize != null && pageSize > 0 ? pageSize : 10;
        Page<WarehouseOutEntity> page = new Page<>(pn, ps);

        LambdaQueryWrapper<WarehouseOutEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(WarehouseOutEntity::getDeleted, 0);
        wrapper.eq(WarehouseOutEntity::getCreatedBy, userId);
        if (StringUtils.hasText(status) && !"ALL".equals(status)) {
            wrapper.eq(WarehouseOutEntity::getStatus, status);
        }
        wrapper.orderByDesc(WarehouseOutEntity::getCreatedAt);

        Page<WarehouseOutEntity> resultPage = warehouseOutMapper.selectPage(page, wrapper);
        List<WarehouseOutDetail> details = resultPage.getRecords().stream()
                .map(e -> {
                    try {
                        return getById(e.getId());
                    } catch (Exception ex) {
                        return convertToDetail(e, null, null);
                    }
                })
                .collect(Collectors.toList());

        Page<WarehouseOutDetail> detailPage = new Page<>(resultPage.getCurrent(), resultPage.getSize(), resultPage.getTotal());
        detailPage.setRecords(details);
        return detailPage;
    }

    @Override
    public Page<WarehouseOutDetail> getMyApprovals(String approverUser, String approverRole, String type, Integer pageNum, Integer pageSize) {
        log.debug("获取我的出库审批列表: type={}, approverUser={}, approverRole={}", type, approverUser, approverRole);

        List<WarehouseOutEntity> records;
        if ("pending".equals(type)) {
            if ("ALL".equals(approverRole) || approverRole == null || approverRole.isBlank()) {
                records = warehouseOutMapper.selectAllPending(approverUser);
            } else {
                records = warehouseOutMapper.selectPendingByApproverRole(approverRole, approverUser);
            }
        } else if ("ongoing".equals(type)) {
            records = warehouseOutMapper.selectMyApprovedOngoing(approverUser);
        } else {
            records = warehouseOutMapper.selectMyHistory(approverUser);
        }

        int current = pageNum != null && pageNum > 0 ? pageNum : 1;
        int size = pageSize != null && pageSize > 0 ? pageSize : 10;
        int total = records.size();
        int pages = (int) Math.ceil((double) total / size);
        int start = (current - 1) * size;
        int end = Math.min(start + size, total);

        Page<WarehouseOutDetail> resultPage = new Page<>();
        resultPage.setCurrent(current);
        resultPage.setSize(size);
        resultPage.setTotal(total);
        resultPage.setPages(pages);

        if (start < total) {
            List<WarehouseOutDetail> details = records.subList(start, end).stream()
                    .map(e -> {
                        try {
                            return getById(e.getId());
                        } catch (Exception ex) {
                            return convertToDetail(e, null, null);
                        }
                    })
                    .collect(Collectors.toList());
            resultPage.setRecords(details);
        } else {
            resultPage.setRecords(java.util.Collections.emptyList());
        }

        return resultPage;
    }

    @Override
    public List<WarehouseOutHistory> getHistory(Long warehouseOutId) {
        log.debug("查询出库历史: warehouseOutId={}", warehouseOutId);
        List<WarehouseOutApprovalEntity> approvals = warehouseOutApprovalMapper.selectList(
                new LambdaQueryWrapper<WarehouseOutApprovalEntity>()
                        .eq(WarehouseOutApprovalEntity::getWarehouseOutId, warehouseOutId));
        List<WarehouseOutHistory> history = new ArrayList<>();
        for (WarehouseOutApprovalEntity a : approvals) {
            WarehouseOutHistory h = new WarehouseOutHistory();
            h.setId(a.getId());
            h.setWarehouseOutId(a.getWarehouseOutId());
            h.setOperationType(a.getStatus());
            h.setOperationDesc(a.getStepName());
            h.setOperatorId(a.getApproverUser() != null ? Long.valueOf(a.getApproverUser()) : null);
            h.setOperatorName(a.getApproverName());
            h.setOperationTime(a.getApprovalTime());
            h.setBeforeValue("PENDING");
            h.setAfterValue(a.getStatus());
            history.add(h);
        }
        return history;
    }

    private WarehouseOutDetail convertToDetail(WarehouseOutEntity entity, WarehouseInEntity warehouseIn,
                                               WarehouseEntity warehouse) {
        WarehouseOutDetail detail = new WarehouseOutDetail();
        detail.setId(entity.getId());
        detail.setWarehouseOutNo("WOUT-" + entity.getId());
        detail.setWarehouseInId(entity.getWhInId());
        detail.setWarehouseInNo(warehouseIn != null ? warehouseIn.getWhCode() : "");
        detail.setCollateralName(warehouseIn != null ? warehouseIn.getCustomerName() : "");
        detail.setCollateralType(warehouseIn != null ? warehouseIn.getCollateralType() : "");
        detail.setCollateralValue(warehouseIn != null ? warehouseIn.getCollateralValue() : null);
        detail.setWarehouseId(warehouse != null ? warehouse.getId() : null);
        detail.setWarehouseName(warehouse != null ? warehouse.getWarehouseName() : "");
        detail.setWarehouseLocation(warehouse != null ? warehouse.getWarehouseName() : "");
        detail.setReleaseType(entity.getOutType());
        detail.setReleaseAmount(entity.getOutAmount());
        detail.setReleasePercentage(entity.getOutPercentage());
        if (warehouseIn != null && warehouseIn.getCollateralValue() != null && entity.getOutAmount() != null) {
            detail.setRemainingValue(warehouseIn.getCollateralValue().subtract(entity.getOutAmount()));
        } else {
            detail.setRemainingValue(BigDecimal.ZERO);
        }
        detail.setOriginalValue(warehouseIn != null ? warehouseIn.getCollateralValue() : null);
        detail.setReleaseReason(entity.getOutReason());
        detail.setReleaseReasonType("OTHER");
        detail.setStatus(entity.getStatus());
        String creator = entity.getCreatedBy();
        Long applicantId = null;
        String applicantName = creator;
        if (creator != null) {
            try {
                applicantId = Long.valueOf(creator);
                SystemUserEntity user = systemUserMapper.selectById(applicantId);
                if (user != null) {
                    applicantName = user.getFullName() != null ? user.getFullName() : user.getUsername();
                }
            } catch (NumberFormatException e) {
                // creator is username, not numeric id
                applicantName = creator;
                LambdaQueryWrapper<SystemUserEntity> wrapper = new LambdaQueryWrapper<>();
                wrapper.eq(SystemUserEntity::getUsername, creator);
                SystemUserEntity user = systemUserMapper.selectOne(wrapper);
                if (user != null) {
                    applicantName = user.getFullName() != null ? user.getFullName() : user.getUsername();
                    applicantId = user.getId();
                }
            }
        }
        detail.setApplicantId(applicantId);
        detail.setApplicantName(applicantName);
        detail.setApplyTime(entity.getCreatedAt());
        detail.setRemarks(entity.getOutReason());
        detail.setCreateTime(entity.getCreatedAt());
        detail.setUpdateTime(entity.getUpdatedAt());

        // Load approvals
        if (entity.getId() != null) {
            try {
                List<WarehouseOutApprovalEntity> approvalEntities = warehouseOutApprovalMapper.selectByWarehouseOutId(entity.getId());
                log.info("出库详情加载审批记录: warehouseOutId={}, count={}", entity.getId(), approvalEntities != null ? approvalEntities.size() : -1);
                List<WarehouseOutApproval> approvals = approvalEntities != null ? approvalEntities.stream()
                        .map(this::convertToApprovalDto)
                        .collect(Collectors.toList()) : new ArrayList<>();
                detail.setApprovals(approvals);
            } catch (Exception e) {
                log.warn("加载审批记录失败: warehouseOutId={}", entity.getId(), e);
            }
        }

        return detail;
    }

    private WarehouseOutApproval convertToApprovalDto(WarehouseOutApprovalEntity entity) {
        WarehouseOutApproval dto = new WarehouseOutApproval();
        dto.setId(entity.getId());
        dto.setWarehouseOutId(entity.getWarehouseOutId());
        dto.setStep(entity.getStepNumber());
        dto.setStepName(entity.getStepName());
        dto.setApproverRole(entity.getApproverRole());
        dto.setApproverId(null);
        dto.setApproverName(entity.getApproverUser());
        dto.setApprovalStatus(entity.getStatus());
        dto.setApprovalOpinion(entity.getApprovalOpinion());
        dto.setApprovalTime(entity.getApprovalTime());
        dto.setCreateTime(entity.getApprovalTime());
        return dto;
    }
}
