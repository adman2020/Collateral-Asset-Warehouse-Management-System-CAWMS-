package com.seabank.cawms.common;


/**
 * Response code enum
 */

public enum ResponseCode {
    /**
     * Success
     */
    SUCCESS(0, "Success"),

    /**
     * Client error
     */
    BAD_REQUEST(400, "Bad Request"),
    UNAUTHORIZED(401, "Unauthorized"),
    FORBIDDEN(403, "Forbidden"),
    NOT_FOUND(404, "Not Found"),

    /**
     * Server error
     */
    ERROR(500, "Internal Server Error"),
    SERVICE_UNAVAILABLE(503, "Service Unavailable"),

    /**
     * Business error codes (1000-1999)
     */
    BUSINESS_ERROR(1000, "Business Processing Failed"),
    VALIDATION_ERROR(1001, "Data Validation Failed"),
    DATA_NOT_FOUND(1002, "Data Not Found"),
    DATA_ALREADY_EXISTS(1003, "Data Already Exists"),
    OPERATION_NOT_ALLOWED(1004, "Operation Not Allowed"),
    INVALID_STATUS(1005, "Invalid Status"),

    /**
     * Authentication/Authorization error codes (2000-2999)
     */
    TOKEN_EXPIRED(2001, "Token Expired"),
    TOKEN_INVALID(2002, "Token Invalid"),
    CREDENTIALS_INVALID(2003, "Invalid Credentials"),
    ACCOUNT_LOCKED(2004, "Account Locked"),
    ACCOUNT_DISABLED(2005, "Account Disabled"),

    /**
     * File operation error codes (3000-3999)
     */
    FILE_UPLOAD_FAILED(3001, "File Upload Failed"),
    FILE_DOWNLOAD_FAILED(3002, "File Download Failed"),
    FILE_SIZE_EXCEEDED(3003, "File Size Exceeded"),
    FILE_TYPE_NOT_ALLOWED(3004, "File Type Not Allowed"),

    /**
     * External integration error codes (4000-4999)
     */
    T24_INTEGRATION_ERROR(4001, "T24 Integration Failed"),
    SEAOPS_INTEGRATION_ERROR(4002, "SeaOps Integration Failed"),
    LOS_INTEGRATION_ERROR(4003, "LOS Integration Failed"),
    E_SIGNATURE_ERROR(4004, "E-Signature Failed"),
    PRINT_SERVICE_ERROR(4005, "Print Service Failed");

    private final Integer code;
    private final String message;

    ResponseCode(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    /**
     * Get enum by code
     */
    public static ResponseCode getByCode(Integer code) {
        if (code == null) {
            return null;
        }
        for (ResponseCode responseCode : values()) {
            if (responseCode.getCode().equals(code)) {
                return responseCode;
            }
        }
        return null;
    }

    /**
     * Check if success status code
     */
    public static boolean isSuccess(Integer code) {
        return code != null && code >= 200 && code < 300;
    }

    /**
     * Check if client error
     */
    public static boolean isClientError(Integer code) {
        return code != null && code >= 400 && code < 500;
    }

    /**
     * Check if server error
     */
    public static boolean isServerError(Integer code) {
        return code != null && code >= 500 && code < 600;
    }
}
