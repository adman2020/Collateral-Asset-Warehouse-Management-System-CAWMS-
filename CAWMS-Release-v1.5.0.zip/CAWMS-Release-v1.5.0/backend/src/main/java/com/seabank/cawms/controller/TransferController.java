package com.seabank.cawms.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.common.ResponseCode;
import com.seabank.cawms.service.TransferService;
import com.seabank.cawms.util.I18nUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transfer")
@Tag(name = "TransferController", description = "抵押资产转移管理API")
public class TransferController {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(TransferController.class);

    private final TransferService transferService;

    @Autowired
    public TransferController(TransferService transferService) {
        this.transferService = transferService;
    }

    @Operation(summary = "Create Transfer")
    @PostMapping
    public ResponseEntity<CommonResponse<TransferService.TransferDetail>> create(
            @RequestBody TransferService.TransferCreateRequest request,
            @RequestHeader("X-User-Id") String userId) {
        log.info("创建转移申请: userId={}", userId);
        try {
            TransferService.TransferDetail detail = transferService.create(request, userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("transfer.createSuccess")));
        } catch (Exception e) {
            log.error("创建转移申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get By Id")
    @GetMapping("/{id}")
    public ResponseEntity<CommonResponse<TransferService.TransferDetail>> getById(
            @PathVariable Long id) {
        log.debug("查询转移详情: id={}", id);
        try {
            TransferService.TransferDetail detail = transferService.getById(id);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("查询转移详情失败", e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(CommonResponse.error(ResponseCode.NOT_FOUND, e.getMessage()));
        }
    }

    @Operation(summary = "Update Transfer")
    @PutMapping("/{id}")
    public ResponseEntity<CommonResponse<TransferService.TransferDetail>> update(
            @PathVariable Long id,
            @RequestBody TransferService.TransferUpdateRequest request,
            @RequestHeader("X-User-Id") String userId) {
        log.info("更新转移申请: id={}, userId={}", id, userId);
        try {
            TransferService.TransferDetail detail = transferService.update(id, request, userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("更新转移申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Delete Transfer")
    @DeleteMapping("/{id}")
    public ResponseEntity<CommonResponse<Boolean>> delete(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String userId) {
        log.info("删除转移申请: id={}, userId={}", id, userId);
        try {
            boolean result = transferService.delete(id, userId);
            return ResponseEntity.ok(CommonResponse.success(result, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("删除转移申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Query Transfers")
    @GetMapping
    public ResponseEntity<CommonResponse<Page<TransferService.TransferDetail>>> query(
            @ModelAttribute TransferService.TransferQuery query) {
        log.debug("查询转移列表: query={}", query);
        try {
            Page<TransferService.TransferDetail> result = transferService.query(query);
            return ResponseEntity.ok(CommonResponse.success(result, "查询成功"));
        } catch (Exception e) {
            log.error("查询转移列表失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Submit Transfer")
    @PostMapping("/submit")
    public ResponseEntity<CommonResponse<TransferService.TransferDetail>> submit(
            @RequestBody SubmitRequest request,
            @RequestHeader("X-User-Id") String userId) {
        log.info("提交转移申请: id={}, userId={}", request.getId(), userId);
        try {
            TransferService.TransferDetail detail = transferService.submit(request.getId(), userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("transfer.submitSuccess")));
        } catch (Exception e) {
            log.error("提交转移申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Approve Transfer")
    @PostMapping("/approve")
    public ResponseEntity<CommonResponse<TransferService.TransferDetail>> approve(
            @RequestBody ApproveRequest request,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader(value = "X-User-Name", required = false) String userName) {
        log.info("审批转移申请: id={}, userId={}", request.getId(), userId);
        try {
            String approverName = userName != null ? userName : userId;
            TransferService.TransferDetail detail = transferService.approve(
                    request.getId(), userId, approverName, request.getApprovalOpinion());
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("transfer.approveSuccess")));
        } catch (Exception e) {
            log.error("审批转移申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Complete Transfer")
    @PostMapping("/{id}/complete")
    public ResponseEntity<CommonResponse<TransferService.TransferDetail>> complete(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String userId) {
        log.info("完成转移: id={}, userId={}", id, userId);
        try {
            TransferService.TransferDetail detail = transferService.complete(id, userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("transfer.completeSuccess")));
        } catch (Exception e) {
            log.error("完成转移失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Cancel Transfer")
    @PostMapping("/{id}/cancel")
    public ResponseEntity<CommonResponse<TransferService.TransferDetail>> cancel(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String userId) {
        log.info("取消转移: id={}, userId={}", id, userId);
        try {
            TransferService.TransferDetail detail = transferService.cancel(id, userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("transfer.cancelSuccess")));
        } catch (Exception e) {
            log.error("取消转移失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get Approval Progress")
    @GetMapping("/{id}/approval-progress")
    public ResponseEntity<CommonResponse<List<TransferService.TransferApproval>>> getApprovalProgress(
            @PathVariable Long id) {
        log.debug("查询审批进度: id={}", id);
        try {
            List<TransferService.TransferApproval> progress = transferService.getApprovalProgress(id);
            return ResponseEntity.ok(CommonResponse.success(progress, "查询成功"));
        } catch (Exception e) {
            log.error("查询审批进度失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get Current Pending Step")
    @GetMapping("/{id}/current-pending-step")
    public ResponseEntity<CommonResponse<TransferService.TransferApproval>> getCurrentPendingStep(
            @PathVariable Long id) {
        log.debug("查询当前待审批步骤: id={}", id);
        try {
            TransferService.TransferApproval step = transferService.getCurrentPendingStep(id);
            return ResponseEntity.ok(CommonResponse.success(step, "查询成功"));
        } catch (Exception e) {
            log.error("查询当前待审批步骤失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get Transfer History")
    @GetMapping("/{id}/history")
    public ResponseEntity<CommonResponse<List<TransferService.TransferHistory>>> getHistory(
            @PathVariable Long id) {
        log.debug("查询转移历史: id={}", id);
        try {
            List<TransferService.TransferHistory> history = transferService.getHistory(id);
            return ResponseEntity.ok(CommonResponse.success(history, "查询成功"));
        } catch (Exception e) {
            log.error("查询转移历史失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get Statistics")
    @GetMapping("/statistics")
    public ResponseEntity<CommonResponse<TransferService.TransferStatistics>> getStatistics() {
        log.debug("查询转移统计");
        try {
            TransferService.TransferStatistics stats = transferService.getStatistics();
            return ResponseEntity.ok(CommonResponse.success(stats, "查询成功"));
        } catch (Exception e) {
            log.error("查询转移统计失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }

    @Operation(summary = "Get Pending Approvals")
    @GetMapping("/pending-approvals")
    public ResponseEntity<CommonResponse<Page<TransferService.TransferDetail>>> getPendingApprovals(
            @RequestParam(required = false) String approverRole,
            @RequestParam(required = false) String approverUser,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        log.debug("查询待审批列表: approverRole={}, approverUser={}", approverRole, approverUser);
        try {
            Page<TransferService.TransferDetail> result = transferService.getPendingApprovals(approverRole, approverUser, page, size);
            return ResponseEntity.ok(CommonResponse.success(result, "查询成功"));
        } catch (Exception e) {
            log.error("查询待审批列表失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }

    @Operation(summary = "Get My Applications")
    @GetMapping("/my-applications")
    public ResponseEntity<CommonResponse<Page<TransferService.TransferDetail>>> getMyApplications(
            @RequestHeader("X-User-Id") String userId,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        log.debug("查询我的申请: userId={}, status={}", userId, status);
        try {
            Page<TransferService.TransferDetail> result = transferService.getMyApplications(userId, status, page, size);
            return ResponseEntity.ok(CommonResponse.success(result, "查询成功"));
        } catch (Exception e) {
            log.error("查询我的申请失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }

    @Operation(summary = "获取我的审批列表")
    @GetMapping("/my-approvals")
    public ResponseEntity<CommonResponse<Page<TransferService.TransferDetail>>> getMyApprovals(
            @RequestParam(required = false) String approverUser,
            @RequestParam(required = false) String approverRole,
            @RequestParam String type,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        log.debug("获取我的转移审批列表: type={}, approverUser={}, approverRole={}", type, approverUser, approverRole);
        try {
            String role = (approverRole == null || approverRole.isBlank()) ? "ALL" : approverRole;
            Page<TransferService.TransferDetail> result = transferService.getMyApprovals(approverUser, role, type, pageNum, pageSize);
            return ResponseEntity.ok(CommonResponse.success(result, "查询成功"));
        } catch (Exception e) {
            log.error("获取我的转移审批列表失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    static class SubmitRequest {
        private Long id;
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
    }

    static class ApproveRequest {
        private Long id;
        private Integer step;
        private String approvalStatus;
        private String approvalOpinion;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Integer getStep() { return step; }
        public void setStep(Integer step) { this.step = step; }
        public String getApprovalStatus() { return approvalStatus; }
        public void setApprovalStatus(String approvalStatus) { this.approvalStatus = approvalStatus; }
        public String getApprovalOpinion() { return approvalOpinion; }
        public void setApprovalOpinion(String approvalOpinion) { this.approvalOpinion = approvalOpinion; }
    }
}
