package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.SystemUserEntity;
import com.seabank.cawms.entity.TransferApprovalEntity;
import com.seabank.cawms.entity.TransferEntity;
import com.seabank.cawms.entity.WarehouseEntity;
import com.seabank.cawms.entity.WarehouseInEntity;
import com.seabank.cawms.mapper.SystemUserMapper;
import com.seabank.cawms.mapper.TransferApprovalMapper;
import com.seabank.cawms.mapper.TransferMapper;
import com.seabank.cawms.mapper.WarehouseInMapper;
import com.seabank.cawms.mapper.WarehouseMapper;
import com.seabank.cawms.service.TransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class TransferServiceImpl implements TransferService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(TransferServiceImpl.class);

    private final TransferMapper transferMapper;
    private final TransferApprovalMapper transferApprovalMapper;
    private final WarehouseInMapper warehouseInMapper;
    private final WarehouseMapper warehouseMapper;
    private final SystemUserMapper systemUserMapper;

    @Autowired
    public TransferServiceImpl(
            TransferMapper transferMapper,
            TransferApprovalMapper transferApprovalMapper,
            WarehouseInMapper warehouseInMapper,
            WarehouseMapper warehouseMapper,
            SystemUserMapper systemUserMapper) {
        this.transferMapper = transferMapper;
        this.transferApprovalMapper = transferApprovalMapper;
        this.warehouseInMapper = warehouseInMapper;
        this.warehouseMapper = warehouseMapper;
        this.systemUserMapper = systemUserMapper;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TransferDetail create(TransferCreateRequest request, String creator) {
        log.info("创建转移申请: creator={}, warehouseInId={}", creator, request.getWarehouseInId());

        WarehouseInEntity warehouseIn = warehouseInMapper.selectById(request.getWarehouseInId());
        if (warehouseIn == null) {
            throw new IllegalArgumentException("入库记录不存在: " + request.getWarehouseInId());
        }

        WarehouseEntity sourceWh = warehouseMapper.selectById(warehouseIn.getWarehouseId());
        WarehouseEntity targetWh = warehouseMapper.selectById(request.getTargetWarehouseId());
        if (targetWh == null) {
            throw new IllegalArgumentException("目标仓库不存在: " + request.getTargetWarehouseId());
        }
        if (sourceWh != null && sourceWh.getId().equals(targetWh.getId())) {
            throw new IllegalArgumentException("源仓库和目标仓库不能相同");
        }

        TransferEntity entity = new TransferEntity();
        entity.setWhInId(request.getWarehouseInId());
        entity.setSourceWhCode(sourceWh != null ? sourceWh.getWarehouseCode() : "");
        entity.setSourceLocation(sourceWh != null ? sourceWh.getWarehouseName() : "");
        entity.setTargetWhCode(targetWh.getWarehouseCode());
        entity.setTargetLocation(targetWh.getWarehouseName());
        entity.setTransferType("CROSS_BRANCH".equals(request.getTransferType()) ? "CROSS_WAREHOUSE" : request.getTransferType());
        entity.setTransferReason(request.getTransferReason());
        entity.setStatus("DRAFT");
        entity.setCreatedBy(creator);
        entity.setCreatedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(creator);

        transferMapper.insert(entity);

        return convertToDetail(entity, warehouseIn, sourceWh, targetWh);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TransferDetail update(Long id, TransferUpdateRequest request, String updater) {
        log.info("更新转移申请: id={}, updater={}", id, updater);

        TransferEntity entity = transferMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("转移记录不存在: " + id);
        }
        if (!"DRAFT".equals(entity.getStatus())) {
            throw new IllegalStateException("只有草稿状态可以编辑");
        }

        if (request.getTargetWarehouseId() != null) {
            WarehouseEntity targetWh = warehouseMapper.selectById(request.getTargetWarehouseId());
            if (targetWh == null) {
                throw new IllegalArgumentException("目标仓库不存在: " + request.getTargetWarehouseId());
            }
            entity.setTargetWhCode(targetWh.getWarehouseCode());
            entity.setTargetLocation(targetWh.getWarehouseName());
        }

        if (StringUtils.hasText(request.getTransferType())) {
            entity.setTransferType("CROSS_BRANCH".equals(request.getTransferType()) ? "CROSS_WAREHOUSE" : request.getTransferType());
        }
        if (StringUtils.hasText(request.getTransferReason())) {
            entity.setTransferReason(request.getTransferReason());
        }
        if (request.getRemarks() != null) {
            entity.setTransferReason(request.getRemarks());
        }
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(updater);

        transferMapper.updateById(entity);
        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(Long id, String deleter) {
        log.info("删除转移申请: id={}, deleter={}", id, deleter);

        TransferEntity entity = transferMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("转移记录不存在: " + id);
        }
        if (!"DRAFT".equals(entity.getStatus()) && !"CANCELLED".equals(entity.getStatus())) {
            throw new IllegalStateException("只有草稿或已取消状态可以删除");
        }

        entity.setDeleted(1);
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(deleter);
        return transferMapper.updateById(entity) > 0;
    }

    @Override
    public TransferDetail getById(Long id) {
        log.debug("查询转移详情: id={}", id);

        TransferEntity entity = transferMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("转移记录不存在: " + id);
        }

        WarehouseInEntity warehouseIn = warehouseInMapper.selectById(entity.getWhInId());
        WarehouseEntity sourceWh = null;
        WarehouseEntity targetWh = null;
        if (StringUtils.hasText(entity.getSourceWhCode())) {
            sourceWh = warehouseMapper.selectOne(
                    new LambdaQueryWrapper<WarehouseEntity>().eq(WarehouseEntity::getWarehouseCode, entity.getSourceWhCode()));
        }
        if (StringUtils.hasText(entity.getTargetWhCode())) {
            targetWh = warehouseMapper.selectOne(
                    new LambdaQueryWrapper<WarehouseEntity>().eq(WarehouseEntity::getWarehouseCode, entity.getTargetWhCode()));
        }

        TransferDetail detail = convertToDetail(entity, warehouseIn, sourceWh, targetWh);
        log.info("转移详情查询完成: id={}, approvalsSize={}", id, detail.getApprovals() != null ? detail.getApprovals().size() : -1);
        return detail;
    }

    @Override
    public Page<TransferDetail> query(TransferQuery query) {
        log.debug("查询转移列表: query={}", query);

        int pageNum = query.getPage() != null && query.getPage() > 0 ? query.getPage() : 1;
        int pageSize = query.getSize() != null && query.getSize() > 0 ? query.getSize() : 10;
        Page<TransferEntity> page = new Page<>(pageNum, pageSize);

        LambdaQueryWrapper<TransferEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TransferEntity::getDeleted, 0);
        if (StringUtils.hasText(query.getStatus())) {
            wrapper.eq(TransferEntity::getStatus, query.getStatus());
        }
        if (StringUtils.hasText(query.getTransferType())) {
            String type = "CROSS_BRANCH".equals(query.getTransferType()) ? "CROSS_WAREHOUSE" : query.getTransferType();
            wrapper.eq(TransferEntity::getTransferType, type);
        }
        if (StringUtils.hasText(query.getStartDate()) && StringUtils.hasText(query.getEndDate())) {
            wrapper.ge(TransferEntity::getCreatedAt, query.getStartDate() + " 00:00:00");
            wrapper.le(TransferEntity::getCreatedAt, query.getEndDate() + " 23:59:59");
        }
        wrapper.orderByDesc(TransferEntity::getCreatedAt);

        Page<TransferEntity> resultPage = transferMapper.selectPage(page, wrapper);

        List<TransferDetail> details = resultPage.getRecords().stream()
                .map(e -> {
                    try {
                        return getById(e.getId());
                    } catch (Exception ex) {
                        log.warn("转换转移记录失败: id={}", e.getId(), ex);
                        return convertToDetail(e, null, null, null);
                    }
                })
                .collect(Collectors.toList());

        Page<TransferDetail> detailPage = new Page<>(resultPage.getCurrent(), resultPage.getSize(), resultPage.getTotal());
        detailPage.setRecords(details);
        return detailPage;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TransferDetail submit(Long id, String submitter) {
        log.info("提交转移申请: id={}, submitter={}", id, submitter);

        TransferEntity entity = transferMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("转移记录不存在: " + id);
        }
        if (!"DRAFT".equals(entity.getStatus()) && !"CANCELLED".equals(entity.getStatus())) {
            throw new IllegalStateException("只有草稿或已取消状态可以提交");
        }

        // 清理旧的审批记录（支持取消后重新提交）
        transferApprovalMapper.deleteByTransferId(id);

        entity.setStatus("SUBMITTED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(submitter);
        transferMapper.updateById(entity);

        // Create approval step 1: 源仓库主管审批出库
        TransferApprovalEntity approval = new TransferApprovalEntity();
        approval.setTransferId(id);
        approval.setStepNumber(1);
        approval.setStepName("源仓库主管审批出库");
        approval.setApproverRole("WAREHOUSE_MANAGER");
        approval.setStatus("PENDING");
        transferApprovalMapper.insert(approval);

        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TransferDetail approve(Long id, String approverId, String approverName, String comments) {
        log.info("审批通过转移申请: id={}, approver={}", id, approverId);

        TransferEntity entity = transferMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("转移记录不存在: " + id);
        }
        if (!"SUBMITTED".equals(entity.getStatus()) && !"PENDING".equals(entity.getStatus())) {
            throw new IllegalStateException("当前状态不可审批");
        }

        TransferApprovalEntity pendingStep = transferApprovalMapper.selectCurrentPendingStep(id);
        if (pendingStep == null) {
            throw new IllegalStateException("没有待审批步骤");
        }

        // 检查审批人是否已经审批过该申请的先前步骤
        List<TransferApprovalEntity> approvedSteps = transferApprovalMapper.selectList(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<TransferApprovalEntity>()
                        .eq(TransferApprovalEntity::getTransferId, id)
                        .eq(TransferApprovalEntity::getStatus, "APPROVED"));
        boolean alreadyApproved = approvedSteps.stream()
                .anyMatch(a -> approverName.equals(a.getApproverUser()));
        if (alreadyApproved) {
            throw new IllegalStateException("您已审批过该申请的先前步骤，不能重复审批");
        }

        pendingStep.setApproverUser(approverName);
        pendingStep.setApproverName(approverName);
        pendingStep.setStatus("APPROVED");
        pendingStep.setApprovalOpinion(comments);
        pendingStep.setApprovalTime(LocalDateTime.now());
        transferApprovalMapper.updateById(pendingStep);

        int currentStep = pendingStep.getStepNumber();
        if (currentStep == 1) {
            // 第1步审批通过，创建第2步：目标仓库主管确认入库
            TransferApprovalEntity step2 = new TransferApprovalEntity();
            step2.setTransferId(id);
            step2.setStepNumber(2);
            step2.setStepName("目标仓库主管确认入库");
            step2.setApproverRole("WAREHOUSE_MANAGER");
            step2.setStatus("PENDING");
            transferApprovalMapper.insert(step2);

            entity.setStatus("SUBMITTED");
        } else if (currentStep == 2) {
            // 第2步审批通过，转移完成，更新入库记录位置
            entity.setStatus("COMPLETED");
            entity.setTransferDate(LocalDate.now());

            WarehouseInEntity warehouseIn = warehouseInMapper.selectById(entity.getWhInId());
            if (warehouseIn != null) {
                WarehouseEntity targetWh = warehouseMapper.selectOne(
                        new LambdaQueryWrapper<WarehouseEntity>()
                                .eq(WarehouseEntity::getWarehouseCode, entity.getTargetWhCode()));
                if (targetWh != null) {
                    warehouseIn.setWarehouseId(targetWh.getId());
                    // keep original whCode, only update warehouse location
                    warehouseIn.setZoneId(targetWh.getZoneId());
                    warehouseIn.setUpdatedBy(approverId);
                    warehouseInMapper.updateById(warehouseIn);
                }
            }
        }

        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(approverId);
        transferMapper.updateById(entity);

        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TransferDetail reject(Long id, String rejectorId, String rejectorName, String comments) {
        log.info("拒绝转移申请: id={}, rejector={}", id, rejectorId);

        TransferEntity entity = transferMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("转移记录不存在: " + id);
        }
        if (!"SUBMITTED".equals(entity.getStatus()) && !"PENDING".equals(entity.getStatus())) {
            throw new IllegalStateException("当前状态不可拒绝");
        }

        TransferApprovalEntity pendingStep = transferApprovalMapper.selectCurrentPendingStep(id);
        if (pendingStep != null) {
            pendingStep.setApproverUser(rejectorId);
            pendingStep.setApproverName(rejectorName);
            pendingStep.setStatus("REJECTED");
            pendingStep.setApprovalOpinion(comments);
            pendingStep.setApprovalTime(LocalDateTime.now());
            // updated_at not in DB schema
            transferApprovalMapper.updateById(pendingStep);
        }

        entity.setStatus("CANCELLED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(rejectorId);
        transferMapper.updateById(entity);

        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TransferDetail complete(Long id, String operator) {
        log.info("完成转移: id={}, operator={}", id, operator);

        TransferEntity entity = transferMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("转移记录不存在: " + id);
        }
        if (!"APPROVED".equals(entity.getStatus())) {
            throw new IllegalStateException("只有已审批状态可以完成");
        }

        entity.setStatus("COMPLETED");
        entity.setTransferDate(LocalDate.now());
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(operator);
        transferMapper.updateById(entity);

        // 更新入库记录的仓库信息到目标仓库
        WarehouseInEntity warehouseIn = warehouseInMapper.selectById(entity.getWhInId());
        if (warehouseIn != null) {
            WarehouseEntity targetWh = warehouseMapper.selectOne(
                    new LambdaQueryWrapper<WarehouseEntity>()
                            .eq(WarehouseEntity::getWarehouseCode, entity.getTargetWhCode()));
            if (targetWh != null) {
                warehouseIn.setWarehouseId(targetWh.getId());
                warehouseIn.setWhCode(targetWh.getWarehouseCode());
                warehouseInMapper.updateById(warehouseIn);
            }
        }

        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TransferDetail cancel(Long id, String operator) {
        log.info("取消转移: id={}, operator={}", id, operator);

        TransferEntity entity = transferMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("转移记录不存在: " + id);
        }
        if ("COMPLETED".equals(entity.getStatus())) {
            throw new IllegalStateException("已完成状态不可取消");
        }

        entity.setStatus("CANCELLED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(operator);
        transferMapper.updateById(entity);

        // 记录取消操作到审批历史
        TransferApprovalEntity cancelRecord = new TransferApprovalEntity();
        cancelRecord.setTransferId(id);
        cancelRecord.setStepNumber(0);
        cancelRecord.setStepName("取消申请");
        cancelRecord.setApproverRole("OPERATOR");
        cancelRecord.setApproverUser(operator);
        cancelRecord.setStatus("CANCELLED");
        cancelRecord.setApprovalOpinion("用户取消申请");
        cancelRecord.setApprovalTime(LocalDateTime.now());
        transferApprovalMapper.insert(cancelRecord);

        return getById(id);
    }

    @Override
    public List<TransferApproval> getApprovalProgress(Long transferId) {
        log.debug("查询审批进度: transferId={}", transferId);

        List<TransferApprovalEntity> entities = transferApprovalMapper.selectList(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<TransferApprovalEntity>()
                        .eq(TransferApprovalEntity::getTransferId, transferId));
        return entities.stream().map(this::convertToApprovalDto).collect(Collectors.toList());
    }

    @Override
    public TransferApproval getCurrentPendingStep(Long transferId) {
        log.debug("查询当前待审批步骤: transferId={}", transferId);

        TransferApprovalEntity entity = transferApprovalMapper.selectCurrentPendingStep(transferId);
        if (entity == null) {
            return null;
        }
        return convertToApprovalDto(entity);
    }

    @Override
    public TransferStatistics getStatistics() {
        log.debug("查询转移统计");

        TransferStatistics stats = new TransferStatistics();
        List<Map<String, Object>> statusCounts = transferMapper.countByStatus();

        Map<String, Integer> byStatus = new HashMap<>();
        int total = 0;
        int pendingApprovals = 0;
        for (Map<String, Object> row : statusCounts) {
            String status = (String) row.get("status");
            Integer count = ((Number) row.get("count")).intValue();
            byStatus.put(status != null ? status : "UNKNOWN", count);
            total += count;
            if ("SUBMITTED".equals(status) || "PENDING".equals(status)) {
                pendingApprovals += count;
            }
        }

        Map<String, Integer> byType = new HashMap<>();
        byType.put("INTERNAL", 0);
        byType.put("CROSS_WAREHOUSE", 0);

        stats.setTotal(total);
        stats.setByStatus(byStatus);
        stats.setByType(byType);
        stats.setPendingApprovals(pendingApprovals);

        Long todayCount = transferMapper.countToday();
        stats.setCompletedToday(todayCount != null ? todayCount.intValue() : 0);

        return stats;
    }

    @Override
    public Page<TransferDetail> getPendingApprovals(String approverRole, String approverUser, Integer pageNum, Integer pageSize) {
        log.debug("查询待审批列表: approverRole={}, approverUser={}", approverRole, approverUser);

        int pn = pageNum != null && pageNum > 0 ? pageNum : 1;
        int ps = pageSize != null && pageSize > 0 ? pageSize : 10;
        Page<TransferEntity> page = new Page<>(pn, ps);

        LambdaQueryWrapper<TransferEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TransferEntity::getDeleted, 0);
        wrapper.in(TransferEntity::getStatus, "SUBMITTED", "PENDING");
        wrapper.orderByDesc(TransferEntity::getCreatedAt);

        Page<TransferEntity> resultPage = transferMapper.selectPage(page, wrapper);
        List<TransferDetail> details = resultPage.getRecords().stream()
                .map(e -> {
                    try {
                        return getById(e.getId());
                    } catch (Exception ex) {
                        return convertToDetail(e, null, null, null);
                    }
                })
                .collect(Collectors.toList());

        Page<TransferDetail> detailPage = new Page<>(resultPage.getCurrent(), resultPage.getSize(), resultPage.getTotal());
        detailPage.setRecords(details);
        return detailPage;
    }

    @Override
    public Page<TransferDetail> getMyApplications(String userId, String status, Integer pageNum, Integer pageSize) {
        log.debug("查询我的申请: userId={}, status={}", userId, status);

        int pn = pageNum != null && pageNum > 0 ? pageNum : 1;
        int ps = pageSize != null && pageSize > 0 ? pageSize : 10;
        Page<TransferEntity> page = new Page<>(pn, ps);

        LambdaQueryWrapper<TransferEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TransferEntity::getDeleted, 0);
        wrapper.eq(TransferEntity::getCreatedBy, userId);
        if (StringUtils.hasText(status) && !"ALL".equals(status)) {
            wrapper.eq(TransferEntity::getStatus, status);
        }
        wrapper.orderByDesc(TransferEntity::getCreatedAt);

        Page<TransferEntity> resultPage = transferMapper.selectPage(page, wrapper);
        List<TransferDetail> details = resultPage.getRecords().stream()
                .map(e -> {
                    try {
                        return getById(e.getId());
                    } catch (Exception ex) {
                        return convertToDetail(e, null, null, null);
                    }
                })
                .collect(Collectors.toList());

        Page<TransferDetail> detailPage = new Page<>(resultPage.getCurrent(), resultPage.getSize(), resultPage.getTotal());
        detailPage.setRecords(details);
        return detailPage;
    }

    @Override
    public Page<TransferDetail> getMyApprovals(String approverUser, String approverRole, String type, Integer pageNum, Integer pageSize) {
        log.debug("获取我的转移审批列表: type={}, approverUser={}, approverRole={}", type, approverUser, approverRole);

        List<TransferEntity> records;
        if ("pending".equals(type)) {
            if ("ALL".equals(approverRole) || approverRole == null || approverRole.isBlank()) {
                records = transferMapper.selectAllPending(approverUser);
            } else {
                records = transferMapper.selectPendingByApproverRole(approverRole, approverUser);
            }
        } else if ("ongoing".equals(type)) {
            records = transferMapper.selectMyApprovedOngoing(approverUser);
        } else {
            records = transferMapper.selectMyHistory(approverUser);
        }

        int current = pageNum != null ? pageNum : 1;
        int size = pageSize != null ? pageSize : 10;
        int total = records.size();
        int pages = (int) Math.ceil((double) total / size);
        int start = (current - 1) * size;
        int end = Math.min(start + size, total);

        Page<TransferDetail> resultPage = new Page<>();
        resultPage.setCurrent(current);
        resultPage.setSize(size);
        resultPage.setTotal(total);
        resultPage.setPages(pages);

        if (start < total) {
            List<TransferDetail> details = records.subList(start, end).stream()
                    .map(e -> convertToDetail(e, null, null, null))
                    .collect(Collectors.toList());
            resultPage.setRecords(details);
        } else {
            resultPage.setRecords(Collections.emptyList());
        }

        return resultPage;
    }

    @Override
    public List<TransferHistory> getHistory(Long transferId) {
        log.debug("查询转移历史: transferId={}", transferId);
        // Return approval records as history for now
        List<TransferApprovalEntity> approvals = transferApprovalMapper.selectList(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<TransferApprovalEntity>()
                        .eq(TransferApprovalEntity::getTransferId, transferId));
        List<TransferHistory> history = new ArrayList<>();
        for (TransferApprovalEntity a : approvals) {
            TransferHistory h = new TransferHistory();
            h.setId(a.getId());
            h.setTransferId(a.getTransferId());
            h.setOperationType(a.getStatus());
            h.setOperationDesc(a.getStepName());
            h.setOperatorId(a.getApproverUser() != null ? Long.valueOf(a.getApproverUser()) : null);
            h.setOperatorName(a.getApproverName());
            h.setOperationTime(a.getApprovalTime());
            h.setBeforeValue("PENDING");
            h.setAfterValue(a.getStatus());
            history.add(h);
        }
        return history;
    }

    private TransferDetail convertToDetail(TransferEntity entity, WarehouseInEntity warehouseIn,
                                           WarehouseEntity sourceWh, WarehouseEntity targetWh) {
        TransferDetail detail = new TransferDetail();
        detail.setId(entity.getId());
        detail.setTransferNo("TRF-" + entity.getId());
        detail.setWarehouseInId(entity.getWhInId());
        detail.setWarehouseInNo(warehouseIn != null ? warehouseIn.getWhCode() : "");
        detail.setCollateralName(warehouseIn != null ? warehouseIn.getCustomerName() : "");
        detail.setCollateralType(warehouseIn != null ? warehouseIn.getCollateralType() : "");
        detail.setCollateralValue(warehouseIn != null ? warehouseIn.getCollateralValue() : null);
        detail.setSourceWarehouseId(sourceWh != null ? sourceWh.getId() : null);
        detail.setSourceWarehouseName(sourceWh != null ? sourceWh.getWarehouseName() : entity.getSourceWhCode());
        detail.setSourceWarehouseLocation(entity.getSourceLocation());
        detail.setTargetWarehouseId(targetWh != null ? targetWh.getId() : null);
        detail.setTargetWarehouseName(targetWh != null ? targetWh.getWarehouseName() : entity.getTargetWhCode());
        detail.setTargetWarehouseLocation(entity.getTargetLocation());
        detail.setTransferType("CROSS_WAREHOUSE".equals(entity.getTransferType()) ? "CROSS_BRANCH" : entity.getTransferType());
        detail.setTransferReason(entity.getTransferReason());
        detail.setStatus(entity.getStatus());
        String creator = entity.getCreatedBy();
        Long applicantId = null;
        String applicantName = creator;
        if (creator != null) {
            try {
                applicantId = Long.valueOf(creator);
                SystemUserEntity user = systemUserMapper.selectById(applicantId);
                if (user != null) {
                    applicantName = user.getFullName() != null ? user.getFullName() : user.getUsername();
                }
            } catch (NumberFormatException e) {
                // creator is username, not numeric id
                applicantName = creator;
                LambdaQueryWrapper<SystemUserEntity> wrapper = new LambdaQueryWrapper<>();
                wrapper.eq(SystemUserEntity::getUsername, creator);
                SystemUserEntity user = systemUserMapper.selectOne(wrapper);
                if (user != null) {
                    applicantName = user.getFullName() != null ? user.getFullName() : user.getUsername();
                    applicantId = user.getId();
                }
            }
        }
        detail.setApplicantId(applicantId);
        detail.setApplicantName(applicantName);
        detail.setApplyTime(entity.getCreatedAt());
        detail.setActualTransferTime(entity.getTransferDate() != null ? entity.getTransferDate().atStartOfDay() : null);
        detail.setRemarks(entity.getTransferReason());
        detail.setCreateTime(entity.getCreatedAt());
        detail.setUpdateTime(entity.getUpdatedAt());

        // Load approvals
        if (entity.getId() != null) {
            try {
                List<TransferApprovalEntity> approvalEntities = transferApprovalMapper.selectByTransferId(entity.getId());
                log.info("转移详情加载审批记录: transferId={}, count={}", entity.getId(), approvalEntities != null ? approvalEntities.size() : -1);
                List<TransferApproval> approvals = approvalEntities != null ? approvalEntities.stream()
                        .map(this::convertToApprovalDto)
                        .collect(Collectors.toList()) : new ArrayList<>();
                detail.setApprovals(approvals);
            } catch (Exception e) {
                log.warn("加载审批记录失败: transferId={}", entity.getId(), e);
            }
        }

        return detail;
    }

    private TransferApproval convertToApprovalDto(TransferApprovalEntity entity) {
        TransferApproval dto = new TransferApproval();
        dto.setId(entity.getId());
        dto.setTransferId(entity.getTransferId());
        dto.setStep(entity.getStepNumber());
        dto.setStepName(entity.getStepName());
        dto.setApproverRole(entity.getApproverRole());
        dto.setApproverId(null);
        dto.setApproverName(entity.getApproverUser());
        dto.setApprovalStatus(entity.getStatus());
        dto.setApprovalOpinion(entity.getApprovalOpinion());
        dto.setApprovalTime(entity.getApprovalTime());
        dto.setCreateTime(entity.getApprovalTime());
        return dto;
    }
}
