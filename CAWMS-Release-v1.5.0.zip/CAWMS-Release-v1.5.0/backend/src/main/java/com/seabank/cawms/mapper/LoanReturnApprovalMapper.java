package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.LoanReturnApprovalEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 褰掕繕审批记录Mapper鎺ュ彛
 */
@Mapper
public interface LoanReturnApprovalMapper extends BaseMapper<LoanReturnApprovalEntity> {
    
    /**
     * 鏍规嵁借出记录ID鏌ヨ褰掕繕审批记录
     * @param loanOutId 借出记录ID
     * @return 褰掕繕审批记录列表
     */
    List<LoanReturnApprovalEntity> selectByLoanOutId(@Param("loanOutId") Long loanOutId);
    
    /**
     * 鏍规嵁借出记录ID鍜屾楠ょ紪鍙锋煡璇㈠綊杩樺鎵硅褰?     * @param loanOutId 借出记录ID
     * @param stepNumber 步骤编号
     * @return 褰掕繕审批记录
     */
    LoanReturnApprovalEntity selectByLoanOutIdAndStep(
            @Param("loanOutId") Long loanOutId,
            @Param("stepNumber") Integer stepNumber);
    
    /**
     * 鏍规嵁瀹℃壒鐘舵€佹煡璇㈠綊杩樺鎵硅褰?     * @param status 瀹℃壒鐘舵€?     * @return 褰掕繕审批记录列表
     */
    List<LoanReturnApprovalEntity> selectByStatus(@Param("status") String status);
    
    /**
     * 鏍规嵁瀹℃壒浜烘煡璇㈠綊杩樺鎵硅褰?     * @param approverUser 瀹℃壒浜虹敤鎴?     * @return 褰掕繕审批记录列表
     */
    List<LoanReturnApprovalEntity> selectByApproverUser(@Param("approverUser") String approverUser);
    
    /**
     * 鏌ヨ寰呭鎵圭殑褰掕繕审批记录
     * @return 寰呭鎵瑰綊杩樺鎵硅褰曞垪琛?     */

    List<LoanReturnApprovalEntity> selectPendingApprovals();
    
    /**
     * 鏌ヨ鎸囧畾瀹℃壒浜哄緟瀹℃壒鐨勫綊杩樺鎵硅褰?     * @param approverUser 瀹℃壒浜虹敤鎴?     * @return 寰呭鎵瑰綊杩樺鎵硅褰曞垪琛?     */

    List<LoanReturnApprovalEntity> selectPendingApprovalsByUser(@Param("approverUser") String approverUser);
    
    /**
     * 鏌ヨ鎸囧畾审批角色寰呭鎵圭殑褰掕繕审批记录
     * @param approverRole 审批角色
     * @return 寰呭鎵瑰綊杩樺鎵硅褰曞垪琛?     */

    List<LoanReturnApprovalEntity> selectPendingApprovalsByRole(@Param("approverRole") String approverRole);
    
    /**
     * 鏍规嵁姝ラ鍚嶇О鏌ヨ褰掕繕审批记录
     * @param stepName 姝ラ鍚嶇О
     * @return 褰掕繕审批记录列表
     */
    List<LoanReturnApprovalEntity> selectByStepName(@Param("stepName") String stepName);
    
    /**
     * 鏌ヨ鎸囧畾鏃堕棿鑼冨洿鍐呯殑褰掕繕审批记录
     * @param startTime 寮€濮嬫椂闂?     * @param endTime 结束时间
     * @return 褰掕繕审批记录列表
     */
    List<LoanReturnApprovalEntity> selectByTimeRange(
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);
    
    /**
     * 鏌ヨ鎸囧畾鍊熷嚭璁板綍鐨勬渶鏂板綊杩樺鎵硅褰?     * @param loanOutId 借出记录ID
     * @return 鏈€鏂板綊杩樺鎵硅褰?     */

    @Select("SELECT * FROM loan_return_approval WHERE loan_out_id = #{loanOutId} ORDER BY step_number DESC LIMIT 1")
    LoanReturnApprovalEntity selectLatestByLoanOutId(@Param("loanOutId") Long loanOutId);
    
    /**
     * 鏌ヨ鎸囧畾鍊熷嚭璁板綍褰撳墠寰呭鎵圭殑褰掕繕审批记录
     * @param loanOutId 借出记录ID
     * @return 褰撳墠寰呭鎵圭殑褰掕繕审批记录
     */
    @Select("SELECT * FROM loan_return_approval WHERE loan_out_id = #{loanOutId} AND status = 'PENDING' ORDER BY step_number ASC LIMIT 1")
    LoanReturnApprovalEntity selectCurrentPendingByLoanOutId(@Param("loanOutId") Long loanOutId);
    
    /**
     * 缁熻鍚勬楠ゅ鎵规暟閲?     * @return 姝ラ缁熻Map
     */
    @Select("SELECT step_number, COUNT(*) as count FROM loan_return_approval GROUP BY step_number")
    List<Map<String, Object>> countByStepNumber();
    
    /**
     * 缁熻鍚勭姸鎬佸鎵规暟閲?     * @return 鐘舵€佺粺璁ap
     */
    @Select("SELECT status, COUNT(*) as count FROM loan_return_approval GROUP BY status")
    List<Map<String, Object>> countByStatus();
    
    /**
     * 缁熻浠婃棩褰掕繕瀹℃壒鏁伴噺
     * @return 浠婃棩褰掕繕瀹℃壒鏁伴噺
     */
    @Select("SELECT COUNT(*) FROM loan_return_approval WHERE DATE(created_at) = CURDATE()")
    Long countTodayApprovals();
    
    /**
     * 缁熻鏈湀褰掕繕瀹℃壒鏁伴噺
     * @return 鏈湀褰掕繕瀹℃壒鏁伴噺
     */
    @Select("SELECT COUNT(*) FROM loan_return_approval WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())")
    Long countMonthApprovals();
    
    /**
     * 鍒嗛〉鏌ヨ褰掕繕审批记录
     * @param page 鍒嗛〉鍙傛暟
     * @param params 鏌ヨ鍙傛暟
     * @return 鍒嗛〉缁撴灉
     */
    IPage<LoanReturnApprovalEntity> selectReturnApprovalPage(
            Page<LoanReturnApprovalEntity> page,
            @Param("params") Map<String, Object> params);
    
    /**
     * 更新褰掕繕审批记录鐘舵€?     * @param id 璁板綍ID
     * @param status 鐘舵€?     * @param comments 瀹℃壒鎰忚
     * @param approverUser 瀹℃壒浜虹敤鎴?     * @param approverName 瀹℃壒浜哄鍚?     * @param approvedAt 瀹℃壒鏃堕棿
     * @return 褰卞搷琛屾暟
     */
    int updateApprovalStatus(
            @Param("id") Long id,
            @Param("status") String status,
            @Param("comments") String comments,
            @Param("approverUser") String approverUser,
            @Param("approverName") String approverName,
            @Param("approvedAt") LocalDateTime approvedAt);
    
    /**
     * 鎵归噺鎻掑叆褰掕繕审批记录
     * @param approvals 褰掕繕审批记录列表
     * @return 褰卞搷琛屾暟
     */
    int batchInsert(@Param("list") List<LoanReturnApprovalEntity> approvals);
    
    /**
     * 删除鎸囧畾鍊熷嚭璁板綍鐨勬墍鏈夊綊杩樺鎵硅褰?     * @param loanOutId 借出记录ID
     * @return 褰卞搷琛屾暟
     */
    int deleteByLoanOutId(@Param("loanOutId") Long loanOutId);
    
    /**
     * 鏌ヨ褰掕繕审批进度
     * @param loanOutId 借出记录ID
     * @return 褰掕繕审批进度淇℃伅
     */
    @Select("SELECT " +
            "COUNT(*) as total_steps, " +
            "SUM(CASE WHEN status = 'APPROVED' THEN 1 ELSE 0 END) as completed_steps, " +
            "SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as pending_steps " +
            "FROM loan_return_approval WHERE loan_out_id = #{loanOutId}")
    Map<String, Object> getApprovalProgress(@Param("loanOutId") Long loanOutId);
    
    /**
     * 鏌ヨ宸插畬鎴愬綊杩樺鎵圭殑鍊熷嚭璁板綍
     * @return 借出记录ID鍒楄〃
     */
    @Select("SELECT DISTINCT loan_out_id FROM loan_return_approval " +
            "WHERE step_number = 4 AND status = 'APPROVED'")
    List<Long> selectCompletedReturnApprovals();
    
    /**
     * 鏌ヨ杩涜涓綊杩樺鎵圭殑鍊熷嚭璁板綍
     * @return 借出记录ID鍒楄〃
     */
    @Select("SELECT DISTINCT loan_out_id FROM loan_return_approval " +
            "WHERE status IN ('PENDING', 'WAITING')")
    List<Long> selectInProgressReturnApprovals();
}