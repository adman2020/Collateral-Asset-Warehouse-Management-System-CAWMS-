package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.WarehouseInApprovalEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 入库审批记录Mapper接口
 */
@Mapper
public interface WarehouseInApprovalMapper extends BaseMapper<WarehouseInApprovalEntity> {
    
    /**
     * 根据入库记录ID查询审批记录列表
     * @param whInId 入库记录ID
     * @return 审批记录列表
     */
    List<WarehouseInApprovalEntity> selectByWhInId(@Param("whInId") Long whInId);
    
    /**
     * 鏍规嵁入库记录ID鍜屾楠ょ紪鍙锋煡璇㈠鎵硅褰?     * @param whInId 入库记录ID
     * @param stepNumber 步骤编号
     * @return 审批记录
     */
    WarehouseInApprovalEntity selectByWhInIdAndStep(
            @Param("whInId") Long whInId,
            @Param("stepNumber") Integer stepNumber);
    
    /**
     * 鏍规嵁入库记录ID鍜岀姸鎬佹煡璇㈠鎵硅褰?     * @param whInId 入库记录ID
     * @param status 瀹℃壒鐘舵€?     * @return 审批记录列表
     */
    List<WarehouseInApprovalEntity> selectByWhInIdAndStatus(
            @Param("whInId") Long whInId,
            @Param("status") String status);
    
    /**
     * 鏍规嵁审批用户鏌ヨ寰呭鎵硅褰?     * @param approverUser 审批用户
     * @return 审批记录列表
     */
    List<WarehouseInApprovalEntity> selectPendingByApproverUser(@Param("approverUser") String approverUser);
    
    /**
     * 鏍规嵁审批角色鏌ヨ寰呭鎵硅褰?     * @param approverRole 审批角色
     * @return 审批记录列表
     */
    List<WarehouseInApprovalEntity> selectPendingByApproverRole(@Param("approverRole") String approverRole);
    
    /**
     * 更新瀹℃壒鐘舵€?     * @param id 审批记录ID
     * @param status 鏂扮姸鎬?     * @param comments 瀹℃壒鎰忚
     * @param approverName 瀹℃壒浜哄鍚?     * @return 褰卞搷琛屾暟
     */
    int updateStatus(@Param("id") Long id,
                    @Param("status") String status,
                    @Param("comments") String comments,
                    @Param("approverName") String approverName);
    
    /**
     * 缁熻鍏ュ簱璁板綍鐨勫鎵硅繘搴?     * @param whInId 入库记录ID
     * @return 审批进度缁熻
     */
    @Select("SELECT " +
            "COUNT(*) as total_steps, " +
            "SUM(CASE WHEN status = 'APPROVED' THEN 1 ELSE 0 END) as approved_steps, " +
            "SUM(CASE WHEN status = 'REJECTED' THEN 1 ELSE 0 END) as rejected_steps, " +
            "SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as pending_steps " +
            "FROM warehouse_in_approval WHERE wh_in_id = #{whInId}")
    ApprovalProgress countApprovalProgress(@Param("whInId") Long whInId);
    
    /**
     * 鑾峰彇褰撳墠寰呭鎵规楠?     * @param whInId 入库记录ID
     * @return 当前待审批步骤编号，如果没有则返回null
     */
    @Select("SELECT MIN(step_number) FROM warehouse_in_approval " +
            "WHERE wh_in_id = #{whInId} AND status = 'PENDING'")
    Integer getCurrentPendingStep(@Param("whInId") Long whInId);
    
    /**
     * 鑾峰彇宸插畬鎴愬鎵圭殑鏈€楂樻楠?     * @param whInId 入库记录ID
     * @return 鏈€楂樺畬鎴愭楠ょ紪鍙凤紝濡傛灉娌℃湁鍒欒繑鍥?
     */
    @Select("SELECT COALESCE(MAX(step_number), 0) FROM warehouse_in_approval " +
            "WHERE wh_in_id = #{whInId} AND status = 'APPROVED'")
    Integer getHighestApprovedStep(@Param("whInId") Long whInId);
    
    /**
     * 妫€鏌ユ槸鍚﹀瓨鍦ㄦ嫆缁濈殑瀹℃壒
     * @param whInId 入库记录ID
     * @return 鏄惁瀛樺湪鎷掔粷鐨勫鎵?     */

    @Select("SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END " +
            "FROM warehouse_in_approval WHERE wh_in_id = #{whInId} AND status = 'REJECTED'")
    boolean hasRejectedApproval(@Param("whInId") Long whInId);
    
    /**
     * 鑾峰彇瀹℃壒鍘嗗彶锛堟寜鏃堕棿鍊掑簭锛?     * @param whInId 入库记录ID
     * @return 审批记录列表
     */
    List<WarehouseInApprovalEntity> selectApprovalHistory(@Param("whInId") Long whInId);
    
    /**
     * 统计用户的审批工作量
     * @param approverUser 审批用户
     * @param startTime 寮€濮嬫椂闂?     * @param endTime 结束时间
     * @return 瀹℃壒宸ヤ綔閲忕粺璁?     */

    @Select("SELECT " +
            "COUNT(*) as total_tasks, " +
            "SUM(CASE WHEN status = 'APPROVED' THEN 1 ELSE 0 END) as approved_tasks, " +
            "SUM(CASE WHEN status = 'REJECTED' THEN 1 ELSE 0 END) as rejected_tasks, " +
            "AVG(processing_minutes) as avg_processing_time " +
            "FROM warehouse_in_approval " +
            "WHERE approver_user = #{approverUser} " +
            "AND approved_at BETWEEN #{startTime} AND #{endTime}")
    UserWorkload countUserWorkload(@Param("approverUser") String approverUser,
                                   @Param("startTime") String startTime,
                                   @Param("endTime") String endTime);
    
    /**
     * 审批进度缁熻缁撴灉
     */
    class ApprovalProgress {
        private Integer totalSteps;
        private Integer approvedSteps;
        private Integer rejectedSteps;
        private Integer pendingSteps;
        
        // Getters and Setters
        public Integer getTotalSteps() {
            return totalSteps;
        }
        
        public void setTotalSteps(Integer totalSteps) {
            this.totalSteps = totalSteps;
        }
        
        public Integer getApprovedSteps() {
            return approvedSteps;
        }
        
        public void setApprovedSteps(Integer approvedSteps) {
            this.approvedSteps = approvedSteps;
        }
        
        public Integer getRejectedSteps() {
            return rejectedSteps;
        }
        
        public void setRejectedSteps(Integer rejectedSteps) {
            this.rejectedSteps = rejectedSteps;
        }
        
        public Integer getPendingSteps() {
            return pendingSteps;
        }
        
        public void setPendingSteps(Integer pendingSteps) {
            this.pendingSteps = pendingSteps;
        }
    }
    
    /**
     * 鐢ㄦ埛宸ヤ綔閲忕粺璁＄粨鏋?     */

    class UserWorkload {
        private Integer totalTasks;
        private Integer approvedTasks;
        private Integer rejectedTasks;
        private Double avgProcessingTime;
        
        // Getters and Setters
        public Integer getTotalTasks() {
            return totalTasks;
        }
        
        public void setTotalTasks(Integer totalTasks) {
            this.totalTasks = totalTasks;
        }
        
        public Integer getApprovedTasks() {
            return approvedTasks;
        }
        
        public void setApprovedTasks(Integer approvedTasks) {
            this.approvedTasks = approvedTasks;
        }
        
        public Integer getRejectedTasks() {
            return rejectedTasks;
        }
        
        public void setRejectedTasks(Integer rejectedTasks) {
            this.rejectedTasks = rejectedTasks;
        }
        
        public Double getAvgProcessingTime() {
            return avgProcessingTime;
        }
        
        public void setAvgProcessingTime(Double avgProcessingTime) {
            this.avgProcessingTime = avgProcessingTime;
        }
    }
}