package com.seabank.cawms.integration.print;

import com.seabank.cawms.integration.IntegrationService;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 打印服务接口
 */
public interface PrintService extends IntegrationService {
    PrintJobResponse submitPrintJob(PrintJob printJob);
    PrintJobStatus queryPrintJobStatus(String jobId);
    CancelResponse cancelPrintJob(String jobId);
    PrinterStatus queryPrinterStatus(String printerId);
    List<PrinterInfo> queryAvailablePrinters(String location);
    BatchPrintResponse submitBatchPrintJobs(List<PrintJob> jobs);
    PrintDocumentDownload downloadPrintDocument(String jobId);
    List<PrintHistory> queryPrintHistory(PrintHistoryCriteria criteria);
    TemplateValidationResponse validatePrintTemplate(String templateId);

    class PrintJob {
        private String jobId;
        private String documentId;
        private String documentName;
        private String documentType;
        private String templateId;
        private Map<String, Object> templateData;
        private PrintSettings printSettings;
        private String printerId;
        private String priority;
        private Integer copies;
        private String outputFormat;
        private String requester;
        private LocalDateTime requestedTime;
        private Map<String, Object> metadata;
        public String getJobId() { return jobId; }
        public void setJobId(String jobId) { this.jobId = jobId; }
        public String getDocumentId() { return documentId; }
        public void setDocumentId(String documentId) { this.documentId = documentId; }
        public String getDocumentName() { return documentName; }
        public void setDocumentName(String documentName) { this.documentName = documentName; }
        public String getDocumentType() { return documentType; }
        public void setDocumentType(String documentType) { this.documentType = documentType; }
        public String getTemplateId() { return templateId; }
        public void setTemplateId(String templateId) { this.templateId = templateId; }
        public Map<String, Object> getTemplateData() { return templateData; }
        public void setTemplateData(Map<String, Object> templateData) { this.templateData = templateData; }
        public PrintSettings getPrintSettings() { return printSettings; }
        public void setPrintSettings(PrintSettings printSettings) { this.printSettings = printSettings; }
        public String getPrinterId() { return printerId; }
        public void setPrinterId(String printerId) { this.printerId = printerId; }
        public String getPriority() { return priority; }
        public void setPriority(String priority) { this.priority = priority; }
        public Integer getCopies() { return copies; }
        public void setCopies(Integer copies) { this.copies = copies; }
        public String getOutputFormat() { return outputFormat; }
        public void setOutputFormat(String outputFormat) { this.outputFormat = outputFormat; }
        public String getRequester() { return requester; }
        public void setRequester(String requester) { this.requester = requester; }
        public LocalDateTime getRequestedTime() { return requestedTime; }
        public void setRequestedTime(LocalDateTime requestedTime) { this.requestedTime = requestedTime; }
        public Map<String, Object> getMetadata() { return metadata; }
        public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    }

    class PrintSettings {
        private String paperSize;
        private String orientation;
        private Boolean duplex;
        private String colorMode;
        private Integer resolution;
        public String getPaperSize() { return paperSize; }
        public void setPaperSize(String paperSize) { this.paperSize = paperSize; }
        public String getOrientation() { return orientation; }
        public void setOrientation(String orientation) { this.orientation = orientation; }
        public Boolean getDuplex() { return duplex; }
        public void setDuplex(Boolean duplex) { this.duplex = duplex; }
        public String getColorMode() { return colorMode; }
        public void setColorMode(String colorMode) { this.colorMode = colorMode; }
        public Integer getResolution() { return resolution; }
        public void setResolution(Integer resolution) { this.resolution = resolution; }
    }

    class PrintJobResponse {
        private boolean success;
        private String jobId;
        private LocalDateTime submittedTime;
        private String status;
        private String message;
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }
        public String getJobId() { return jobId; }
        public void setJobId(String jobId) { this.jobId = jobId; }
        public LocalDateTime getSubmittedTime() { return submittedTime; }
        public void setSubmittedTime(LocalDateTime submittedTime) { this.submittedTime = submittedTime; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }

    class PrintJobStatus {
        private String jobId;
        private String status;
        private Integer progress;
        public String getJobId() { return jobId; }
        public void setJobId(String jobId) { this.jobId = jobId; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public Integer getProgress() { return progress; }
        public void setProgress(Integer progress) { this.progress = progress; }
    }

    class CancelResponse {
        private boolean success;
        private String jobId;
        private String message;
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }
        public String getJobId() { return jobId; }
        public void setJobId(String jobId) { this.jobId = jobId; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }

    class PrinterStatus {
        private String printerId;
        private String printerName;
        private String status;
        public String getPrinterId() { return printerId; }
        public void setPrinterId(String printerId) { this.printerId = printerId; }
        public String getPrinterName() { return printerName; }
        public void setPrinterName(String printerName) { this.printerName = printerName; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    class PrinterInfo {
        private String printerId;
        private String printerName;
        private String location;
        private String status;
        public String getPrinterId() { return printerId; }
        public void setPrinterId(String printerId) { this.printerId = printerId; }
        public String getPrinterName() { return printerName; }
        public void setPrinterName(String printerName) { this.printerName = printerName; }
        public String getLocation() { return location; }
        public void setLocation(String location) { this.location = location; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    class BatchPrintResponse {
        private boolean success;
        private Integer totalJobs;
        private Integer successfulJobs;
        private Integer failedJobs;
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }
        public Integer getTotalJobs() { return totalJobs; }
        public void setTotalJobs(Integer totalJobs) { this.totalJobs = totalJobs; }
        public Integer getSuccessfulJobs() { return successfulJobs; }
        public void setSuccessfulJobs(Integer successfulJobs) { this.successfulJobs = successfulJobs; }
        public Integer getFailedJobs() { return failedJobs; }
        public void setFailedJobs(Integer failedJobs) { this.failedJobs = failedJobs; }
    }

    class PrintDocumentDownload {
        private String jobId;
        private String downloadUrl;
        public String getJobId() { return jobId; }
        public void setJobId(String jobId) { this.jobId = jobId; }
        public String getDownloadUrl() { return downloadUrl; }
        public void setDownloadUrl(String downloadUrl) { this.downloadUrl = downloadUrl; }
    }

    class PrintHistory {
        private String jobId;
        private String documentName;
        private String status;
        public String getJobId() { return jobId; }
        public void setJobId(String jobId) { this.jobId = jobId; }
        public String getDocumentName() { return documentName; }
        public void setDocumentName(String documentName) { this.documentName = documentName; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    class PrintHistoryCriteria {
        private LocalDateTime startDate;
        private LocalDateTime endDate;
        public LocalDateTime getStartDate() { return startDate; }
        public void setStartDate(LocalDateTime startDate) { this.startDate = startDate; }
        public LocalDateTime getEndDate() { return endDate; }
        public void setEndDate(LocalDateTime endDate) { this.endDate = endDate; }
    }

    class TemplateValidationResponse {
        private boolean valid;
        private String templateId;
        public boolean isValid() { return valid; }
        public void setValid(boolean valid) { this.valid = valid; }
        public String getTemplateId() { return templateId; }
        public void setTemplateId(String templateId) { this.templateId = templateId; }
    }
}
