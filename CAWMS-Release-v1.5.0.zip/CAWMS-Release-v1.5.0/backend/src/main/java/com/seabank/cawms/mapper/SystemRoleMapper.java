package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.SystemRoleEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 系统角色Mapper接口
 */
@Mapper
public interface SystemRoleMapper extends BaseMapper<SystemRoleEntity> {
}
