package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.TransferEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface TransferMapper extends BaseMapper<TransferEntity> {

    List<TransferEntity> selectByStatus(@Param("status") String status);

    IPage<TransferEntity> selectTransferPage(
            Page<TransferEntity> page,
            @Param("params") Map<String, Object> params);

    @Select("SELECT status, COUNT(*) as count FROM collateral_transfer WHERE deleted = 0 GROUP BY status")
    List<Map<String, Object>> countByStatus();

    @Select("SELECT COUNT(*) FROM collateral_transfer WHERE deleted = 0 AND status = 'COMPLETED' AND transfer_date = CURDATE()")
    Long countToday();

    @Select("SELECT COUNT(*) FROM collateral_transfer WHERE deleted = 0 AND status = 'PENDING'")
    Long countPending();

    @Select("SELECT DISTINCT t.* FROM collateral_transfer t " +
            "JOIN transfer_approval a ON t.id = a.transfer_id " +
            "WHERE t.deleted = 0 AND a.status = 'PENDING' " +
            "AND a.approver_role = #{approverRole} " +
            "AND NOT EXISTS (SELECT 1 FROM transfer_approval a2 WHERE a2.transfer_id = t.id AND a2.approver_user = #{approverUser} AND a2.status = 'APPROVED') " +
            "ORDER BY t.created_at DESC")
    List<TransferEntity> selectPendingByApproverRole(@Param("approverRole") String approverRole, @Param("approverUser") String approverUser);

    @Select("SELECT DISTINCT t.* FROM collateral_transfer t " +
            "JOIN transfer_approval a ON t.id = a.transfer_id " +
            "WHERE t.deleted = 0 AND a.status = 'PENDING' " +
            "AND NOT EXISTS (SELECT 1 FROM transfer_approval a2 WHERE a2.transfer_id = t.id AND a2.approver_user = #{approverUser} AND a2.status = 'APPROVED') " +
            "ORDER BY t.created_at DESC")
    List<TransferEntity> selectAllPending(@Param("approverUser") String approverUser);

    @Select("SELECT DISTINCT t.* FROM collateral_transfer t " +
            "JOIN transfer_approval a ON t.id = a.transfer_id " +
            "WHERE t.deleted = 0 AND t.status = 'SUBMITTED' " +
            "AND a.status = 'APPROVED' AND a.approver_user = #{approverUser} " +
            "ORDER BY t.created_at DESC")
    List<TransferEntity> selectMyApprovedOngoing(@Param("approverUser") String approverUser);

    @Select("SELECT DISTINCT t.* FROM collateral_transfer t " +
            "JOIN transfer_approval a ON t.id = a.transfer_id " +
            "WHERE t.deleted = 0 AND t.status IN ('APPROVED', 'COMPLETED', 'REJECTED') " +
            "AND a.status = 'APPROVED' AND a.approver_user = #{approverUser} " +
            "ORDER BY t.created_at DESC")
    List<TransferEntity> selectMyHistory(@Param("approverUser") String approverUser);
}
