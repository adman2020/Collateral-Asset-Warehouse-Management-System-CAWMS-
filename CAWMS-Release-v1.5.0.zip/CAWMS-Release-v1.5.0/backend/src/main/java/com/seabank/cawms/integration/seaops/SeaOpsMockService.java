package com.seabank.cawms.integration.seaops;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SeaOps Mock鏈嶅姟瀹炵幇
 * 鐢ㄤ簬寮€鍙戝拰娴嬭瘯鐜锛屾ā鎷熸捣娲嬭繍钀ョ郴缁熺殑琛屼负
 */
@Service
@Profile("demo")
public class SeaOpsMockService implements SeaOpsIntegrationService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(SeaOpsMockService.class);

    private final Random random = new Random();
    private final Map<String, CargoInfo> cargoInfos = new ConcurrentHashMap<>();
    private final Map<String, VesselInfo> vesselInfos = new ConcurrentHashMap<>();
    private final Map<String, RouteInfo> routeInfos = new ConcurrentHashMap<>();
    private final Map<String, PortInfo> portInfos = new ConcurrentHashMap<>();
    private final Map<String, TransportPlan> transportPlans = new ConcurrentHashMap<>();
    private final Map<String, TransportStatus> transportStatuses = new ConcurrentHashMap<>();
    private final Map<String, CargoLocation> cargoLocations = new ConcurrentHashMap<>();
    private String lastError;
    
    public SeaOpsMockService() {
        initializeMockData();
    }
    
    private void initializeMockData() {
        log.info("处理条件");
        
        // TODO: fix encoding comment
        initializePortInfos();
        
        // TODO: fix encoding comment
        initializeVesselInfos();
        
        // TODO: fix encoding comment
        initializeRouteInfos();
        
        // TODO: fix encoding comment
        initializeCargoInfos();
        
        // TODO: fix encoding comment
        initializeTransportPlans();
        
        // TODO: fix encoding comment
        initializeCargoLocations();
        
        log.info("处理条件");
    }
    
    private void initializePortInfos() {
        // TODO: fix encoding comment
        PortInfo catLai = createPortInfo("VNCAT", "Cat Lai Port", "Vietnam", "Ho Chi Minh City",
                new BigDecimal("10.754"), new BigDecimal("106.792"), "SEAPORT", 13, 12,
                List.of("Container", "Bulk", "General Cargo"), "Saigon Newport", "+84 28 3773 8888",
                "info@catlaiport.vn", "OPERATIONAL");
        portInfos.put("VNCAT", catLai);
        
        PortInfo haiPhong = createPortInfo("VNHPH", "Hai Phong Port", "Vietnam", "Hai Phong",
                new BigDecimal("20.862"), new BigDecimal("106.683"), "SEAPORT", 11, 8,
                List.of("Container", "Bulk"), "Hai Phong Port Authority", "+84 225 382 9111",
                "info@haiphongport.com.vn", "OPERATIONAL");
        portInfos.put("VNHPH", haiPhong);
        
        PortInfo daNang = createPortInfo("VNDAD", "Da Nang Port", "Vietnam", "Da Nang",
                new BigDecimal("16.068"), new BigDecimal("108.221"), "SEAPORT", 10, 6,
                List.of("Container", "General Cargo"), "Da Nang Port Authority", "+84 236 382 2888",
                "info@danangport.com.vn", "OPERATIONAL");
        portInfos.put("VNDAD", daNang);
        
        // TODO: fix encoding comment
        PortInfo singapore = createPortInfo("SGSIN", "Singapore Port", "Singapore", "Singapore",
                new BigDecimal("1.265"), new BigDecimal("103.820"), "SEAPORT", 16, 50,
                List.of("Container", "Bulk", "Oil", "LNG"), "PSA International", "+65 6270 8888",
                "info@psa.com.sg", "OPERATIONAL");
        portInfos.put("SGSIN", singapore);
        
        // TODO: fix encoding comment
        PortInfo shanghai = createPortInfo("CNSHA", "Shanghai Port", "China", "Shanghai",
                new BigDecimal("31.239"), new BigDecimal("121.499"), "SEAPORT", 15, 40,
                List.of("Container", "Bulk", "General Cargo"), "Shanghai Port Authority", "+86 21 6329 0666",
                "info@shport.gov.cn", "OPERATIONAL");
        portInfos.put("CNSHA", shanghai);
    }
    
    private PortInfo createPortInfo(String portCode, String portName, String country, String city,
                                    BigDecimal latitude, BigDecimal longitude, String portType,
                                    Integer maxDraft, Integer berths, List<String> handlingCapabilities,
                                    String portOperator, String contactNumber, String email, String portStatus) {
        PortInfo portInfo = new PortInfo();
        portInfo.setPortCode(portCode);
        portInfo.setPortName(portName);
        portInfo.setCountry(country);
        portInfo.setCity(city);
        portInfo.setLatitude(latitude);
        portInfo.setLongitude(longitude);
        portInfo.setPortType(portType);
        portInfo.setMaxDraft(maxDraft);
        portInfo.setBerths(berths);
        portInfo.setHandlingCapabilities(handlingCapabilities);
        portInfo.setPortOperator(portOperator);
        portInfo.setContactNumber(contactNumber);
        portInfo.setEmail(email);
        portInfo.setPortStatus(portStatus);
        return portInfo;
    }
    
    private void initializeVesselInfos() {
        // TODO: fix encoding comment
        VesselInfo vessel1 = createVesselInfo("VSL001", "SeABank Express", "CONTAINER", "IMO1234567",
                "Vietnam", new BigDecimal("50000"), new BigDecimal("60000"), 300, 40, 12,
                "SeABank Shipping", "SeABank Logistics", "VNCAT", 
                LocalDateTime.now().plusDays(2), LocalDateTime.now().plusDays(3), "AT_PORT",
                List.of("ISPS", "ISM", "ISO 9001"));
        vesselInfos.put("VSL001", vessel1);
        
        VesselInfo vessel2 = createVesselInfo("VSL002", "Vietnam Star", "BULK_CARRIER", "IMO2345678",
                "Singapore", new BigDecimal("80000"), new BigDecimal("100000"), 250, 32, 15,
                "Singapore Shipping Co.", "Global Logistics", "SGSIN", 
                LocalDateTime.now().plusDays(1), LocalDateTime.now().plusDays(2), "IN_TRANSIT",
                List.of("ISPS", "ISM", "MARPOL"));
        vesselInfos.put("VSL002", vessel2);
        
        VesselInfo vessel3 = createVesselInfo("VSL003", "Pacific Voyager", "CONTAINER", "IMO3456789",
                "Panama", new BigDecimal("120000"), new BigDecimal("150000"), 350, 45, 14,
                "Pacific Shipping", "Ocean Transport", "CNSHA", 
                LocalDateTime.now().plusDays(5), LocalDateTime.now().plusDays(6), "AT_SEA",
                List.of("ISPS", "ISM", "ISO 14001"));
        vesselInfos.put("VSL003", vessel3);
    }
    
    private VesselInfo createVesselInfo(String vesselId, String vesselName, String vesselType, String imoNumber,
                                        String flag, BigDecimal grossTonnage, BigDecimal deadweightTonnage,
                                        Integer length, Integer width, Integer draft, String owner, String operator,
                                        String currentLocation, LocalDateTime eta, LocalDateTime etd, 
                                        String vesselStatus, List<String> certifications) {
        VesselInfo vesselInfo = new VesselInfo();
        vesselInfo.setVesselId(vesselId);
        vesselInfo.setVesselName(vesselName);
        vesselInfo.setVesselType(vesselType);
        vesselInfo.setImoNumber(imoNumber);
        vesselInfo.setFlag(flag);
        vesselInfo.setGrossTonnage(grossTonnage);
        vesselInfo.setDeadweightTonnage(deadweightTonnage);
        vesselInfo.setLength(length);
        vesselInfo.setWidth(width);
        vesselInfo.setDraft(draft);
        vesselInfo.setOwner(owner);
        vesselInfo.setOperator(operator);
        vesselInfo.setCurrentLocation(currentLocation);
        vesselInfo.setEta(eta);
        vesselInfo.setEtd(etd);
        vesselInfo.setVesselStatus(vesselStatus);
        vesselInfo.setCertifications(certifications);
        return vesselInfo;
    }
    
    private void initializeRouteInfos() {
        RouteInfo route1 = createRouteInfo("RT001", "Vietnam-Singapore", "VNCAT", "SGSIN", 1200, 3,
                List.of("VNHPH"), "DIRECT", new BigDecimal("150000"), "USD", "ACTIVE",
                List.of("CONTAINER", "BULK_CARRIER"));
        routeInfos.put("RT001", route1);
        
        RouteInfo route2 = createRouteInfo("RT002", "Singapore-Shanghai", "SGSIN", "CNSHA", 2800, 7,
                List.of("VNDAD", "HKHKG"), "MULTIPORT", new BigDecimal("350000"), "USD", "ACTIVE",
                List.of("CONTAINER"));
        routeInfos.put("RT002", route2);
        
        RouteInfo route3 = createRouteInfo("RT003", "Vietnam-China", "VNHPH", "CNSHA", 1600, 5,
                List.of("VNCAT", "VNDAD"), "MULTIPORT", new BigDecimal("250000"), "USD", "ACTIVE",
                List.of("CONTAINER", "GENERAL_CARGO"));
        routeInfos.put("RT003", route3);
    }
    
    private RouteInfo createRouteInfo(String routeId, String routeName, String originPort, String destinationPort,
                                      Integer distanceNauticalMiles, Integer estimatedDays, List<String> intermediatePorts,
                                      String routeType, BigDecimal standardFreightRate, String currency, 
                                      String routeStatus, List<String> supportedVesselTypes) {
        RouteInfo routeInfo = new RouteInfo();
        routeInfo.setRouteId(routeId);
        routeInfo.setRouteName(routeName);
        routeInfo.setOriginPort(originPort);
        routeInfo.setDestinationPort(destinationPort);
        routeInfo.setDistanceNauticalMiles(distanceNauticalMiles);
        routeInfo.setEstimatedDays(estimatedDays);
        routeInfo.setIntermediatePorts(intermediatePorts);
        routeInfo.setRouteType(routeType);
        routeInfo.setStandardFreightRate(standardFreightRate);
        routeInfo.setCurrency(currency);
        routeInfo.setRouteStatus(routeStatus);
        routeInfo.setSupportedVesselTypes(supportedVesselTypes);
        return routeInfo;
    }
    
    private void initializeCargoInfos() {
        // TODO: fix encoding comment
        CargoInfo cargo1 = createCargoInfo("CARGO001", "CONTAINER", "Electronics Components", 
                new BigDecimal("20000"), "KG", new BigDecimal("30"), "CBM", "SeABank Trading",
                "VNCAT-WH01", LocalDateTime.now().minusDays(10), "INSURED", new BigDecimal("500000"),
                "STORED", createCustomsInfo("CLEARED", "IM123456"), 
                List.of("Temperature Controlled", "Fragile"));
        cargoInfos.put("CARGO001", cargo1);
        
        CargoInfo cargo2 = createCargoInfo("CARGO002", "BULK", "Rice", 
                new BigDecimal("50000"), "KG", new BigDecimal("100"), "CBM", "Vietnam Agri Corp",
                "VNCAT-WH02", LocalDateTime.now().minusDays(5), "INSURED", new BigDecimal("100000"),
                "READY_FOR_SHIPMENT", createCustomsInfo("PENDING", "IM234567"), 
                List.of("Keep Dry", "Avoid Moisture"));
        cargoInfos.put("CARGO002", cargo2);
        
        CargoInfo cargo3 = createCargoInfo("CARGO003", "CONTAINER", "Textile Products", 
                new BigDecimal("15000"), "KG", new BigDecimal("25"), "CBM", "Vietnam Textile Inc",
                "VNHPH-WH01", LocalDateTime.now().minusDays(7), "INSURED", new BigDecimal("300000"),
                "IN_TRANSIT", createCustomsInfo("CLEARED", "IM345678"), 
                List.of("Non-Hazardous", "Standard Packaging"));
        cargoInfos.put("CARGO003", cargo3);
        
        CargoInfo cargo4 = createCargoInfo("CARGO004", "GENERAL_CARGO", "Machinery Parts", 
                new BigDecimal("35000"), "KG", new BigDecimal("45"), "CBM", "Vietnam Machinery Co",
                "VNDAD-WH01", LocalDateTime.now().minusDays(3), "NOT_INSURED", new BigDecimal("0"),
                "STORED", createCustomsInfo("IN_PROGRESS", "IM456789"), 
                List.of("Heavy Lift", "Special Handling"));
        cargoInfos.put("CARGO004", cargo4);
    }
    
    private CargoInfo createCargoInfo(String cargoId, String cargoType, String description, 
                                      BigDecimal weight, String weightUnit, BigDecimal volume, String volumeUnit,
                                      String cargoOwner, String storageLocation, LocalDateTime storageDate,
                                      String insuranceStatus, BigDecimal insuredValue, String cargoStatus,
                                      Map<String, Object> customsInfo, List<String> specialRequirements) {
        CargoInfo cargoInfo = new CargoInfo();
        cargoInfo.setCargoId(cargoId);
        cargoInfo.setCargoType(cargoType);
        cargoInfo.setDescription(description);
        cargoInfo.setWeight(weight);
        cargoInfo.setWeightUnit(weightUnit);
        cargoInfo.setVolume(volume);
        cargoInfo.setVolumeUnit(volumeUnit);
        cargoInfo.setCargoOwner(cargoOwner);
        cargoInfo.setStorageLocation(storageLocation);
        cargoInfo.setStorageDate(storageDate);
        cargoInfo.setInsuranceStatus(insuranceStatus);
        cargoInfo.setInsuredValue(insuredValue);
        cargoInfo.setCargoStatus(cargoStatus);
        cargoInfo.setCustomsInfo(customsInfo);
        cargoInfo.setSpecialRequirements(specialRequirements);
        return cargoInfo;
    }
    
    private Map<String, Object> createCustomsInfo(String clearanceStatus, String importDeclaration) {
        Map<String, Object> customsInfo = new HashMap<>();
        customsInfo.put("clearanceStatus", clearanceStatus);
        customsInfo.put("importDeclaration", importDeclaration);
        customsInfo.put("customsValue", new BigDecimal("100000"));
        customsInfo.put("dutyAmount", new BigDecimal("10000"));
        customsInfo.put("taxAmount", new BigDecimal("5000"));
        return customsInfo;
    }
    
    private void initializeTransportPlans() {
        TransportPlan plan1 = createTransportPlan("PLAN001", "Vietnam-Singapore Express", 
                LocalDateTime.now().plusDays(1), "VSL001", "RT001", 
                List.of("CARGO001", "CARGO002"), new BigDecimal("175000"), "USD", 
                "CONFIRMED", LocalDateTime.now().minusDays(2), "logistics.manager");
        transportPlans.put("PLAN001", plan1);
        
        TransportPlan plan2 = createTransportPlan("PLAN002", "Singapore-Shanghai Route", 
                LocalDateTime.now().plusDays(3), "VSL002", "RT002", 
                List.of("CARGO003"), new BigDecimal("380000"), "USD", 
                "PLANNED", LocalDateTime.now().minusDays(1), "transport.coordinator");
        transportPlans.put("PLAN002", plan2);
    }
    
    private TransportPlan createTransportPlan(String planId, String planName, LocalDateTime plannedDate,
                                              String vesselId, String routeId, List<String> cargoIds,
                                              BigDecimal estimatedCost, String currency, String planStatus,
                                              LocalDateTime createdAt, String createdBy) {
        TransportPlan plan = new TransportPlan();
        plan.setPlanId(planId);
        plan.setPlanName(planName);
        plan.setPlannedDate(plannedDate);
        plan.setVesselId(vesselId);
        plan.setRouteId(routeId);
        plan.setCargoIds(cargoIds);
        plan.setEstimatedCost(estimatedCost);
        plan.setCurrency(currency);
        plan.setPlanStatus(planStatus);
        plan.setCreatedAt(createdAt);
        plan.setCreatedBy(createdBy);
        return plan;
    }
    
    private void initializeCargoLocations() {
        // TODO: fix encoding comment
        CargoLocation location1 = createCargoLocation("CARGO001", "VNCAT-WH01", 
                LocalDateTime.now().minusHours(2), "WAREHOUSE", null, "VNCAT",
                new BigDecimal("10.754"), new BigDecimal("106.792"));
        cargoLocations.put("CARGO001", location1);
        
        CargoLocation location2 = createCargoLocation("CARGO002", "VNCAT Terminal", 
                LocalDateTime.now().minusHours(1), "PORT", null, "VNCAT",
                new BigDecimal("10.755"), new BigDecimal("106.793"));
        cargoLocations.put("CARGO002", location2);
        
        CargoLocation location3 = createCargoLocation("CARGO003", "South China Sea", 
                LocalDateTime.now().minusDays(1), "IN_TRANSIT", "VSL002", null,
                new BigDecimal("12.500"), new BigDecimal("110.000"));
        cargoLocations.put("CARGO003", location3);
    }
    
    private CargoLocation createCargoLocation(String cargoId, String location, LocalDateTime timestamp,
                                              String locationType, String vesselId, String portCode,
                                              BigDecimal latitude, BigDecimal longitude) {
        CargoLocation cargoLocation = new CargoLocation();
        cargoLocation.setCargoId(cargoId);
        cargoLocation.setLocation(location);
        cargoLocation.setTimestamp(timestamp);
        cargoLocation.setLocationType(locationType);
        cargoLocation.setVesselId(vesselId);
        cargoLocation.setPortCode(portCode);
        cargoLocation.setLatitude(latitude);
        cargoLocation.setLongitude(longitude);
        return cargoLocation;
    }
    
    @Override
    public String getServiceName() {
        return "SeaOps Mock Service";
    }
    
    @Override
    public boolean isAvailable() {
        return true;
    }
    
    @Override
    public ServiceStatus getStatus() {
        return ServiceStatus.AVAILABLE;
    }
    
    @Override
    public ConnectionTestResult testConnection() {
        long startTime = System.currentTimeMillis();
        
        try {
            Thread.sleep(random.nextInt(200) + 100); // TODO: encoding issue
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        long responseTime = System.currentTimeMillis() - startTime;
        return new ConnectionTestResult(true, responseTime, "SeaOps Mock service connection successful", "Mock v1.0");
    }
    
    @Override
    public String getLastError() {
        return lastError;
    }
    
    @Override
    public CargoInfo queryCargoInfo(String cargoId) {
        log.debug("处理条件", cargoId);
        return cargoInfos.get(cargoId);
    }
    
    @Override
    public VesselInfo queryVesselInfo(String vesselId) {
        log.debug("处理条件", vesselId);
        
        VesselInfo vesselInfo = vesselInfos.get(vesselId);
        if (vesselInfo != null) {
            // TODO: fix encoding comment
            updateVesselPosition(vesselInfo);
        }
        
        return vesselInfo;
    }
    
    private void updateVesselPosition(VesselInfo vesselInfo) {
        // TODO: fix encoding comment
        String[] positions = {"AT_PORT", "IN_TRANSIT", "AT_SEA", "AT_ANCHOR"};
        vesselInfo.setVesselStatus(positions[random.nextInt(positions.length)]);
        
        // TODO: fix encoding comment
        if ("AT_PORT".equals(vesselInfo.getVesselStatus())) {
            vesselInfo.setEtd(LocalDateTime.now().plusHours(random.nextInt(24) + 6));
        } else if ("IN_TRANSIT".equals(vesselInfo.getVesselStatus())) {
            vesselInfo.setEta(LocalDateTime.now().plusDays(random.nextInt(5) + 1));
        }
    }
    
    @Override
    public RouteInfo queryRouteInfo(String routeId) {
        log.debug("处理条件", routeId);
        return routeInfos.get(routeId);
    }
    
    @Override
    public PortInfo queryPortInfo(String portCode) {
        log.debug("处理条件", portCode);
        return portInfos.get(portCode);
    }
    
    @Override
    public TransportPlan queryTransportPlan(String planId) {
        log.debug("处理条件", planId);
        return transportPlans.get(planId);
    }
    
    @Override
    public TransportOrderResponse createTransportOrder(TransportOrderRequest request) {
        log.debug("创建杩愯緭璁㈠崟: cargoId={}, origin={}, destination={}", 
                request.getCargoId(), request.getOriginPort(), request.getDestinationPort());
        
        TransportOrderResponse response = new TransportOrderResponse();
        
        // TODO: fix encoding comment
        CargoInfo cargoInfo = cargoInfos.get(request.getCargoId());
        if (cargoInfo == null) {
            lastError = "Cargo not found: " + request.getCargoId();
            response.setSuccess(false);
            response.setMessage("Cargo not found");
            return response;
        }
        
        // TODO: fix encoding comment
        if (!portInfos.containsKey(request.getOriginPort()) || !portInfos.containsKey(request.getDestinationPort())) {
            lastError = "Invalid port code";
            response.setSuccess(false);
            response.setMessage("Invalid port code");
            return response;
        }
        
        // TODO: fix encoding comment
        try {
            Thread.sleep(random.nextInt(1000) + 500); // TODO: encoding issue
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // TODO: fix encoding comment
        String orderId = "ORD" + System.currentTimeMillis();
        String trackingNumber = "TRK" + (1000000 + random.nextInt(9000000));
        
        // TODO: fix encoding comment
        BigDecimal baseRate = new BigDecimal("100000"); // TODO: fix encoding comment
        BigDecimal weightFactor = cargoInfo.getWeight().divide(new BigDecimal("1000")); // TODO: encoding issue
        BigDecimal volumeFactor = cargoInfo.getVolume().multiply(new BigDecimal("100")); // TODO: encoding issue
        BigDecimal totalCost = baseRate.add(weightFactor).add(volumeFactor);
        
        if (request.isInsuranceRequired()) {
            BigDecimal insuranceCost = request.getDeclaredValue().multiply(new BigDecimal("0.01")); // TODO: encoding issue
        }
        
        // TODO: fix encoding comment
        String assignedVessel = "VSL00" + (random.nextInt(3) + 1);
        
        // TODO: fix encoding comment
        TransportStatus status = new TransportStatus();
        status.setTrackingNumber(trackingNumber);
        status.setCurrentLocation(request.getOriginPort());
        status.setLocationTimestamp(LocalDateTime.now());
        status.setStatus("PICKUP_SCHEDULED");
        status.setNextLocation(request.getDestinationPort());
        status.setEstimatedArrival(LocalDateTime.now().plusDays(random.nextInt(10) + 5));
        status.setActualPickupDate(LocalDateTime.now().plusDays(1));
        
        List<StatusHistory> history = new ArrayList<>();
        StatusHistory historyEntry = new StatusHistory();
        historyEntry.setStatus("ORDER_CREATED");
        historyEntry.setTimestamp(LocalDateTime.now());
        historyEntry.setLocation("SYSTEM");
        historyEntry.setRemarks("Transport order created");
        history.add(historyEntry);
        status.setStatusHistory(history);
        
        transportStatuses.put(trackingNumber, status);
        
        // TODO: fix encoding comment
        cargoInfo.setCargoStatus("SCHEDULED_FOR_TRANSPORT");
        
        // TODO: fix encoding comment
        response.setSuccess(true);
        response.setOrderId(orderId);
        response.setTrackingNumber(trackingNumber);
        response.setOrderDate(LocalDateTime.now());
        response.setTotalCost(totalCost);
        response.setCurrency("USD");
        response.setStatus("CONFIRMED");
        response.setMessage("Transport order created successfully");
        response.setAssignedVessel(assignedVessel);
        response.setEstimatedPickupDate(LocalDateTime.now().plusDays(1));
        response.setEstimatedDeliveryDate(LocalDateTime.now().plusDays(random.nextInt(10) + 5));
        
        if (request.isInsuranceRequired()) {
            response.setInsurancePolicyNumber("INS" + (100000 + random.nextInt(900000)));
        }
        
        log.info("杩愯緭璁㈠崟创建鎴愬姛: orderId={}, trackingNumber={}, totalCost={} USD", 
                orderId, trackingNumber, totalCost);
        
        return response;
    }
    
    @Override
    public TransportStatus queryTransportStatus(String trackingNumber) {
        log.debug("处理条件", trackingNumber);
        
        TransportStatus status = transportStatuses.get(trackingNumber);
        if (status == null) {
            // TODO: fix encoding comment
            status = createMockTransportStatus(trackingNumber);
            transportStatuses.put(trackingNumber, status);
        } else {
            // TODO: fix encoding comment
            updateTransportStatus(status);
        }
        
        return status;
    }
    
    private TransportStatus createMockTransportStatus(String trackingNumber) {
        TransportStatus status = new TransportStatus();
        status.setTrackingNumber(trackingNumber);
        
        String[] statuses = {"PICKUP_SCHEDULED", "IN_TRANSIT", "AT_PORT", "CUSTOMS_CLEARANCE", "DELIVERED"};
        String currentStatus = statuses[random.nextInt(statuses.length)];
        
        status.setStatus(currentStatus);
        status.setLocationTimestamp(LocalDateTime.now().minusDays(random.nextInt(5)));
        
        if ("PICKUP_SCHEDULED".equals(currentStatus)) {
            status.setCurrentLocation("VNCAT");
            status.setNextLocation("SGSIN");
        } else if ("IN_TRANSIT".equals(currentStatus)) {
            status.setCurrentLocation("South China Sea");
            status.setNextLocation("SGSIN");
        } else if ("AT_PORT".equals(currentStatus)) {
            status.setCurrentLocation("SGSIN");
            status.setNextLocation("CNSHA");
        } else if ("CUSTOMS_CLEARANCE".equals(currentStatus)) {
            status.setCurrentLocation("CNSHA");
            status.setNextLocation("Final Destination");
        } else if ("DELIVERED".equals(currentStatus)) {
            status.setCurrentLocation("Final Destination");
            status.setNextLocation("N/A");
            status.setActualDeliveryDate(LocalDateTime.now().minusDays(1));
        }
        
        status.setEstimatedArrival(LocalDateTime.now().plusDays(random.nextInt(7) + 3));
        
        // TODO: fix encoding comment
        List<StatusHistory> history = new ArrayList<>();
        LocalDateTime startTime = LocalDateTime.now().minusDays(10);
        
        for (String s : statuses) {
            if (s.equals(currentStatus)) break;
            
            StatusHistory historyEntry = new StatusHistory();
            historyEntry.setStatus(s);
            historyEntry.setTimestamp(startTime.plusDays(random.nextInt(2)));
            historyEntry.setLocation(getLocationForStatus(s));
            historyEntry.setRemarks("Status updated");
            history.add(historyEntry);
            
            startTime = startTime.plusDays(1);
        }
        
        status.setStatusHistory(history);
        
        return status;
    }
    
    private String getLocationForStatus(String status) {
        switch (status) {
            case "PICKUP_SCHEDULED": return "VNCAT";
            case "IN_TRANSIT": return "South China Sea";
            case "AT_PORT": return "SGSIN";
            case "CUSTOMS_CLEARANCE": return "CNSHA";
            case "DELIVERED": return "Final Destination";
            default: return "Unknown";
        }
    }
    
    private void updateTransportStatus(TransportStatus status) {
        // TODO: fix encoding comment
        String[] statusSequence = {"PICKUP_SCHEDULED", "IN_TRANSIT", "AT_PORT", "CUSTOMS_CLEARANCE", "DELIVERED"};
        int currentIndex = -1;
        
        for (int i = 0; i < statusSequence.length; i++) {
            if (statusSequence[i].equals(status.getStatus())) {
                currentIndex = i;
                break;
            }
        }
        
        // TODO: fix encoding comment
        if (currentIndex >= 0 && currentIndex < statusSequence.length - 1 && random.nextInt(10) < 3) {
            String newStatus = statusSequence[currentIndex + 1];
            status.setStatus(newStatus);
            status.setLocationTimestamp(LocalDateTime.now());
            status.setCurrentLocation(getLocationForStatus(newStatus));
            
            // TODO: fix encoding comment
            StatusHistory historyEntry = new StatusHistory();
            historyEntry.setStatus(newStatus);
            historyEntry.setTimestamp(LocalDateTime.now());
            historyEntry.setLocation(status.getCurrentLocation());
            historyEntry.setRemarks("Status updated automatically");
            
            if (status.getStatusHistory() == null) {
                status.setStatusHistory(new ArrayList<>());
            }
            status.getStatusHistory().add(historyEntry);
            
            // TODO: fix encoding comment
            if ("DELIVERED".equals(newStatus)) {
                status.setActualDeliveryDate(LocalDateTime.now());
            }
            
            log.debug("杩愯緭鐘舵€佹洿鏂? trackingNumber={}, newStatus={}", status.getTrackingNumber(), newStatus);
        }
    }
    
    @Override
    public List<CargoLocation> batchQueryCargoLocations(List<String> cargoIds) {
        log.debug("处理条件", cargoIds);
        
        List<CargoLocation> results = new ArrayList<>();
        for (String cargoId : cargoIds) {
            CargoLocation location = cargoLocations.get(cargoId);
            if (location != null) {
                // TODO: fix encoding comment
                location.setTimestamp(LocalDateTime.now());
                results.add(location);
            }
        }
        
        return results;
    }
    
    @Override
    public WeatherInfo queryWeatherInfo(String location) {
        log.debug("处理条件", location);
        
        WeatherInfo weatherInfo = new WeatherInfo();
        weatherInfo.setLocation(location);
        weatherInfo.setObservationTime(LocalDateTime.now());
        
        // TODO: fix encoding comment
        if (location.contains("Vietnam") || "VNCAT".equals(location) || "VNHPH".equals(location) || "VNDAD".equals(location)) {
            weatherInfo.setTemperature(new BigDecimal("28.5"));
            weatherInfo.setTemperatureUnit("Celsius");
            weatherInfo.setHumidity(75);
            weatherInfo.setWindSpeed(new BigDecimal("12.5"));
            weatherInfo.setWindDirection("East");
            weatherInfo.setWeatherCondition("Partly Cloudy");
            weatherInfo.setPrecipitation(new BigDecimal("0.2"));
            weatherInfo.setVisibility(new BigDecimal("10"));
            weatherInfo.setPressure(new BigDecimal("1013"));
        } else if (location.contains("Singapore") || "SGSIN".equals(location)) {
            weatherInfo.setTemperature(new BigDecimal("30.2"));
            weatherInfo.setTemperatureUnit("Celsius");
            weatherInfo.setHumidity(80);
            weatherInfo.setWindSpeed(new BigDecimal("8.3"));
            weatherInfo.setWindDirection("North");
            weatherInfo.setWeatherCondition("Sunny");
            weatherInfo.setPrecipitation(new BigDecimal("0.1"));
            weatherInfo.setVisibility(new BigDecimal("12"));
            weatherInfo.setPressure(new BigDecimal("1012"));
        } else if (location.contains("China") || "CNSHA".equals(location)) {
            weatherInfo.setTemperature(new BigDecimal("22.8"));
            weatherInfo.setTemperatureUnit("Celsius");
            weatherInfo.setHumidity(65);
            weatherInfo.setWindSpeed(new BigDecimal("15.7"));
            weatherInfo.setWindDirection("North East");
            weatherInfo.setWeatherCondition("Cloudy");
            weatherInfo.setPrecipitation(new BigDecimal("0.5"));
            weatherInfo.setVisibility(new BigDecimal("8"));
            weatherInfo.setPressure(new BigDecimal("1015"));
        } else {
            // TODO: fix encoding comment
            weatherInfo.setTemperature(new BigDecimal("25.0"));
            weatherInfo.setTemperatureUnit("Celsius");
            weatherInfo.setHumidity(70);
            weatherInfo.setWindSpeed(new BigDecimal("10.0"));
            weatherInfo.setWindDirection("Variable");
            weatherInfo.setWeatherCondition("Clear");
            weatherInfo.setPrecipitation(new BigDecimal("0.0"));
            weatherInfo.setVisibility(new BigDecimal("15"));
            weatherInfo.setPressure(new BigDecimal("1013"));
        }
        
        // TODO: fix encoding comment
        weatherInfo.setSunrise(LocalDateTime.now().withHour(6).withMinute(0).withSecond(0));
        weatherInfo.setSunset(LocalDateTime.now().withHour(18).withMinute(30).withSecond(0));
        
        // TODO: fix encoding comment
        List<WeatherForecast> forecast = new ArrayList<>();
        for (int i = 1; i <= 3; i++) {
            WeatherForecast dayForecast = new WeatherForecast();
            dayForecast.setForecastDate(LocalDateTime.now().plusDays(i));
            dayForecast.setHighTemperature(new BigDecimal(weatherInfo.getTemperature().doubleValue() + random.nextInt(5)));
            dayForecast.setLowTemperature(new BigDecimal(weatherInfo.getTemperature().doubleValue() - random.nextInt(5)));
            dayForecast.setWeatherCondition(getRandomWeatherCondition());
            dayForecast.setPrecipitationProbability(new BigDecimal(random.nextInt(50)));
            dayForecast.setWindSpeed(new BigDecimal(random.nextInt(20) + 5));
            dayForecast.setWindDirection(getRandomWindDirection());
            forecast.add(dayForecast);
        }
        weatherInfo.setForecast(forecast);
        
        return weatherInfo;
    }
    
    private String getRandomWeatherCondition() {
        String[] conditions = {"Sunny", "Partly Cloudy", "Cloudy", "Rain", "Thunderstorm", "Fog"};
        return conditions[random.nextInt(conditions.length)];
    }
    
    private String getRandomWindDirection() {
        String[] directions = {"North", "North East", "East", "South East", "South", "South West", "West", "North West"};
        return directions[random.nextInt(directions.length)];
    }
}