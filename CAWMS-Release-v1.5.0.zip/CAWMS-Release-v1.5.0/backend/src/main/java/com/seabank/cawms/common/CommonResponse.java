package com.seabank.cawms.common;


import java.io.Serializable;

/**
 * 閫氱敤鍝嶅簲绫? * @param <T> 响应数据类型
 */
public class CommonResponse<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 鍝嶅簲鐮?     */

    private Integer code;

    /**
     * 响应消息
     */
    private String message;

    /**
     * 响应数据
     */
    private T data;

    /**
     * 鏃堕棿鎴?     */

    private Long timestamp;

    /**
     * 鎴愬姛鏍囧織
     */
    private Boolean success;

    /**
     * 鎴愬姛鍝嶅簲锛堟棤鏁版嵁锛?     */

    public static <T> CommonResponse<T> success() {
        return success(null, "操作成功");
    }

    /**
     * 鎴愬姛鍝嶅簲锛堟湁鏁版嵁锛?     */

    public static <T> CommonResponse<T> success(T data) {
        return success(data, "操作成功");
    }

    /**
     * 鎴愬姛鍝嶅簲锛堣嚜瀹氫箟娑堟伅锛?     */

    public static <T> CommonResponse<T> success(T data, String message) {
        CommonResponse<T> response = new CommonResponse<>();
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMessage(message);
        response.setData(data);
        response.setTimestamp(System.currentTimeMillis());
        response.setSuccess(true);
        return response;
    }

    /**
     * 澶辫触鍝嶅簲
     */
    public static <T> CommonResponse<T> error(String message) {
        return error(ResponseCode.ERROR.getCode(), message);
    }

    /**
     * 失败响应（自定义错误码）
     */
    public static <T> CommonResponse<T> error(Integer code, String message) {
        CommonResponse<T> response = new CommonResponse<>();
        response.setCode(code);
        response.setMessage(message);
        response.setData(null);
        response.setTimestamp(System.currentTimeMillis());
        response.setSuccess(false);
        return response;
    }

    /**
     * 澶辫触鍝嶅簲锛堜娇鐢≧esponseCode鏋氫妇锛?     */

    public static <T> CommonResponse<T> error(ResponseCode responseCode) {
        return error(responseCode.getCode(), responseCode.getMessage());
    }

    /**
     * 澶辫触鍝嶅簲锛堜娇鐢≧esponseCode鏋氫妇锛岃嚜瀹氫箟娑堟伅锛?     */

    public static <T> CommonResponse<T> error(ResponseCode responseCode, String message) {
        CommonResponse<T> response = new CommonResponse<>();
        response.setCode(responseCode.getCode());
        response.setMessage(message);
        response.setData(null);
        response.setTimestamp(System.currentTimeMillis());
        return response;
    }

    /**
     * 判断是否成功
     */
    public boolean isSuccess() {
        if (this.success != null) {
            return this.success;
        }
        return ResponseCode.SUCCESS.getCode().equals(this.code);
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }


    public CommonResponse() {
    }

    public CommonResponse(Integer code, String message, T data, Long timestamp) {
        this.code = code;
        this.message = message;
        this.data = data;
        this.timestamp = timestamp;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}