package com.seabank.cawms.controller;

import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.common.PageResult;
import com.seabank.cawms.entity.AuditLogEntity;
import com.seabank.cawms.entity.SystemConfigEntity;
import com.seabank.cawms.entity.SystemUserEntity;
import com.seabank.cawms.service.AuditLogService;
import com.seabank.cawms.service.SystemConfigService;
import com.seabank.cawms.util.I18nUtil;
import com.seabank.cawms.service.SystemUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * System Management Controller (Audit Logs, Statistics)
 */
@Validated
@RestController
@RequestMapping("/api/system")
@Tag(name = "SystemController", description = "System Management API")
public class SystemController {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(SystemController.class);

    private final AuditLogService auditLogService;
    private final SystemUserService systemUserService;
    private final SystemConfigService systemConfigService;

    public SystemController(AuditLogService auditLogService, SystemUserService systemUserService, SystemConfigService systemConfigService) {
        this.auditLogService = auditLogService;
        this.systemUserService = systemUserService;
        this.systemConfigService = systemConfigService;
    }

    @Operation(summary = "Get Audit Log List")
    @GetMapping("/audit-logs")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<PageResult<AuditLogDto>> getAuditLogs(
            @RequestParam(defaultValue = "1") @Min(1) Integer page,
            @RequestParam(defaultValue = "10") @Min(1) Integer size,
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) String module,
            @RequestParam(required = false) String operation,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {

        String username = null;
        if (userId != null) {
            SystemUserEntity user = systemUserService.getById(userId);
            username = user != null ? user.getUsername() : "__not_found__";
        }

        // Temporarily return empty list due to audit_logs schema mismatch
        PageResult<AuditLogDto> dtoResult = PageResult.of((long) page, (long) size, 0L, List.<AuditLogDto>of());
        return CommonResponse.success(dtoResult);
    }

    @Operation(summary = "Get System Statistics")
    @GetMapping("/statistics")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<SystemStatisticsDto> getStatistics() {
        long totalUsers = systemUserService.count();
        long activeUsers = systemUserService.lambdaQuery()
                .eq(SystemUserEntity::getStatus, "ACTIVE")
                .count();
        long totalRoles = systemUserService.lambdaQuery()
                .select(SystemUserEntity::getRole)
                .groupBy(SystemUserEntity::getRole)
                .list()
                .size();

        long auditLogsToday = 0;
        long auditLogsTotal = 0;

        SystemStatisticsDto dto = new SystemStatisticsDto();
        dto.setTotalUsers((int) totalUsers);
        dto.setActiveUsers((int) activeUsers);
        dto.setTotalRoles((int) totalRoles);
        dto.setTotalPermissions(0);
        dto.setAuditLogsToday((int) auditLogsToday);
        dto.setAuditLogsTotal((int) auditLogsTotal);

        return CommonResponse.success(dto);
    }

    @Operation(summary = "获取系统配置列表")
    @GetMapping("/config")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<List<ConfigDto>> getConfigList() {
        List<SystemConfigEntity> list = systemConfigService.lambdaQuery()
                .eq(SystemConfigEntity::getDeleted, 0)
                .orderByAsc(SystemConfigEntity::getConfigKey)
                .list();
        List<ConfigDto> result = list.stream().map(this::toConfigDto).toList();
        return CommonResponse.success(result);
    }

    @Operation(summary = "更新系统配置")
    @PutMapping("/config/{id}")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<ConfigDto> updateConfig(@PathVariable @NotNull Long id,
                                                   @RequestBody ConfigUpdateRequest request) {
        SystemConfigEntity config = systemConfigService.getById(id);
        if (config == null) {
            return CommonResponse.error(404, I18nUtil.getMessage("system.config.notFound"));
        }
        if (config.getEditable() != null && config.getEditable() == 0) {
            return CommonResponse.error(403, I18nUtil.getMessage("system.config.notEditable"));
        }
        if (request.getConfigValue() != null) {
            config.setConfigValue(request.getConfigValue());
        }
        systemConfigService.updateById(config);
        return CommonResponse.success(toConfigDto(config), I18nUtil.getMessage("system.config.updateSuccess"));
    }

    private ConfigDto toConfigDto(SystemConfigEntity entity) {
        ConfigDto dto = new ConfigDto();
        dto.setId(entity.getId());
        dto.setConfigKey(entity.getConfigKey());
        dto.setConfigValue(entity.getConfigValue());
        dto.setConfigType(entity.getConfigType());
        dto.setDescription(entity.getDescription());
        dto.setEditable(entity.getEditable());
        dto.setCreateTime(entity.getCreatedAt() != null ? entity.getCreatedAt().toString() : null);
        dto.setUpdateTime(entity.getUpdatedAt() != null ? entity.getUpdatedAt().toString() : null);
        return dto;
    }

    public static class ConfigDto {
        private Long id;
        private String configKey;
        private String configValue;
        private String configType;
        private String description;
        private Integer editable;
        private String createTime;
        private String updateTime;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getConfigKey() { return configKey; }
        public void setConfigKey(String configKey) { this.configKey = configKey; }
        public String getConfigValue() { return configValue; }
        public void setConfigValue(String configValue) { this.configValue = configValue; }
        public String getConfigType() { return configType; }
        public void setConfigType(String configType) { this.configType = configType; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public Integer getEditable() { return editable; }
        public void setEditable(Integer editable) { this.editable = editable; }
        public String getCreateTime() { return createTime; }
        public void setCreateTime(String createTime) { this.createTime = createTime; }
        public String getUpdateTime() { return updateTime; }
        public void setUpdateTime(String updateTime) { this.updateTime = updateTime; }
    }

    public static class ConfigUpdateRequest {
        private String configValue;

        public String getConfigValue() { return configValue; }
        public void setConfigValue(String configValue) { this.configValue = configValue; }
    }

    private AuditLogDto toAuditLogDto(AuditLogEntity entity) {
        AuditLogDto dto = new AuditLogDto();
        dto.setId(entity.getId());
        dto.setUserId(entity.getUserId());
        dto.setUserName(entity.getUsername());
        dto.setOperation(entity.getOperation());
        dto.setModule(entity.getModule());
        dto.setMethod(entity.getRequestMethod());
        dto.setParams(null);
        dto.setResult(entity.getStatusCode());
        dto.setIpAddress(entity.getClientIp());
        dto.setUserAgent(entity.getUserAgent());
        dto.setExecutionTime(entity.getExecutionTime());
        dto.setStatus("SUCCESS".equalsIgnoreCase(entity.getAction()) ? "SUCCESS" : "FAILURE");
        dto.setCreateTime(entity.getTimestamp() != null ? entity.getTimestamp().toString() : null);
        return dto;
    }

    // ==================== DTOs ====================

    public static class AuditLogDto {
        private Long id;
        private Long userId;
        private String userName;
        private String operation;
        private String module;
        private String method;
        private String params;
        private String result;
        private String ipAddress;
        private String userAgent;
        private Integer executionTime;
        private String status;
        private String createTime;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }
        public String getUserName() { return userName; }
        public void setUserName(String userName) { this.userName = userName; }
        public String getOperation() { return operation; }
        public void setOperation(String operation) { this.operation = operation; }
        public String getModule() { return module; }
        public void setModule(String module) { this.module = module; }
        public String getMethod() { return method; }
        public void setMethod(String method) { this.method = method; }
        public String getParams() { return params; }
        public void setParams(String params) { this.params = params; }
        public String getResult() { return result; }
        public void setResult(String result) { this.result = result; }
        public String getIpAddress() { return ipAddress; }
        public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }
        public String getUserAgent() { return userAgent; }
        public void setUserAgent(String userAgent) { this.userAgent = userAgent; }
        public Integer getExecutionTime() { return executionTime; }
        public void setExecutionTime(Integer executionTime) { this.executionTime = executionTime; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getCreateTime() { return createTime; }
        public void setCreateTime(String createTime) { this.createTime = createTime; }
    }

    public static class SystemStatisticsDto {
        private Integer totalUsers;
        private Integer activeUsers;
        private Integer totalRoles;
        private Integer totalPermissions;
        private Integer auditLogsToday;
        private Integer auditLogsTotal;

        public Integer getTotalUsers() { return totalUsers; }
        public void setTotalUsers(Integer totalUsers) { this.totalUsers = totalUsers; }
        public Integer getActiveUsers() { return activeUsers; }
        public void setActiveUsers(Integer activeUsers) { this.activeUsers = activeUsers; }
        public Integer getTotalRoles() { return totalRoles; }
        public void setTotalRoles(Integer totalRoles) { this.totalRoles = totalRoles; }
        public Integer getTotalPermissions() { return totalPermissions; }
        public void setTotalPermissions(Integer totalPermissions) { this.totalPermissions = totalPermissions; }
        public Integer getAuditLogsToday() { return auditLogsToday; }
        public void setAuditLogsToday(Integer auditLogsToday) { this.auditLogsToday = auditLogsToday; }
        public Integer getAuditLogsTotal() { return auditLogsTotal; }
        public void setAuditLogsTotal(Integer auditLogsTotal) { this.auditLogsTotal = auditLogsTotal; }
    }
}
