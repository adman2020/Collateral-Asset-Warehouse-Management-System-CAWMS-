package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.seabank.cawms.entity.LoanOutEntity;
import com.seabank.cawms.entity.OverdueAlertConfigEntity;
import com.seabank.cawms.entity.OverdueAlertLogEntity;
import com.seabank.cawms.mapper.LoanOutMapper;
import com.seabank.cawms.mapper.OverdueAlertConfigMapper;
import com.seabank.cawms.mapper.OverdueAlertLogMapper;
import com.seabank.cawms.service.OverdueDetectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 閫炬湡妫€娴嬫湇鍔″疄鐜扮被
 * 浣跨敤Spring @Scheduled瀹炵幇瀹氭椂妫€娴? */

@Service
public class OverdueDetectionServiceImpl implements OverdueDetectionService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(OverdueDetectionServiceImpl.class);

    private final LoanOutMapper loanOutMapper;
    private final OverdueAlertConfigMapper overdueAlertConfigMapper;
    private final OverdueAlertLogMapper overdueAlertLogMapper;
    
    // TODO: fix encoding comment
    private DetectionConfig defaultConfig = new DetectionConfig();
    
    @Autowired
    public OverdueDetectionServiceImpl(
            LoanOutMapper loanOutMapper,
            OverdueAlertConfigMapper overdueAlertConfigMapper,
            OverdueAlertLogMapper overdueAlertLogMapper) {
        this.loanOutMapper = loanOutMapper;
        this.overdueAlertConfigMapper = overdueAlertConfigMapper;
        this.overdueAlertLogMapper = overdueAlertLogMapper;
        
        // TODO: fix encoding comment
        initDefaultConfig();
    }
    
    /**
     * 鍒濆鍖栭粯璁ら厤缃?     */

    private void initDefaultConfig() {
        defaultConfig.setEnabled(true);
        defaultConfig.setCronExpression("处理条件"); // TODO: fix encoding comment
        // TODO: fix encoding comment
        defaultConfig.setRetryCount(3); // TODO: encoding issue
        defaultConfig.setNotificationMethod("SYSTEM_NOTIFICATION"); // TODO: fix encoding comment
        defaultConfig.setAlertTemplate("DEFAULT_OVERDUE_ALERT");
    }
    
    /**
     * 瀹氭椂妫€娴嬩换鍔?- 姣忓ぉ涓婂崍9鐐规墽琛?     */

    @Scheduled(cron = "${overdue.detection.cron:0 0 9 * * ?}")
    @Transactional(rollbackFor = Exception.class)
    public void scheduledDetection() {
        log.info("处理条件");
        
        try {
            // TODO: fix encoding comment
            DetectionConfig config = getDetectionConfig();
            if (!config.getEnabled()) {
                log.info("处理条件");
                return;
            }
            
            // TODO: fix encoding comment
            DetectionResult result = performDetection(config);
            
            log.info("处理条件", 
                    result.getExpiringCount(), result.getOverdueCount(), 
                    result.getWarningGenerated(), result.getStatusUpdated());
            
        } catch (Exception e) {
            log.error("处理条件", e);
        }
    }
    
    /**
     * 鎵ц妫€娴嬮€昏緫
     */
    private DetectionResult performDetection(DetectionConfig config) {
        DetectionResult result = new DetectionResult();
        result.setDetectionDate(LocalDate.now());
        result.setSuccess(true);
        
        // TODO: fix encoding comment
        DetectionResult expiringResult = detectExpiringLoans(config.getDefaultDaysBefore());
        result.setExpiringCount(expiringResult.getExpiringCount());
        result.setExpiringLoans(expiringResult.getExpiringLoans());
        
        // TODO: fix encoding comment
        DetectionResult overdueResult = detectOverdueLoans();
        result.setOverdueCount(overdueResult.getOverdueCount());
        result.setOverdueLoans(overdueResult.getOverdueLoans());
        
        // TODO: fix encoding comment
        List<OverdueAlertLogEntity> generatedAlerts = new ArrayList<>();
        if (config.getGenerateWarnings()) {
            generatedAlerts.addAll(generateExpiringWarnings(expiringResult.getExpiringLoans(), config));
            generatedAlerts.addAll(generateOverdueWarnings(overdueResult.getOverdueLoans(), config));
        }
        result.setGeneratedAlerts(generatedAlerts);
        result.setWarningGenerated(generatedAlerts.size());
        
        // TODO: fix encoding comment
        if (config.getAutoUpdateStatus() && !overdueResult.getOverdueLoans().isEmpty()) {
            List<Long> overdueIds = overdueResult.getOverdueLoans().stream()
                    .map(LoanOutEntity::getId)
                    .collect(Collectors.toList());
            UpdateResult updateResult = updateOverdueStatus(overdueIds);
            result.setStatusUpdated(updateResult.getSuccessCount());
        }
        
        result.setTotalRecords(result.getExpiringCount() + result.getOverdueCount());
        result.setMessage(String.format("处理条件",
                result.getExpiringCount(), result.getOverdueCount(),
                result.getWarningGenerated(), result.getStatusUpdated()));
        
        return result;
    }
    
    @Override
    public DetectionResult detectExpiringLoans(Integer daysBefore) {
        log.debug("妫€娴嬪嵆灏嗗埌鏈熷€熷嚭璁板綍: daysBefore={}", daysBefore);
        
        if (daysBefore == null) {
            daysBefore = defaultConfig.getDefaultDaysBefore();
        }
        
        DetectionResult result = new DetectionResult();
        result.setDetectionDate(LocalDate.now());
        
        try {
            // TODO: fix encoding comment
            LocalDate currentDate = LocalDate.now();
            LocalDate startDate = currentDate.plusDays(daysBefore);
            
            // TODO: fix encoding comment
            LambdaQueryWrapper<LoanOutEntity> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(LoanOutEntity::getStatus, "LOANED")
                  .ge(LoanOutEntity::getExpectedReturnDate, currentDate)
                  .le(LoanOutEntity::getExpectedReturnDate, startDate)
                  .orderByAsc(LoanOutEntity::getExpectedReturnDate);
            
            List<LoanOutEntity> expiringLoans = loanOutMapper.selectList(wrapper);
            
            result.setSuccess(true);
            result.setExpiringCount(expiringLoans.size());
            result.setExpiringLoans(expiringLoans);
            result.setMessage(String.format("鍙戠幇 %d 鏉″嵆灏嗗埌鏈熺殑鍊熷嚭璁板綍", expiringLoans.size()));
            
        } catch (Exception e) {
            log.error("妫€娴嬪嵆灏嗗埌鏈熷€熷嚭璁板綍澶辫触", e);
            result.setSuccess(false);
            result.setMessage("妫€娴嬪嵆灏嗗埌鏈熷€熷嚭璁板綍澶辫触: " + e.getMessage());
        }
        
        return result;
    }
    
    @Override
    public DetectionResult detectOverdueLoans() {
        log.debug("妫€娴嬪凡閫炬湡鍊熷嚭璁板綍");
        
        DetectionResult result = new DetectionResult();
        result.setDetectionDate(LocalDate.now());
        
        try {
            LocalDate currentDate = LocalDate.now();
            
            // TODO: fix encoding comment
            LambdaQueryWrapper<LoanOutEntity> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(LoanOutEntity::getStatus, "LOANED")
                  .lt(LoanOutEntity::getExpectedReturnDate, currentDate)
                  .orderByAsc(LoanOutEntity::getExpectedReturnDate);
            
            List<LoanOutEntity> overdueLoans = loanOutMapper.selectList(wrapper);
            
            result.setSuccess(true);
            result.setOverdueCount(overdueLoans.size());
            result.setOverdueLoans(overdueLoans);
            result.setMessage(String.format("鍙戠幇 %d 鏉″凡閫炬湡鐨勫€熷嚭璁板綍", overdueLoans.size()));
            
        } catch (Exception e) {
            log.error("妫€娴嬪凡閫炬湡鍊熷嚭璁板綍澶辫触", e);
            result.setSuccess(false);
            result.setMessage("妫€娴嬪凡閫炬湡鍊熷嚭璁板綍澶辫触: " + e.getMessage());
        }
        
        return result;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public UpdateResult updateOverdueStatus(List<Long> loanOutIds) {
        log.info("鎵归噺更新閫炬湡鐘舵€? loanOutIds={}", loanOutIds.size());
        
        UpdateResult result = new UpdateResult();
        result.setTotalRecords(loanOutIds.size());
        
        if (loanOutIds == null || loanOutIds.isEmpty()) {
            result.setSuccess(true);
            result.setSuccessCount(0);
            result.setFailCount(0);
            result.setMessage("娌℃湁闇€瑕佹洿鏂扮殑璁板綍");
            return result;
        }
        
        List<Long> successfulIds = new ArrayList<>();
        List<Map<String, Object>> failureDetails = new ArrayList<>();
        
        // TODO: fix encoding comment
        int batchSize = defaultConfig.getBatchSize();
        for (int i = 0; i < loanOutIds.size(); i += batchSize) {
            int end = Math.min(i + batchSize, loanOutIds.size());
            List<Long> batchIds = loanOutIds.subList(i, end);
            
            for (Long loanOutId : batchIds) {
                try {
                    // TODO: fix encoding comment
                    LoanOutEntity loanOut = loanOutMapper.selectById(loanOutId);
                    if (loanOut != null && "LOANED".equals(loanOut.getStatus())) {
                        loanOut.setStatus("OVERDUE");
                        loanOut.setUpdatedAt(LocalDateTime.now());
                        loanOutMapper.updateById(loanOut);
                        successfulIds.add(loanOutId);
                        log.debug("鍊熷嚭璁板綍鐘舵€佹洿鏂颁负OVERDUE: id={}", loanOutId);
                    } else {
                        Map<String, Object> failure = new HashMap<>();
                        failure.put("loanOutId", loanOutId);
                        failure.put("reason", "璁板綍涓嶅瓨鍦ㄦ垨鐘舵€佷笉鏄疞OANED");
                        failureDetails.add(failure);
                    }
                } catch (Exception e) {
                    Map<String, Object> failure = new HashMap<>();
                    failure.put("loanOutId", loanOutId);
                    failure.put("reason", "更新澶辫触: " + e.getMessage());
                    failureDetails.add(failure);
                    log.error("更新鍊熷嚭璁板綍鐘舵€佸け璐? id={}", loanOutId, e);
                }
            }
        }
        
        result.setSuccess(failureDetails.isEmpty());
        result.setSuccessCount(successfulIds.size());
        result.setFailCount(failureDetails.size());
        result.setSuccessfulIds(successfulIds);
        result.setFailureDetails(failureDetails);
        result.setMessage(String.format("更新瀹屾垚: 鎴愬姛 %d 鏉? 澶辫触 %d 鏉?", 
                successfulIds.size(), failureDetails.size()));
        
        return result;
    }
    
    @Override
    public OverdueStatistics getOverdueStatistics() {
        log.debug("处理条件");
        
        OverdueStatistics statistics = new OverdueStatistics();
        statistics.setStatisticsDate(LocalDate.now());
        
        try {
            // TODO: fix encoding comment
            List<LoanOutEntity> allLoans = loanOutMapper.selectList(null);
            
            int totalLoans = allLoans.size();
            int activeLoans = 0;
            int overdueLoans = 0;
            int expiringLoans = 0;
            double totalOverdueValue = 0.0;
            int totalOverdueDays = 0;
            
            LocalDate currentDate = LocalDate.now();
            
            // TODO: fix encoding comment
            Map<String, Integer> overdueByDepartment = new HashMap<>();
            Map<String, Integer> overdueByCollateralType = new HashMap<>();
            List<LoanOutEntity> topOverdueLoans = new ArrayList<>();
            
            for (LoanOutEntity loan : allLoans) {
                String status = loan.getStatus();
                LocalDate expectedDate = loan.getExpectedReturnDate();
                
                if ("LOANED".equals(status) || "OVERDUE".equals(status)) {
                    activeLoans++;
                    
                    if (expectedDate != null) {
                        // TODO: fix encoding comment
                        long daysUntilDue = ChronoUnit.DAYS.between(currentDate, expectedDate);
                        if (daysUntilDue >= 0 && daysUntilDue <= 3) {
                            expiringLoans++;
                        }
                        
                        // TODO: fix encoding comment
                        if (expectedDate.isBefore(currentDate) && "LOANED".equals(status)) {
                            overdueLoans++;
                            long overdueDays = ChronoUnit.DAYS.between(expectedDate, currentDate);
                            totalOverdueDays += overdueDays;
                            
                            // TODO: fix encoding comment
                            // TODO: fix encoding comment
                            
                            // TODO: fix encoding comment
                            // TODO: fix encoding comment
                            String buCode = "DEFAULT_BU";
                            if (StringUtils.hasText(buCode)) {
                                overdueByDepartment.merge(buCode, 1, Integer::sum);
                            }
                            
                            // TODO: fix encoding comment
                            // TODO: fix encoding comment
                            String collateralType = "DEFAULT_COLLATERAL";
                            if (StringUtils.hasText(collateralType)) {
                                overdueByCollateralType.merge(collateralType, 1, Integer::sum);
                            }
                            
                            // TODO: fix encoding comment
                            topOverdueLoans.add(loan);
                        }
                    }
                }
            }
            
            // TODO: fix encoding comment
            double averageOverdueDays = overdueLoans > 0 ? (double) totalOverdueDays / overdueLoans : 0;
            
            // TODO: fix encoding comment
            topOverdueLoans.sort((a, b) -> {
                long daysA = ChronoUnit.DAYS.between(a.getExpectedReturnDate(), currentDate);
                long daysB = ChronoUnit.DAYS.between(b.getExpectedReturnDate(), currentDate);
                return Long.compare(daysB, daysA); // TODO: encoding issue
            });
            
            if (topOverdueLoans.size() > 10) {
                topOverdueLoans = topOverdueLoans.subList(0, 10);
            }
            
            statistics.setTotalLoans(totalLoans);
            statistics.setActiveLoans(activeLoans);
            statistics.setOverdueLoans(overdueLoans);
            statistics.setExpiringLoans(expiringLoans);
            statistics.setTotalOverdueValue(totalOverdueValue);
            statistics.setAverageOverdueDays(averageOverdueDays);
            statistics.setOverdueByDepartment(overdueByDepartment);
            statistics.setOverdueByCollateralType(overdueByCollateralType);
            statistics.setTopOverdueLoans(topOverdueLoans);
            
        } catch (Exception e) {
            log.error("处理条件", e);
        }
        
        return statistics;
    }
    
    @Override
    public ManualDetectionResult manualTriggerDetection(Map<String, Object> options) {
        log.info("鎵嬪姩瑙﹀彂閫炬湡妫€娴? options={}", options);
        
        ManualDetectionResult result = new ManualDetectionResult();
        result.setTriggeredBy((String) options.get("triggeredBy"));
        result.setTriggeredAt(LocalDateTime.now());
        
        long startTime = System.currentTimeMillis();
        
        try {
            // TODO: fix encoding comment
            DetectionConfig config = getDetectionConfig();
            
            // TODO: fix encoding comment
            if (options.containsKey("daysBefore")) {
                config.setDefaultDaysBefore((Integer) options.get("daysBefore"));
            }
            if (options.containsKey("autoUpdateStatus")) {
                config.setAutoUpdateStatus((Boolean) options.get("autoUpdateStatus"));
            }
            if (options.containsKey("generateWarnings")) {
                config.setGenerateWarnings((Boolean) options.get("generateWarnings"));
            }
            
            // TODO: fix encoding comment
            DetectionResult detectionResult = performDetection(config);
            
            result.setSuccess(true);
            result.setDetectionResult(detectionResult);
            result.setExecutionTimeMs(System.currentTimeMillis() - startTime);
            
            log.info("处理条件", 
                    result.getExecutionTimeMs(), 
                    detectionResult.getExpiringCount(), 
                    detectionResult.getOverdueCount());
            
        } catch (Exception e) {
            log.error("处理条件", e);
            result.setSuccess(false);
            result.setExecutionTimeMs(System.currentTimeMillis() - startTime);
        }
        
        return result;
    }
    
    @Override
    public DetectionConfig getDetectionConfig() {
        // TODO: fix encoding comment
        try {
            List<OverdueAlertConfigEntity> configs = overdueAlertConfigMapper.selectList(null);
            if (!configs.isEmpty()) {
                OverdueAlertConfigEntity dbConfig = configs.get(0);
                
                DetectionConfig config = new DetectionConfig();
                config.setEnabled(dbConfig.getEnabled() != null ? dbConfig.getEnabled() : true);
                config.setDefaultDaysBefore(dbConfig.getAlertDaysBefore());
                config.setAlertTemplate(dbConfig.getAlertTemplateId());
                config.setNotificationMethod(dbConfig.getAlertMethod());
                // TODO: fix encoding comment
                 
                return config;
            }
        } catch (Exception e) {
            log.warn("处理条件", e);
        }
        
        // TODO: fix encoding comment
        return defaultConfig;
    }
    
    @Override
    public ConfigUpdateResult updateDetectionConfig(DetectionConfig config) {
        log.info("处理条件");
        
        ConfigUpdateResult result = new ConfigUpdateResult();
        
        try {
            DetectionConfig oldConfig = getDetectionConfig();
            
            // TODO: fix encoding comment
            this.defaultConfig = config;
            
            // TODO: fix encoding comment
            List<OverdueAlertConfigEntity> configs = overdueAlertConfigMapper.selectList(null);
            OverdueAlertConfigEntity dbConfig;
            
            if (configs.isEmpty()) {
                dbConfig = new OverdueAlertConfigEntity();
                dbConfig.setAlertDaysBefore(config.getDefaultDaysBefore());
                dbConfig.setEnabled(config.getEnabled());
                dbConfig.setAlertMethod(config.getNotificationMethod());
                dbConfig.setAlertTemplateId(config.getAlertTemplate());
                dbConfig.setCreatedAt(LocalDateTime.now());
                dbConfig.setUpdatedAt(LocalDateTime.now());
                overdueAlertConfigMapper.insert(dbConfig);
            } else {
                dbConfig = configs.get(0);
                dbConfig.setAlertDaysBefore(config.getDefaultDaysBefore());
                dbConfig.setEnabled(config.getEnabled());
                dbConfig.setAlertMethod(config.getNotificationMethod());
                dbConfig.setAlertTemplateId(config.getAlertTemplate());
                dbConfig.setUpdatedAt(LocalDateTime.now());
                overdueAlertConfigMapper.updateById(dbConfig);
            }
            
            result.setSuccess(true);
            result.setOldConfig(oldConfig);
            result.setNewConfig(config);
            result.setUpdatedAt(LocalDateTime.now());
            result.setMessage("处理条件");
            
            log.info("处理条件");
            
        } catch (Exception e) {
            log.error("处理条件", e);
            result.setSuccess(false);
            result.setMessage("处理条件" + e.getMessage());
        }
        
        return result;
    }
    
    // TODO: fix encoding comment
    
    /**
     * 鐢熸垚鍗冲皢鍒版湡预警记录
     */
    private List<OverdueAlertLogEntity> generateExpiringWarnings(
            List<LoanOutEntity> expiringLoans, DetectionConfig config) {
        List<OverdueAlertLogEntity> alerts = new ArrayList<>();
        
        if (expiringLoans == null || expiringLoans.isEmpty()) {
            return alerts;
        }
        
        for (LoanOutEntity loan : expiringLoans) {
            try {
                OverdueAlertLogEntity alert = createAlertLog(loan, "WARNING", config);
                alerts.add(alert);
                overdueAlertLogMapper.insert(alert);
                log.debug("处理条件", 
                        loan.getId(), loan.getExpectedReturnDate());
            } catch (Exception e) {
                log.error("处理条件", loan.getId(), e);
            }
        }
        
        return alerts;
    }
    
    /**
     * 鐢熸垚閫炬湡预警记录
     */
    private List<OverdueAlertLogEntity> generateOverdueWarnings(
            List<LoanOutEntity> overdueLoans, DetectionConfig config) {
        List<OverdueAlertLogEntity> alerts = new ArrayList<>();
        
        if (overdueLoans == null || overdueLoans.isEmpty()) {
            return alerts;
        }
        
        for (LoanOutEntity loan : overdueLoans) {
            try {
                OverdueAlertLogEntity alert = createAlertLog(loan, "OVERDUE", config);
                alerts.add(alert);
                overdueAlertLogMapper.insert(alert);
                log.debug("处理条件", 
                        loan.getId(), loan.getExpectedReturnDate());
            } catch (Exception e) {
                log.error("处理条件", loan.getId(), e);
            }
        }
        
        return alerts;
    }
    
    /**
     * 创建预警记录
     */
    private OverdueAlertLogEntity createAlertLog(
            LoanOutEntity loan, String alertType, DetectionConfig config) {
        OverdueAlertLogEntity alert = new OverdueAlertLogEntity();
        
        alert.setLoanOutId(loan.getId());
        alert.setAlertType(alertType);
        
        // TODO: fix encoding comment
        LocalDate currentDate = LocalDate.now();
        LocalDate expectedDate = loan.getExpectedReturnDate();
        long daysDiff = ChronoUnit.DAYS.between(currentDate, expectedDate);
        
        String message;
        if ("WARNING".equals(alertType)) {
            message = String.format("处理条件", 
                    loan.getCustomerName(), expectedDate, Math.abs(daysDiff));
        } else {
            long overdueDays = ChronoUnit.DAYS.between(expectedDate, currentDate);
            message = String.format("处理条件", 
                    loan.getCustomerName(), expectedDate, overdueDays);
        }
        alert.setAlertMessage(message);
        
        alert.setAlertTime(LocalDateTime.now());
        alert.setSentStatus("PENDING");
        alert.setSendMethod(config.getNotificationMethod());
        alert.setCreatedAt(LocalDateTime.now());
        alert.setUpdatedAt(LocalDateTime.now());
        
        // TODO: fix encoding comment
        // TODO: fix encoding comment
        alert.setRecipients("[\"warehouse_manager@seabank.com\", \"risk_officer@seabank.com\"]");
        
        return alert;
    }
}