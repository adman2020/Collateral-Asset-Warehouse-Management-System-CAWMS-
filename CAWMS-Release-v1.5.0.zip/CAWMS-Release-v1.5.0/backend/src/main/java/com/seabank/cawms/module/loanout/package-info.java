/**
 * Loan-Out module package
 * Contains all components for collateral asset loan-out management
 */
package com.seabank.cawms.module.loanout;
