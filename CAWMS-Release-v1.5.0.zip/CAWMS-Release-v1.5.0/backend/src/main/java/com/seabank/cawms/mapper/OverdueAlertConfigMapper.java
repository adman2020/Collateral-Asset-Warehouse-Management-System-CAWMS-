package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.OverdueAlertConfigEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * 閫炬湡预警配置Mapper鎺ュ彛
 */
@Mapper
public interface OverdueAlertConfigMapper extends BaseMapper<OverdueAlertConfigEntity> {
    
    /**
     * 鏌ヨ鎵€鏈夊惎鐢ㄧ殑预警配置
     * @return 鍚敤閰嶇疆鍒楄〃
     */
    List<OverdueAlertConfigEntity> selectEnabledConfigs();
    
    /**
     * 鏍规嵁棰勮澶╂暟鏌ヨ閰嶇疆
     * @param alertDaysBefore 棰勮澶╂暟
     * @return 閰嶇疆鍒楄〃
     */
    List<OverdueAlertConfigEntity> selectByAlertDays(@Param("alertDaysBefore") Integer alertDaysBefore);
    
    /**
     * 鏍规嵁棰勮鏂瑰紡鏌ヨ閰嶇疆
     * @param alertMethod 棰勮鏂瑰紡
     * @return 閰嶇疆鍒楄〃
     */
    List<OverdueAlertConfigEntity> selectByAlertMethod(@Param("alertMethod") String alertMethod);
    
    /**
     * 鏌ヨ榛樿閰嶇疆锛堟寜鍚敤鐘舵€佸拰创建鏃堕棿鎺掑簭鐨勭涓€涓厤缃級
     * @return 榛樿閰嶇疆
     */
    @Select("SELECT * FROM overdue_alert_config WHERE enabled = TRUE ORDER BY created_at LIMIT 1")
    OverdueAlertConfigEntity selectDefaultConfig();
    
    /**
     * 更新閰嶇疆鍚敤鐘舵€?     * @param id 閰嶇疆ID
     * @param enabled 鍚敤鐘舵€?     * @param updatedBy 更新浜?     * @return 褰卞搷琛屾暟
     */
    int updateEnabledStatus(
            @Param("id") Long id,
            @Param("enabled") Boolean enabled,
            @Param("updatedBy") String updatedBy);
    
    /**
     * 更新閰嶇疆棰勮澶╂暟
     * @param id 閰嶇疆ID
     * @param alertDaysBefore 棰勮澶╂暟
     * @param updatedBy 更新浜?     * @return 褰卞搷琛屾暟
     */
    int updateAlertDays(
            @Param("id") Long id,
            @Param("alertDaysBefore") Integer alertDaysBefore,
            @Param("updatedBy") String updatedBy);
    
    /**
     * 更新閰嶇疆鎺ユ敹浜?     * @param id 閰嶇疆ID
     * @param alertRecipients 鎺ユ敹浜哄垪琛?     * @param updatedBy 更新浜?     * @return 褰卞搷琛屾暟
     */
    int updateRecipients(
            @Param("id") Long id,
            @Param("alertRecipients") String alertRecipients,
            @Param("updatedBy") String updatedBy);
    
    /**
     * 缁熻鍚敤鍜岀鐢ㄩ厤缃暟閲?     * @return 缁熻Map
     */
    @Select("SELECT enabled, COUNT(*) as count FROM overdue_alert_config GROUP BY enabled")
    List<Map<String, Object>> countByEnabledStatus();
    
    /**
     * 鏌ヨ鏈€鏂伴厤缃紙鎸夋洿鏂版椂闂存帓搴忥級
     * @return 鏈€鏂伴厤缃?     */

    @Select("SELECT * FROM overdue_alert_config ORDER BY updated_at DESC LIMIT 1")
    OverdueAlertConfigEntity selectLatestConfig();
}