package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.LoanOutApprovalEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 鍊熷嚭审批记录Mapper鎺ュ彛
 */
@Mapper
public interface LoanOutApprovalMapper extends BaseMapper<LoanOutApprovalEntity> {
    
    /**
     * 鏍规嵁借出记录ID鏌ヨ审批记录
     * @param loanOutId 借出记录ID
     * @return 审批记录列表
     */
    List<LoanOutApprovalEntity> selectByLoanOutId(@Param("loanOutId") Long loanOutId);
    
    /**
     * 鏍规嵁借出记录ID鍜屾楠ょ紪鍙锋煡璇㈠鎵硅褰?     * @param loanOutId 借出记录ID
     * @param stepNumber 步骤编号
     * @return 审批记录
     */
    LoanOutApprovalEntity selectByLoanOutIdAndStep(
            @Param("loanOutId") Long loanOutId,
            @Param("stepNumber") Integer stepNumber);
    
    /**
     * 鏍规嵁瀹℃壒鐘舵€佹煡璇㈠鎵硅褰?     * @param status 瀹℃壒鐘舵€?     * @return 审批记录列表
     */
    List<LoanOutApprovalEntity> selectByStatus(@Param("status") String status);
    
    /**
     * 鏍规嵁瀹℃壒浜烘煡璇㈠鎵硅褰?     * @param approverUser 瀹℃壒浜虹敤鎴?     * @return 审批记录列表
     */
    List<LoanOutApprovalEntity> selectByApproverUser(@Param("approverUser") String approverUser);
    
    /**
     * 鏍规嵁审批角色鏌ヨ审批记录
     * @param approverRole 审批角色
     * @return 审批记录列表
     */
    List<LoanOutApprovalEntity> selectByApproverRole(@Param("approverRole") String approverRole);
    
    /**
     * 鏌ヨ鎸囧畾鏃堕棿娈靛唴鐨勫鎵硅褰?     * @param startTime 寮€濮嬫椂闂?     * @param endTime 结束时间
     * @return 审批记录列表
     */
    List<LoanOutApprovalEntity> selectByTimeRange(
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);
    
    /**
     * 鏌ヨ寰呭鎵圭殑璁板綍锛堟寜借出记录ID鍒嗙粍锛?     * @return 寰呭鎵硅褰曞垪琛?     */

    List<LoanOutApprovalEntity> selectPendingApprovals();
    
    /**
     * 鏌ヨ宸插畬鎴愬鎵圭殑璁板綍
     * @return 宸插畬鎴愬鎵硅褰曞垪琛?     */

    List<LoanOutApprovalEntity> selectCompletedApprovals();
    
    /**
     * 鏌ヨ鎸囧畾鍊熷嚭璁板綍鐨勫綋鍓嶅鎵规楠?     * @param loanOutId 借出记录ID
     * @return 褰撳墠瀹℃壒姝ラ
     */
    @Select("SELECT * FROM loan_out_approval WHERE loan_out_id = #{loanOutId} AND status = 'PENDING' ORDER BY step_number LIMIT 1")
    LoanOutApprovalEntity selectCurrentStep(@Param("loanOutId") Long loanOutId);
    
    /**
     * 鏌ヨ鎸囧畾鍊熷嚭璁板綍鐨勬渶澶ф楠ょ紪鍙?     * @param loanOutId 借出记录ID
     * @return 鏈€澶ф楠ょ紪鍙?     */

    @Select("SELECT MAX(step_number) FROM loan_out_approval WHERE loan_out_id = #{loanOutId}")
    Integer selectMaxStepNumber(@Param("loanOutId") Long loanOutId);
    
    /**
     * 鏌ヨ鎸囧畾鍊熷嚭璁板綍鏄惁鎵€鏈夋楠ら兘宸插畬鎴?     * @param loanOutId 借出记录ID
     * @return 鏄惁鍏ㄩ儴瀹屾垚
     */
    @Select("SELECT COUNT(*) = 0 FROM loan_out_approval WHERE loan_out_id = #{loanOutId} AND status = 'PENDING'")
    Boolean isAllStepsCompleted(@Param("loanOutId") Long loanOutId);
    
    /**
     * 缁熻鍚勭姸鎬佸鎵硅褰曟暟閲?     * @return 鐘舵€佺粺璁ap
     */
    @Select("SELECT status, COUNT(*) as count FROM loan_out_approval GROUP BY status")
    List<Map<String, Object>> countByStatus();
    
    /**
     * 缁熻鍚勮鑹插鎵硅褰曟暟閲?     * @return 角色缁熻Map
     */
    @Select("SELECT approver_role, COUNT(*) as count FROM loan_out_approval GROUP BY approver_role")
    List<Map<String, Object>> countByApproverRole();
    
    /**
     * 鍒嗛〉鏌ヨ审批记录锛堝甫鍏宠仈鏌ヨ锛?     * @param page 鍒嗛〉鍙傛暟
     * @param params 鏌ヨ鍙傛暟
     * @return 鍒嗛〉缁撴灉
     */
    IPage<LoanOutApprovalEntity> selectApprovalPage(
            Page<LoanOutApprovalEntity> page,
            @Param("params") Map<String, Object> params);
    
    /**
     * 更新审批记录鐘舵€?     * @param id 璁板綍ID
     * @param status 鏂扮姸鎬?     * @param comments 瀹℃壒鎰忚
     * @param approvedAt 瀹℃壒鏃堕棿
     * @param approverName 瀹℃壒浜哄鍚?     * @return 褰卞搷琛屾暟
     */
    int updateApprovalStatus(
            @Param("id") Long id,
            @Param("status") String status,
            @Param("comments") String comments,
            @Param("approvedAt") LocalDateTime approvedAt,
            @Param("approverName") String approverName);
    
    /**
     * 鎵归噺鎻掑叆瀹℃壒姝ラ璁板綍
     * @param approvals 审批记录列表
     * @return 褰卞搷琛屾暟
     */
    int batchInsert(@Param("list") List<LoanOutApprovalEntity> approvals);
    
    /**
     * 删除鎸囧畾鍊熷嚭璁板綍鐨勬墍鏈夊鎵硅褰?     * @param loanOutId 借出记录ID
     * @return 褰卞搷琛屾暟
     */
    int deleteByLoanOutId(@Param("loanOutId") Long loanOutId);

    /**
     * 查询待我审批的借出单
     */
    @Select("SELECT DISTINCT l.* FROM collateral_loan_out l " +
            "JOIN loan_out_approval a ON l.id = a.loan_out_id " +
            "WHERE l.deleted = 0 AND a.status = 'PENDING' " +
            "AND a.approver_role = #{approverRole} " +
            "ORDER BY l.updated_at DESC")
    List<com.seabank.cawms.entity.LoanOutEntity> selectPendingByApproverRole(@Param("approverRole") String approverRole);

    /**
     * 查询所有待审批的借出单（管理员用）
     */
    @Select("SELECT DISTINCT l.* FROM collateral_loan_out l " +
            "JOIN loan_out_approval a ON l.id = a.loan_out_id " +
            "WHERE l.deleted = 0 AND a.status = 'PENDING' " +
            "ORDER BY l.updated_at DESC")
    List<com.seabank.cawms.entity.LoanOutEntity> selectAllPending();

    /**
     * 查询我已审批但还在进行中的借出单
     */
    @Select("SELECT DISTINCT l.* FROM collateral_loan_out l " +
            "JOIN loan_out_approval a ON l.id = a.loan_out_id " +
            "WHERE l.deleted = 0 AND l.status = 'PENDING' " +
            "AND a.status = 'APPROVED' AND a.approver_user = #{approverUser} " +
            "ORDER BY l.updated_at DESC")
    List<com.seabank.cawms.entity.LoanOutEntity> selectMyApprovedOngoing(@Param("approverUser") String approverUser);

    /**
     * 查询我已审批且已完结的借出单（审批记录）
     */
    @Select("SELECT DISTINCT l.* FROM collateral_loan_out l " +
            "JOIN loan_out_approval a ON l.id = a.loan_out_id " +
            "WHERE l.deleted = 0 AND l.status IN ('APPROVED', 'LOANED', 'RETURNED', 'REJECTED') " +
            "AND a.status = 'APPROVED' AND a.approver_user = #{approverUser} " +
            "ORDER BY l.updated_at DESC")
    List<com.seabank.cawms.entity.LoanOutEntity> selectMyHistory(@Param("approverUser") String approverUser);
}