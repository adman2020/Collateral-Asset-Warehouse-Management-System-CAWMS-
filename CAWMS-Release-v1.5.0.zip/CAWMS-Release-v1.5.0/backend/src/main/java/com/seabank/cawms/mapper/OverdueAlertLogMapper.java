package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.OverdueAlertLogEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 閫炬湡预警记录Mapper鎺ュ彛
 */
@Mapper
public interface OverdueAlertLogMapper extends BaseMapper<OverdueAlertLogEntity> {
    
    /**
     * 鏍规嵁借出记录ID鏌ヨ预警记录
     * @param loanOutId 借出记录ID
     * @return 预警记录列表
     */
    List<OverdueAlertLogEntity> selectByLoanOutId(@Param("loanOutId") Long loanOutId);
    
    /**
     * 鏍规嵁预警类型鏌ヨ预警记录
     * @param alertType 预警类型
     * @return 预警记录列表
     */
    List<OverdueAlertLogEntity> selectByAlertType(@Param("alertType") String alertType);
    
    /**
     * 鏍规嵁鍙戦€佺姸鎬佹煡璇㈤璀﹁褰?     * @param sentStatus 鍙戦€佺姸鎬?     * @return 预警记录列表
     */
    List<OverdueAlertLogEntity> selectBySentStatus(@Param("sentStatus") String sentStatus);
    
    /**
     * 鏌ヨ鎸囧畾鏃堕棿娈靛唴鐨勯璀﹁褰?     * @param startTime 寮€濮嬫椂闂?     * @param endTime 结束时间
     * @return 预警记录列表
     */
    List<OverdueAlertLogEntity> selectByTimeRange(
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);
    
    /**
     * 鏌ヨ寰呭彂閫佺殑预警记录
     * @return 寰呭彂閫侀璀﹁褰曞垪琛?     */

    List<OverdueAlertLogEntity> selectPendingAlerts();
    
    /**
     * 鏌ヨ鍙戦€佸け璐ョ殑预警记录
     * @return 鍙戦€佸け璐ラ璀﹁褰曞垪琛?     */

    List<OverdueAlertLogEntity> selectFailedAlerts();
    
    /**
     * 鏌ヨ浠婃棩鍙戦€佺殑预警记录
     * @param today 浠婃棩鏃ユ湡
     * @return 浠婃棩预警记录列表
     */
    List<OverdueAlertLogEntity> selectTodayAlerts(@Param("today") LocalDate today);
    
    /**
     * 鏌ヨ鎸囧畾鍊熷嚭璁板綍鐨勬渶鏂伴璀﹁褰?     * @param loanOutId 借出记录ID
     * @return 鏈€鏂伴璀﹁褰?     */

    @Select("SELECT * FROM overdue_alert_log WHERE loan_out_id = #{loanOutId} ORDER BY alert_time DESC LIMIT 1")
    OverdueAlertLogEntity selectLatestByLoanOutId(@Param("loanOutId") Long loanOutId);
    
    /**
     * 缁熻鍚勯璀︾被鍨嬫暟閲?     * @return 预警类型缁熻Map
     */
    @Select("SELECT alert_type, COUNT(*) as count FROM overdue_alert_log GROUP BY alert_type")
    List<Map<String, Object>> countByAlertType();
    
    /**
     * 缁熻鍚勫彂閫佺姸鎬佹暟閲?     * @return 鍙戦€佺姸鎬佺粺璁ap
     */
    @Select("SELECT sent_status, COUNT(*) as count FROM overdue_alert_log GROUP BY sent_status")
    List<Map<String, Object>> countBySentStatus();
    
    /**
     * 缁熻浠婃棩棰勮鏁伴噺
     * @return 浠婃棩棰勮鏁伴噺
     */
    @Select("SELECT COUNT(*) FROM overdue_alert_log WHERE DATE(alert_time) = CURDATE()")
    Long countTodayAlerts();
    
    /**
     * 缁熻鏈湀棰勮鏁伴噺
     * @return 鏈湀棰勮鏁伴噺
     */
    @Select("SELECT COUNT(*) FROM overdue_alert_log WHERE MONTH(alert_time) = MONTH(CURDATE()) AND YEAR(alert_time) = YEAR(CURDATE())")
    Long countMonthAlerts();
    
    /**
     * 鍒嗛〉鏌ヨ预警记录锛堝甫鍏宠仈鏌ヨ锛?     * @param page 鍒嗛〉鍙傛暟
     * @param params 鏌ヨ鍙傛暟
     * @return 鍒嗛〉缁撴灉
     */
    IPage<OverdueAlertLogEntity> selectAlertLogPage(
            Page<OverdueAlertLogEntity> page,
            @Param("params") Map<String, Object> params);
    
    /**
     * 更新预警记录鍙戦€佺姸鎬?     * @param id 璁板綍ID
     * @param sentStatus 鍙戦€佺姸鎬?     * @param sentTime 鍙戦€佹椂闂?     * @param sendDetails 鍙戦€佽鎯?     * @return 褰卞搷琛屾暟
     */
    int updateSentStatus(
            @Param("id") Long id,
            @Param("sentStatus") String sentStatus,
            @Param("sentTime") LocalDateTime sentTime,
            @Param("sendDetails") String sendDetails);
    
    /**
     * 鎵归噺更新预警记录鍙戦€佺姸鎬?     * @param ids 璁板綍ID鍒楄〃
     * @param sentStatus 鍙戦€佺姸鎬?     * @param sentTime 鍙戦€佹椂闂?     * @return 褰卞搷琛屾暟
     */
    int batchUpdateSentStatus(
            @Param("ids") List<Long> ids,
            @Param("sentStatus") String sentStatus,
            @Param("sentTime") LocalDateTime sentTime);
    
    /**
     * 删除鎸囧畾鍊熷嚭璁板綍鐨勬墍鏈夐璀﹁褰?     * @param loanOutId 借出记录ID
     * @return 褰卞搷琛屾暟
     */
    int deleteByLoanOutId(@Param("loanOutId") Long loanOutId);
    
    /**
     * 删除鎸囧畾鏃ユ湡涔嬪墠鐨勯璀﹁褰曪紙鐢ㄤ簬娓呯悊鍘嗗彶鏁版嵁锛?     * @param beforeDate 鏃ユ湡
     * @return 褰卞搷琛屾暟
     */
    int deleteBeforeDate(@Param("beforeDate") LocalDate beforeDate);
}