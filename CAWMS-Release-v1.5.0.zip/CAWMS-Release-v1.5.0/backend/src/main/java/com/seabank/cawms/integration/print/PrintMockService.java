package com.seabank.cawms.integration.print;

import com.seabank.cawms.integration.IntegrationService;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.*;

@Service
@Profile("demo")
public class PrintMockService implements PrintService {
    @Override
    public String getServiceName() { return "PrintMockService"; }
    @Override
    public boolean isAvailable() { return true; }
    @Override
    public IntegrationService.ServiceStatus getStatus() { return IntegrationService.ServiceStatus.AVAILABLE; }
    @Override
    public IntegrationService.ConnectionTestResult testConnection() { return new IntegrationService.ConnectionTestResult(true, 0L, "OK", "Mock v1.0"); }
    @Override
    public String getLastError() { return null; }
    @Override
    public PrintJobResponse submitPrintJob(PrintJob printJob) {
        PrintJobResponse r = new PrintJobResponse();
        r.setSuccess(true);
        r.setJobId("JOB-" + System.currentTimeMillis());
        r.setStatus("COMPLETED");
        return r;
    }
    @Override
    public PrintJobStatus queryPrintJobStatus(String jobId) {
        PrintJobStatus s = new PrintJobStatus();
        s.setJobId(jobId);
        s.setStatus("COMPLETED");
        return s;
    }
    @Override
    public CancelResponse cancelPrintJob(String jobId) {
        CancelResponse r = new CancelResponse();
        r.setSuccess(true);
        return r;
    }
    @Override
    public PrinterStatus queryPrinterStatus(String printerId) {
        PrinterStatus s = new PrinterStatus();
        s.setPrinterId(printerId);
        s.setStatus("ONLINE");
        return s;
    }
    @Override
    public List<PrinterInfo> queryAvailablePrinters(String location) {
        List<PrinterInfo> list = new ArrayList<>();
        PrinterInfo p = new PrinterInfo();
        p.setPrinterId("P001");
        p.setStatus("ONLINE");
        list.add(p);
        return list;
    }
    @Override
    public BatchPrintResponse submitBatchPrintJobs(List<PrintJob> jobs) {
        BatchPrintResponse r = new BatchPrintResponse();
        r.setSuccess(true);
        return r;
    }
    @Override
    public PrintDocumentDownload downloadPrintDocument(String jobId) {
        PrintDocumentDownload d = new PrintDocumentDownload();
        d.setJobId(jobId);
        return d;
    }
    @Override
    public List<PrintHistory> queryPrintHistory(PrintHistoryCriteria c) { return new ArrayList<>(); }
    @Override
    public TemplateValidationResponse validatePrintTemplate(String templateId) {
        TemplateValidationResponse r = new TemplateValidationResponse();
        r.setValid(true);
        return r;
    }
}
