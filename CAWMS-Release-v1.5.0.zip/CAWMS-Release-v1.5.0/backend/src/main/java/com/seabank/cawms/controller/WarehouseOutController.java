package com.seabank.cawms.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.common.ResponseCode;
import com.seabank.cawms.service.WarehouseOutService;
import com.seabank.cawms.util.I18nUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/warehouse-out")
@Tag(name = "WarehouseOutController", description = "抵押资产出库管理API")
public class WarehouseOutController {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WarehouseOutController.class);

    private final WarehouseOutService warehouseOutService;

    @Autowired
    public WarehouseOutController(WarehouseOutService warehouseOutService) {
        this.warehouseOutService = warehouseOutService;
    }

    @Operation(summary = "Create WarehouseOut")
    @PostMapping
    public ResponseEntity<CommonResponse<WarehouseOutService.WarehouseOutDetail>> create(
            @RequestBody WarehouseOutService.WarehouseOutCreateRequest request,
            @RequestHeader("X-User-Id") String userId) {
        log.info("创建出库申请: userId={}", userId);
        try {
            WarehouseOutService.WarehouseOutDetail detail = warehouseOutService.create(request, userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("warehouseOut.createSuccess")));
        } catch (Exception e) {
            log.error("创建出库申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get By Id")
    @GetMapping("/{id}")
    public ResponseEntity<CommonResponse<WarehouseOutService.WarehouseOutDetail>> getById(
            @PathVariable Long id) {
        log.debug("查询出库详情: id={}", id);
        try {
            WarehouseOutService.WarehouseOutDetail detail = warehouseOutService.getById(id);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("查询出库详情失败", e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(CommonResponse.error(ResponseCode.NOT_FOUND, e.getMessage()));
        }
    }

    @Operation(summary = "Update WarehouseOut")
    @PutMapping("/{id}")
    public ResponseEntity<CommonResponse<WarehouseOutService.WarehouseOutDetail>> update(
            @PathVariable Long id,
            @RequestBody WarehouseOutService.WarehouseOutUpdateRequest request,
            @RequestHeader("X-User-Id") String userId) {
        log.info("更新出库申请: id={}, userId={}", id, userId);
        try {
            WarehouseOutService.WarehouseOutDetail detail = warehouseOutService.update(id, request, userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("更新出库申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Delete WarehouseOut")
    @DeleteMapping("/{id}")
    public ResponseEntity<CommonResponse<Boolean>> delete(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String userId) {
        log.info("删除出库申请: id={}, userId={}", id, userId);
        try {
            boolean result = warehouseOutService.delete(id, userId);
            return ResponseEntity.ok(CommonResponse.success(result, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("删除出库申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Query WarehouseOuts")
    @GetMapping
    public ResponseEntity<CommonResponse<Page<WarehouseOutService.WarehouseOutDetail>>> query(
            @ModelAttribute WarehouseOutService.WarehouseOutQuery query) {
        log.debug("查询出库列表: query={}", query);
        try {
            Page<WarehouseOutService.WarehouseOutDetail> result = warehouseOutService.query(query);
            return ResponseEntity.ok(CommonResponse.success(result, "查询成功"));
        } catch (Exception e) {
            log.error("查询出库列表失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Submit WarehouseOut")
    @PostMapping("/submit")
    public ResponseEntity<CommonResponse<WarehouseOutService.WarehouseOutDetail>> submit(
            @RequestBody SubmitRequest request,
            @RequestHeader("X-User-Id") String userId) {
        log.info("提交出库申请: id={}, userId={}", request.getId(), userId);
        try {
            WarehouseOutService.WarehouseOutDetail detail = warehouseOutService.submit(request.getId(), userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("warehouseOut.submitSuccess")));
        } catch (Exception e) {
            log.error("提交出库申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Approve WarehouseOut")
    @PostMapping("/approve")
    public ResponseEntity<CommonResponse<WarehouseOutService.WarehouseOutDetail>> approve(
            @RequestBody ApproveRequest request,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader(value = "X-User-Name", required = false) String userName) {
        log.info("审批出库申请: id={}, userId={}", request.getId(), userId);
        try {
            String approverName = userName != null ? userName : userId;
            WarehouseOutService.WarehouseOutDetail detail = warehouseOutService.approve(
                    request.getId(), userId, approverName, request.getApprovalOpinion());
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("warehouseOut.approveSuccess")));
        } catch (Exception e) {
            log.error("审批出库申请失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Complete WarehouseOut")
    @PostMapping("/{id}/complete")
    public ResponseEntity<CommonResponse<WarehouseOutService.WarehouseOutDetail>> complete(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String userId) {
        log.info("完成出库: id={}, userId={}", id, userId);
        try {
            WarehouseOutService.WarehouseOutDetail detail = warehouseOutService.complete(id, userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("warehouseOut.completeSuccess")));
        } catch (Exception e) {
            log.error("完成出库失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Cancel WarehouseOut")
    @PostMapping("/{id}/cancel")
    public ResponseEntity<CommonResponse<WarehouseOutService.WarehouseOutDetail>> cancel(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String userId) {
        log.info("取消出库: id={}, userId={}", id, userId);
        try {
            WarehouseOutService.WarehouseOutDetail detail = warehouseOutService.cancel(id, userId);
            return ResponseEntity.ok(CommonResponse.success(detail, I18nUtil.getMessage("warehouseOut.cancelSuccess")));
        } catch (Exception e) {
            log.error("取消出库失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get Approval Progress")
    @GetMapping("/{id}/approval-progress")
    public ResponseEntity<CommonResponse<List<WarehouseOutService.WarehouseOutApproval>>> getApprovalProgress(
            @PathVariable Long id) {
        log.debug("查询审批进度: id={}", id);
        try {
            List<WarehouseOutService.WarehouseOutApproval> progress = warehouseOutService.getApprovalProgress(id);
            return ResponseEntity.ok(CommonResponse.success(progress, "查询成功"));
        } catch (Exception e) {
            log.error("查询审批进度失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get Current Pending Step")
    @GetMapping("/{id}/current-pending-step")
    public ResponseEntity<CommonResponse<WarehouseOutService.WarehouseOutApproval>> getCurrentPendingStep(
            @PathVariable Long id) {
        log.debug("查询当前待审批步骤: id={}", id);
        try {
            WarehouseOutService.WarehouseOutApproval step = warehouseOutService.getCurrentPendingStep(id);
            return ResponseEntity.ok(CommonResponse.success(step, "查询成功"));
        } catch (Exception e) {
            log.error("查询当前待审批步骤失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get WarehouseOut History")
    @GetMapping("/{id}/history")
    public ResponseEntity<CommonResponse<List<WarehouseOutService.WarehouseOutHistory>>> getHistory(
            @PathVariable Long id) {
        log.debug("查询出库历史: id={}", id);
        try {
            List<WarehouseOutService.WarehouseOutHistory> history = warehouseOutService.getHistory(id);
            return ResponseEntity.ok(CommonResponse.success(history, "查询成功"));
        } catch (Exception e) {
            log.error("查询出库历史失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    @Operation(summary = "Get Statistics")
    @GetMapping("/statistics")
    public ResponseEntity<CommonResponse<WarehouseOutService.WarehouseOutStatistics>> getStatistics() {
        log.debug("查询出库统计");
        try {
            WarehouseOutService.WarehouseOutStatistics stats = warehouseOutService.getStatistics();
            return ResponseEntity.ok(CommonResponse.success(stats, "查询成功"));
        } catch (Exception e) {
            log.error("查询出库统计失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }

    @Operation(summary = "Get Pending Approvals")
    @GetMapping("/pending-approvals")
    public ResponseEntity<CommonResponse<Page<WarehouseOutService.WarehouseOutDetail>>> getPendingApprovals(
            @RequestParam(required = false) String approverRole,
            @RequestParam(required = false) String approverUser,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        log.debug("查询待审批列表: approverRole={}, approverUser={}", approverRole, approverUser);
        try {
            Page<WarehouseOutService.WarehouseOutDetail> result = warehouseOutService.getPendingApprovals(approverRole, approverUser, page, size);
            return ResponseEntity.ok(CommonResponse.success(result, "查询成功"));
        } catch (Exception e) {
            log.error("查询待审批列表失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }

    @Operation(summary = "Get My Applications")
    @GetMapping("/my-applications")
    public ResponseEntity<CommonResponse<Page<WarehouseOutService.WarehouseOutDetail>>> getMyApplications(
            @RequestHeader("X-User-Id") String userId,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        log.debug("查询我的申请: userId={}, status={}", userId, status);
        try {
            Page<WarehouseOutService.WarehouseOutDetail> result = warehouseOutService.getMyApplications(userId, status, page, size);
            return ResponseEntity.ok(CommonResponse.success(result, "查询成功"));
        } catch (Exception e) {
            log.error("查询我的申请失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }

    @Operation(summary = "获取我的审批列表")
    @GetMapping("/my-approvals")
    public ResponseEntity<CommonResponse<Page<WarehouseOutService.WarehouseOutDetail>>> getMyApprovals(
            @RequestParam(required = false) String approverUser,
            @RequestParam(required = false) String approverRole,
            @RequestParam String type,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        log.debug("获取我的出库审批列表: type={}, approverUser={}, approverRole={}", type, approverUser, approverRole);
        try {
            String role = (approverRole == null || approverRole.isBlank()) ? "ALL" : approverRole;
            Page<WarehouseOutService.WarehouseOutDetail> result = warehouseOutService.getMyApprovals(approverUser, role, type, pageNum, pageSize);
            return ResponseEntity.ok(CommonResponse.success(result, "查询成功"));
        } catch (Exception e) {
            log.error("获取我的出库审批列表失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }

    static class SubmitRequest {
        private Long id;
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
    }

    static class ApproveRequest {
        private Long id;
        private Integer step;
        private String approvalStatus;
        private String approvalOpinion;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Integer getStep() { return step; }
        public void setStep(Integer step) { this.step = step; }
        public String getApprovalStatus() { return approvalStatus; }
        public void setApprovalStatus(String approvalStatus) { this.approvalStatus = approvalStatus; }
        public String getApprovalOpinion() { return approvalOpinion; }
        public void setApprovalOpinion(String approvalOpinion) { this.approvalOpinion = approvalOpinion; }
    }
}
