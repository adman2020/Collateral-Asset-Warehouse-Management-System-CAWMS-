package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seabank.cawms.entity.WarehouseInEntity;
import com.seabank.cawms.entity.WarehouseInFileEntity;
import com.seabank.cawms.entity.WarehouseInApprovalEntity;
import com.seabank.cawms.integration.los.LOSIntegrationService;
import com.seabank.cawms.integration.t24.T24IntegrationService;
import com.seabank.cawms.mapper.WarehouseInApprovalMapper;
import com.seabank.cawms.mapper.WarehouseInFileMapper;
import com.seabank.cawms.mapper.WarehouseInMapper;
import com.seabank.cawms.service.WarehouseInService;
import com.seabank.cawms.service.FileUploadService;
import com.seabank.cawms.service.SlipGenerationService;
import com.seabank.cawms.service.WarehouseCodeGenerator;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@SuppressWarnings({"cast", "unchecked", "all"})
@Service
public class WarehouseInServiceImpl extends ServiceImpl<WarehouseInMapper, WarehouseInEntity> 
        implements WarehouseInService {

    private static final Logger log = LoggerFactory.getLogger(WarehouseInServiceImpl.class);

    private final WarehouseInMapper warehouseInMapper;
    private final WarehouseInFileMapper warehouseInFileMapper;
    private final WarehouseInApprovalMapper warehouseInApprovalMapper;
    private final com.seabank.cawms.mapper.WarehouseZoneMapper warehouseZoneMapper;
    private final com.seabank.cawms.mapper.WarehouseMapper warehouseMapper;
    private final FileUploadService fileUploadService;
    private final SlipGenerationService slipGenerationService;
    private final WarehouseCodeGenerator warehouseCodeGenerator;
    private final T24IntegrationService t24IntegrationService;
    private final LOSIntegrationService losIntegrationService;
    
    @Autowired
    public WarehouseInServiceImpl(
            WarehouseInMapper warehouseInMapper,
            WarehouseInFileMapper warehouseInFileMapper,
            WarehouseInApprovalMapper warehouseInApprovalMapper,
            com.seabank.cawms.mapper.WarehouseZoneMapper warehouseZoneMapper,
            com.seabank.cawms.mapper.WarehouseMapper warehouseMapper,
            FileUploadService fileUploadService,
            SlipGenerationService slipGenerationService,
            WarehouseCodeGenerator warehouseCodeGenerator,
            T24IntegrationService t24IntegrationService,
            LOSIntegrationService losIntegrationService) {
        this.warehouseInMapper = warehouseInMapper;
        this.warehouseInFileMapper = warehouseInFileMapper;
        this.warehouseInApprovalMapper = warehouseInApprovalMapper;
        this.warehouseZoneMapper = warehouseZoneMapper;
        this.warehouseMapper = warehouseMapper;
        this.fileUploadService = fileUploadService;
        this.slipGenerationService = slipGenerationService;
        this.warehouseCodeGenerator = warehouseCodeGenerator;
        this.t24IntegrationService = t24IntegrationService;
        this.losIntegrationService = losIntegrationService;
    }
    
    @Transactional(rollbackFor = Exception.class)
    public Long createDraft(WarehouseInEntity entity, List<WarehouseInFileEntity> files) {
        log.info("处理条件", 
                entity.getCustomerName(), entity.getCollateralType());
        ValidationResult validationResult = validateApplication(entity);
        if (!validationResult.isValid()) {
            throw new IllegalArgumentException("处理条件" + 
                    validationResult.getErrors().stream()
                            .map(e -> e.getField() + ": " + e.getError())
                            .collect(Collectors.joining("; ")));
        }
        if (!StringUtils.hasText(entity.getWhCode())) {
            String whCode = warehouseCodeGenerator.generateWarehouseCode(
                    entity.getBuCode(), entity.getIntakeType());
            // 确保编码唯一，避免重启后 counter 归零导致重复
            for (int i = 0; i < 100; i++) {
                Long count = warehouseInMapper.countByWhCode(whCode);
                if (count == null || count == 0L) {
                    break;
                }
                whCode = warehouseCodeGenerator.generateWarehouseCode(
                        entity.getBuCode(), entity.getIntakeType());
            }
            entity.setWhCode(whCode);
        }
        entity.setStatus("DRAFT");
        entity.setCurrentStep(1);
        entity.setDataSource("MANUAL");
        if (entity.getCreatedAt() == null) {
            entity.setCreatedAt(LocalDateTime.now());
        }
        warehouseInMapper.insert(entity);
        Long whInId = entity.getId();
        log.debug("处理条件", whInId, entity.getWhCode());
        if (!CollectionUtils.isEmpty(files)) {
            for (WarehouseInFileEntity file : files) {
                file.setWarehouseInId(whInId);
                file.setStatus("ACTIVE");
                file.setUploadTime(LocalDateTime.now());
                if (file.getId() != null) {
                    warehouseInFileMapper.updateById(file);
                } else {
                    warehouseInFileMapper.insert(file);
                }
            }
            log.debug("处理条件", files.size(), whInId);
        }
        createInitialApprovalRecords(whInId);
        logAudit("CREATE_DRAFT", entity.getCreatedBy(), 
                Map.of("whInId", whInId, "whCode", entity.getWhCode()));
        
        return whInId;
    }
    
    @Transactional(rollbackFor = Exception.class)
    public boolean submitApplication(Long id, String submitter) {
        log.info("处理条件", id, submitter);
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("处理条件" + id);
        }
        if (!"DRAFT".equals(entity.getStatus()) && !"REJECTED".equals(entity.getStatus())) {
            throw new IllegalStateException("只有草稿或已拒绝状态的申请才能提交，当前状态: " + entity.getStatus());
        }
        List<WarehouseInFileEntity> files = warehouseInFileMapper.selectByWarehouseInId(id);
        validateCustomerInfo(entity);
        entity.setStatus("SUBMITTED");
        entity.setCurrentStep(1);
        entity.setSubmittedAt(LocalDateTime.now());
        entity.setUpdatedBy(submitter);
        entity.setUpdatedAt(LocalDateTime.now());
        
        warehouseInMapper.updateById(entity);
        WarehouseInApprovalEntity firstApproval = warehouseInApprovalMapper
                .selectByWhInIdAndStep(id, 1);
        if (firstApproval != null) {
            firstApproval.setStatus("PENDING");
            firstApproval.setUpdatedAt(LocalDateTime.now());
            warehouseInApprovalMapper.updateById(firstApproval);
        }
        logAudit("SUBMIT_APPLICATION", submitter, 
                Map.of("whInId", id, "whCode", entity.getWhCode()));
        
        log.info("处理条件", id, entity.getWhCode());
        return true;
    }
    
    @Transactional(rollbackFor = Exception.class)
    public boolean updateApplication(WarehouseInEntity entity, List<WarehouseInFileEntity> files) {
        log.info("处理条件", entity.getId(), entity.getWhCode());
        WarehouseInEntity existing = warehouseInMapper.selectById(entity.getId());
        if (existing == null) {
            throw new IllegalArgumentException("处理条件" + entity.getId());
        }
        String currentStatus = existing.getStatus();
        if (!"DRAFT".equals(currentStatus) && !"RETURNED".equals(currentStatus) && !"REJECTED".equals(currentStatus)) {
            throw new IllegalStateException("只有草稿、已退回或已拒绝状态的申请才能编辑，当前状态: " + currentStatus);
        }
        ValidationResult validationResult = validateApplication(entity);
        if (!validationResult.isValid()) {
            throw new IllegalArgumentException("处理条件" + 
                    validationResult.getErrors().stream()
                            .map(e -> e.getField() + ": " + e.getError())
                            .collect(Collectors.joining("; ")));
        }
        entity.setWhCode(existing.getWhCode());
        entity.setStatus(existing.getStatus());
        entity.setCurrentStep(existing.getCurrentStep());
        entity.setCreatedAt(existing.getCreatedAt());
        entity.setCreatedBy(existing.getCreatedBy());
        entity.setUpdatedAt(LocalDateTime.now());
        warehouseInMapper.updateById(entity);
        if (files != null) {
            warehouseInFileMapper.deleteByWarehouseInId(entity.getId());
            for (WarehouseInFileEntity file : files) {
                file.setWarehouseInId(entity.getId());
                file.setStatus("ACTIVE");
                file.setUploadTime(LocalDateTime.now());
                if (file.getId() != null) {
                    warehouseInFileMapper.updateById(file);
                } else {
                    warehouseInFileMapper.insert(file);
                }
            }
        }
        logAudit("UPDATE_APPLICATION", entity.getUpdatedBy(), 
                Map.of("whInId", entity.getId(), "whCode", entity.getWhCode()));
        
        log.info("处理条件", entity.getId(), entity.getWhCode());
        return true;
    }
    
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteApplication(Long id, String deletedBy) {
        log.info("处理条件", id, deletedBy);
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("处理条件" + id);
        }
        if (!"DRAFT".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件" + entity.getStatus());
        }
        entity.setDeleted(1);
        entity.setUpdatedBy(deletedBy);
        entity.setUpdatedAt(LocalDateTime.now());
        warehouseInMapper.updateById(entity);
        List<WarehouseInFileEntity> files = warehouseInFileMapper.selectByWarehouseInId(id);
        for (WarehouseInFileEntity file : files) {
            file.setStatus("DELETED");
            warehouseInFileMapper.updateById(file);
        }
        LambdaUpdateWrapper<WarehouseInApprovalEntity> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(WarehouseInApprovalEntity::getWhInId, id)
                    .set(WarehouseInApprovalEntity::getStatus, "CANCELLED");
        warehouseInApprovalMapper.update(null, updateWrapper);
        logAudit("DELETE_APPLICATION", deletedBy, 
                Map.of("whInId", id, "whCode", entity.getWhCode()));
        
        log.info("处理条件", id, entity.getWhCode());
        return true;
    }
    
    public WarehouseInDetail getDetailById(Long id) {
        log.debug("处理条件", id);
        WarehouseInEntity warehouseIn = warehouseInMapper.selectById(id);
        if (warehouseIn == null || warehouseIn.getDeleted() == 1) {
            throw new IllegalArgumentException("处理条件" + id);
        }
        List<WarehouseInFileEntity> files = warehouseInFileMapper.selectByWarehouseInId(id);
        List<WarehouseInApprovalEntity> approvals = warehouseInApprovalMapper.selectByWhInId(id);
        Map<String, Object> additionalInfo = fetchAdditionalInfo(warehouseIn);
        WarehouseInDetail detail = new WarehouseInDetail();
        detail.setWarehouseIn(warehouseIn);
        detail.setFiles(files);
        detail.setApprovals(approvals);
        detail.setAdditionalInfo(additionalInfo);
        
        return detail;
    }
    
    public WarehouseInDetail getDetailByWhCode(String whCode) {
        log.debug("处理条件", whCode);
        LambdaQueryWrapper<WarehouseInEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(WarehouseInEntity::getWhCode, whCode)
                   .eq(WarehouseInEntity::getDeleted, 0);
        WarehouseInEntity warehouseIn = warehouseInMapper.selectOne(queryWrapper);
        
        if (warehouseIn == null) {
            throw new IllegalArgumentException("处理条件" + whCode);
        }
        
        return getDetailById(warehouseIn.getId());
    }
    
    public Page<WarehouseInEntity> queryList(WarehouseInQuery query, Page<WarehouseInEntity> page) {
        log.debug("处理条件", query, page);
        LambdaQueryWrapper<WarehouseInEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(WarehouseInEntity::getDeleted, 0);
        
        if (StringUtils.hasText(query.getBuCode())) {
            queryWrapper.eq(WarehouseInEntity::getBuCode, query.getBuCode());
        }
        
        if (StringUtils.hasText(query.getCustomerId())) {
            queryWrapper.eq(WarehouseInEntity::getCustomerId, query.getCustomerId());
        }
        
        if (StringUtils.hasText(query.getCustomerName())) {
            queryWrapper.like(WarehouseInEntity::getCustomerName, query.getCustomerName());
        }
        
        if (StringUtils.hasText(query.getCollateralType())) {
            queryWrapper.eq(WarehouseInEntity::getCollateralType, query.getCollateralType());
        }
        
        if (StringUtils.hasText(query.getIntakeType())) {
            queryWrapper.eq(WarehouseInEntity::getIntakeType, query.getIntakeType());
        }
        
        if (StringUtils.hasText(query.getStatus())) {
            queryWrapper.eq(WarehouseInEntity::getStatus, query.getStatus());
        }
        
        if (query.getCurrentStep() != null) {
            queryWrapper.eq(WarehouseInEntity::getCurrentStep, query.getCurrentStep());
        }
        
        if (query.getStartTime() != null) {
            queryWrapper.ge(WarehouseInEntity::getCreatedAt, query.getStartTime());
        }
        
        if (query.getEndTime() != null) {
            queryWrapper.le(WarehouseInEntity::getCreatedAt, query.getEndTime());
        }
        
        if (StringUtils.hasText(query.getKeyword())) {
            queryWrapper.and(wrapper -> wrapper
                    .like(WarehouseInEntity::getCustomerName, query.getKeyword())
                    .or()
                    .like(WarehouseInEntity::getWhCode, query.getKeyword())
                    .or()
                    .like(WarehouseInEntity::getCreditAgreementNo, query.getKeyword())
            );
        }
        queryWrapper.orderByDesc(WarehouseInEntity::getUpdatedAt);
        return warehouseInMapper.selectPage(page, queryWrapper);
    }
    
    @Transactional(rollbackFor = Exception.class)
    public ApprovalResult approveApplication(Long id, Integer stepNumber, ApprovalRequest approval) {
        log.info("处理条件", 
                id, stepNumber, approval.getApproverUser());
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("处理条件" + id);
        }
        WarehouseInApprovalEntity approvalRecord = warehouseInApprovalMapper
                .selectByWhInIdAndStep(id, stepNumber);
        if (approvalRecord == null) {
            throw new IllegalArgumentException("处理条件" + id + ", stepNumber=" + stepNumber);
        }
        if (!"PENDING".equals(approvalRecord.getStatus())) {
            throw new IllegalStateException("处理条件" + approvalRecord.getStatus());
        }
        String requestApproverRole = approval.getApproverRole();
        if (requestApproverRole == null || requestApproverRole.isBlank()) {
            requestApproverRole = approvalRecord.getApproverRole();
        }
        boolean isAdmin = requestApproverRole != null && (
                requestApproverRole.toLowerCase().contains("admin") ||
                requestApproverRole.toLowerCase().contains("super_admin")
        );
        if (!isAdmin && !requestApproverRole.equals(approvalRecord.getApproverRole())) {
            throw new IllegalStateException("审批角色不匹配，期望: " + approvalRecord.getApproverRole() +
                    ", 实际: " + requestApproverRole);
        }
        approvalRecord.setStatus("APPROVED");
        approvalRecord.setApproverUser(approval.getApproverUser());
        approvalRecord.setApproverName(approval.getApproverName());
        approvalRecord.setComments(approval.getComments());
        approvalRecord.setApprovedAt(LocalDateTime.now());
        approvalRecord.setAutoApproved(approval.getAutoApproved());
        approvalRecord.setCompletedAt(LocalDateTime.now());
        if (approvalRecord.getCreatedAt() != null) {
            long minutes = ChronoUnit.MINUTES.between(
                    approvalRecord.getCreatedAt(), approvalRecord.getCompletedAt());
            approvalRecord.setProcessingMinutes((int) minutes);
        }
        
        warehouseInApprovalMapper.updateById(approvalRecord);
        ApprovalResult result = new ApprovalResult();
        boolean allStepsApproved = checkAllStepsApproved(id);
        
        if (allStepsApproved) {
            entity.setStatus("COMPLETED");
            entity.setCurrentStep(5);
            entity.setCompletedAt(LocalDateTime.now());
            entity.setUpdatedBy(approval.getApproverUser());
            entity.setUpdatedAt(LocalDateTime.now());
            
            result.setNextStep(null);
            result.setNextApproverRole(null);
            
            log.info("处理条件", id, entity.getWhCode());
        } else {
            int nextStep = stepNumber + 1;
            entity.setStatus("IN_REVIEW");
            entity.setCurrentStep(nextStep);
            entity.setUpdatedBy(approval.getApproverUser());
            entity.setUpdatedAt(LocalDateTime.now());
            WarehouseInApprovalEntity nextApproval = warehouseInApprovalMapper
                    .selectByWhInIdAndStep(id, nextStep);
            if (nextApproval != null) {
                nextApproval.setStatus("PENDING");
                nextApproval.setUpdatedAt(LocalDateTime.now());
                warehouseInApprovalMapper.updateById(nextApproval);
                
                result.setNextStep(nextStep);
                result.setNextApproverRole(nextApproval.getApproverRole());
            }
        }
        
        warehouseInMapper.updateById(entity);
        
        if (allStepsApproved) {
            generateSlip(id, approval.getApproverUser());
        }
        
        result.setSuccess(true);
        result.setMessage("审批通过");
        result.setUpdatedWarehouseIn(entity);
        result.setApprovalRecord(approvalRecord);
        logAudit("APPROVE_APPLICATION", approval.getApproverUser(), 
                Map.of("whInId", id, "stepNumber", stepNumber, "status", "APPROVED"));
        
        log.info("处理条件", 
                id, stepNumber, approval.getApproverUser());
        
        return result;
    }
    
    @Transactional(rollbackFor = Exception.class)
    public RejectionResult rejectApplication(Long id, Integer stepNumber, RejectionRequest rejection) {
        log.info("处理条件", 
                id, stepNumber, rejection.getApproverUser());
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("处理条件" + id);
        }
        WarehouseInApprovalEntity approvalRecord = warehouseInApprovalMapper
                .selectByWhInIdAndStep(id, stepNumber);
        if (approvalRecord == null) {
            throw new IllegalArgumentException("处理条件" + id + ", stepNumber=" + stepNumber);
        }
        if (!"PENDING".equals(approvalRecord.getStatus())) {
            throw new IllegalStateException("处理条件" + approvalRecord.getStatus());
        }
        String rejectApproverRole = rejection.getApproverRole();
        if (rejectApproverRole == null || rejectApproverRole.isBlank()) {
            rejectApproverRole = approvalRecord.getApproverRole();
        }
        boolean rejectIsAdmin = rejectApproverRole != null && (
                rejectApproverRole.toLowerCase().contains("admin") ||
                rejectApproverRole.toLowerCase().contains("super_admin")
        );
        if (!rejectIsAdmin && !rejectApproverRole.equals(approvalRecord.getApproverRole())) {
            throw new IllegalStateException("审批角色不匹配，期望: " + approvalRecord.getApproverRole() +
                    ", 实际: " + rejectApproverRole);
        }
        approvalRecord.setStatus("REJECTED");
        approvalRecord.setApproverUser(rejection.getApproverUser());
        approvalRecord.setApproverName(rejection.getApproverName());
        approvalRecord.setComments("处理条件" + rejection.getReason() + 
                (StringUtils.hasText(rejection.getComments()) ? "; " + rejection.getComments() : ""));
        approvalRecord.setApprovedAt(LocalDateTime.now());
        approvalRecord.setCompletedAt(LocalDateTime.now());
        
        warehouseInApprovalMapper.updateById(approvalRecord);
        entity.setStatus("REJECTED");
        entity.setUpdatedBy(rejection.getApproverUser());
        entity.setUpdatedAt(LocalDateTime.now());
        warehouseInMapper.updateById(entity);
        RejectionResult result = new RejectionResult();
        result.setSuccess(true);
        result.setMessage("已拒绝");
        result.setUpdatedWarehouseIn(entity);
        result.setApprovalRecord(approvalRecord);
        logAudit("REJECT_APPLICATION", rejection.getApproverUser(), 
                Map.of("whInId", id, "stepNumber", stepNumber, "reason", rejection.getReason()));
        
        log.info("处理条件", 
                id, stepNumber, rejection.getApproverUser());
        
        return result;
    }
    
    @Transactional(rollbackFor = Exception.class)
    public ReturnResult returnApplication(Long id, Integer stepNumber, ReturnRequest returnRequest) {
        log.info("处理条件", 
                id, stepNumber, returnRequest.getApproverUser(), returnRequest.getReturnToStep());
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("处理条件" + id);
        }
        WarehouseInApprovalEntity approvalRecord = warehouseInApprovalMapper
                .selectByWhInIdAndStep(id, stepNumber);
        if (approvalRecord == null) {
            throw new IllegalArgumentException("处理条件" + id + ", stepNumber=" + stepNumber);
        }
        if (!"PENDING".equals(approvalRecord.getStatus())) {
            throw new IllegalStateException("处理条件" + approvalRecord.getStatus());
        }
        String returnApproverRole = returnRequest.getApproverRole();
        if (returnApproverRole == null || returnApproverRole.isBlank()) {
            returnApproverRole = approvalRecord.getApproverRole();
        }
        boolean returnIsAdmin = returnApproverRole != null && (
                returnApproverRole.toLowerCase().contains("admin") ||
                returnApproverRole.toLowerCase().contains("super_admin")
        );
        if (!returnIsAdmin && !returnApproverRole.equals(approvalRecord.getApproverRole())) {
            throw new IllegalStateException("审批角色不匹配，期望: " + approvalRecord.getApproverRole() +
                    ", 实际: " + returnApproverRole);
        }
        if (returnRequest.getReturnToStep() == null || returnRequest.getReturnToStep() < 1 || 
                returnRequest.getReturnToStep() >= stepNumber) {
            throw new IllegalArgumentException("处理条件" + returnRequest.getReturnToStep() + 
                    "处理条件");
        }
        approvalRecord.setStatus("RETURNED");
        approvalRecord.setApproverUser(returnRequest.getApproverUser());
        approvalRecord.setApproverName(returnRequest.getApproverName());
        approvalRecord.setComments("处理条件" + returnRequest.getReason() + 
                (StringUtils.hasText(returnRequest.getComments()) ? "; " + returnRequest.getComments() : ""));
        approvalRecord.setApprovedAt(LocalDateTime.now());
        approvalRecord.setCompletedAt(LocalDateTime.now());
        
        warehouseInApprovalMapper.updateById(approvalRecord);
        entity.setStatus("RETURNED");
        entity.setCurrentStep(returnRequest.getReturnToStep());
        entity.setUpdatedBy(returnRequest.getApproverUser());
        entity.setUpdatedAt(LocalDateTime.now());
        warehouseInMapper.updateById(entity);
        WarehouseInApprovalEntity returnToApproval = warehouseInApprovalMapper
                .selectByWhInIdAndStep(id, returnRequest.getReturnToStep());
        if (returnToApproval != null) {
            returnToApproval.setStatus("PENDING");
            returnToApproval.setUpdatedAt(LocalDateTime.now());
            warehouseInApprovalMapper.updateById(returnToApproval);
        }
        for (int i = returnRequest.getReturnToStep() + 1; i < stepNumber; i++) {
            WarehouseInApprovalEntity intermediateApproval = warehouseInApprovalMapper
                    .selectByWhInIdAndStep(id, i);
            if (intermediateApproval != null) {
                intermediateApproval.setStatus("CANCELLED");
                intermediateApproval.setUpdatedAt(LocalDateTime.now());
                warehouseInApprovalMapper.updateById(intermediateApproval);
            }
        }
        ReturnResult result = new ReturnResult();
        result.setSuccess(true);
        result.setMessage("处理条件");
        result.setUpdatedWarehouseIn(entity);
        result.setApprovalRecord(approvalRecord);
        logAudit("RETURN_APPLICATION", returnRequest.getApproverUser(), 
                Map.of("whInId", id, "stepNumber", stepNumber, 
                       "returnToStep", returnRequest.getReturnToStep(), "reason", returnRequest.getReason()));
        
        log.info("处理条件", 
                id, stepNumber, returnRequest.getReturnToStep());
        
        return result;
    }
    
    public Page<PendingApproval> getPendingApprovals(String approverRole, String approverUser, Page<PendingApproval> page) {
        log.debug("处理条件", approverRole, approverUser);
        List<WarehouseInApprovalEntity> pendingApprovals;
        if (StringUtils.hasText(approverUser)) {
            pendingApprovals = warehouseInApprovalMapper.selectPendingByApproverUser(approverUser);
        } else if (StringUtils.hasText(approverRole)) {
            pendingApprovals = warehouseInApprovalMapper.selectPendingByApproverRole(approverRole);
        } else {
            throw new IllegalArgumentException("处理条件");
        }
        List<PendingApproval> pendingList = new ArrayList<>();
        for (WarehouseInApprovalEntity approval : pendingApprovals) {
            WarehouseInEntity warehouseIn = warehouseInMapper.selectById(approval.getWhInId());
            if (warehouseIn != null && warehouseIn.getDeleted() == 0) {
                PendingApproval pending = new PendingApproval();
                pending.setId(warehouseIn.getId());
                pending.setWhCode(warehouseIn.getWhCode());
                pending.setCustomerName(warehouseIn.getCustomerName());
                pending.setCollateralType(warehouseIn.getCollateralType());
                pending.setCollateralValue(warehouseIn.getCollateralValue());
                pending.setBuName(warehouseIn.getBuName());
                pending.setCurrentStep(warehouseIn.getCurrentStep());
                pending.setStepName(approval.getStepName());
                pending.setSubmittedAt(warehouseIn.getSubmittedAt());
                if (warehouseIn.getSubmittedAt() != null) {
                    long days = ChronoUnit.DAYS.between(warehouseIn.getSubmittedAt(), LocalDateTime.now());
                    pending.setPendingDays((int) days);
                }
                if (warehouseIn.getCollateralValue() != null) {
                    if (warehouseIn.getCollateralValue().compareTo(new BigDecimal("1000000000")) > 0) {
                        pending.setPriority("HIGH");
                    } else if (warehouseIn.getCollateralValue().compareTo(new BigDecimal("500000000")) > 0) {
                        pending.setPriority("MEDIUM");
                    } else {
                        pending.setPriority("LOW");
                    }
                } else {
                    pending.setPriority("LOW");
                }
                
                pendingList.add(pending);
            }
        }
        int total = pendingList.size();
        int pageSize = (int) page.getSize();
        int current = (int) page.getCurrent();
        int fromIndex = (current - 1) * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, total);
        
        if (fromIndex < total) {
            List<PendingApproval> pageList = pendingList.subList(fromIndex, toIndex);
            page.setRecords(pageList);
            page.setTotal(total);
        } else {
            page.setRecords(new ArrayList<>());
            page.setTotal(total);
        }
        
        return page;
    }
    
    public WarehouseInStatistics getStatistics(StatisticsQuery query) {
        log.debug("处理条件", query);
        
        WarehouseInStatistics statistics = new WarehouseInStatistics();
        LambdaQueryWrapper<WarehouseInEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(WarehouseInEntity::getDeleted, 0);
        
        if (query.getStartTime() != null) {
            queryWrapper.ge(WarehouseInEntity::getCreatedAt, query.getStartTime());
        }
        
        if (query.getEndTime() != null) {
            queryWrapper.le(WarehouseInEntity::getCreatedAt, query.getEndTime());
        }
        
        if (StringUtils.hasText(query.getBuCode())) {
            queryWrapper.eq(WarehouseInEntity::getBuCode, query.getBuCode());
        }
        
        if (StringUtils.hasText(query.getCollateralType())) {
            queryWrapper.eq(WarehouseInEntity::getCollateralType, query.getCollateralType());
        }
        
        if (StringUtils.hasText(query.getIntakeType())) {
            queryWrapper.eq(WarehouseInEntity::getIntakeType, query.getIntakeType());
        }
        Long totalCount = warehouseInMapper.selectCount(queryWrapper);
        statistics.setTotalApplications(totalCount != null ? totalCount.intValue() : 0);
        queryWrapper.clear();
        queryWrapper.eq(WarehouseInEntity::getDeleted, 0);
        if (query.getStartTime() != null) queryWrapper.ge(WarehouseInEntity::getCreatedAt, query.getStartTime());
        if (query.getEndTime() != null) queryWrapper.le(WarehouseInEntity::getCreatedAt, query.getEndTime());
        
        Map<String, Integer> statusCounts = new HashMap<>();
        List<WarehouseInMapper.StatusCount> statusCountList = warehouseInMapper.countByStatus();
        for (WarehouseInMapper.StatusCount sc : statusCountList) {
            statusCounts.put(sc.getStatus(), sc.getCount());
            if ("PENDING".equals(sc.getStatus()) || "IN_REVIEW".equals(sc.getStatus())) {
                statistics.setPendingApplications(sc.getCount());
            } else if ("APPROVED".equals(sc.getStatus()) || "COMPLETED".equals(sc.getStatus())) {
                statistics.setApprovedApplications(
                        statistics.getApprovedApplications() != null ? 
                        statistics.getApprovedApplications() + sc.getCount() : sc.getCount());
            } else if ("REJECTED".equals(sc.getStatus())) {
                statistics.setRejectedApplications(sc.getCount());
            }
        }
        statistics.setApplicationsByStatus(statusCounts);
        Map<String, Integer> typeCounts = new HashMap<>();
        List<WarehouseInMapper.CollateralTypeCount> typeCountList = warehouseInMapper.countByCollateralType();
        for (WarehouseInMapper.CollateralTypeCount ctc : typeCountList) {
            typeCounts.put(ctc.getCollateralType(), ctc.getCount());
        }
        statistics.setApplicationsByType(typeCounts);
        Map<String, Integer> buCounts = new HashMap<>();
        statistics.setApplicationsByBu(buCounts);
        queryWrapper.clear();
        queryWrapper.eq(WarehouseInEntity::getDeleted, 0)
                   .isNotNull(WarehouseInEntity::getCollateralValue);
        if (query.getStartTime() != null) queryWrapper.ge(WarehouseInEntity::getCreatedAt, query.getStartTime());
        if (query.getEndTime() != null) queryWrapper.le(WarehouseInEntity::getCreatedAt, query.getEndTime());
        
        List<WarehouseInEntity> allRecords = warehouseInMapper.selectList(queryWrapper);
        BigDecimal totalValue = BigDecimal.ZERO;
        Map<String, BigDecimal> valueByType = new HashMap<>();
        
        for (WarehouseInEntity record : allRecords) {
            if (record.getCollateralValue() != null) {
                totalValue = totalValue.add(record.getCollateralValue());
                
                String type = record.getCollateralType();
                BigDecimal currentValue = valueByType.getOrDefault(type, BigDecimal.ZERO);
                valueByType.put(type, currentValue.add(record.getCollateralValue()));
            }
        }
        
        statistics.setTotalCollateralValue(totalValue);
        statistics.setValueByCollateralType(valueByType);
        statistics.setMonthlyStats(new ArrayList<>());
        
        log.debug("处理条件", 
                statistics.getTotalApplications(), statistics.getTotalCollateralValue());
        
        return statistics;
    }
    
    public Page<WarehouseInEntity> getMyApprovals(String approverUser, String approverRole, String type, Page<WarehouseInEntity> page) {
        List<WarehouseInEntity> records;
        if ("pending".equals(type)) {
            if ("ALL".equals(approverRole)) {
                records = warehouseInMapper.selectAllPending();
            } else {
                records = warehouseInMapper.selectPendingByApproverRole(approverRole);
            }
        } else if ("ongoing".equals(type)) {
            records = warehouseInMapper.selectMyApprovedOngoing(approverUser);
        } else {
            records = warehouseInMapper.selectMyHistory(approverUser);
        }
        long total = records.size();
        int from = (int) ((page.getCurrent() - 1) * page.getSize());
        int to = (int) Math.min(from + page.getSize(), total);
        List<WarehouseInEntity> pageRecords = from < total ? records.subList(from, to) : new ArrayList<>();
        page.setRecords(pageRecords);
        page.setTotal(total);
        return page;
    }
    
    public Map<String, Object> generateSlip(Long id, String generator) {
        log.info("处理条件", id, generator);
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("处理条件" + id);
        }
        if (!"COMPLETED".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件" + entity.getStatus());
        }
        String slipNumber = "WH-SLIP-" + System.currentTimeMillis();
        Map<String, Object> slip = new HashMap<>();
        slip.put("generatedBy", generator);
        slip.put("slipDate", LocalDateTime.now());
        slip.put("slipNumber", slipNumber);
        slip.put("whCode", entity.getWhCode());
        slip.put("customerName", "");
        slip.put("collateralType", entity.getCollateralType());
        slip.put("collateralValue", entity.getCollateralValue());
        slip.put("buName", "Default BU");
        slip.put("downloadUrl", "");
        slip.put("qrCodeUrl", "");
        slip.put("slipContent", "");
        logAudit("GENERATE_SLIP", generator, 
                Map.of("whInId", id, "whCode", entity.getWhCode(), "slipNumber", slipNumber));
        
        log.info("处理条件", id, slipNumber);
        
        return slip;
    }
    
    public ExportData exportData(ExportQuery query) {
        log.info("处理条件", query);
        Page<WarehouseInEntity> page = new Page<>(1, Integer.MAX_VALUE);
        Page<WarehouseInEntity> resultPage = queryList(query.getFilter(), page);
        List<WarehouseInEntity> records = resultPage.getRecords();
        ExportData exportData = new ExportData();
        exportData.setFileName("warehouse_in_export_" + LocalDateTime.now().toString() + ".xlsx");
        exportData.setFileType("EXCEL");
        exportData.setFileSize((long) (records.size() * 1024));
        exportData.setDownloadUrl("/api/warehouse-in/export/download/" + UUID.randomUUID());
        exportData.setGeneratedAt(LocalDateTime.now());
        exportData.setRecordCount(records.size());
        
        log.info("处理条件", records.size());
        
        return exportData;
    }
    
    @Transactional(rollbackFor = Exception.class)
    public ImportResult importData(List<WarehouseInEntity> importData, String importer) {
        log.info("处理条件", importData.size(), importer);
        
        ImportResult result = new ImportResult();
        result.setTotalRecords(importData.size());
        result.setSuccessfulRecords(0);
        result.setFailedRecords(0);
        List<ImportError> errors = new ArrayList<>();
        
        for (int i = 0; i < importData.size(); i++) {
            WarehouseInEntity entity = importData.get(i);
            int rowNumber = i + 1;
            
            try {
                ValidationResult validationResult = validateApplication(entity);
                if (!validationResult.isValid()) {
                    String errorMsg = validationResult.getErrors().stream()
                            .map(e -> e.getField() + ": " + e.getError())
                            .collect(Collectors.joining("; "));
                    
                    ImportError error = new ImportError();
                    error.setRowNumber(rowNumber);
                    error.setError("处理条件");
                    error.setValue(entity.toString());
                    error.setSuggestion("处理条件");
                    errors.add(error);
                    result.setFailedRecords(result.getFailedRecords() + 1);
                    continue;
                }
                entity.setDataSource("IMPORT");
                entity.setStatus("DRAFT");
                entity.setCurrentStep(1);
                entity.setCreatedBy(importer);
                entity.setCreatedAt(LocalDateTime.now());
                if (!StringUtils.hasText(entity.getWhCode())) {
                    String whCode = warehouseCodeGenerator.generateWarehouseCode(
                            entity.getBuCode(), entity.getIntakeType());
                    for (int attempt = 0; attempt < 100; attempt++) {
                        Long count = warehouseInMapper.countByWhCode(whCode);
                        if (count == null || count == 0L) {
                            break;
                        }
                        whCode = warehouseCodeGenerator.generateWarehouseCode(
                                entity.getBuCode(), entity.getIntakeType());
                    }
                    entity.setWhCode(whCode);
                }
                warehouseInMapper.insert(entity);
                createInitialApprovalRecords(entity.getId());
                
                result.setSuccessfulRecords(result.getSuccessfulRecords() + 1);
                
                log.debug("处理条件", rowNumber, entity.getWhCode());
                
            } catch (Exception e) {
                ImportError error = new ImportError();
                error.setRowNumber(rowNumber);
                error.setError("处理条件" + e.getMessage());
                error.setValue(entity.toString());
                error.setSuggestion("处理条件");
                errors.add(error);
                result.setFailedRecords(result.getFailedRecords() + 1);
                
                log.error("处理条件", rowNumber, e.getMessage(), e);
            }
        }
        result.setSuccess(result.getFailedRecords() == 0);
        result.setMessage(String.format("处理条件", 
                result.getSuccessfulRecords(), result.getFailedRecords()));
        result.setErrors(errors);
        result.setReportUrl("/api/warehouse-in/import/report/" + UUID.randomUUID());
        logAudit("IMPORT_DATA", importer, 
                Map.of("totalRecords", importData.size(), 
                       "successfulRecords", result.getSuccessfulRecords(),
                       "failedRecords", result.getFailedRecords()));
        
        log.info("处理条件", 
                importData.size(), result.getSuccessfulRecords(), result.getFailedRecords());
        
        return result;
    }
    
    public List<HistoryRecord> getHistory(Long id) {
        log.debug("处理条件", id);
        
        List<HistoryRecord> history = new ArrayList<>();
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("处理条件" + id);
        }
        HistoryRecord createRecord = new HistoryRecord();
        createRecord.setTimestamp(entity.getCreatedAt());
        createRecord.setAction("CREATE");
        createRecord.setUser(entity.getCreatedBy());
        createRecord.setDescription("处理条件");
        createRecord.setDetails(Map.of(
                "whCode", entity.getWhCode(),
                "customerName", entity.getCustomerName(),
                "collateralType", entity.getCollateralType()
        ));
        history.add(createRecord);
        if (entity.getSubmittedAt() != null) {
            HistoryRecord submitRecord = new HistoryRecord();
            submitRecord.setTimestamp(entity.getSubmittedAt());
            submitRecord.setAction("SUBMIT");
            submitRecord.setUser(entity.getUpdatedBy());
            submitRecord.setDescription("处理条件");
            submitRecord.setDetails(Map.of("status", "SUBMITTED"));
            history.add(submitRecord);
        }
        List<WarehouseInApprovalEntity> approvals = warehouseInApprovalMapper.selectByWhInId(id);
        for (WarehouseInApprovalEntity approval : approvals) {
            String status = approval.getStatus();
            boolean isProcessed = "APPROVED".equals(status) || "REJECTED".equals(status) || "RETURNED".equals(status);
            if (isProcessed) {
                HistoryRecord approvalRecord = new HistoryRecord();
                LocalDateTime ts = approval.getApprovedAt() != null ? approval.getApprovedAt() : approval.getUpdatedAt();
                approvalRecord.setTimestamp(ts);
                String actionLabel;
                if ("APPROVED".equals(status)) {
                    actionLabel = "审批通过";
                } else if ("REJECTED".equals(status)) {
                    actionLabel = "审批拒绝";
                } else if ("RETURNED".equals(status)) {
                    actionLabel = "退回修改";
                } else {
                    actionLabel = "审批处理";
                }
                approvalRecord.setAction(actionLabel);
                approvalRecord.setUser(approval.getApproverUser());
                approvalRecord.setUserRole(approval.getApproverRole());
                approvalRecord.setComment(approval.getComments());
                approvalRecord.setDescription(String.format("步骤 %d %s", 
                        approval.getStepNumber(), actionLabel));
                approvalRecord.setDetails(Map.of(
                        "stepNumber", approval.getStepNumber(),
                        "stepName", approval.getStepName(),
                        "status", status,
                        "comments", approval.getComments() != null ? approval.getComments() : ""
                ));
                history.add(approvalRecord);
            }
        }
        if (entity.getCompletedAt() != null) {
            HistoryRecord completeRecord = new HistoryRecord();
            completeRecord.setTimestamp(entity.getCompletedAt());
            completeRecord.setAction("COMPLETE");
            completeRecord.setUser(entity.getUpdatedBy());
            completeRecord.setDescription("处理条件");
            completeRecord.setDetails(Map.of("status", "COMPLETED"));
            history.add(completeRecord);
        }
        history.sort((h1, h2) -> h2.getTimestamp().compareTo(h1.getTimestamp()));
        
        return history;
    }
    
    public ValidationResult validateApplication(WarehouseInEntity entity) {
        log.debug("处理条件", entity.getWhCode(), entity.getCustomerName());
        
        ValidationResult result = new ValidationResult();
        List<ValidationError> errors = new ArrayList<>();
        List<ValidationWarning> warnings = new ArrayList<>();
        Map<String, Object> suggestions = new HashMap<>();
        if (!StringUtils.hasText(entity.getBuCode())) {
            errors.add(createValidationError("buCode", "处理条件", "REQUIRED_FIELD"));
        }
        
        if (!StringUtils.hasText(entity.getCustomerName())) {
            errors.add(createValidationError("customerName", "处理条件", "REQUIRED_FIELD"));
        }
        
        if (!StringUtils.hasText(entity.getCollateralType())) {
            errors.add(createValidationError("collateralType", "处理条件", "REQUIRED_FIELD"));
        }
        
        if (entity.getCollateralValue() == null) {
            errors.add(createValidationError("collateralValue", "处理条件", "REQUIRED_FIELD"));
        } else if (entity.getCollateralValue().compareTo(BigDecimal.ZERO) <= 0) {
            errors.add(createValidationError("collateralValue", "处理条件", "INVALID_VALUE"));
        }
        
        if (!StringUtils.hasText(entity.getIntakeType())) {
            errors.add(createValidationError("intakeType", "处理条件", "REQUIRED_FIELD"));
        }
        if (StringUtils.hasText(entity.getWhCode()) && entity.getWhCode().length() > 50) {
            errors.add(createValidationError("whCode", "处理条件", "FIELD_TOO_LONG"));
        }
        
        if (StringUtils.hasText(entity.getCustomerName()) && entity.getCustomerName().length() > 200) {
            warnings.add(createValidationWarning("customerName", "处理条件", "FIELD_TOO_LONG"));
        }
        if ("NEW".equals(entity.getIntakeType()) && !StringUtils.hasText(entity.getCreditAgreementNo())) {
            warnings.add(createValidationWarning("creditAgreementNo", "处理条件", "BUSINESS_RULE"));
        }
        
        if (entity.getCollateralValue() != null && 
                entity.getCollateralValue().compareTo(new BigDecimal("10000000000")) > 0) {
            warnings.add(createValidationWarning("collateralValue", "处理条件", "HIGH_VALUE"));
            suggestions.put("needSpecialApproval", true);
        }
        result.setValid(errors.isEmpty());
        result.setErrors(errors);
        result.setWarnings(warnings);
        result.setSuggestions(suggestions);
        
        log.debug("处理条件", 
                result.isValid(), errors.size(), warnings.size());
        
        return result;
    }

    @Override
    public List<String> getApprovalHistory(Long id) {
        LambdaQueryWrapper<WarehouseInApprovalEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(WarehouseInApprovalEntity::getWhInId, id)
               .orderByAsc(WarehouseInApprovalEntity::getStepNumber);
        List<WarehouseInApprovalEntity> approvals = warehouseInApprovalMapper.selectList(wrapper);
        List<String> history = new ArrayList<>();
        for (WarehouseInApprovalEntity approval : approvals) {
            history.add(approval.getStepName() + ":" + approval.getStatus());
        }
        return history;
    }

    private void createInitialApprovalRecords(Long whInId) {
        log.debug("处理条件", whInId);
        String[][] approvalSteps = {
            {"1", "处理条件", "BUSINESS_MANAGER", "PENDING"},
            {"2", "处理条件", "RISK_OFFICER", "NOT_STARTED"},
            {"3", "处理条件", "COMPLIANCE_OFFICER", "NOT_STARTED"},
            {"4", "处理条件", "WAREHOUSE_MANAGER", "NOT_STARTED"}
        };
        
        for (String[] step : approvalSteps) {
            WarehouseInApprovalEntity approval = new WarehouseInApprovalEntity();
            approval.setWhInId(whInId);
            approval.setStepNumber(Integer.parseInt(step[0]));
            approval.setStepName(step[1]);
            approval.setApproverRole(step[2]);
            approval.setStatus(step[3]);
            approval.setCreatedAt(LocalDateTime.now());
            approval.setUpdatedAt(LocalDateTime.now());
            
            warehouseInApprovalMapper.insert(approval);
        }
        
        log.debug("处理条件", whInId);
    }

    private void validateCustomerInfo(WarehouseInEntity entity) {
        log.debug("处理条件", entity.getCustomerId(), entity.getCustomerName());
        try {
            if (t24IntegrationService.isAvailable()) {
                log.debug("处理条件", entity.getCustomerId());
            }
            if (losIntegrationService.isAvailable() && StringUtils.hasText(entity.getCreditAgreementNo())) {
                log.debug("处理条件", entity.getCreditAgreementNo());
            }
            
        } catch (Exception e) {
            log.warn("处理条件", e.getMessage());
        }
    }

    private boolean checkAllStepsApproved(Long whInId) {
        List<WarehouseInApprovalEntity> approvals = warehouseInApprovalMapper.selectByWhInId(whInId);
        
        for (WarehouseInApprovalEntity approval : approvals) {
            if (!"APPROVED".equals(approval.getStatus())) {
                return false;
            }
        }
        
        return true;
    }

    private Map<String, Object> fetchAdditionalInfo(WarehouseInEntity entity) {
        Map<String, Object> additionalInfo = new HashMap<>();

        try {
            if (StringUtils.hasText(entity.getCustomerId()) && t24IntegrationService.isAvailable()) {
                Map<String, Object> customerInfo = new HashMap<>();
                customerInfo.put("customerId", entity.getCustomerId());
                customerInfo.put("customerName", entity.getCustomerName());
                customerInfo.put("source", "T24 Mock");
                additionalInfo.put("customerInfo", customerInfo);
            }
            if (StringUtils.hasText(entity.getCreditAgreementNo()) && losIntegrationService.isAvailable()) {
                Map<String, Object> loanInfo = new HashMap<>();
                loanInfo.put("agreementNo", entity.getCreditAgreementNo());
                loanInfo.put("status", "ACTIVE");
                loanInfo.put("source", "LOS Mock");
                additionalInfo.put("loanInfo", loanInfo);
            }

            // 回填仓库/库区信息
            if (entity.getZoneId() != null) {
                com.seabank.cawms.entity.WarehouseZoneEntity zone = warehouseZoneMapper.selectById(entity.getZoneId());
                if (zone != null) {
                    Map<String, Object> zoneInfo = new HashMap<>();
                    zoneInfo.put("id", zone.getId());
                    zoneInfo.put("zoneCode", zone.getZoneCode());
                    zoneInfo.put("zoneName", zone.getZoneName());
                    zoneInfo.put("zoneType", zone.getZoneType());
                    additionalInfo.put("zone", zoneInfo);
                }
            }
            if (entity.getWarehouseId() != null) {
                com.seabank.cawms.entity.WarehouseEntity warehouse = warehouseMapper.selectById(entity.getWarehouseId());
                if (warehouse != null) {
                    Map<String, Object> whInfo = new HashMap<>();
                    whInfo.put("id", warehouse.getId());
                    whInfo.put("warehouseCode", warehouse.getWarehouseCode());
                    whInfo.put("warehouseName", warehouse.getWarehouseName());
                    additionalInfo.put("warehouse", whInfo);
                }
            }

        } catch (Exception e) {
            log.warn("处理条件", e.getMessage());
        }

        return additionalInfo;
    }
    
    @Override
    public String generateWarehouseNo() {
        return warehouseCodeGenerator.generateWarehouseCode("WH", java.time.LocalDateTime.now().toString().substring(0,10).replace("-",""));
    }

    @Override
    public byte[] exportData(List<Long> ids, String format) {
        return new byte[0];
    }

    @Override
    public Map<String, Object> getStatistics() {
        return new HashMap<>();
    }

    @Override
    public Map<String, Object> validateProof(Long id) {
        Map<String, Object> result = new HashMap<>();
        result.put("valid", true);
        return result;
    }

    @Override
    public WarehouseInEntity createWarehouseIn(WarehouseInEntity entity) {
        entity.setCreatedAt(LocalDateTime.now());
        warehouseInMapper.insert(entity);
        return entity;
    }

    @Override
    public WarehouseInEntity updateWarehouseIn(Long id, WarehouseInEntity entity) {
        entity.setId(id);
        entity.setUpdatedAt(LocalDateTime.now());
        warehouseInMapper.updateById(entity);
        return entity;
    }

    @Override
    public boolean deleteWarehouseIn(Long id) {
        return warehouseInMapper.deleteById(id) > 0;
    }

    @Override
    public WarehouseInEntity getWarehouseInById(Long id) {
        return warehouseInMapper.selectById(id);
    }

    @Override
    public Page<WarehouseInEntity> queryWarehouseInList(int page, int size, String status, String warehouseNo, String collateralName) {
        LambdaQueryWrapper<WarehouseInEntity> wrapper = new LambdaQueryWrapper<>();
        if (status != null && !status.isEmpty()) {
            wrapper.eq(WarehouseInEntity::getStatus, status);
        }
        if (warehouseNo != null && !warehouseNo.isEmpty()) {
            wrapper.eq(WarehouseInEntity::getWhCode, warehouseNo);
        }
        if (collateralName != null && !collateralName.isEmpty()) {
            wrapper.like(WarehouseInEntity::getCollateralType, collateralName);
        }
        wrapper.orderByDesc(WarehouseInEntity::getUpdatedAt);
        return page(new Page<>(page, size), wrapper);
    }

    @Override
    public WarehouseInEntity submitWarehouseIn(Long id) {
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity != null) {
            entity.setStatus("SUBMITTED");
            entity.setUpdatedAt(LocalDateTime.now());
            warehouseInMapper.updateById(entity);
        }
        return entity;
    }

    @Override
    public WarehouseInEntity approveWarehouseIn(Long id, Integer step, String approvalStatus, String opinion) {
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity != null) {
            entity.setStatus("APPROVED");
            entity.setUpdatedAt(LocalDateTime.now());
            warehouseInMapper.updateById(entity);
        }
        return entity;
    }

    @Override
    public WarehouseInEntity rejectWarehouseIn(Long id, Integer step, String reason) {
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity != null) {
            entity.setStatus("REJECTED");
            entity.setUpdatedAt(LocalDateTime.now());
            warehouseInMapper.updateById(entity);
        }
        return entity;
    }

    @Override
    public WarehouseInEntity returnWarehouseIn(Long id, String reason) {
        WarehouseInEntity entity = warehouseInMapper.selectById(id);
        if (entity != null) {
            entity.setStatus("RETURNED");
            entity.setUpdatedAt(LocalDateTime.now());
            warehouseInMapper.updateById(entity);
        }
        return entity;
    }

    @Override
    public Page<WarehouseInEntity> queryPendingApprovals(String role, int page, int size) {
        return page(new Page<>(page, size), new LambdaQueryWrapper<WarehouseInEntity>());
    }

    private void logAudit(String action, String user, Map<String, Object> details) {
        log.info("处理条件", action, user, details);
    }

    private ValidationError createValidationError(String field, String error, String code) {
        ValidationError validationError = new ValidationError();
        validationError.setField(field);
        validationError.setError(error);
        validationError.setCode(code);
        return validationError;
    }

    private ValidationWarning createValidationWarning(String field, String warning, String code) {
        ValidationWarning validationWarning = new ValidationWarning();
        validationWarning.setField(field);
        validationWarning.setWarning(warning);
        validationWarning.setCode(code);
        return validationWarning;
    }
    public static class WarehouseInDetail {
        private WarehouseInEntity warehouseIn;
        private List<WarehouseInFileEntity> files;
        private List<WarehouseInApprovalEntity> approvals;
        private Map<String, Object> additionalInfo;

        public WarehouseInEntity getWarehouseIn() {
            return warehouseIn;
        }
        public void setWarehouseIn(WarehouseInEntity warehouseIn) {
            this.warehouseIn = warehouseIn;
        }

        public List<WarehouseInFileEntity> getFiles() {
            return files;
        }
        public void setFiles(List<WarehouseInFileEntity> files) {
            this.files = files;
        }

        public List<WarehouseInApprovalEntity> getApprovals() {
            return approvals;
        }
        public void setApprovals(List<WarehouseInApprovalEntity> approvals) {
            this.approvals = approvals;
        }

        public Map<String, Object> getAdditionalInfo() {
            return additionalInfo;
        }
        public void setAdditionalInfo(Map<String, Object> additionalInfo) {
            this.additionalInfo = additionalInfo;
        }
    }
    
    public static class WarehouseInQuery {
        private String buCode;
        private String customerId;
        private String customerName;
        private String collateralType;
        private String intakeType;
        private String status;
        private Integer currentStep;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private String keyword;

        public String getBuCode() {
            return buCode;
        }
        public void setBuCode(String buCode) {
            this.buCode = buCode;
        }

        public String getCustomerId() {
            return customerId;
        }
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }

        public String getCustomerName() {
            return customerName;
        }
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }

        public String getCollateralType() {
            return collateralType;
        }
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }

        public String getIntakeType() {
            return intakeType;
        }
        public void setIntakeType(String intakeType) {
            this.intakeType = intakeType;
        }

        public String getStatus() {
            return status;
        }
        public void setStatus(String status) {
            this.status = status;
        }

        public Integer getCurrentStep() {
            return currentStep;
        }
        public void setCurrentStep(Integer currentStep) {
            this.currentStep = currentStep;
        }

        public LocalDateTime getStartTime() {
            return startTime;
        }
        public void setStartTime(LocalDateTime startTime) {
            this.startTime = startTime;
        }

        public LocalDateTime getEndTime() {
            return endTime;
        }
        public void setEndTime(LocalDateTime endTime) {
            this.endTime = endTime;
        }

        public String getKeyword() {
            return keyword;
        }
        public void setKeyword(String keyword) {
            this.keyword = keyword;
        }
    }
    
    public static class StatisticsQuery {
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private String buCode;
        private String collateralType;
        private String intakeType;

        public LocalDateTime getStartTime() {
            return startTime;
        }
        public void setStartTime(LocalDateTime startTime) {
            this.startTime = startTime;
        }

        public LocalDateTime getEndTime() {
            return endTime;
        }
        public void setEndTime(LocalDateTime endTime) {
            this.endTime = endTime;
        }

        public String getBuCode() {
            return buCode;
        }
        public void setBuCode(String buCode) {
            this.buCode = buCode;
        }

        public String getCollateralType() {
            return collateralType;
        }
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }

        public String getIntakeType() {
            return intakeType;
        }
        public void setIntakeType(String intakeType) {
            this.intakeType = intakeType;
        }
    }
    
    public static class ApprovalRequest {
        private String approverUser;
        private String approverRole;
        private String approverName;
        private String comments;
        private Boolean autoApproved;

        public String getApproverUser() {
            return approverUser;
        }
        public void setApproverUser(String approverUser) {
            this.approverUser = approverUser;
        }

        public String getApproverRole() {
            return approverRole;
        }
        public void setApproverRole(String approverRole) {
            this.approverRole = approverRole;
        }

        public String getApproverName() {
            return approverName;
        }
        public void setApproverName(String approverName) {
            this.approverName = approverName;
        }

        public String getComments() {
            return comments;
        }
        public void setComments(String comments) {
            this.comments = comments;
        }

        public Boolean getAutoApproved() {
            return autoApproved;
        }
        public void setAutoApproved(Boolean autoApproved) {
            this.autoApproved = autoApproved;
        }
    }
    
    public static class ApprovalResult {
        private boolean success;
        private String message;
        private WarehouseInEntity updatedWarehouseIn;
        private WarehouseInApprovalEntity approvalRecord;
        private Integer nextStep;
        private String nextApproverRole;

        public boolean getSuccess() {
            return success;
        }
        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getMessage() {
            return message;
        }
        public void setMessage(String message) {
            this.message = message;
        }

        public WarehouseInEntity getUpdatedWarehouseIn() {
            return updatedWarehouseIn;
        }
        public void setUpdatedWarehouseIn(WarehouseInEntity updatedWarehouseIn) {
            this.updatedWarehouseIn = updatedWarehouseIn;
        }

        public WarehouseInApprovalEntity getApprovalRecord() {
            return approvalRecord;
        }
        public void setApprovalRecord(WarehouseInApprovalEntity approvalRecord) {
            this.approvalRecord = approvalRecord;
        }

        public Integer getNextStep() {
            return nextStep;
        }
        public void setNextStep(Integer nextStep) {
            this.nextStep = nextStep;
        }

        public String getNextApproverRole() {
            return nextApproverRole;
        }
        public void setNextApproverRole(String nextApproverRole) {
            this.nextApproverRole = nextApproverRole;
        }
    }
    
    public static class RejectionRequest {
        private String approverUser;
        private String approverRole;
        private String approverName;
        private String reason;
        private String comments;

        public String getApproverUser() {
            return approverUser;
        }
        public void setApproverUser(String approverUser) {
            this.approverUser = approverUser;
        }

        public String getApproverRole() {
            return approverRole;
        }
        public void setApproverRole(String approverRole) {
            this.approverRole = approverRole;
        }

        public String getApproverName() {
            return approverName;
        }
        public void setApproverName(String approverName) {
            this.approverName = approverName;
        }

        public String getReason() {
            return reason;
        }
        public void setReason(String reason) {
            this.reason = reason;
        }

        public String getComments() {
            return comments;
        }
        public void setComments(String comments) {
            this.comments = comments;
        }
    }
    
    public static class RejectionResult {
        private boolean success;
        private String message;
        private WarehouseInEntity updatedWarehouseIn;
        private WarehouseInApprovalEntity approvalRecord;

        public boolean getSuccess() {
            return success;
        }
        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getMessage() {
            return message;
        }
        public void setMessage(String message) {
            this.message = message;
        }

        public WarehouseInEntity getUpdatedWarehouseIn() {
            return updatedWarehouseIn;
        }
        public void setUpdatedWarehouseIn(WarehouseInEntity updatedWarehouseIn) {
            this.updatedWarehouseIn = updatedWarehouseIn;
        }

        public WarehouseInApprovalEntity getApprovalRecord() {
            return approvalRecord;
        }
        public void setApprovalRecord(WarehouseInApprovalEntity approvalRecord) {
            this.approvalRecord = approvalRecord;
        }
    }
    
    public static class ReturnRequest {
        private String approverUser;
        private String approverRole;
        private String approverName;
        private String reason;
        private String comments;
        private Integer returnToStep;

        public String getApproverUser() {
            return approverUser;
        }
        public void setApproverUser(String approverUser) {
            this.approverUser = approverUser;
        }

        public String getApproverRole() {
            return approverRole;
        }
        public void setApproverRole(String approverRole) {
            this.approverRole = approverRole;
        }

        public String getApproverName() {
            return approverName;
        }
        public void setApproverName(String approverName) {
            this.approverName = approverName;
        }

        public String getReason() {
            return reason;
        }
        public void setReason(String reason) {
            this.reason = reason;
        }

        public String getComments() {
            return comments;
        }
        public void setComments(String comments) {
            this.comments = comments;
        }

        public Integer getReturnToStep() {
            return returnToStep;
        }
        public void setReturnToStep(Integer returnToStep) {
            this.returnToStep = returnToStep;
        }
    }
    
    public static class ReturnResult {
        private boolean success;
        private String message;
        private WarehouseInEntity updatedWarehouseIn;
        private WarehouseInApprovalEntity approvalRecord;

        public boolean getSuccess() {
            return success;
        }
        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getMessage() {
            return message;
        }
        public void setMessage(String message) {
            this.message = message;
        }

        public WarehouseInEntity getUpdatedWarehouseIn() {
            return updatedWarehouseIn;
        }
        public void setUpdatedWarehouseIn(WarehouseInEntity updatedWarehouseIn) {
            this.updatedWarehouseIn = updatedWarehouseIn;
        }

        public WarehouseInApprovalEntity getApprovalRecord() {
            return approvalRecord;
        }
        public void setApprovalRecord(WarehouseInApprovalEntity approvalRecord) {
            this.approvalRecord = approvalRecord;
        }
    }
    
    public static class PendingApproval {
        private Long id;
        private String whCode;
        private String customerName;
        private String collateralType;
        private BigDecimal collateralValue;
        private String buName;
        private Integer currentStep;
        private String stepName;
        private String approverRole;
        private String approverUser;
        private String approverName;
        private int pendingDays;
        private String priority;
        private LocalDateTime submittedAt;

        public Long getId() {
            return id;
        }
        public void setId(Long id) {
            this.id = id;
        }

        public String getWhCode() {
            return whCode;
        }
        public void setWhCode(String whCode) {
            this.whCode = whCode;
        }

        public String getCustomerName() {
            return customerName;
        }
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }

        public String getCollateralType() {
            return collateralType;
        }
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }

        public BigDecimal getCollateralValue() {
            return collateralValue;
        }
        public void setCollateralValue(BigDecimal collateralValue) {
            this.collateralValue = collateralValue;
        }

        public String getBuName() {
            return buName;
        }
        public void setBuName(String buName) {
            this.buName = buName;
        }

        public Integer getCurrentStep() {
            return currentStep;
        }
        public void setCurrentStep(Integer currentStep) {
            this.currentStep = currentStep;
        }

        public String getStepName() {
            return stepName;
        }
        public void setStepName(String stepName) {
            this.stepName = stepName;
        }

        public String getApproverRole() {
            return approverRole;
        }
        public void setApproverRole(String approverRole) {
            this.approverRole = approverRole;
        }

        public String getApproverUser() {
            return approverUser;
        }
        public void setApproverUser(String approverUser) {
            this.approverUser = approverUser;
        }

        public String getApproverName() {
            return approverName;
        }
        public void setApproverName(String approverName) {
            this.approverName = approverName;
        }

        public int getPendingDays() {
            return pendingDays;
        }
        public void setPendingDays(int pendingDays) {
            this.pendingDays = pendingDays;
        }

        public String getPriority() {
            return priority;
        }
        public void setPriority(String priority) {
            this.priority = priority;
        }

        public LocalDateTime getSubmittedAt() {
            return submittedAt;
        }
        public void setSubmittedAt(LocalDateTime submittedAt) {
            this.submittedAt = submittedAt;
        }
    }
    
    public static class WarehouseInStatistics {
        private int totalApplications;
        private int pendingApplications;
        private Integer approvedApplications;
        private Integer rejectedApplications;
        private Map<String, Integer> applicationsByStatus;
        private Map<String, Integer> applicationsByType;
        private Map<String, Integer> applicationsByBu;
        private BigDecimal totalCollateralValue;
        private Map<String, BigDecimal> valueByCollateralType;
        private List<Object> monthlyStats;

        public int getTotalApplications() {
            return totalApplications;
        }
        public void setTotalApplications(int totalApplications) {
            this.totalApplications = totalApplications;
        }

        public int getPendingApplications() {
            return pendingApplications;
        }
        public void setPendingApplications(int pendingApplications) {
            this.pendingApplications = pendingApplications;
        }

        public Integer getApprovedApplications() {
            return approvedApplications;
        }
        public void setApprovedApplications(Integer approvedApplications) {
            this.approvedApplications = approvedApplications;
        }

        public Integer getRejectedApplications() {
            return rejectedApplications;
        }
        public void setRejectedApplications(Integer rejectedApplications) {
            this.rejectedApplications = rejectedApplications;
        }

        public Map<String, Integer> getApplicationsByStatus() {
            return applicationsByStatus;
        }
        public void setApplicationsByStatus(Map<String, Integer> applicationsByStatus) {
            this.applicationsByStatus = applicationsByStatus;
        }

        public Map<String, Integer> getApplicationsByType() {
            return applicationsByType;
        }
        public void setApplicationsByType(Map<String, Integer> applicationsByType) {
            this.applicationsByType = applicationsByType;
        }

        public Map<String, Integer> getApplicationsByBu() {
            return applicationsByBu;
        }
        public void setApplicationsByBu(Map<String, Integer> applicationsByBu) {
            this.applicationsByBu = applicationsByBu;
        }

        public BigDecimal getTotalCollateralValue() {
            return totalCollateralValue;
        }
        public void setTotalCollateralValue(BigDecimal totalCollateralValue) {
            this.totalCollateralValue = totalCollateralValue;
        }

        public Map<String, BigDecimal> getValueByCollateralType() {
            return valueByCollateralType;
        }
        public void setValueByCollateralType(Map<String, BigDecimal> valueByCollateralType) {
            this.valueByCollateralType = valueByCollateralType;
        }

        public List<Object> getMonthlyStats() {
            return monthlyStats;
        }
        public void setMonthlyStats(List<Object> monthlyStats) {
            this.monthlyStats = monthlyStats;
        }
    }
    
    public static class WarehouseInSlip {
        private String generatedBy;
        private LocalDateTime slipDate;
        private String slipNumber;
        private String whCode;
        private String customerName;
        private String collateralType;
        private BigDecimal collateralValue;
        private String buName;
        private String downloadUrl;
        private String qrCodeUrl;
        private String slipContent;

        public String getGeneratedBy() {
            return generatedBy;
        }
        public void setGeneratedBy(String generatedBy) {
            this.generatedBy = generatedBy;
        }

        public LocalDateTime getSlipDate() {
            return slipDate;
        }
        public void setSlipDate(LocalDateTime slipDate) {
            this.slipDate = slipDate;
        }

        public String getSlipNumber() {
            return slipNumber;
        }
        public void setSlipNumber(String slipNumber) {
            this.slipNumber = slipNumber;
        }

        public String getWhCode() {
            return whCode;
        }
        public void setWhCode(String whCode) {
            this.whCode = whCode;
        }

        public String getCustomerName() {
            return customerName;
        }
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }

        public String getCollateralType() {
            return collateralType;
        }
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }

        public BigDecimal getCollateralValue() {
            return collateralValue;
        }
        public void setCollateralValue(BigDecimal collateralValue) {
            this.collateralValue = collateralValue;
        }

        public String getBuName() {
            return buName;
        }
        public void setBuName(String buName) {
            this.buName = buName;
        }

        public String getDownloadUrl() {
            return downloadUrl;
        }
        public void setDownloadUrl(String downloadUrl) {
            this.downloadUrl = downloadUrl;
        }

        public String getQrCodeUrl() {
            return qrCodeUrl;
        }
        public void setQrCodeUrl(String qrCodeUrl) {
            this.qrCodeUrl = qrCodeUrl;
        }

        public String getSlipContent() {
            return slipContent;
        }
        public void setSlipContent(String slipContent) {
            this.slipContent = slipContent;
        }
    }
    
    public static class ExportQuery {
        private WarehouseInQuery filter;
        private List<String> columns;
        private String exportFormat;
        private Boolean includeFiles;
        private Boolean includeApprovals;

        public WarehouseInQuery getFilter() {
            return filter;
        }
        public void setFilter(WarehouseInQuery filter) {
            this.filter = filter;
        }

        public List<String> getColumns() {
            return columns;
        }
        public void setColumns(List<String> columns) {
            this.columns = columns;
        }

        public String getExportFormat() {
            return exportFormat;
        }
        public void setExportFormat(String exportFormat) {
            this.exportFormat = exportFormat;
        }

        public Boolean getIncludeFiles() {
            return includeFiles;
        }
        public void setIncludeFiles(Boolean includeFiles) {
            this.includeFiles = includeFiles;
        }

        public Boolean getIncludeApprovals() {
            return includeApprovals;
        }
        public void setIncludeApprovals(Boolean includeApprovals) {
            this.includeApprovals = includeApprovals;
        }
    }
    
    public static class ExportData {
        private String fileName;
        private String fileType;
        private long fileSize;
        private String downloadUrl;
        private LocalDateTime generatedAt;
        private int recordCount;

        public String getFileName() {
            return fileName;
        }
        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public String getFileType() {
            return fileType;
        }
        public void setFileType(String fileType) {
            this.fileType = fileType;
        }

        public long getFileSize() {
            return fileSize;
        }
        public void setFileSize(long fileSize) {
            this.fileSize = fileSize;
        }

        public String getDownloadUrl() {
            return downloadUrl;
        }
        public void setDownloadUrl(String downloadUrl) {
            this.downloadUrl = downloadUrl;
        }

        public LocalDateTime getGeneratedAt() {
            return generatedAt;
        }
        public void setGeneratedAt(LocalDateTime generatedAt) {
            this.generatedAt = generatedAt;
        }

        public int getRecordCount() {
            return recordCount;
        }
        public void setRecordCount(int recordCount) {
            this.recordCount = recordCount;
        }
    }
    
    public static class ImportResult {
        private boolean success;
        private String message;
        private int totalRecords;
        private int successfulRecords;
        private int failedRecords;
        private String reportUrl;
        private List<ImportError> errors;

        public boolean getSuccess() {
            return success;
        }
        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getMessage() {
            return message;
        }
        public void setMessage(String message) {
            this.message = message;
        }

        public int getTotalRecords() {
            return totalRecords;
        }
        public void setTotalRecords(int totalRecords) {
            this.totalRecords = totalRecords;
        }

        public int getSuccessfulRecords() {
            return successfulRecords;
        }
        public void setSuccessfulRecords(int successfulRecords) {
            this.successfulRecords = successfulRecords;
        }

        public int getFailedRecords() {
            return failedRecords;
        }
        public void setFailedRecords(int failedRecords) {
            this.failedRecords = failedRecords;
        }

        public String getReportUrl() {
            return reportUrl;
        }
        public void setReportUrl(String reportUrl) {
            this.reportUrl = reportUrl;
        }

        public List<ImportError> getErrors() {
            return errors;
        }
        public void setErrors(List<ImportError> errors) {
            this.errors = errors;
        }
    }
    
    public static class ImportError {
        private int rowNumber;
        private String field;
        private String error;
        private String value;
        private String suggestion;

        public int getRowNumber() {
            return rowNumber;
        }
        public void setRowNumber(int rowNumber) {
            this.rowNumber = rowNumber;
        }

        public String getField() {
            return field;
        }
        public void setField(String field) {
            this.field = field;
        }

        public String getError() {
            return error;
        }
        public void setError(String error) {
            this.error = error;
        }

        public String getValue() {
            return value;
        }
        public void setValue(String value) {
            this.value = value;
        }

        public String getSuggestion() {
            return suggestion;
        }
        public void setSuggestion(String suggestion) {
            this.suggestion = suggestion;
        }
    }
    
    public static class HistoryRecord {
        private LocalDateTime timestamp;
        private String action;
        private String user;
        private String userRole;
        private String description;
        private String comment;
        private Map<String, Object> details;

        public LocalDateTime getTimestamp() {
            return timestamp;
        }
        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }

        public String getAction() {
            return action;
        }
        public void setAction(String action) {
            this.action = action;
        }

        public String getUser() {
            return user;
        }
        public void setUser(String user) {
            this.user = user;
        }

        public String getUserRole() {
            return userRole;
        }
        public void setUserRole(String userRole) {
            this.userRole = userRole;
        }

        public String getDescription() {
            return description;
        }
        public void setDescription(String description) {
            this.description = description;
        }

        public String getComment() {
            return comment;
        }
        public void setComment(String comment) {
            this.comment = comment;
        }

        public Map<String, Object> getDetails() {
            return details;
        }
        public void setDetails(Map<String, Object> details) {
            this.details = details;
        }
    }
    
    public static class ValidationResult {
        private boolean valid;
        private String message;
        private List<ValidationError> errors = new ArrayList<>();
        private List<ValidationWarning> warnings = new ArrayList<>();
        private Map<String, Object> suggestions;

        public boolean isValid() {
            return valid;
        }
        public void setValid(boolean valid) {
            this.valid = valid;
        }

        public String getMessage() {
            return message;
        }
        public void setMessage(String message) {
            this.message = message;
        }

        public List<ValidationError> getErrors() {
            return errors;
        }
        public void setErrors(List<ValidationError> errors) {
            this.errors = errors;
        }

        public List<ValidationWarning> getWarnings() {
            return warnings;
        }
        public void setWarnings(List<ValidationWarning> warnings) {
            this.warnings = warnings;
        }

        public Map<String, Object> getSuggestions() {
            return suggestions;
        }
        public void setSuggestions(Map<String, Object> suggestions) {
            this.suggestions = suggestions;
        }
    }
    
    public static class ValidationError {
        private String field;
        private String error;
        private String code;
        private String suggestion;

        public String getField() {
            return field;
        }
        public void setField(String field) {
            this.field = field;
        }

        public String getError() {
            return error;
        }
        public void setError(String error) {
            this.error = error;
        }

        public String getCode() {
            return code;
        }
        public void setCode(String code) {
            this.code = code;
        }

        public String getSuggestion() {
            return suggestion;
        }
        public void setSuggestion(String suggestion) {
            this.suggestion = suggestion;
        }
    }
    
    public static class ValidationWarning {
        private String field;
        private String warning;
        private String code;

        public String getField() {
            return field;
        }
        public void setField(String field) {
            this.field = field;
        }

        public String getWarning() {
            return warning;
        }
        public void setWarning(String warning) {
            this.warning = warning;
        }

        public String getCode() {
            return code;
        }
        public void setCode(String code) {
            this.code = code;
        }
    }
}
