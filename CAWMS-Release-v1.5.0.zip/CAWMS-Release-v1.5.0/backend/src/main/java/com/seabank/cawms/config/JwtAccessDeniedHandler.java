package com.seabank.cawms.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.common.ResponseCode;
import com.seabank.cawms.common.SecurityUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * JWT访问拒绝处理器（处理已认证但权限不足的访问）
 */
@Component
public class JwtAccessDeniedHandler implements AccessDeniedHandler {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(JwtAccessDeniedHandler.class);

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void handle(HttpServletRequest request,
                       HttpServletResponse response,
                       AccessDeniedException accessDeniedException) throws IOException, ServletException {
        
        log.warn("处理条件", 
                SecurityUtils.getCurrentUsername(),
                request.getMethod(),
                request.getRequestURI(),
                accessDeniedException.getMessage());
        
        // TODO: fix encoding comment
        response.setStatus(HttpStatus.FORBIDDEN.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        
        // TODO: fix encoding comment
        CommonResponse<Object> errorResponse = CommonResponse.error(
                ResponseCode.FORBIDDEN,
                "权限不足，无法访问该资源");
        
        // TODO: fix encoding comment
        String jsonResponse = objectMapper.writeValueAsString(errorResponse);
        response.getWriter().write(jsonResponse);
    }
}