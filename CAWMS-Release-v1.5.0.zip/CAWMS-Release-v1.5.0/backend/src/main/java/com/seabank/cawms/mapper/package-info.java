/**
 * Mapper package for CAWMS application
 * Contains MyBatis-Plus mapper interfaces for database operations
 */
package com.seabank.cawms.mapper;
