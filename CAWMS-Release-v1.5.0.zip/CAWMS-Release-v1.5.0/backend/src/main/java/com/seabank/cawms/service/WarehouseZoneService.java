package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.WarehouseZoneEntity;
import java.util.List;

public interface WarehouseZoneService {
    WarehouseZoneEntity create(WarehouseZoneEntity entity);
    WarehouseZoneEntity update(Long id, WarehouseZoneEntity entity);
    boolean delete(Long id);
    WarehouseZoneEntity getById(Long id);
    Page<WarehouseZoneEntity> list(int page, int size, String keyword);
    List<WarehouseZoneEntity> listAllActive();
}
