package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.WarehouseEntity;
import java.util.List;

public interface WarehouseService {
    WarehouseEntity create(WarehouseEntity entity);
    WarehouseEntity update(Long id, WarehouseEntity entity);
    boolean delete(Long id);
    WarehouseEntity getById(Long id);
    Page<WarehouseEntity> list(int page, int size, Long zoneId, String keyword);
    List<WarehouseEntity> listByZoneId(Long zoneId);
    List<WarehouseEntity> listAllActive();
}
