package com.seabank.cawms.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.BlockAttackInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.OptimisticLockerInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * MyBatis-Plus閰嶇疆绫? */

@Configuration
@EnableTransactionManagement
@MapperScan("com.seabank.cawms.mapper")
public class MyBatisPlusConfig {

    /**
     * MyBatis-Plus鎷︽埅鍣ㄩ厤缃?     */

    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        
        // TODO: fix encoding comment
        interceptor.addInnerInterceptor(paginationInnerInterceptor());
        
        // TODO: fix encoding comment
        interceptor.addInnerInterceptor(optimisticLockerInnerInterceptor());
        
        // TODO: fix encoding comment
        interceptor.addInnerInterceptor(blockAttackInnerInterceptor());
        
        return interceptor;
    }

    /**
     * 鍒嗛〉鎻掍欢閰嶇疆
     */
    @Bean
    public PaginationInnerInterceptor paginationInnerInterceptor() {
        PaginationInnerInterceptor paginationInterceptor = new PaginationInnerInterceptor();
        
        // TODO: fix encoding comment
        paginationInterceptor.setDbType(DbType.MYSQL);
        
        // TODO: fix encoding comment
        paginationInterceptor.setMaxLimit(1000L);
        
        // TODO: fix encoding comment
        paginationInterceptor.setOptimizeJoin(true);
        
        // TODO: fix encoding comment
        paginationInterceptor.setOverflow(false);
        
        return paginationInterceptor;
    }

    /**
     * 涔愯閿佹彃浠堕厤缃?     */

    @Bean
    public OptimisticLockerInnerInterceptor optimisticLockerInnerInterceptor() {
        return new OptimisticLockerInnerInterceptor();
    }

    /**
     * 闃叉鍏ㄨ〃更新涓庡垹闄ゆ彃浠?     */

    @Bean
    public BlockAttackInnerInterceptor blockAttackInnerInterceptor() {
        return new BlockAttackInnerInterceptor();
    }

    /**
     * SQL鎵ц鎬ц兘鍒嗘瀽鎻掍欢锛堜粎寮€鍙戠幆澧冨惎鐢級
     */
    // @Bean
    // TODO: fix encoding comment
    // public PerformanceInterceptor performanceInterceptor() {
    //     PerformanceInterceptor performanceInterceptor = new PerformanceInterceptor();
    // TODO: fix encoding comment
    // performanceInterceptor.setMaxTime(1000); // TODO: encoding issue
    // TODO: fix encoding comment
    // performanceInterceptor.setFormat(true); // TODO: encoding issue
    // TODO: fix encoding comment
    // return performanceInterceptor;
    // }
}