/**
 * System module package
 * Contains all components for system management (users, roles, audit logs, etc.)
 */
package com.seabank.cawms.module.system;
