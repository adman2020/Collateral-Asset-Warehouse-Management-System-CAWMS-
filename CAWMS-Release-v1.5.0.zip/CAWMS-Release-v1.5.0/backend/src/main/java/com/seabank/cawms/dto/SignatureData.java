package com.seabank.cawms.dto;

import java.time.LocalDateTime;

/**
 * 绛惧悕鏁版嵁 DTO
 */
public class SignatureData {
    private String signerName;
    private String signerTitle;
    private String signerRole;
    private String signatureImage;
    private String signatureDate;
    private LocalDateTime signTime;
    private String signatureMethod;
    private String certificateId;
    private String signatureLocation;
    private Boolean digitalSignature;
    private String signatureHash;


    public SignatureData() {
    }

    public SignatureData(String signerName, String signerTitle, String signerRole, String signatureImage, String signatureDate, LocalDateTime signTime, String signatureMethod, String certificateId, String signatureLocation, Boolean digitalSignature, String signatureHash) {
        this.signerName = signerName;
        this.signerTitle = signerTitle;
        this.signerRole = signerRole;
        this.signatureImage = signatureImage;
        this.signatureDate = signatureDate;
        this.signTime = signTime;
        this.signatureMethod = signatureMethod;
        this.certificateId = certificateId;
        this.signatureLocation = signatureLocation;
        this.digitalSignature = digitalSignature;
        this.signatureHash = signatureHash;
    }

    public String getSignerName() {
        return signerName;
    }

    public void setSignerName(String signerName) {
        this.signerName = signerName;
    }

    public String getSignerTitle() {
        return signerTitle;
    }

    public void setSignerTitle(String signerTitle) {
        this.signerTitle = signerTitle;
    }

    public String getSignerRole() {
        return signerRole;
    }

    public void setSignerRole(String signerRole) {
        this.signerRole = signerRole;
    }

    public String getSignatureImage() {
        return signatureImage;
    }

    public void setSignatureImage(String signatureImage) {
        this.signatureImage = signatureImage;
    }

    public String getSignatureDate() {
        return signatureDate;
    }

    public void setSignatureDate(String signatureDate) {
        this.signatureDate = signatureDate;
    }

    public LocalDateTime getSignTime() {
        return signTime;
    }

    public void setSignTime(LocalDateTime signTime) {
        this.signTime = signTime;
    }

    public String getSignatureMethod() {
        return signatureMethod;
    }

    public void setSignatureMethod(String signatureMethod) {
        this.signatureMethod = signatureMethod;
    }

    public String getCertificateId() {
        return certificateId;
    }

    public void setCertificateId(String certificateId) {
        this.certificateId = certificateId;
    }

    public String getSignatureLocation() {
        return signatureLocation;
    }

    public void setSignatureLocation(String signatureLocation) {
        this.signatureLocation = signatureLocation;
    }

    public Boolean getDigitalSignature() {
        return digitalSignature;
    }

    public void setDigitalSignature(Boolean digitalSignature) {
        this.digitalSignature = digitalSignature;
    }

    public String getSignatureHash() {
        return signatureHash;
    }

    public void setSignatureHash(String signatureHash) {
        this.signatureHash = signatureHash;
    }
}
