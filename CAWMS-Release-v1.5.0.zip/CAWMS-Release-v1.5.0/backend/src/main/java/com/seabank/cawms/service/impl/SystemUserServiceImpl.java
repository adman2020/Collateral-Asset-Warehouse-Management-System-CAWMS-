package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seabank.cawms.entity.SystemUserEntity;
import com.seabank.cawms.mapper.SystemUserMapper;
import com.seabank.cawms.service.SystemUserService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class SystemUserServiceImpl extends ServiceImpl<SystemUserMapper, SystemUserEntity> implements SystemUserService {

    public SystemUserEntity createUser(SystemUserEntity user) {
        baseMapper.insert(user);
        return user;
    }

    public SystemUserEntity updateUser(Long id, SystemUserEntity user) {
        user.setId(id);
        baseMapper.updateById(user);
        return user;
    }

    public boolean deleteUser(Long id) {
        return baseMapper.deleteById(id) > 0;
    }

    public SystemUserEntity getUserById(Long id) {
        return baseMapper.selectById(id);
    }

    public List<SystemUserEntity> listUsers() {
        return baseMapper.selectList(null);
    }

    @Override
    public SystemUserEntity findByUsername(String username) {
        return lambdaQuery().eq(SystemUserEntity::getUsername, username).one();
    }

    @Override
    public List<String> getUserRoles(Long userId) {
        return java.util.Collections.emptyList();
    }

    @Override
    public boolean existsByUsername(String username) {
        return baseMapper.selectCount(new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<SystemUserEntity>().eq(SystemUserEntity::getUsername, username)) > 0;
    }

    @Override
    public boolean existsByEmail(String email) {
        return baseMapper.selectCount(new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<SystemUserEntity>().eq(SystemUserEntity::getEmail, email)) > 0;
    }

    @Override
    public void updateLastLoginInfo(Long userId, String ipAddress) {
        SystemUserEntity user = new SystemUserEntity();
        user.setId(userId);
        user.setLastLoginIp(ipAddress);
        user.setLastLoginTime(java.time.LocalDateTime.now());
        baseMapper.updateById(user);
    }

    @Override
    public boolean lockUser(Long userId, String reason) {
        SystemUserEntity user = new SystemUserEntity();
        user.setId(userId);
        user.setStatus("LOCKED");
        return baseMapper.updateById(user) > 0;
    }

    @Override
    public boolean unlockUser(Long userId) {
        SystemUserEntity user = new SystemUserEntity();
        user.setId(userId);
        user.setStatus("ACTIVE");
        return baseMapper.updateById(user) > 0;
    }

    @Override
    public boolean resetPassword(Long userId, String newPassword) {
        SystemUserEntity user = new SystemUserEntity();
        user.setId(userId);
        user.setPassword(newPassword);
        return baseMapper.updateById(user) > 0;
    }

    @Override
    public boolean validatePassword(Long userId, String password) {
        SystemUserEntity user = baseMapper.selectById(userId);
        return user != null && password.equals(user.getPassword());
    }
}
