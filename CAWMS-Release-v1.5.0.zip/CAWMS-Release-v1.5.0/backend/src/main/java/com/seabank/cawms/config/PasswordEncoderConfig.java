package com.seabank.cawms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.Pbkdf2PasswordEncoder;
import org.springframework.security.crypto.scrypt.SCryptPasswordEncoder;

import java.util.HashMap;
import java.util.Map;

/**
 * Password encoder configuration
 * Supports multiple password encoding algorithms, default is BCrypt
 */
@Configuration
public class PasswordEncoderConfig {

    /**
     * Password encoder
     * Supports multiple encoding algorithms, default is bcrypt
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        Map<String, PasswordEncoder> encoders = new HashMap<>();

        String bcryptId = "bcrypt";
        encoders.put(bcryptId, new BCryptPasswordEncoder());

        String pbkdf2Id = "pbkdf2";
        encoders.put(pbkdf2Id, Pbkdf2PasswordEncoder.defaultsForSpringSecurity_v5_8());

        String scryptId = "scrypt";
        encoders.put(scryptId, SCryptPasswordEncoder.defaultsForSpringSecurity_v5_8());

        DelegatingPasswordEncoder delegatingPasswordEncoder = new DelegatingPasswordEncoder(bcryptId, encoders);
        delegatingPasswordEncoder.setDefaultPasswordEncoderForMatches(encoders.get(bcryptId));

        return delegatingPasswordEncoder;
    }

    /**
     * BCrypt password encoder (standalone Bean for specific scenarios)
     */
    @Bean
    public BCryptPasswordEncoder bcryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Password strength validator
     */
    @Bean
    public PasswordStrengthValidator passwordStrengthValidator() {
        return new PasswordStrengthValidator();
    }

    /**
     * Password policy configuration
     */
    public static class PasswordStrengthValidator {

        /**
         * Validate password strength
         * @param password password
         * @return validation result message, null means passed
         */
        public String validatePasswordStrength(String password) {
            if (password == null || password.length() < 8) {
                return "Password must be at least 8 characters";
            }

            if (!password.matches(".*\\d.*")) {
                return "Password must contain at least one digit";
            }

            if (!password.matches(".*[A-Z].*")) {
                return "Password must contain at least one uppercase letter";
            }

            if (!password.matches(".*[a-z].*")) {
                return "Password must contain at least one lowercase letter";
            }

            if (!password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) {
                return "Password must contain at least one special character";
            }

            if (isCommonWeakPassword(password)) {
                return "Password is too common or weak";
            }

            if (hasRepeatingCharacters(password, 3)) {
                return "Password cannot contain 3 or more consecutive repeating characters";
            }

            if (hasSequentialCharacters(password, 3)) {
                return "Password cannot contain 3 or more consecutive sequential characters";
            }

            return null;
        }

        /**
         * Check if common weak password
         */
        private boolean isCommonWeakPassword(String password) {
            String[] weakPasswords = {
                "password", "123456", "qwerty", "admin", "welcome",
                "password123", "admin123", "12345678", "123456789",
                "abc123", "1234567", "1234567890", "letmein", "monkey"
            };

            String lowerPassword = password.toLowerCase();
            for (String weak : weakPasswords) {
                if (lowerPassword.contains(weak) || weak.contains(lowerPassword)) {
                    return true;
                }
            }

            return false;
        }

        /**
         * Check if contains repeating characters
         */
        private boolean hasRepeatingCharacters(String str, int maxRepeating) {
            if (str == null || str.length() < maxRepeating) {
                return false;
            }

            for (int i = 0; i <= str.length() - maxRepeating; i++) {
                char current = str.charAt(i);
                boolean allSame = true;

                for (int j = 1; j < maxRepeating; j++) {
                    if (str.charAt(i + j) != current) {
                        allSame = false;
                        break;
                    }
                }

                if (allSame) {
                    return true;
                }
            }

            return false;
        }

        /**
         * Check if contains sequential characters
         */
        private boolean hasSequentialCharacters(String str, int sequenceLength) {
            if (str == null || str.length() < sequenceLength) {
                return false;
            }

            for (int i = 0; i <= str.length() - sequenceLength; i++) {
                boolean sequentialAsc = true;
                boolean sequentialDesc = true;

                for (int j = 1; j < sequenceLength; j++) {
                    char current = str.charAt(i + j - 1);
                    char next = str.charAt(i + j);

                    if (sequentialAsc && next != current + 1) {
                        sequentialAsc = false;
                    }

                    if (sequentialDesc && next != current - 1) {
                        sequentialDesc = false;
                    }

                    if (!sequentialAsc && !sequentialDesc) {
                        break;
                    }
                }

                if (sequentialAsc || sequentialDesc) {
                    return true;
                }
            }

            return false;
        }

        /**
         * Calculate password strength score
         * @param password password
         * @return strength score, 0-100
         */
        public int calculatePasswordStrengthScore(String password) {
            if (password == null || password.isEmpty()) {
                return 0;
            }

            int score = 0;

            if (password.length() >= 8) score += 10;
            if (password.length() >= 12) score += 10;
            if (password.length() >= 16) score += 10;

            if (password.matches(".*\\d.*")) score += 15;
            if (password.matches(".*[a-z].*")) score += 15;
            if (password.matches(".*[A-Z].*")) score += 15;
            if (password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) score += 15;

            if (password.length() >= 20) score += 10;
            if (password.matches(".*\\d.*\\d.*")) score += 5;
            if (password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) {
                score += 5;
            }

            if (isCommonWeakPassword(password)) score = Math.max(0, score - 30);
            if (hasRepeatingCharacters(password, 3)) score = Math.max(0, score - 20);
            if (hasSequentialCharacters(password, 3)) score = Math.max(0, score - 20);

            return Math.min(score, 100);
        }

        /**
         * Get password strength level
         * @param password password
         * @return strength level (VERY_WEAK, WEAK, MEDIUM, STRONG, VERY_STRONG)
         */
        public PasswordStrength getPasswordStrength(String password) {
            int score = calculatePasswordStrengthScore(password);

            if (score >= 80) {
                return PasswordStrength.VERY_STRONG;
            } else if (score >= 60) {
                return PasswordStrength.STRONG;
            } else if (score >= 40) {
                return PasswordStrength.MEDIUM;
            } else if (score >= 20) {
                return PasswordStrength.WEAK;
            } else {
                return PasswordStrength.VERY_WEAK;
            }
        }
    }

    /**
     * Password strength level enum
     */
    public enum PasswordStrength {
        VERY_WEAK("Very Weak", "Password security is extremely low, please change immediately"),
        WEAK("Weak", "Password security is low"),
        MEDIUM("Medium", "Password security is acceptable"),
        STRONG("Strong", "Password security is good"),
        VERY_STRONG("Very Strong", "Password security is excellent");

        private final String displayName;
        private final String description;

        PasswordStrength(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }

        public String getDisplayName() {
            return displayName;
        }

        public String getDescription() {
            return description;
        }
    }
}
