package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.WarehouseEntity;
import com.seabank.cawms.mapper.WarehouseMapper;
import com.seabank.cawms.service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class WarehouseServiceImpl implements WarehouseService {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WarehouseServiceImpl.class);

    private final WarehouseMapper warehouseMapper;

    @Autowired
    public WarehouseServiceImpl(WarehouseMapper warehouseMapper) {
        this.warehouseMapper = warehouseMapper;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseEntity create(WarehouseEntity entity) {
        entity.setDeleted(0);
        entity.setStatus(StringUtils.hasText(entity.getStatus()) ? entity.getStatus() : "ACTIVE");
        if (entity.getCreatedAt() == null) {
            entity.setCreatedAt(LocalDateTime.now());
        }
        warehouseMapper.insert(entity);
        return entity;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseEntity update(Long id, WarehouseEntity entity) {
        WarehouseEntity existing = warehouseMapper.selectById(id);
        if (existing == null || existing.getDeleted() != null && existing.getDeleted() == 1) {
            throw new IllegalArgumentException("仓库不存在: " + id);
        }
        entity.setId(id);
        warehouseMapper.updateById(entity);
        return warehouseMapper.selectById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(Long id) {
        WarehouseEntity existing = warehouseMapper.selectById(id);
        if (existing == null) {
            return false;
        }
        existing.setDeleted(1);
        existing.setUpdatedAt(LocalDateTime.now());
        warehouseMapper.updateById(existing);
        return true;
    }

    @Override
    public WarehouseEntity getById(Long id) {
        WarehouseEntity entity = warehouseMapper.selectById(id);
        if (entity == null || entity.getDeleted() != null && entity.getDeleted() == 1) {
            return null;
        }
        return entity;
    }

    @Override
    public Page<WarehouseEntity> list(int page, int size, Long zoneId, String keyword) {
        LambdaQueryWrapper<WarehouseEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(WarehouseEntity::getDeleted, 0);
        if (zoneId != null) {
            wrapper.eq(WarehouseEntity::getZoneId, zoneId);
        }
        if (StringUtils.hasText(keyword)) {
            wrapper.and(w -> w.like(WarehouseEntity::getWarehouseCode, keyword)
                    .or()
                    .like(WarehouseEntity::getWarehouseName, keyword));
        }
        wrapper.orderByDesc(WarehouseEntity::getCreatedAt);
        return warehouseMapper.selectPage(new Page<>(page, size), wrapper);
    }

    @Override
    public List<WarehouseEntity> listByZoneId(Long zoneId) {
        LambdaQueryWrapper<WarehouseEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(WarehouseEntity::getDeleted, 0)
               .eq(WarehouseEntity::getZoneId, zoneId)
               .eq(WarehouseEntity::getStatus, "ACTIVE")
               .orderByDesc(WarehouseEntity::getCreatedAt);
        return warehouseMapper.selectList(wrapper);
    }

    @Override
    public List<WarehouseEntity> listAllActive() {
        LambdaQueryWrapper<WarehouseEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(WarehouseEntity::getDeleted, 0)
               .eq(WarehouseEntity::getStatus, "ACTIVE")
               .orderByDesc(WarehouseEntity::getCreatedAt);
        return warehouseMapper.selectList(wrapper);
    }
}
