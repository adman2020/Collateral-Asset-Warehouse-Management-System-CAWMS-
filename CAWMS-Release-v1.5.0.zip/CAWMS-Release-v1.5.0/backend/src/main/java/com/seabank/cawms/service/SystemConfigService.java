package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.seabank.cawms.entity.SystemConfigEntity;

/**
 * 系统配置服务接口
 */
public interface SystemConfigService extends IService<SystemConfigEntity> {
}
