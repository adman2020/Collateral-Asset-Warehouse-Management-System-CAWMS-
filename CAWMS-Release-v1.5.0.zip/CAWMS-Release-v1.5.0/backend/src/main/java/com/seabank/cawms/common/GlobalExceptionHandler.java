package com.seabank.cawms.common;

import com.baomidou.mybatisplus.core.exceptions.MybatisPlusException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 鍏ㄥ眬寮傚父澶勭悊鍣? */
@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * 澶勭悊业务异常
     */
    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<CommonResponse<Object>> handleBusinessException(BusinessException e) {
        log.warn("业务异常: {}", e.getMessage(), e);
        CommonResponse<Object> response = CommonResponse.error(e.getCode(), e.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    /**
     * 处理认证异常
     */
    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<CommonResponse<Object>> handleAuthenticationException(AuthenticationException e) {
        log.warn("认证异常: {}", e.getMessage(), e);
        CommonResponse<Object> response;
        if (e instanceof BadCredentialsException) {
            response = CommonResponse.error(ResponseCode.CREDENTIALS_INVALID, "用户名或密码错误");
        } else if (e instanceof InternalAuthenticationServiceException) {
            response = CommonResponse.error(ResponseCode.SERVICE_UNAVAILABLE, "认证服务不可用");
        } else {
            response = CommonResponse.error(ResponseCode.UNAUTHORIZED, "认证失败: " + e.getMessage());
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
    }

    /**
     * 处理权限不足异常
     */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<CommonResponse<Object>> handleAccessDeniedException(AccessDeniedException e) {
        log.warn("鏉冮檺涓嶈冻: {}", e.getMessage(), e);
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.FORBIDDEN, "权限不足，无法访问该资源");
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
    }

    /**
     * 澶勭悊鍙傛暟楠岃瘉寮傚父锛園Validated @Valid锛?     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<CommonResponse<Object>> handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        log.warn("参数验证失败: {}", e.getMessage(), e);
        String errorMessage = e.getBindingResult().getFieldErrors().stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .collect(Collectors.joining("; "));
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.VALIDATION_ERROR, errorMessage);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    /**
     * 处理参数绑定异常
     */
    @ExceptionHandler(BindException.class)
    public ResponseEntity<CommonResponse<Object>> handleBindException(BindException e) {
        log.warn("参数绑定失败: {}", e.getMessage(), e);
        String errorMessage = e.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining("; "));
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.VALIDATION_ERROR, errorMessage);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    /**
     * 澶勭悊绾︽潫杩濆弽寮傚父
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<CommonResponse<Object>> handleConstraintViolationException(ConstraintViolationException e) {
        log.warn("绾︽潫杩濆弽: {}", e.getMessage(), e);
        String errorMessage = e.getConstraintViolations().stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining("; "));
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.VALIDATION_ERROR, errorMessage);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    /**
     * 澶勭悊鍙傛暟绫诲瀷涓嶅尮閰嶅紓甯?     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<CommonResponse<Object>> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException e) {
        log.warn("鍙傛暟绫诲瀷涓嶅尮閰? {}", e.getMessage(), e);
        String errorMessage = String.format("鍙傛暟 '%s' 绫诲瀷涓嶅尮閰嶏紝鏈熸湜绫诲瀷: %s", e.getName(), e.getRequiredType().getSimpleName());
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.BAD_REQUEST, errorMessage);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    /**
     * 澶勭悊HTTP娑堟伅涓嶅彲璇诲紓甯革紙濡侸SON瑙ｆ瀽澶辫触锛?     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<CommonResponse<Object>> handleHttpMessageNotReadableException(HttpMessageNotReadableException e) {
        log.warn("HTTP娑堟伅涓嶅彲璇? {}", e.getMessage(), e);
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.BAD_REQUEST, "请求格式错误，请检查提交的数据");
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    /**
     * 处理文件大小超过限制异常
     */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<CommonResponse<Object>> handleMaxUploadSizeExceededException(MaxUploadSizeExceededException e) {
        log.warn("文件大小超过限制: {}", e.getMessage(), e);
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.FILE_SIZE_EXCEEDED, "文件大小超过限制");
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    /**
     * 处理MyBatis-Plus异常
     */
    @ExceptionHandler(MybatisPlusException.class)
    public ResponseEntity<CommonResponse<Object>> handleMybatisPlusException(MybatisPlusException e) {
        log.error("MyBatis-Plus异常: {}", e.getMessage(), e);
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.ERROR, "鏁版嵁搴撴搷浣滃け璐? " + e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }

    /**
     * 处理SQL异常
     */
    @ExceptionHandler(SQLException.class)
    public ResponseEntity<CommonResponse<Object>> handleSQLException(SQLException e) {
        log.error("SQL寮傚父: {}", e.getMessage(), e);
        
        String errorMessage;
        if (e instanceof SQLIntegrityConstraintViolationException) {
            // TODO: fix encoding comment
            errorMessage = "鏁版嵁瀹屾暣鎬х害鏉熻繚鍙? " + e.getMessage();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.DATA_ALREADY_EXISTS, errorMessage));
        } else {
            errorMessage = "鏁版嵁搴撴搷浣滃け璐? " + e.getMessage();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, errorMessage));
        }
    }

    /**
     * 澶勭悊鎵€鏈夊叾浠栧紓甯?     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<CommonResponse<Object>> handleException(Exception e) {
        log.error("系统异常: {}", e.getMessage(), e);
        
        // TODO: fix encoding comment
        String errorMessage;
        if (isProductionEnvironment()) {
            errorMessage = "系统繁忙，请稍后再试";
        } else {
            errorMessage = "系统异常: " + e.getClass().getSimpleName() + ": " + e.getMessage();
        }
        
        CommonResponse<Object> response = CommonResponse.error(ResponseCode.ERROR, errorMessage);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }

    /**
     * 鍒ゆ柇鏄惁涓虹敓浜х幆澧?     */

    private boolean isProductionEnvironment() {
        // TODO: fix encoding comment
        String activeProfile = System.getProperty("spring.profiles.active");
        return activeProfile != null && activeProfile.contains("production");
    }
}