/**
 * Configuration package for CAWMS application
 * Contains Spring configuration classes for security, database, integration, etc.
 */
package com.seabank.cawms.config;
