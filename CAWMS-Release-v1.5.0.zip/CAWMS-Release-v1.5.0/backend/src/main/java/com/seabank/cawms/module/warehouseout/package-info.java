/**
 * Warehouse-Out module package
 * Contains all components for collateral asset warehouse-out management
 */
package com.seabank.cawms.module.warehouseout;
