/**
 * Entity package.
 */
package com.seabank.cawms.entity;
