package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@TableName("collateral_warehouse_in")
public class WarehouseInEntity extends BaseEntity {

    private String whCode;

    private Long zoneId;

    private Long warehouseId;
    
        private String buName;
    
        private String buCode;
    
        private String customerName;
    
        private String customerId;
    
        private String collateralType;

    private BigDecimal collateralValue;
    
        private String creditAgreementNo;
    
        private String intakeType;

    private String status;
    
        private Integer currentStep;
    
        private String dataSource;
    
        private LocalDateTime submittedAt;
    
        private LocalDateTime reviewedAt;
    
        private LocalDateTime completedAt;
    
        private String remarks;
    
        private String extData;
    
        @Version
    private Integer version;


    public String getWhCode() {
        return whCode;
    }
    public void setWhCode(String whCode) {
        this.whCode = whCode;
    }

    public Long getZoneId() {
        return zoneId;
    }
    public void setZoneId(Long zoneId) {
        this.zoneId = zoneId;
    }

    public Long getWarehouseId() {
        return warehouseId;
    }
    public void setWarehouseId(Long warehouseId) {
        this.warehouseId = warehouseId;
    }

    public String getBuName() {
        return buName;
    }
    public void setBuName(String buName) {
        this.buName = buName;
    }

    public String getBuCode() {
        return buCode;
    }
    public void setBuCode(String buCode) {
        this.buCode = buCode;
    }

    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCollateralType() {
        return collateralType;
    }
    public void setCollateralType(String collateralType) {
        this.collateralType = collateralType;
    }

    public BigDecimal getCollateralValue() {
        return collateralValue;
    }
    public void setCollateralValue(BigDecimal collateralValue) {
        this.collateralValue = collateralValue;
    }

    public String getCreditAgreementNo() {
        return creditAgreementNo;
    }
    public void setCreditAgreementNo(String creditAgreementNo) {
        this.creditAgreementNo = creditAgreementNo;
    }

    public String getIntakeType() {
        return intakeType;
    }
    public void setIntakeType(String intakeType) {
        this.intakeType = intakeType;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getCurrentStep() {
        return currentStep;
    }
    public void setCurrentStep(Integer currentStep) {
        this.currentStep = currentStep;
    }

    public String getDataSource() {
        return dataSource;
    }
    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    public LocalDateTime getSubmittedAt() {
        return submittedAt;
    }
    public void setSubmittedAt(LocalDateTime submittedAt) {
        this.submittedAt = submittedAt;
    }

    public LocalDateTime getReviewedAt() {
        return reviewedAt;
    }
    public void setReviewedAt(LocalDateTime reviewedAt) {
        this.reviewedAt = reviewedAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }
    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public String getRemarks() {
        return remarks;
    }
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getExtData() {
        return extData;
    }
    public void setExtData(String extData) {
        this.extData = extData;
    }

    public Integer getVersion() {
        return version;
    }
    public void setVersion(Integer version) {
        this.version = version;
    }
}