package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.LoanOutEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 鎶垫娂璧勪骇鍊熷嚭Mapper鎺ュ彛
 */
@Mapper
public interface LoanOutMapper extends BaseMapper<LoanOutEntity> {
    
    /**
     * 鏍规嵁鐘舵€佹煡璇㈠€熷嚭璁板綍
     * @param status 鐘舵€?     * @return 鍊熷嚭璁板綍鍒楄〃
     */
    List<LoanOutEntity> selectByStatus(@Param("status") String status);
    
    /**
     * 鏍规嵁瀹㈡埛鍚嶇О鏌ヨ鍊熷嚭璁板綍锛堥€氳繃鍏宠仈鐨勫叆搴撹褰曪級
     * @param customerName 瀹㈡埛鍚嶇О
     * @return 鍊熷嚭璁板綍鍒楄〃
     */
    List<LoanOutEntity> selectByCustomerName(@Param("customerName") String customerName);
    
    /**
     * 鏍规嵁鍊熷嚭鐩殑鏌ヨ鍊熷嚭璁板綍
     * @param loanPurpose 鍊熷嚭鐩殑
     * @return 鍊熷嚭璁板綍鍒楄〃
     */
    List<LoanOutEntity> selectByLoanPurpose(@Param("loanPurpose") String loanPurpose);
    
    /**
     * 鏌ヨ鎸囧畾鏃堕棿娈靛唴鐨勫€熷嚭璁板綍
     * @param startTime 寮€濮嬫椂闂?     * @param endTime 结束时间
     * @return 鍊熷嚭璁板綍鍒楄〃
     */
    List<LoanOutEntity> selectByTimeRange(
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);
    
    /**
     * 鏍规嵁棰勮褰掕繕鏃ユ湡鑼冨洿鏌ヨ鍊熷嚭璁板綍
     * @param startDate 寮€濮嬫棩鏈?     * @param endDate 缁撴潫鏃ユ湡
     * @return 鍊熷嚭璁板綍鍒楄〃
     */
    List<LoanOutEntity> selectByExpectedReturnDateRange(
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate);
    
    /**
     * 鏌ヨ閫炬湡鍊熷嚭璁板綍
     * @param currentDate 褰撳墠鏃ユ湡
     * @return 閫炬湡鍊熷嚭璁板綍鍒楄〃
     */
    List<LoanOutEntity> selectOverdueLoans(@Param("currentDate") LocalDate currentDate);
    
    /**
     * 鏌ヨ鍗冲皢鍒版湡鐨勫€熷嚭璁板綍锛堝湪鎸囧畾澶╂暟鍐呭埌鏈燂級
     * @param currentDate 褰撳墠鏃ユ湡
     * @param days 澶╂暟
     * @return 鍗冲皢鍒版湡鍊熷嚭璁板綍鍒楄〃
     */
    List<LoanOutEntity> selectExpiringLoans(
            @Param("currentDate") LocalDate currentDate,
            @Param("days") Integer days);
    
    /**
     * 鏍规嵁入库记录ID鏌ヨ鍊熷嚭璁板綍
     * @param whInId 入库记录ID
     * @return 鍊熷嚭璁板綍鍒楄〃
     */
    List<LoanOutEntity> selectByWhInId(@Param("whInId") Long whInId);
    
    /**
     * 鏍规嵁T24鍚屾鐘舵€佹煡璇㈠€熷嚭璁板綍
     * @param t24SyncStatus T24鍚屾鐘舵€?     * @return 鍊熷嚭璁板綍鍒楄〃
     */
    List<LoanOutEntity> selectByT24SyncStatus(@Param("t24SyncStatus") String t24SyncStatus);
    
    /**
     * 缁熻鍚勭姸鎬佸€熷嚭璁板綍鏁伴噺
     * @return 鐘舵€佺粺璁ap
     */
    @Select("<script>SELECT status, COUNT(*) as count FROM collateral_loan_out WHERE deleted = 0 " +
            "<if test='startDate != null'> AND created_at &gt;= #{startDate}</if>" +
            "<if test='endDate != null'> AND created_at &lt;= #{endDate}</if>" +
            " GROUP BY status</script>")
    List<Map<String, Object>> countByStatus(@Param("startDate") String startDate, @Param("endDate") String endDate);
    
    /**
     * 缁熻鍊熷嚭鎬讳环鍊硷紙閫氳繃鍏宠仈鍏ュ簱璁板綍锛?     * @return 鎬讳环鍊?     */

    @Select("<script>SELECT SUM(w.collateral_value) FROM collateral_loan_out l " +
            "JOIN collateral_warehouse_in w ON l.wh_in_id = w.id " +
            "WHERE l.status IN ('LOANED', 'OVERDUE') " +
            "<if test='startDate != null'> AND l.created_at &gt;= #{startDate}</if>" +
            "<if test='endDate != null'> AND l.created_at &lt;= #{endDate}</if></script>")
    BigDecimal sumLoanValue(@Param("startDate") String startDate, @Param("endDate") String endDate);
    
    /**
     * 鍒嗛〉鏌ヨ鍊熷嚭璁板綍锛堝甫鍏宠仈鏌ヨ锛?     * @param page 鍒嗛〉鍙傛暟
     * @param params 鏌ヨ鍙傛暟
     * @return 鍒嗛〉缁撴灉
     */
    IPage<LoanOutEntity> selectLoanOutPage(
            Page<LoanOutEntity> page,
            @Param("params") Map<String, Object> params);
    
    /**
     * 更新鍊熷嚭璁板綍鐘舵€?     * @param id 璁板綍ID
     * @param status 鏂扮姸鎬?     * @param updatedBy 更新浜?     * @return 褰卞搷琛屾暟
     */
    int updateStatus(
            @Param("id") Long id,
            @Param("status") String status,
            @Param("updatedBy") String updatedBy);
    
    /**
     * 更新T24鍚屾鐘舵€?     * @param id 璁板綍ID
     * @param t24SyncStatus T24鍚屾鐘舵€?     * @param t24SyncTime T24鍚屾鏃堕棿
     * @param updatedBy 更新浜?     * @return 褰卞搷琛屾暟
     */
    int updateT24SyncStatus(
            @Param("id") Long id,
            @Param("t24SyncStatus") String t24SyncStatus,
            @Param("t24SyncTime") LocalDateTime t24SyncTime,
            @Param("updatedBy") String updatedBy);
    
    /**
     * 更新瀹為檯褰掕繕鏃ユ湡
     * @param id 璁板綍ID
     * @param actualReturnDate 瀹為檯褰掕繕鏃ユ湡
     * @param updatedBy 更新浜?     * @return 褰卞搷琛屾暟
     */
    int updateActualReturnDate(
            @Param("id") Long id,
            @Param("actualReturnDate") LocalDate actualReturnDate,
            @Param("updatedBy") String updatedBy);
    
    /**
     * 缁熻浠婃棩鏂板鍊熷嚭璁板綍鏁?     * @return 浠婃棩鏂板鏁伴噺
     */
    @Select("SELECT COUNT(*) FROM collateral_loan_out WHERE DATE(created_at) = CURDATE()")
    Long countTodayLoans();
    
    /**
     * 缁熻鏈湀鍊熷嚭璁板綍鏁?     * @return 鏈湀鏁伴噺
     */
    @Select("SELECT COUNT(*) FROM collateral_loan_out WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())")
    Long countMonthLoans();
}