package com.seabank.cawms.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.common.PageResult;
import com.seabank.cawms.entity.SystemRoleEntity;
import com.seabank.cawms.service.SystemRoleService;
import com.seabank.cawms.util.I18nUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 角色管理控制器
 */
@Validated
@RestController
@RequestMapping("/api/system/roles")
@Tag(name = "RoleController", description = "角色管理API")
public class RoleController {

    private final SystemRoleService systemRoleService;

    public RoleController(SystemRoleService systemRoleService) {
        this.systemRoleService = systemRoleService;
    }

    @Operation(summary = "获取角色列表")
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<PageResult<RoleDto>> getRoleList(
            @RequestParam(defaultValue = "1") @Min(1) Integer page,
            @RequestParam(defaultValue = "10") @Min(1) Integer size,
            @RequestParam(required = false) String roleCode,
            @RequestParam(required = false) String roleName) {

        LambdaQueryWrapper<SystemRoleEntity> wrapper = new LambdaQueryWrapper<>();
        if (roleCode != null && !roleCode.isBlank()) {
            wrapper.like(SystemRoleEntity::getRoleCode, roleCode);
        }
        if (roleName != null && !roleName.isBlank()) {
            wrapper.like(SystemRoleEntity::getRoleName, roleName);
        }
        wrapper.orderByDesc(SystemRoleEntity::getCreatedAt);

        Page<SystemRoleEntity> entityPage = systemRoleService.page(new Page<>(page, size), wrapper);
        List<RoleDto> records = entityPage.getRecords().stream()
                .map(this::toDto)
                .toList();

        PageResult<RoleDto> result = PageResult.of(entityPage.getCurrent(), entityPage.getSize(),
                entityPage.getTotal(), records);
        return CommonResponse.success(result);
    }

    @Operation(summary = "获取角色详情")
    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<RoleDto> getRoleDetail(@PathVariable @NotNull Long id) {
        SystemRoleEntity role = systemRoleService.getById(id);
        if (role == null) {
            return CommonResponse.error(404, I18nUtil.getMessage("system.role.notFound"));
        }
        return CommonResponse.success(toDto(role));
    }

    @Operation(summary = "创建角色")
    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<RoleDto> createRole(@Valid @RequestBody RoleCreateRequest request) {
        if (systemRoleService.lambdaQuery().eq(SystemRoleEntity::getRoleCode, request.getRoleCode()).count() > 0) {
            return CommonResponse.error(409, I18nUtil.getMessage("system.role.codeExists"));
        }

        SystemRoleEntity role = new SystemRoleEntity();
        role.setRoleCode(request.getRoleCode());
        role.setRoleName(request.getRoleName());
        role.setDescription(request.getDescription());
        role.setDataScope(request.getDataScope());
        role.setStatus(request.getStatus() != null ? request.getStatus().toUpperCase() : "ACTIVE");
        role.setCreatedAt(LocalDateTime.now());
        role.setUpdatedAt(LocalDateTime.now());
        role.setDeleted(0);

        systemRoleService.save(role);
        return CommonResponse.success(toDto(role), I18nUtil.getMessage("system.role.createSuccess"));
    }

    @Operation(summary = "更新角色")
    @PutMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<RoleDto> updateRole(@PathVariable @NotNull Long id,
                                               @Valid @RequestBody RoleUpdateRequest request) {
        SystemRoleEntity role = systemRoleService.getById(id);
        if (role == null) {
            return CommonResponse.error(404, I18nUtil.getMessage("system.role.notFound"));
        }

        if (request.getRoleName() != null) role.setRoleName(request.getRoleName());
        if (request.getDescription() != null) role.setDescription(request.getDescription());
        if (request.getDataScope() != null) role.setDataScope(request.getDataScope());
        if (request.getStatus() != null) role.setStatus(request.getStatus().toUpperCase());
        if (request.getPermissions() != null) role.setPermissions(request.getPermissions());
        role.setUpdatedAt(LocalDateTime.now());

        systemRoleService.updateById(role);
        return CommonResponse.success(toDto(role), I18nUtil.getMessage("system.role.updateSuccess"));
    }

    @Operation(summary = "删除角色")
    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<Boolean> deleteRole(@PathVariable @NotNull Long id) {
        boolean removed = systemRoleService.removeById(id);
        if (!removed) {
            return CommonResponse.error(404, I18nUtil.getMessage("system.role.notFound"));
        }
        return CommonResponse.success(true, I18nUtil.getMessage("system.role.deleteSuccess"));
    }

    private RoleDto toDto(SystemRoleEntity role) {
        RoleDto dto = new RoleDto();
        dto.setId(role.getId());
        dto.setRoleCode(role.getRoleCode());
        dto.setRoleName(role.getRoleName());
        dto.setDescription(role.getDescription());
        dto.setDataScope(role.getDataScope());
        dto.setStatus(role.getStatus());
        dto.setPermissions(role.getPermissions());
        dto.setCreateTime(role.getCreatedAt() != null ? role.getCreatedAt().toString() : null);
        dto.setUpdateTime(role.getUpdatedAt() != null ? role.getUpdatedAt().toString() : null);
        return dto;
    }

    @Validated
    public static class RoleCreateRequest {
        @NotBlank private String roleCode;
        @NotBlank private String roleName;
        private String description;
        private String dataScope;
        private String status;

        public String getRoleCode() { return roleCode; }
        public void setRoleCode(String roleCode) { this.roleCode = roleCode; }
        public String getRoleName() { return roleName; }
        public void setRoleName(String roleName) { this.roleName = roleName; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public String getDataScope() { return dataScope; }
        public void setDataScope(String dataScope) { this.dataScope = dataScope; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    @Validated
    public static class RoleUpdateRequest {
        private String roleName;
        private String description;
        private String dataScope;
        private String status;
        private String permissions;

        public String getRoleName() { return roleName; }
        public void setRoleName(String roleName) { this.roleName = roleName; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public String getDataScope() { return dataScope; }
        public void setDataScope(String dataScope) { this.dataScope = dataScope; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getPermissions() { return permissions; }
        public void setPermissions(String permissions) { this.permissions = permissions; }
    }

    public static class RoleDto {
        private Long id;
        private String roleCode;
        private String roleName;
        private String description;
        private String dataScope;
        private String status;
        private String permissions;
        private String createTime;
        private String updateTime;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getRoleCode() { return roleCode; }
        public void setRoleCode(String roleCode) { this.roleCode = roleCode; }
        public String getRoleName() { return roleName; }
        public void setRoleName(String roleName) { this.roleName = roleName; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public String getDataScope() { return dataScope; }
        public void setDataScope(String dataScope) { this.dataScope = dataScope; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getPermissions() { return permissions; }
        public void setPermissions(String permissions) { this.permissions = permissions; }
        public String getCreateTime() { return createTime; }
        public void setCreateTime(String createTime) { this.createTime = createTime; }
        public String getUpdateTime() { return updateTime; }
        public void setUpdateTime(String updateTime) { this.updateTime = updateTime; }
    }
}
