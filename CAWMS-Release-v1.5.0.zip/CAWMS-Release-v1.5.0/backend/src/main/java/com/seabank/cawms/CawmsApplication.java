package com.seabank.cawms;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * CAWMS Application Main Class
 * SeABank Collateral Asset Warehouse Management System
 * 
 * @author SeABank Development Team
 * @version 1.0.0
 */
@SpringBootApplication
@EnableAsync
@EnableScheduling
@MapperScan("com.seabank.cawms.mapper")
public class CawmsApplication {

    public static void main(String[] args) {
        SpringApplication.run(CawmsApplication.class, args);
        System.out.println("""
            
            ========================================
            CAWMS Backend Application Started
            SeABank Collateral Asset Warehouse Management System
            Profile: Demo Mode
            ========================================
            """);
    }
}
