/**
 * Exception package for CAWMS application
 * Contains custom exception classes and global exception handlers
 */
package com.seabank.cawms.exception;
