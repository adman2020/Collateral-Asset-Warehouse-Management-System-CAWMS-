package com.seabank.cawms.dto;


public class SignatureResult {
    private Boolean success;
    private String slipId;
    private String signatureId;
    private String message;


    public SignatureResult() {
    }

    public SignatureResult(Boolean success, String slipId, String signatureId, String message) {
        this.success = success;
        this.slipId = slipId;
        this.signatureId = signatureId;
        this.message = message;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getSlipId() {
        return slipId;
    }

    public void setSlipId(String slipId) {
        this.slipId = slipId;
    }

    public String getSignatureId() {
        return signatureId;
    }

    public void setSignatureId(String signatureId) {
        this.signatureId = signatureId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
