package com.seabank.cawms.integration.t24;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * T24 Mock服务实现
 * 鐢ㄤ簬寮€鍙戝拰娴嬭瘯鐜锛屾ā鎷烼24閾惰鏍稿績绯荤粺鐨勮涓? */

@Service
@Profile("demo")
public class T24MockService implements T24IntegrationService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(T24MockService.class);

    private final Random random = new Random();
    private final Map<String, AccountBalance> accountBalances = new ConcurrentHashMap<>();
    private final Map<String, CustomerInfo> customerInfos = new ConcurrentHashMap<>();
    private final Map<String, List<TransactionDetail>> accountTransactions = new ConcurrentHashMap<>();
    private final Map<String, String> transactionPasswords = new ConcurrentHashMap<>();
    private String lastError;
    
    public T24MockService() {
        initializeMockData();
    }
    
    private void initializeMockData() {
        log.info("处理条件");
        
        // TODO: fix encoding comment
        initializeAccountBalances();
        
        // TODO: fix encoding comment
        initializeCustomerInfos();
        
        // TODO: fix encoding comment
        initializeTransactionPasswords();
        
        // TODO: fix encoding comment
        initializeTransactionHistory();
        
        log.info("处理条件");
    }
    
    private void initializeAccountBalances() {
        // TODO: fix encoding comment
        accountBalances.put("100000001", createAccountBalance("100000001", "Nguyen Van A", "VND", 
                new BigDecimal("1500000000"), new BigDecimal("1500000000"), new BigDecimal("0")));
        accountBalances.put("100000002", createAccountBalance("100000002", "Tran Thi B", "VND", 
                new BigDecimal("2500000000"), new BigDecimal("2500000000"), new BigDecimal("500000000")));
        accountBalances.put("100000003", createAccountBalance("100000003", "Le Van C", "VND", 
                new BigDecimal("750000000"), new BigDecimal("750000000"), new BigDecimal("0")));
        
        // TODO: fix encoding comment
        accountBalances.put("200000001", createAccountBalance("200000001", "Nguyen Van A", "USD", 
                new BigDecimal("50000"), new BigDecimal("50000"), new BigDecimal("10000")));
        accountBalances.put("200000002", createAccountBalance("200000002", "SeABank Treasury", "USD", 
                new BigDecimal("1000000"), new BigDecimal("1000000"), new BigDecimal("0")));
        
        // TODO: fix encoding comment
        accountBalances.put("300000001", createAccountBalance("300000001", "Tran Thi B", "EUR", 
                new BigDecimal("25000"), new BigDecimal("25000"), new BigDecimal("5000")));
    }
    
    private AccountBalance createAccountBalance(String accountNumber, String accountName, String currency,
                                                BigDecimal availableBalance, BigDecimal ledgerBalance, BigDecimal blockedAmount) {
        AccountBalance balance = new AccountBalance();
        balance.setAccountNumber(accountNumber);
        balance.setAccountName(accountName);
        balance.setCurrency(currency);
        balance.setAvailableBalance(availableBalance);
        balance.setLedgerBalance(ledgerBalance);
        balance.setBlockedAmount(blockedAmount);
        balance.setBalanceDate(LocalDateTime.now());
        balance.setAccountStatus("ACTIVE");
        return balance;
    }
    
    private void initializeCustomerInfos() {
        CustomerInfo customer1 = new CustomerInfo();
        customer1.setCustomerId("CUST001");
        customer1.setCustomerName("Nguyen Van A");
        customer1.setCustomerType("INDIVIDUAL");
        customer1.setIdNumber("001234567890");
        customer1.setBirthDate(LocalDateTime.of(1980, 5, 15, 0, 0));
        customer1.setNationality("Vietnamese");
        customer1.setAddress("123 Le Loi, District 1, Ho Chi Minh City");
        customer1.setPhoneNumber("+84 912345678");
        customer1.setEmail("nguyen.van.a@example.com");
        customer1.setRiskRating("LOW");
        customer1.setCustomerSince(LocalDateTime.of(2015, 3, 10, 0, 0));
        customer1.setCustomerStatus("ACTIVE");
        customerInfos.put("CUST001", customer1);
        
        CustomerInfo customer2 = new CustomerInfo();
        customer2.setCustomerId("CUST002");
        customer2.setCustomerName("Tran Thi B");
        customer2.setCustomerType("INDIVIDUAL");
        customer2.setIdNumber("002345678901");
        customer2.setBirthDate(LocalDateTime.of(1975, 8, 22, 0, 0));
        customer2.setNationality("Vietnamese");
        customer2.setAddress("456 Nguyen Hue, District 1, Ho Chi Minh City");
        customer2.setPhoneNumber("+84 923456789");
        customer2.setEmail("tran.thi.b@example.com");
        customer2.setRiskRating("MEDIUM");
        customer2.setCustomerSince(LocalDateTime.of(2018, 7, 15, 0, 0));
        customer2.setCustomerStatus("ACTIVE");
        customerInfos.put("CUST002", customer2);
        
        CustomerInfo customer3 = new CustomerInfo();
        customer3.setCustomerId("CUST003");
        customer3.setCustomerName("Le Van C");
        customer3.setCustomerType("INDIVIDUAL");
        customer3.setIdNumber("003456789012");
        customer3.setBirthDate(LocalDateTime.of(1990, 11, 30, 0, 0));
        customer3.setNationality("Vietnamese");
        customer3.setAddress("789 Dong Khoi, District 1, Ho Chi Minh City");
        customer3.setPhoneNumber("+84 934567890");
        customer3.setEmail("le.van.c@example.com");
        customer3.setRiskRating("LOW");
        customer3.setCustomerSince(LocalDateTime.of(2020, 1, 20, 0, 0));
        customer3.setCustomerStatus("ACTIVE");
        customerInfos.put("CUST003", customer3);
    }
    
    private void initializeTransactionPasswords() {
        transactionPasswords.put("100000001", "123456");
        transactionPasswords.put("100000002", "234567");
        transactionPasswords.put("100000003", "345678");
        transactionPasswords.put("200000001", "456789");
        transactionPasswords.put("200000002", "567890");
        transactionPasswords.put("300000001", "678901");
    }
    
    private void initializeTransactionHistory() {
        // TODO: fix encoding comment
        for (String accountNumber : accountBalances.keySet()) {
            List<TransactionDetail> transactions = generateMockTransactions(accountNumber);
            accountTransactions.put(accountNumber, transactions);
        }
    }
    
    private List<TransactionDetail> generateMockTransactions(String accountNumber) {
        List<TransactionDetail> transactions = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        
        // TODO: fix encoding comment
        for (int i = 0; i < 20; i++) {
            TransactionDetail transaction = new TransactionDetail();
            transaction.setTransactionId("TXN" + (1000000 + random.nextInt(9000000)));
            transaction.setReferenceNumber("REF" + (100000 + random.nextInt(900000)));
            transaction.setTransactionDate(now.minusDays(random.nextInt(30)).minusHours(random.nextInt(24)));
            
            // TODO: fix encoding comment
            String[] descriptions = {
                "Salary Payment", "Bill Payment", "ATM Withdrawal", "Fund Transfer",
                "Online Purchase", "Interest Credit", "Service Charge", "Loan Disbursement"
            };
            transaction.setDescription(descriptions[random.nextInt(descriptions.length)]);
            
            // TODO: fix encoding comment
            BigDecimal amount = new BigDecimal(random.nextInt(10000000) + 100000);
            transaction.setAmount(amount);
            
            AccountBalance balance = accountBalances.get(accountNumber);
            transaction.setCurrency(balance.getCurrency());
            
            // TODO: fix encoding comment
            String[] types = {"CREDIT", "DEBIT", "TRANSFER", "PAYMENT"};
            transaction.setTransactionType(types[random.nextInt(types.length)]);
            
            transaction.setDebitCreditFlag(random.nextBoolean() ? "D" : "C");
            transaction.setBalanceAfter(balance.getAvailableBalance().subtract(
                    transaction.getDebitCreditFlag().equals("D") ? amount : amount.negate()));
            
            String[] channels = {"ATM", "Internet Banking", "Mobile Banking", "Branch"};
            transaction.setChannel(channels[random.nextInt(channels.length)]);
            
            transactions.add(transaction);
        }
        
        // TODO: fix encoding comment
        transactions.sort((t1, t2) -> t2.getTransactionDate().compareTo(t1.getTransactionDate()));
        
        return transactions;
    }
    
    @Override
    public String getServiceName() {
        return "T24 Mock Service";
    }
    
    @Override
    public boolean isAvailable() {
        return true; // TODO: fix encoding comment
    }
    
    @Override
    public ServiceStatus getStatus() {
        return ServiceStatus.AVAILABLE;
    }
    
    @Override
    public ConnectionTestResult testConnection() {
        long startTime = System.currentTimeMillis();
        
        // TODO: fix encoding comment
        try {
            Thread.sleep(random.nextInt(100) + 50); // TODO: encoding issue
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        long responseTime = System.currentTimeMillis() - startTime;
        return new ConnectionTestResult(true, responseTime, "T24 Mock service connection successful", "Mock v1.0");
    }
    
    @Override
    public String getLastError() {
        return lastError;
    }
    
    @Override
    public AccountBalance queryAccountBalance(String accountNumber, String currency) {
        log.debug("处理条件", accountNumber, currency);
        
        AccountBalance balance = accountBalances.get(accountNumber);
        if (balance == null) {
            lastError = "Account not found: " + accountNumber;
            return null;
        }
        
        if (currency != null && !currency.equals(balance.getCurrency())) {
            lastError = "Currency mismatch. Account currency: " + balance.getCurrency();
            return null;
        }
        
        // TODO: fix encoding comment
        BigDecimal fluctuation = new BigDecimal(random.nextInt(10000) - 5000);
        balance.setAvailableBalance(balance.getAvailableBalance().add(fluctuation));
        balance.setBalanceDate(LocalDateTime.now());
        
        return balance;
    }
    
    @Override
    public List<TransactionDetail> queryAccountTransactions(String accountNumber, LocalDateTime startDate, LocalDateTime endDate) {
        log.debug("处理条件", accountNumber, startDate, endDate);
        
        List<TransactionDetail> allTransactions = accountTransactions.get(accountNumber);
        if (allTransactions == null) {
            lastError = "Account not found: " + accountNumber;
            return new ArrayList<>();
        }
        
        List<TransactionDetail> filteredTransactions = new ArrayList<>();
        for (TransactionDetail transaction : allTransactions) {
            LocalDateTime transactionDate = transaction.getTransactionDate();
            
            boolean afterStartDate = startDate == null || !transactionDate.isBefore(startDate);
            boolean beforeEndDate = endDate == null || !transactionDate.isAfter(endDate);
            
            if (afterStartDate && beforeEndDate) {
                filteredTransactions.add(transaction);
            }
        }
        
        return filteredTransactions;
    }
    
    @Override
    public FundTransferResponse fundTransfer(FundTransferRequest request) {
        log.debug("处理条件", 
                request.getFromAccount(), request.getToAccount(), 
                request.getAmount(), request.getCurrency());
        
        FundTransferResponse response = new FundTransferResponse();
        
        AccountBalance fromBalance = accountBalances.get(request.getFromAccount());
        
        // TODO: fix encoding comment
        if (fromBalance == null) {
            lastError = "Source account not found: " + request.getFromAccount();
            response.setSuccess(false);
            response.setMessage("Source account not found");
            return response;
        }
        
        // TODO: fix encoding comment
        AccountBalance toBalance = accountBalances.get(request.getToAccount());
        if (toBalance == null) {
            lastError = "Destination account not found: " + request.getToAccount();
            response.setSuccess(false);
            response.setMessage("Destination account not found");
            return response;
        }
        
        // TODO: fix encoding comment
        if (!request.getCurrency().equals(fromBalance.getCurrency())) {
            lastError = "Currency mismatch. Source account currency: " + fromBalance.getCurrency();
            response.setSuccess(false);
            response.setMessage("Currency mismatch");
            return response;
        }
        
        // TODO: fix encoding comment
        if (fromBalance.getAvailableBalance().compareTo(request.getAmount()) < 0) {
            lastError = "Insufficient balance. Available: " + fromBalance.getAvailableBalance();
            response.setSuccess(false);
            response.setMessage("Insufficient balance");
            return response;
        }
        
        // TODO: fix encoding comment
        try {
            Thread.sleep(random.nextInt(500) + 100); // TODO: encoding issue
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // TODO: fix encoding comment
        fromBalance.setAvailableBalance(fromBalance.getAvailableBalance().subtract(request.getAmount()));
        fromBalance.setLedgerBalance(fromBalance.getLedgerBalance().subtract(request.getAmount()));
        
        toBalance.setAvailableBalance(toBalance.getAvailableBalance().add(request.getAmount()));
        toBalance.setLedgerBalance(toBalance.getLedgerBalance().add(request.getAmount()));
        
        // TODO: fix encoding comment
        String transactionId = "TXN" + System.currentTimeMillis();
        
        // TODO: fix encoding comment
        response.setSuccess(true);
        response.setTransactionId(transactionId);
        response.setReferenceNumber(request.getTransactionReference());
        response.setTransactionDate(LocalDateTime.now());
        response.setStatus("COMPLETED");
        response.setMessage("Fund transfer completed successfully");
        response.setFees(new BigDecimal("10000")); // TODO: encoding issue
        
        log.info("处理条件", 
                transactionId, request.getAmount(), request.getCurrency());
        
        return response;
    }
    
    @Override
    public CustomerInfo queryCustomerInfo(String customerId) {
        log.debug("处理条件", customerId);
        return customerInfos.get(customerId);
    }
    
    @Override
    public PasswordValidationResult validateTransactionPassword(String accountNumber, String transactionPassword) {
        log.debug("验证交易密码: accountNumber={}", accountNumber);
        
        PasswordValidationResult result = new PasswordValidationResult();
        
        String storedPassword = transactionPasswords.get(accountNumber);
        if (storedPassword == null) {
            result.setValid(false);
            result.setRemainingAttempts(0);
            result.setLocked(true);
            result.setLockReason("Account not found");
            return result;
        }
        
        boolean isValid = storedPassword.equals(transactionPassword);
        result.setValid(isValid);
        
        if (isValid) {
            result.setRemainingAttempts(3);
            result.setLocked(false);
        } else {
            result.setRemainingAttempts(2);
            result.setLocked(false);
            // TODO: fix encoding comment
            if (random.nextInt(10) < 2) { // TODO: encoding issue
                result.setLocked(true);
                result.setLockReason("Too many failed attempts");
                result.setUnlockTime(LocalDateTime.now().plusHours(1));
            }
        }
        
        return result;
    }
    
    @Override
    public ProductInfo queryProductInfo(String productCode) {
        log.debug("处理条件", productCode);
        
        // TODO: fix encoding comment
        ProductInfo productInfo = new ProductInfo();
        productInfo.setProductCode(productCode);
        
        if ("SAVINGS".equals(productCode)) {
            productInfo.setProductName("Savings Account");
            productInfo.setProductType("DEPOSIT");
            productInfo.setCurrency("VND");
            productInfo.setMinimumBalance(new BigDecimal("100000"));
            productInfo.setInterestRate(new BigDecimal("0.05")); // 5%
            productInfo.setInterestCalculationMethod("DAILY");
            productInfo.setFeatures(List.of("Online Banking", "Mobile Banking", "ATM Card", "Monthly Statement"));
            productInfo.setStatus("ACTIVE");
        } else if ("CURRENT".equals(productCode)) {
            productInfo.setProductName("Current Account");
            productInfo.setProductType("DEPOSIT");
            productInfo.setCurrency("VND");
            productInfo.setMinimumBalance(new BigDecimal("500000"));
            productInfo.setInterestRate(new BigDecimal("0.01")); // 1%
            productInfo.setInterestCalculationMethod("MONTHLY");
            productInfo.setFeatures(List.of("Check Book", "Overdraft Facility", "Online Banking"));
            productInfo.setStatus("ACTIVE");
        } else if ("FIXED".equals(productCode)) {
            productInfo.setProductName("Fixed Deposit");
            productInfo.setProductType("TERM_DEPOSIT");
            productInfo.setCurrency("USD");
            productInfo.setMinimumBalance(new BigDecimal("1000"));
            productInfo.setInterestRate(new BigDecimal("0.07")); // 7%
            productInfo.setInterestCalculationMethod("QUARTERLY");
            productInfo.setFeatures(List.of("Fixed Term", "Higher Interest", "Auto Renewal"));
            productInfo.setStatus("ACTIVE");
        } else {
            productInfo.setProductName("Unknown Product");
            productInfo.setStatus("INACTIVE");
        }
        
        return productInfo;
    }
    
    @Override
    public List<AccountBalance> batchQueryAccountBalances(List<String> accountNumbers) {
        log.debug("处理条件", accountNumbers);
        
        List<AccountBalance> results = new ArrayList<>();
        for (String accountNumber : accountNumbers) {
            AccountBalance balance = accountBalances.get(accountNumber);
            if (balance != null) {
                results.add(balance);
            }
        }
        
        return results;
    }
    
    @Override
    public ExchangeRate queryExchangeRate(String fromCurrency, String toCurrency) {
        log.debug("处理条件", fromCurrency, toCurrency);
        
        ExchangeRate exchangeRate = new ExchangeRate();
        exchangeRate.setFromCurrency(fromCurrency);
        exchangeRate.setToCurrency(toCurrency);
        exchangeRate.setRateDate(LocalDateTime.now());
        exchangeRate.setRateType("SPOT");
        
        // TODO: fix encoding comment
        if ("USD".equals(fromCurrency) && "VND".equals(toCurrency)) {
            exchangeRate.setBuyingRate(new BigDecimal("23250"));
            exchangeRate.setSellingRate(new BigDecimal("23350"));
            exchangeRate.setMiddleRate(new BigDecimal("23300"));
        } else if ("EUR".equals(fromCurrency) && "VND".equals(toCurrency)) {
            exchangeRate.setBuyingRate(new BigDecimal("25100"));
            exchangeRate.setSellingRate(new BigDecimal("25200"));
            exchangeRate.setMiddleRate(new BigDecimal("25150"));
        } else if ("USD".equals(fromCurrency) && "EUR".equals(toCurrency)) {
            exchangeRate.setBuyingRate(new BigDecimal("0.92"));
            exchangeRate.setSellingRate(new BigDecimal("0.93"));
            exchangeRate.setMiddleRate(new BigDecimal("0.925"));
        } else {
            // TODO: fix encoding comment
            exchangeRate.setBuyingRate(new BigDecimal("1.0"));
            exchangeRate.setSellingRate(new BigDecimal("1.0"));
            exchangeRate.setMiddleRate(new BigDecimal("1.0"));
        }
        
        return exchangeRate;
    }
}