package com.seabank.cawms.service.impl;

import com.seabank.cawms.entity.LoanOutApprovalEntity;
import com.seabank.cawms.entity.SystemUserEntity;
import com.seabank.cawms.mapper.LoanOutApprovalMapper;
import com.seabank.cawms.mapper.SystemUserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;

@Component
public class LoanOutApprovalWorkflow {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(LoanOutApprovalWorkflow.class);
    public static final List<ApprovalStep> APPROVAL_STEPS = Arrays.asList(
        new ApprovalStep(1, "业务部门提交申请", "BUSINESS_MANAGER"),
        new ApprovalStep(2, "风险部门初审", "RISK_OFFICER"),
        new ApprovalStep(3, "合规部门审核", "COMPLIANCE_OFFICER"),
        new ApprovalStep(4, "资金部门审批", "TREASURY_OFFICER"),
        new ApprovalStep(5, "仓库管理员确认", "WAREHOUSE_MANAGER"),
        new ApprovalStep(6, "完成借出", "SYSTEM")
    );
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_APPROVED = "APPROVED";
    public static final String STATUS_REJECTED = "REJECTED";
    public static final String STATUS_RETURNED = "RETURNED";
    public static final String STATUS_CANCELLED = "CANCELLED";

    private final LoanOutApprovalMapper loanOutApprovalMapper;
    private final SystemUserMapper systemUserMapper;

    @Autowired
    public LoanOutApprovalWorkflow(LoanOutApprovalMapper loanOutApprovalMapper,
                                   SystemUserMapper systemUserMapper) {
        this.loanOutApprovalMapper = loanOutApprovalMapper;
        this.systemUserMapper = systemUserMapper;
    }

    public List<LoanOutApprovalEntity> initApprovalProcess(Long loanOutId, String creatorId, String creatorName) {
        log.info("初始化借出审批流程: loanOutId={}, creatorId={}", loanOutId, creatorId);

        List<LoanOutApprovalEntity> approvals = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();

        for (ApprovalStep step : APPROVAL_STEPS) {
            LoanOutApprovalEntity approval = new LoanOutApprovalEntity();
            approval.setLoanOutId(loanOutId);
            approval.setStepNumber(step.getStepNumber());
            approval.setStepName(step.getStepName());
            approval.setApproverRole(step.getApproverRole());

            if (step.getStepNumber() == 1) {
                approval.setStatus(STATUS_PENDING);
                approval.setApproverUser(creatorId);
                approval.setApproverName(creatorName);
            } else {
                approval.setStatus("WAITING");
            }

            approval.setCreatedAt(now);
            approval.setUpdatedAt(now);
            approvals.add(approval);
        }

        if (!approvals.isEmpty()) {
            loanOutApprovalMapper.batchInsert(approvals);
        }

        log.info("借出审批流程初始化完成: loanOutId={}, steps={}", loanOutId, approvals.size());
        return approvals;
    }

    public LoanOutApprovalEntity getCurrentPendingStep(Long loanOutId) {
        List<LoanOutApprovalEntity> approvals = loanOutApprovalMapper.selectByLoanOutId(loanOutId);
        approvals.sort(Comparator.comparing(LoanOutApprovalEntity::getStepNumber));

        for (LoanOutApprovalEntity approval : approvals) {
            if (STATUS_PENDING.equals(approval.getStatus())) {
                return approval;
            }
        }

        for (LoanOutApprovalEntity approval : approvals) {
            if ("WAITING".equals(approval.getStatus())) {
                approval.setStatus(STATUS_PENDING);
                approval.setUpdatedAt(LocalDateTime.now());
                loanOutApprovalMapper.updateById(approval);
                return approval;
            }
        }

        return null;
    }

    public ApprovalResult approveStep(Long loanOutId, Long approvalId,
                                      String comments, String approver, String approverName) {
        log.info("审批通过借出步骤: approvalId={}, approver={}", approvalId, approver);

        LoanOutApprovalEntity approval = loanOutApprovalMapper.selectById(approvalId);
        if (approval == null) {
            throw new IllegalArgumentException("审批记录不存在: " + approvalId);
        }

        if (!approval.getLoanOutId().equals(loanOutId)) {
            throw new IllegalArgumentException("审批记录与借出记录不匹配");
        }

        if (!STATUS_PENDING.equals(approval.getStatus())) {
            throw new IllegalStateException("只能审批PENDING状态的步骤");
        }

        checkApproverRole(approver, approval.getApproverRole());

        approval.setStatus(STATUS_APPROVED);
        approval.setApproverUser(approver);
        approval.setApproverName(approverName);
        approval.setComments(comments);
        approval.setApprovedAt(LocalDateTime.now());
        approval.setUpdatedAt(LocalDateTime.now());

        if (approval.getCreatedAt() != null) {
            long minutes = java.time.Duration.between(approval.getCreatedAt(), approval.getApprovedAt()).toMinutes();
            approval.setProcessingMinutes((int) minutes);
        }

        loanOutApprovalMapper.updateById(approval);

        if (approval.getStepNumber() < APPROVAL_STEPS.size()) {
            activateNextStep(loanOutId, approval.getStepNumber());
            autoCompleteSystemStepIfNeeded(loanOutId);
        }

        ApprovalResult result = new ApprovalResult();
        result.setSuccess(true);
        result.setApprovalId(approvalId);
        result.setStepNumber(approval.getStepNumber());
        result.setStepName(approval.getStepName());
        result.setMessage("步骤审批通过");
        result.setCompletedAt(approval.getApprovedAt());
        result.setNextStepActivated(approval.getStepNumber() < APPROVAL_STEPS.size());

        log.info("借出步骤审批通过: approvalId={}, stepNumber={}", approvalId, approval.getStepNumber());
        return result;
    }

    public RejectionResult rejectStep(Long loanOutId, Long approvalId,
                                      String comments, String rejector, String rejectorName) {
        log.info("拒绝借出步骤: approvalId={}, rejector={}", approvalId, rejector);

        LoanOutApprovalEntity approval = loanOutApprovalMapper.selectById(approvalId);
        if (approval == null) {
            throw new IllegalArgumentException("审批记录不存在: " + approvalId);
        }

        if (!approval.getLoanOutId().equals(loanOutId)) {
            throw new IllegalArgumentException("审批记录与借出记录不匹配");
        }

        if (!STATUS_PENDING.equals(approval.getStatus())) {
            throw new IllegalStateException("只能拒绝PENDING状态的步骤");
        }

        checkApproverRole(rejector, approval.getApproverRole());

        approval.setStatus(STATUS_REJECTED);
        approval.setApproverUser(rejector);
        approval.setApproverName(rejectorName);
        approval.setComments(comments);
        approval.setApprovedAt(LocalDateTime.now());
        approval.setUpdatedAt(LocalDateTime.now());

        loanOutApprovalMapper.updateById(approval);
        cancelPendingSteps(loanOutId, approval.getStepNumber());

        RejectionResult result = new RejectionResult();
        result.setSuccess(true);
        result.setApprovalId(approvalId);
        result.setStepNumber(approval.getStepNumber());
        result.setStepName(approval.getStepName());
        result.setMessage("步骤拒绝成功");
        result.setCompletedAt(approval.getApprovedAt());

        log.info("借出步骤拒绝成功: approvalId={}, stepNumber={}", approvalId, approval.getStepNumber());
        return result;
    }

    public ReturnResult returnStep(Long loanOutId, Long approvalId,
                                   String comments, String returner, String returnerName,
                                   Integer returnToStep) {
        log.info("退回借出步骤: approvalId={}, returnToStep={}, returner={}", approvalId, returnToStep, returner);

        LoanOutApprovalEntity approval = loanOutApprovalMapper.selectById(approvalId);
        if (approval == null) {
            throw new IllegalArgumentException("审批记录不存在: " + approvalId);
        }

        if (!approval.getLoanOutId().equals(loanOutId)) {
            throw new IllegalArgumentException("审批记录与借出记录不匹配");
        }

        if (!STATUS_PENDING.equals(approval.getStatus())) {
            throw new IllegalStateException("只能退回PENDING状态的步骤");
        }

        if (returnToStep == null || returnToStep < 1 || returnToStep >= approval.getStepNumber()) {
            throw new IllegalArgumentException("退回步骤编号无效，必须小于当前步骤");
        }

        checkApproverRole(returner, approval.getApproverRole());

        approval.setStatus(STATUS_RETURNED);
        approval.setApproverUser(returner);
        approval.setApproverName(returnerName);
        approval.setComments(comments);
        approval.setApprovedAt(LocalDateTime.now());
        approval.setUpdatedAt(LocalDateTime.now());

        loanOutApprovalMapper.updateById(approval);
        resetStepsTo(loanOutId, returnToStep);

        ReturnResult result = new ReturnResult();
        result.setSuccess(true);
        result.setApprovalId(approvalId);
        result.setStepNumber(approval.getStepNumber());
        result.setStepName(approval.getStepName());
        result.setReturnToStep(returnToStep);
        result.setMessage("步骤退回成功");
        result.setCompletedAt(approval.getApprovedAt());

        log.info("借出步骤退回成功: approvalId={}, returnToStep={}", approvalId, returnToStep);
        return result;
    }

    public boolean isProcessCompleted(Long loanOutId) {
        List<LoanOutApprovalEntity> approvals = loanOutApprovalMapper.selectByLoanOutId(loanOutId);

        if (approvals.isEmpty()) {
            return false;
        }

        int lastStep = APPROVAL_STEPS.size();
        for (LoanOutApprovalEntity approval : approvals) {
            if (approval.getStepNumber() == lastStep) {
                return STATUS_APPROVED.equals(approval.getStatus());
            }
        }

        return false;
    }

    public ApprovalProgress getApprovalProgress(Long loanOutId) {
        List<LoanOutApprovalEntity> approvals = loanOutApprovalMapper.selectByLoanOutId(loanOutId);

        ApprovalProgress progress = new ApprovalProgress();
        progress.setLoanOutId(loanOutId);
        progress.setTotalSteps(APPROVAL_STEPS.size());

        int completed = 0;
        int pending = 0;
        int waiting = 0;
        int rejected = 0;
        int returned = 0;
        int cancelled = 0;

        for (LoanOutApprovalEntity approval : approvals) {
            String status = approval.getStatus();
            if (STATUS_APPROVED.equals(status)) {
                completed++;
            } else if (STATUS_PENDING.equals(status)) {
                pending++;
            } else if ("WAITING".equals(status)) {
                waiting++;
            } else if (STATUS_REJECTED.equals(status)) {
                rejected++;
            } else if (STATUS_RETURNED.equals(status)) {
                returned++;
            } else if (STATUS_CANCELLED.equals(status)) {
                cancelled++;
            }
        }

        progress.setCompletedSteps(completed);
        progress.setPendingSteps(pending);
        progress.setWaitingSteps(waiting);
        progress.setRejectedSteps(rejected);
        progress.setReturnedSteps(returned);
        progress.setCancelledSteps(cancelled);

        if (APPROVAL_STEPS.size() > 0) {
            progress.setProgressPercentage((int) ((double) completed / APPROVAL_STEPS.size() * 100));
        } else {
            progress.setProgressPercentage(0);
        }

        progress.setCurrentStep(getCurrentPendingStep(loanOutId));
        progress.setIsCompleted(isProcessCompleted(loanOutId));

        return progress;
    }

    private void activateNextStep(Long loanOutId, Integer currentStepNumber) {
        Integer nextStepNumber = currentStepNumber + 1;
        List<LoanOutApprovalEntity> approvals = loanOutApprovalMapper.selectByLoanOutId(loanOutId);
        for (LoanOutApprovalEntity approval : approvals) {
            if (approval.getStepNumber().equals(nextStepNumber) && "WAITING".equals(approval.getStatus())) {
                approval.setStatus(STATUS_PENDING);
                approval.setUpdatedAt(LocalDateTime.now());
                loanOutApprovalMapper.updateById(approval);
                log.debug("激活下一步骤: loanOutId={}, stepNumber={}", loanOutId, nextStepNumber);
                break;
            }
        }
    }

    private void autoCompleteSystemStepIfNeeded(Long loanOutId) {
        List<LoanOutApprovalEntity> approvals = loanOutApprovalMapper.selectByLoanOutId(loanOutId);
        for (LoanOutApprovalEntity approval : approvals) {
            if (STATUS_PENDING.equals(approval.getStatus()) && "SYSTEM".equals(approval.getApproverRole())) {
                approval.setStatus(STATUS_APPROVED);
                approval.setApproverUser("SYSTEM");
                approval.setApproverName("SYSTEM");
                approval.setComments("系统自动完成借出");
                approval.setApprovedAt(LocalDateTime.now());
                approval.setUpdatedAt(LocalDateTime.now());
                if (approval.getCreatedAt() != null) {
                    long minutes = java.time.Duration.between(approval.getCreatedAt(), approval.getApprovedAt()).toMinutes();
                    approval.setProcessingMinutes((int) minutes);
                }
                loanOutApprovalMapper.updateById(approval);
                log.info("系统自动完成借出步骤: loanOutId={}, stepNumber={}", loanOutId, approval.getStepNumber());
                break;
            }
        }
    }

    private void cancelPendingSteps(Long loanOutId, Integer currentStepNumber) {
        List<LoanOutApprovalEntity> approvals = loanOutApprovalMapper.selectByLoanOutId(loanOutId);
        for (LoanOutApprovalEntity approval : approvals) {
            if (approval.getStepNumber() > currentStepNumber &&
                (STATUS_PENDING.equals(approval.getStatus()) || "WAITING".equals(approval.getStatus()))) {
                approval.setStatus(STATUS_CANCELLED);
                approval.setUpdatedAt(LocalDateTime.now());
                loanOutApprovalMapper.updateById(approval);
            }
        }
        log.debug("取消后续步骤: loanOutId={}, fromStep={}", loanOutId, currentStepNumber);
    }

    private void checkApproverRole(String approverUserId, String requiredRole) {
        if ("SYSTEM".equals(requiredRole)) {
            return;
        }

        SystemUserEntity user = null;
        try {
            user = systemUserMapper.selectById(Long.valueOf(approverUserId));
        } catch (NumberFormatException e) {
            log.warn("审批人ID格式不正确，尝试按用户名查询: {}", approverUserId);
        }

        if (user == null) {
            throw new IllegalArgumentException("审批用户不存在: " + approverUserId);
        }

        if (!requiredRole.equals(user.getRole()) && !"SUPER_ADMIN".equals(user.getRole())) {
            throw new IllegalStateException(
                "权限不足：当前步骤需要 [" + requiredRole + "] 角色，您的角色是 [" + user.getRole() + "]");
        }
    }

    private void resetStepsTo(Long loanOutId, Integer targetStepNumber) {
        List<LoanOutApprovalEntity> approvals = loanOutApprovalMapper.selectByLoanOutId(loanOutId);
        for (LoanOutApprovalEntity approval : approvals) {
            if (approval.getStepNumber() >= targetStepNumber) {
                if (approval.getStepNumber().equals(targetStepNumber)) {
                    approval.setStatus(STATUS_PENDING);
                } else {
                    approval.setStatus("WAITING");
                }
                approval.setApproverUser(null);
                approval.setApproverName(null);
                approval.setComments(null);
                approval.setApprovedAt(null);
                approval.setProcessingMinutes(null);
                approval.setUpdatedAt(LocalDateTime.now());
                loanOutApprovalMapper.updateById(approval);
            }
        }
        log.debug("重置步骤到: loanOutId={}, targetStep={}", loanOutId, targetStepNumber);
    }

    public static class ApprovalStep {
        private final Integer stepNumber;
        private final String stepName;
        private final String approverRole;

        public ApprovalStep(Integer stepNumber, String stepName, String approverRole) {
            this.stepNumber = stepNumber;
            this.stepName = stepName;
            this.approverRole = approverRole;
        }

        public Integer getStepNumber() { return stepNumber; }
        public String getStepName() { return stepName; }
        public String getApproverRole() { return approverRole; }
    }

    public static class ApprovalResult {
        private Boolean success;
        private Long approvalId;
        private Integer stepNumber;
        private String stepName;
        private String message;
        private LocalDateTime completedAt;
        private Boolean nextStepActivated;

        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Long getApprovalId() { return approvalId; }
        public void setApprovalId(Long approvalId) { this.approvalId = approvalId; }
        public Integer getStepNumber() { return stepNumber; }
        public void setStepNumber(Integer stepNumber) { this.stepNumber = stepNumber; }
        public String getStepName() { return stepName; }
        public void setStepName(String stepName) { this.stepName = stepName; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public LocalDateTime getCompletedAt() { return completedAt; }
        public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
        public Boolean getNextStepActivated() { return nextStepActivated; }
        public void setNextStepActivated(Boolean nextStepActivated) { this.nextStepActivated = nextStepActivated; }
    }

    public static class RejectionResult {
        private Boolean success;
        private Long approvalId;
        private Integer stepNumber;
        private String stepName;
        private String message;
        private LocalDateTime completedAt;

        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Long getApprovalId() { return approvalId; }
        public void setApprovalId(Long approvalId) { this.approvalId = approvalId; }
        public Integer getStepNumber() { return stepNumber; }
        public void setStepNumber(Integer stepNumber) { this.stepNumber = stepNumber; }
        public String getStepName() { return stepName; }
        public void setStepName(String stepName) { this.stepName = stepName; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public LocalDateTime getCompletedAt() { return completedAt; }
        public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
    }

    public static class ReturnResult {
        private Boolean success;
        private Long approvalId;
        private Integer stepNumber;
        private String stepName;
        private Integer returnToStep;
        private String message;
        private LocalDateTime completedAt;

        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Long getApprovalId() { return approvalId; }
        public void setApprovalId(Long approvalId) { this.approvalId = approvalId; }
        public Integer getStepNumber() { return stepNumber; }
        public void setStepNumber(Integer stepNumber) { this.stepNumber = stepNumber; }
        public String getStepName() { return stepName; }
        public void setStepName(String stepName) { this.stepName = stepName; }
        public Integer getReturnToStep() { return returnToStep; }
        public void setReturnToStep(Integer returnToStep) { this.returnToStep = returnToStep; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public LocalDateTime getCompletedAt() { return completedAt; }
        public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
    }

    public static class ApprovalProgress {
        private Long loanOutId;
        private Integer totalSteps;
        private Integer completedSteps;
        private Integer pendingSteps;
        private Integer waitingSteps;
        private Integer rejectedSteps;
        private Integer returnedSteps;
        private Integer cancelledSteps;
        private Integer progressPercentage;
        private LoanOutApprovalEntity currentStep;
        private Boolean isCompleted;

        public Long getLoanOutId() { return loanOutId; }
        public void setLoanOutId(Long loanOutId) { this.loanOutId = loanOutId; }
        public Integer getTotalSteps() { return totalSteps; }
        public void setTotalSteps(Integer totalSteps) { this.totalSteps = totalSteps; }
        public Integer getCompletedSteps() { return completedSteps; }
        public void setCompletedSteps(Integer completedSteps) { this.completedSteps = completedSteps; }
        public Integer getPendingSteps() { return pendingSteps; }
        public void setPendingSteps(Integer pendingSteps) { this.pendingSteps = pendingSteps; }
        public Integer getWaitingSteps() { return waitingSteps; }
        public void setWaitingSteps(Integer waitingSteps) { this.waitingSteps = waitingSteps; }
        public Integer getRejectedSteps() { return rejectedSteps; }
        public void setRejectedSteps(Integer rejectedSteps) { this.rejectedSteps = rejectedSteps; }
        public Integer getReturnedSteps() { return returnedSteps; }
        public void setReturnedSteps(Integer returnedSteps) { this.returnedSteps = returnedSteps; }
        public Integer getCancelledSteps() { return cancelledSteps; }
        public void setCancelledSteps(Integer cancelledSteps) { this.cancelledSteps = cancelledSteps; }
        public Integer getProgressPercentage() { return progressPercentage; }
        public void setProgressPercentage(Integer progressPercentage) { this.progressPercentage = progressPercentage; }
        public LoanOutApprovalEntity getCurrentStep() { return currentStep; }
        public void setCurrentStep(LoanOutApprovalEntity currentStep) { this.currentStep = currentStep; }
        public Boolean getIsCompleted() { return isCompleted; }
        public void setIsCompleted(Boolean isCompleted) { this.isCompleted = isCompleted; }
    }
}
