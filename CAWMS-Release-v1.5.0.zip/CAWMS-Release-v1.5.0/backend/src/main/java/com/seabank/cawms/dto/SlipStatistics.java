package com.seabank.cawms.dto;

import java.util.Map;

/**
 * 鍗曟嵁缁熻 DTO
 */
public class SlipStatistics {
    private Long totalGenerated;
    private Long totalSlips;
    private Long todayGenerated;
    private Long slipsGeneratedToday;
    private Long monthGenerated;
    private Long slipsGeneratedThisMonth;
    private Map<String, Long> byType;
    private Map<SlipFormat, Long> countByFormat;
    private Map<String, Long> byDepartment;
    private Map<String, Long> byTemplate;
    private Double successRate;
    private Long averageGenerationTime;
    private Long totalFileSize;
    private String mostFrequentType;
    private String busiestDepartment;


    public SlipStatistics() {
    }

    public SlipStatistics(Long totalGenerated, Long totalSlips, Long todayGenerated, Long slipsGeneratedToday, Long monthGenerated, Long slipsGeneratedThisMonth, Map<String, Long> byType, Map<SlipFormat, Long> countByFormat, Map<String, Long> byDepartment, Map<String, Long> byTemplate, Double successRate, Long averageGenerationTime, Long totalFileSize, String mostFrequentType, String busiestDepartment) {
        this.totalGenerated = totalGenerated;
        this.totalSlips = totalSlips;
        this.todayGenerated = todayGenerated;
        this.slipsGeneratedToday = slipsGeneratedToday;
        this.monthGenerated = monthGenerated;
        this.slipsGeneratedThisMonth = slipsGeneratedThisMonth;
        this.byType = byType;
        this.countByFormat = countByFormat;
        this.byDepartment = byDepartment;
        this.byTemplate = byTemplate;
        this.successRate = successRate;
        this.averageGenerationTime = averageGenerationTime;
        this.totalFileSize = totalFileSize;
        this.mostFrequentType = mostFrequentType;
        this.busiestDepartment = busiestDepartment;
    }

    public Long getTotalGenerated() {
        return totalGenerated;
    }

    public void setTotalGenerated(Long totalGenerated) {
        this.totalGenerated = totalGenerated;
    }

    public Long getTotalSlips() {
        return totalSlips;
    }

    public void setTotalSlips(Long totalSlips) {
        this.totalSlips = totalSlips;
    }

    public Long getTodayGenerated() {
        return todayGenerated;
    }

    public void setTodayGenerated(Long todayGenerated) {
        this.todayGenerated = todayGenerated;
    }

    public Long getSlipsGeneratedToday() {
        return slipsGeneratedToday;
    }

    public void setSlipsGeneratedToday(Long slipsGeneratedToday) {
        this.slipsGeneratedToday = slipsGeneratedToday;
    }

    public Long getMonthGenerated() {
        return monthGenerated;
    }

    public void setMonthGenerated(Long monthGenerated) {
        this.monthGenerated = monthGenerated;
    }

    public Long getSlipsGeneratedThisMonth() {
        return slipsGeneratedThisMonth;
    }

    public void setSlipsGeneratedThisMonth(Long slipsGeneratedThisMonth) {
        this.slipsGeneratedThisMonth = slipsGeneratedThisMonth;
    }

    public Map<String, Long> getByType() {
        return byType;
    }

    public void setByType(Map<String, Long> byType) {
        this.byType = byType;
    }

    public Map<SlipFormat, Long> getCountByFormat() {
        return countByFormat;
    }

    public void setCountByFormat(Map<SlipFormat, Long> countByFormat) {
        this.countByFormat = countByFormat;
    }

    public Map<String, Long> getByDepartment() {
        return byDepartment;
    }

    public void setByDepartment(Map<String, Long> byDepartment) {
        this.byDepartment = byDepartment;
    }

    public Map<String, Long> getByTemplate() {
        return byTemplate;
    }

    public void setByTemplate(Map<String, Long> byTemplate) {
        this.byTemplate = byTemplate;
    }

    public Double getSuccessRate() {
        return successRate;
    }

    public void setSuccessRate(Double successRate) {
        this.successRate = successRate;
    }

    public Long getAverageGenerationTime() {
        return averageGenerationTime;
    }

    public void setAverageGenerationTime(Long averageGenerationTime) {
        this.averageGenerationTime = averageGenerationTime;
    }

    public Long getTotalFileSize() {
        return totalFileSize;
    }

    public void setTotalFileSize(Long totalFileSize) {
        this.totalFileSize = totalFileSize;
    }

    public String getMostFrequentType() {
        return mostFrequentType;
    }

    public void setMostFrequentType(String mostFrequentType) {
        this.mostFrequentType = mostFrequentType;
    }

    public String getBusiestDepartment() {
        return busiestDepartment;
    }

    public void setBusiestDepartment(String busiestDepartment) {
        this.busiestDepartment = busiestDepartment;
    }
}
