package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDateTime;

/**
 * 绯荤粺鐢ㄦ埛瀹炰綋绫? */

@TableName("system_users")
public class SystemUserEntity extends BaseEntity {
    
    /**
     * 鐢ㄦ埛鍚?     */

    private String username;
    
    /**
     * 瀵嗙爜锛圔Crypt鍔犲瘑锛?     */

    private String password;
    
    /**
     * 用户全名
     */
    private String fullName;
    
    /**
     * 邮箱
     */
    private String email;
    
    /**
     * 电话号码
     */
    private String phoneNumber;
    
    /**
     * 部门
     */
    private String department;
    
    /**
     * 业务单元代码
     */
    private String buCode;
    
    /**
     * 角色
     */
    private String role;
    
    /**
     * 状态：ACTIVE, INACTIVE, LOCKED
     */
    private String status;
    
    /**
     * 鏈€鍚庣櫥褰曟椂闂?     */

    private LocalDateTime lastLoginTime;
    
    /**
     * 最后登录IP
     */
    private String lastLoginIp;


    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getDepartment() {
        return department;
    }
    public void setDepartment(String department) {
        this.department = department;
    }

    public String getBuCode() {
        return buCode;
    }
    public void setBuCode(String buCode) {
        this.buCode = buCode;
    }

    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getLastLoginTime() {
        return lastLoginTime;
    }
    public void setLastLoginTime(LocalDateTime lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public String getLastLoginIp() {
        return lastLoginIp;
    }
    public void setLastLoginIp(String lastLoginIp) {
        this.lastLoginIp = lastLoginIp;
    }
}