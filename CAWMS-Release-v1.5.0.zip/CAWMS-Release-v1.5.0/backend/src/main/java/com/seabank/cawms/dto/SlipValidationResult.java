package com.seabank.cawms.dto;

import java.util.List;
import java.util.Map;

/**
 * 单据验证结果 DTO
 */
public class SlipValidationResult {
    private Boolean valid;
    private String message;
    private String field;
    private String errorCode;
    private String suggestedFix;
    private Boolean canAutoFix;
    private String validationType;
    private Integer severity;
    private List<String> errors;
    private List<String> warnings;
    private Map<String, Object> validationDetails;
    
    public boolean isValid() {
        return valid != null && valid;
    }


    public SlipValidationResult() {
    }

    public SlipValidationResult(Boolean valid, String message, String field, String errorCode, String suggestedFix, Boolean canAutoFix, String validationType, Integer severity, List<String> errors, List<String> warnings, Map<String, Object> validationDetails) {
        this.valid = valid;
        this.message = message;
        this.field = field;
        this.errorCode = errorCode;
        this.suggestedFix = suggestedFix;
        this.canAutoFix = canAutoFix;
        this.validationType = validationType;
        this.severity = severity;
        this.errors = errors;
        this.warnings = warnings;
        this.validationDetails = validationDetails;
    }

    public Boolean getValid() {
        return valid;
    }

    public void setValid(Boolean valid) {
        this.valid = valid;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getSuggestedFix() {
        return suggestedFix;
    }

    public void setSuggestedFix(String suggestedFix) {
        this.suggestedFix = suggestedFix;
    }

    public Boolean getCanAutoFix() {
        return canAutoFix;
    }

    public void setCanAutoFix(Boolean canAutoFix) {
        this.canAutoFix = canAutoFix;
    }

    public String getValidationType() {
        return validationType;
    }

    public void setValidationType(String validationType) {
        this.validationType = validationType;
    }

    public Integer getSeverity() {
        return severity;
    }

    public void setSeverity(Integer severity) {
        this.severity = severity;
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }

    public List<String> getWarnings() {
        return warnings;
    }

    public void setWarnings(List<String> warnings) {
        this.warnings = warnings;
    }

    public Map<String, Object> getValidationDetails() {
        return validationDetails;
    }

    public void setValidationDetails(Map<String, Object> validationDetails) {
        this.validationDetails = validationDetails;
    }
}
