package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDateTime;

/**
 * 瀹¤鏃ュ織瀹炰綋绫? */

@TableName("audit_logs")
public class AuditLogEntity extends BaseEntity {
    
    /**
     * 妯″潡鍚嶇О
     */
    private String module;
    
    /**
     * 操作鍚嶇О
     */
    private String operation;
    
    /**
     * 璧勬簮绫诲瀷
     */
    private String resourceType;
    
    /**
     * 璧勬簮ID
     */
    private Long resourceId;
    
    /**
     * 鐢ㄦ埛ID
     */
    private Long userId;
    
    /**
     * 鐢ㄦ埛鍚?     */

    private String username;
    
    /**
     * 瀹㈡埛绔疘P
     */
    private String clientIp;
    
    /**
     * 鐢ㄦ埛浠ｇ悊
     */
    private String userAgent;
    
    /**
     * 璇锋眰URI
     */
    private String requestUri;
    
    /**
     * 璇锋眰鏂规硶
     */
    private String requestMethod;
    
    /**
     * 操作绫诲瀷
     */
    private String action;
    
    /**
     * 鐘舵€佺爜
     */
    private String statusCode;
    
    /**
     * 閿欒娑堟伅
     */
    private String errorMessage;
    
    /**
     * 閿欒鍫嗘爤
     */
    private String errorStack;
    
    /**
     * 鎵ц鏃堕棿锛堟绉掞級
     */
    private Integer executionTime;
    
    /**
     * 鏃堕棿鎴?     */

    private LocalDateTime timestamp;


    public String getModule() {
        return module;
    }
    public void setModule(String module) {
        this.module = module;
    }

    public String getOperation() {
        return operation;
    }
    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getResourceType() {
        return resourceType;
    }
    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }

    public Long getResourceId() {
        return resourceId;
    }
    public void setResourceId(Long resourceId) {
        this.resourceId = resourceId;
    }

    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getClientIp() {
        return clientIp;
    }
    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public String getUserAgent() {
        return userAgent;
    }
    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public String getRequestUri() {
        return requestUri;
    }
    public void setRequestUri(String requestUri) {
        this.requestUri = requestUri;
    }

    public String getRequestMethod() {
        return requestMethod;
    }
    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }

    public String getStatusCode() {
        return statusCode;
    }
    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorStack() {
        return errorStack;
    }
    public void setErrorStack(String errorStack) {
        this.errorStack = errorStack;
    }

    public Integer getExecutionTime() {
        return executionTime;
    }
    public void setExecutionTime(Integer executionTime) {
        this.executionTime = executionTime;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}