package com.seabank.cawms.dto;


public class GenerationRequest {
    private String prefix;
    private String dateStr;
    private Integer count;


    public GenerationRequest() {
    }

    public GenerationRequest(String prefix, String dateStr, Integer count) {
        this.prefix = prefix;
        this.dateStr = dateStr;
        this.count = count;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getDateStr() {
        return dateStr;
    }

    public void setDateStr(String dateStr) {
        this.dateStr = dateStr;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
