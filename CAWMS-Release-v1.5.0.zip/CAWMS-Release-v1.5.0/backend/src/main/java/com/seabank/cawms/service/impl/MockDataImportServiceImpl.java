package com.seabank.cawms.service.impl;

import com.seabank.cawms.service.DataImportService;
import static com.seabank.cawms.service.DataImportService.*;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.util.*;

@Service
@Profile("demo")
public class MockDataImportServiceImpl implements DataImportService {

    @Override
    public ImportResult importDataFile(MultipartFile file, String importType, String importer) {
        ImportResult r = new ImportResult();
        r.setSuccess(true);
        r.setImportedCount(0);
        r.setMessage("导入成功");
        return r;
    }

    @Override
    public BatchImportResult importBatchData(List<ImportRequest> requests) {
        BatchImportResult r = new BatchImportResult();
        r.setSuccess(true);
        return r;
    }

    @Override
    public ValidationResult validateImportData(Map<String, Object> data, String importType) {
        ValidationResult r = new ValidationResult();
        r.setValid(true);
        return r;
    }

    @Override
    public Map<String, Object> parseImportFile(MultipartFile file) {
        return new HashMap<>();
    }

    @Override
    public List<String> getSupportedImportTypes() {
        return Arrays.asList("WAREHOUSE_IN", "LOAN_OUT", "TRANSFER", "WAREHOUSE_OUT");
    }

    @Override
    public Map<String, Object> getImportTemplate(String importType) {
        return new HashMap<>();
    }

}
