package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seabank.cawms.common.PageResult;
import com.seabank.cawms.entity.AuditLogEntity;
import com.seabank.cawms.mapper.AuditLogMapper;
import com.seabank.cawms.service.AuditLogService;
import com.seabank.cawms.service.AuditLogService.AuditLogStats;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * 瀹¤鏃ュ織鏈嶅姟瀹炵幇绫? */


@Service
public class AuditLogServiceImpl extends ServiceImpl<AuditLogMapper, AuditLogEntity> implements AuditLogService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AuditLogServiceImpl.class);

    @Async("taskExecutor")
    @Override
    public void saveAuditLogAsync(AuditLogEntity auditLog) {
        try {
            // Temporarily disabled due to DB schema mismatch
            // save(auditLog);
            log.debug("Audit log skipped (schema mismatch): user={}, operation={}", auditLog.getUsername(), auditLog.getOperation());
        } catch (Exception e) {
            log.error("处理条件", auditLog, e);
            // TODO: fix encoding comment
        }
    }

    @Override
    @Transactional(readOnly = true)
    public PageResult<AuditLogEntity> queryAuditLogs(String module, String operation, String username,
                                                     LocalDateTime startTime, LocalDateTime endTime,
                                                     Long current, Long size) {
        
        LambdaQueryWrapper<AuditLogEntity> queryWrapper = new LambdaQueryWrapper<>();
        
        if (module != null && !module.isEmpty()) {
            queryWrapper.eq(AuditLogEntity::getModule, module);
        }
        
        if (operation != null && !operation.isEmpty()) {
            queryWrapper.eq(AuditLogEntity::getOperation, operation);
        }
        
        if (username != null && !username.isEmpty()) {
            queryWrapper.eq(AuditLogEntity::getUsername, username);
        }
        
        if (startTime != null) {
            queryWrapper.ge(AuditLogEntity::getTimestamp, startTime);
        }
        
        if (endTime != null) {
            queryWrapper.le(AuditLogEntity::getTimestamp, endTime);
        }
        
        queryWrapper.orderByDesc(AuditLogEntity::getTimestamp);
        
        Page<AuditLogEntity> page = new Page<>(current, size);
        Page<AuditLogEntity> resultPage = page(page, queryWrapper);
        
        return PageResult.of(resultPage);
    }

    @Override
    @Transactional
    public int cleanupExpiredAuditLogs(int retentionDays) {
        LocalDateTime cutoffDate = LocalDateTime.now().minusDays(retentionDays);
        
        LambdaQueryWrapper<AuditLogEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.lt(AuditLogEntity::getTimestamp, cutoffDate);
        
        int deletedCount = baseMapper.delete(queryWrapper);
        
        log.info("处理条件", retentionDays, deletedCount);
        return deletedCount;
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> getModuleList() {
        // TODO: fix encoding comment
        // TODO: fix encoding comment
        return List.of("入库管理", "借出管理", "处理条件", "出库管理", "用户管理", "角色管理", "绯荤粺閰嶇疆", "处理条件");
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> getOperationList() {
        // TODO: fix encoding comment
        // TODO: fix encoding comment
        return List.of("创建", "更新", "删除", "处理条件", "鐧诲綍", "鐧诲嚭", "瀹℃壒", "椹冲洖", "导出", "导入");
    }

    @Override
    @Transactional(readOnly = true)
    public AuditLogService.AuditLogStats getAuditLogStats(LocalDateTime startTime, LocalDateTime endTime) {
        LambdaQueryWrapper<AuditLogEntity> queryWrapper = new LambdaQueryWrapper<>();
        
        if (startTime != null) {
            queryWrapper.ge(AuditLogEntity::getTimestamp, startTime);
        }
        
        if (endTime != null) {
            queryWrapper.le(AuditLogEntity::getTimestamp, endTime);
        }
        
        long totalCount = count(queryWrapper);
        
        LambdaQueryWrapper<AuditLogEntity> successQuery = queryWrapper.clone();
        successQuery.eq(AuditLogEntity::getAction, "SUCCESS");
        long successCount = count(successQuery);
        
        LambdaQueryWrapper<AuditLogEntity> failureQuery = queryWrapper.clone();
        failureQuery.eq(AuditLogEntity::getAction, "FAILURE");
        long failureCount = count(failureQuery);
        
        // TODO: fix encoding comment
        LambdaQueryWrapper<AuditLogEntity> avgTimeQuery = queryWrapper.clone();
        avgTimeQuery.select(AuditLogEntity::getExecutionTime);
        List<Object> avgResult = listObjs(avgTimeQuery);
        Long averageExecutionTime = 0L;
        if (avgResult != null && !avgResult.isEmpty() && avgResult.get(0) != null) {
            averageExecutionTime = ((Number) avgResult.get(0)).longValue();
        }
        
        AuditLogService.AuditLogStats stats = new AuditLogService.AuditLogStats();
        stats.setTotalCount(totalCount);
        stats.setSuccessCount(successCount);
        stats.setFailureCount(failureCount);
        stats.setAverageExecutionTime(averageExecutionTime);
        
        return stats;
    }
    
    // TODO: fix encoding comment

}
