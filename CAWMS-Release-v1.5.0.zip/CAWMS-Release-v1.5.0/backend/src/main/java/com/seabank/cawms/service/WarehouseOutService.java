package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public interface WarehouseOutService {

    WarehouseOutDetail create(WarehouseOutCreateRequest request, String creator);

    WarehouseOutDetail update(Long id, WarehouseOutUpdateRequest request, String updater);

    boolean delete(Long id, String deleter);

    WarehouseOutDetail getById(Long id);

    Page<WarehouseOutDetail> query(WarehouseOutQuery query);

    WarehouseOutDetail submit(Long id, String submitter);

    WarehouseOutDetail approve(Long id, String approverId, String approverName, String comments);

    WarehouseOutDetail reject(Long id, String rejectorId, String rejectorName, String comments);

    WarehouseOutDetail complete(Long id, String operator);

    WarehouseOutDetail cancel(Long id, String operator);

    List<WarehouseOutApproval> getApprovalProgress(Long warehouseOutId);

    WarehouseOutApproval getCurrentPendingStep(Long warehouseOutId);

    WarehouseOutStatistics getStatistics();

    Page<WarehouseOutDetail> getPendingApprovals(String approverRole, String approverUser, Integer pageNum, Integer pageSize);

    Page<WarehouseOutDetail> getMyApplications(String userId, String status, Integer pageNum, Integer pageSize);

    Page<WarehouseOutDetail> getMyApprovals(String approverUser, String approverRole, String type, Integer pageNum, Integer pageSize);

    List<WarehouseOutHistory> getHistory(Long warehouseOutId);

    class WarehouseOutDetail {
        private Long id;
        private String warehouseOutNo;
        private Long warehouseInId;
        private String warehouseInNo;
        private String collateralName;
        private String collateralType;
        private BigDecimal collateralValue;
        private Long warehouseId;
        private String warehouseName;
        private String warehouseLocation;
        private String releaseType;
        private BigDecimal releaseAmount;
        private BigDecimal releasePercentage;
        private BigDecimal remainingValue;
        private BigDecimal originalValue;
        private String releaseReason;
        private String releaseReasonType;
        private String status;
        private Long applicantId;
        private String applicantName;
        private LocalDateTime applyTime;
        private LocalDateTime actualReleaseTime;
        private String remarks;
        private LocalDateTime createTime;
        private LocalDateTime updateTime;
        private List<WarehouseOutApproval> approvals;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getWarehouseOutNo() { return warehouseOutNo; }
        public void setWarehouseOutNo(String warehouseOutNo) { this.warehouseOutNo = warehouseOutNo; }
        public Long getWarehouseInId() { return warehouseInId; }
        public void setWarehouseInId(Long warehouseInId) { this.warehouseInId = warehouseInId; }
        public String getWarehouseInNo() { return warehouseInNo; }
        public void setWarehouseInNo(String warehouseInNo) { this.warehouseInNo = warehouseInNo; }
        public String getCollateralName() { return collateralName; }
        public void setCollateralName(String collateralName) { this.collateralName = collateralName; }
        public String getCollateralType() { return collateralType; }
        public void setCollateralType(String collateralType) { this.collateralType = collateralType; }
        public BigDecimal getCollateralValue() { return collateralValue; }
        public void setCollateralValue(BigDecimal collateralValue) { this.collateralValue = collateralValue; }
        public Long getWarehouseId() { return warehouseId; }
        public void setWarehouseId(Long warehouseId) { this.warehouseId = warehouseId; }
        public String getWarehouseName() { return warehouseName; }
        public void setWarehouseName(String warehouseName) { this.warehouseName = warehouseName; }
        public String getWarehouseLocation() { return warehouseLocation; }
        public void setWarehouseLocation(String warehouseLocation) { this.warehouseLocation = warehouseLocation; }
        public String getReleaseType() { return releaseType; }
        public void setReleaseType(String releaseType) { this.releaseType = releaseType; }
        public BigDecimal getReleaseAmount() { return releaseAmount; }
        public void setReleaseAmount(BigDecimal releaseAmount) { this.releaseAmount = releaseAmount; }
        public BigDecimal getReleasePercentage() { return releasePercentage; }
        public void setReleasePercentage(BigDecimal releasePercentage) { this.releasePercentage = releasePercentage; }
        public BigDecimal getRemainingValue() { return remainingValue; }
        public void setRemainingValue(BigDecimal remainingValue) { this.remainingValue = remainingValue; }
        public BigDecimal getOriginalValue() { return originalValue; }
        public void setOriginalValue(BigDecimal originalValue) { this.originalValue = originalValue; }
        public String getReleaseReason() { return releaseReason; }
        public void setReleaseReason(String releaseReason) { this.releaseReason = releaseReason; }
        public String getReleaseReasonType() { return releaseReasonType; }
        public void setReleaseReasonType(String releaseReasonType) { this.releaseReasonType = releaseReasonType; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public Long getApplicantId() { return applicantId; }
        public void setApplicantId(Long applicantId) { this.applicantId = applicantId; }
        public String getApplicantName() { return applicantName; }
        public void setApplicantName(String applicantName) { this.applicantName = applicantName; }
        public LocalDateTime getApplyTime() { return applyTime; }
        public void setApplyTime(LocalDateTime applyTime) { this.applyTime = applyTime; }
        public LocalDateTime getActualReleaseTime() { return actualReleaseTime; }
        public void setActualReleaseTime(LocalDateTime actualReleaseTime) { this.actualReleaseTime = actualReleaseTime; }
        public String getRemarks() { return remarks; }
        public void setRemarks(String remarks) { this.remarks = remarks; }
        public LocalDateTime getCreateTime() { return createTime; }
        public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }
        public LocalDateTime getUpdateTime() { return updateTime; }
        public void setUpdateTime(LocalDateTime updateTime) { this.updateTime = updateTime; }
        public List<WarehouseOutApproval> getApprovals() { return approvals; }
        public void setApprovals(List<WarehouseOutApproval> approvals) { this.approvals = approvals; }
    }

    class WarehouseOutCreateRequest {
        private Long warehouseInId;
        private String releaseType;
        private BigDecimal releaseAmount;
        private BigDecimal releasePercentage;
        private String releaseReasonType;
        private String releaseReason;
        private String remarks;

        public Long getWarehouseInId() { return warehouseInId; }
        public void setWarehouseInId(Long warehouseInId) { this.warehouseInId = warehouseInId; }
        public String getReleaseType() { return releaseType; }
        public void setReleaseType(String releaseType) { this.releaseType = releaseType; }
        public BigDecimal getReleaseAmount() { return releaseAmount; }
        public void setReleaseAmount(BigDecimal releaseAmount) { this.releaseAmount = releaseAmount; }
        public BigDecimal getReleasePercentage() { return releasePercentage; }
        public void setReleasePercentage(BigDecimal releasePercentage) { this.releasePercentage = releasePercentage; }
        public String getReleaseReasonType() { return releaseReasonType; }
        public void setReleaseReasonType(String releaseReasonType) { this.releaseReasonType = releaseReasonType; }
        public String getReleaseReason() { return releaseReason; }
        public void setReleaseReason(String releaseReason) { this.releaseReason = releaseReason; }
        public String getRemarks() { return remarks; }
        public void setRemarks(String remarks) { this.remarks = remarks; }
    }

    class WarehouseOutUpdateRequest {
        private String releaseType;
        private BigDecimal releaseAmount;
        private BigDecimal releasePercentage;
        private String releaseReasonType;
        private String releaseReason;
        private String remarks;

        public String getReleaseType() { return releaseType; }
        public void setReleaseType(String releaseType) { this.releaseType = releaseType; }
        public BigDecimal getReleaseAmount() { return releaseAmount; }
        public void setReleaseAmount(BigDecimal releaseAmount) { this.releaseAmount = releaseAmount; }
        public BigDecimal getReleasePercentage() { return releasePercentage; }
        public void setReleasePercentage(BigDecimal releasePercentage) { this.releasePercentage = releasePercentage; }
        public String getReleaseReasonType() { return releaseReasonType; }
        public void setReleaseReasonType(String releaseReasonType) { this.releaseReasonType = releaseReasonType; }
        public String getReleaseReason() { return releaseReason; }
        public void setReleaseReason(String releaseReason) { this.releaseReason = releaseReason; }
        public String getRemarks() { return remarks; }
        public void setRemarks(String remarks) { this.remarks = remarks; }
    }

    class WarehouseOutQuery {
        private Integer page;
        private Integer size;
        private String status;
        private String releaseType;
        private String releaseReasonType;
        private String warehouseInNo;
        private String collateralName;
        private String startDate;
        private String endDate;

        public Integer getPage() { return page; }
        public void setPage(Integer page) { this.page = page; }
        public Integer getSize() { return size; }
        public void setSize(Integer size) { this.size = size; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getReleaseType() { return releaseType; }
        public void setReleaseType(String releaseType) { this.releaseType = releaseType; }
        public String getReleaseReasonType() { return releaseReasonType; }
        public void setReleaseReasonType(String releaseReasonType) { this.releaseReasonType = releaseReasonType; }
        public String getWarehouseInNo() { return warehouseInNo; }
        public void setWarehouseInNo(String warehouseInNo) { this.warehouseInNo = warehouseInNo; }
        public String getCollateralName() { return collateralName; }
        public void setCollateralName(String collateralName) { this.collateralName = collateralName; }
        public String getStartDate() { return startDate; }
        public void setStartDate(String startDate) { this.startDate = startDate; }
        public String getEndDate() { return endDate; }
        public void setEndDate(String endDate) { this.endDate = endDate; }
    }

    class WarehouseOutApproval {
        private Long id;
        private Long warehouseOutId;
        private Integer step;
        private String stepName;
        private String approverRole;
        private Long approverId;
        private String approverName;
        private String approvalStatus;
        private String approvalOpinion;
        private LocalDateTime approvalTime;
        private LocalDateTime createTime;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getWarehouseOutId() { return warehouseOutId; }
        public void setWarehouseOutId(Long warehouseOutId) { this.warehouseOutId = warehouseOutId; }
        public Integer getStep() { return step; }
        public void setStep(Integer step) { this.step = step; }
        public String getStepName() { return stepName; }
        public void setStepName(String stepName) { this.stepName = stepName; }
        public String getApproverRole() { return approverRole; }
        public void setApproverRole(String approverRole) { this.approverRole = approverRole; }
        public Long getApproverId() { return approverId; }
        public void setApproverId(Long approverId) { this.approverId = approverId; }
        public String getApproverName() { return approverName; }
        public void setApproverName(String approverName) { this.approverName = approverName; }
        public String getApprovalStatus() { return approvalStatus; }
        public void setApprovalStatus(String approvalStatus) { this.approvalStatus = approvalStatus; }
        public String getApprovalOpinion() { return approvalOpinion; }
        public void setApprovalOpinion(String approvalOpinion) { this.approvalOpinion = approvalOpinion; }
        public LocalDateTime getApprovalTime() { return approvalTime; }
        public void setApprovalTime(LocalDateTime approvalTime) { this.approvalTime = approvalTime; }
        public LocalDateTime getCreateTime() { return createTime; }
        public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }
    }

    class WarehouseOutStatistics {
        private Integer total;
        private Map<String, Integer> byStatus;
        private Map<String, Integer> byReleaseType;
        private Map<String, Integer> byReasonType;
        private Integer pendingApprovals;
        private Integer completedToday;
        private BigDecimal totalReleaseAmount;

        public Integer getTotal() { return total; }
        public void setTotal(Integer total) { this.total = total; }
        public Map<String, Integer> getByStatus() { return byStatus; }
        public void setByStatus(Map<String, Integer> byStatus) { this.byStatus = byStatus; }
        public Map<String, Integer> getByReleaseType() { return byReleaseType; }
        public void setByReleaseType(Map<String, Integer> byReleaseType) { this.byReleaseType = byReleaseType; }
        public Map<String, Integer> getByReasonType() { return byReasonType; }
        public void setByReasonType(Map<String, Integer> byReasonType) { this.byReasonType = byReasonType; }
        public Integer getPendingApprovals() { return pendingApprovals; }
        public void setPendingApprovals(Integer pendingApprovals) { this.pendingApprovals = pendingApprovals; }
        public Integer getCompletedToday() { return completedToday; }
        public void setCompletedToday(Integer completedToday) { this.completedToday = completedToday; }
        public BigDecimal getTotalReleaseAmount() { return totalReleaseAmount; }
        public void setTotalReleaseAmount(BigDecimal totalReleaseAmount) { this.totalReleaseAmount = totalReleaseAmount; }
    }

    class WarehouseOutHistory {
        private Long id;
        private Long warehouseOutId;
        private String operationType;
        private String operationDesc;
        private Long operatorId;
        private String operatorName;
        private LocalDateTime operationTime;
        private String beforeValue;
        private String afterValue;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getWarehouseOutId() { return warehouseOutId; }
        public void setWarehouseOutId(Long warehouseOutId) { this.warehouseOutId = warehouseOutId; }
        public String getOperationType() { return operationType; }
        public void setOperationType(String operationType) { this.operationType = operationType; }
        public String getOperationDesc() { return operationDesc; }
        public void setOperationDesc(String operationDesc) { this.operationDesc = operationDesc; }
        public Long getOperatorId() { return operatorId; }
        public void setOperatorId(Long operatorId) { this.operatorId = operatorId; }
        public String getOperatorName() { return operatorName; }
        public void setOperatorName(String operatorName) { this.operatorName = operatorName; }
        public LocalDateTime getOperationTime() { return operationTime; }
        public void setOperationTime(LocalDateTime operationTime) { this.operationTime = operationTime; }
        public String getBeforeValue() { return beforeValue; }
        public void setBeforeValue(String beforeValue) { this.beforeValue = beforeValue; }
        public String getAfterValue() { return afterValue; }
        public void setAfterValue(String afterValue) { this.afterValue = afterValue; }
    }
}
