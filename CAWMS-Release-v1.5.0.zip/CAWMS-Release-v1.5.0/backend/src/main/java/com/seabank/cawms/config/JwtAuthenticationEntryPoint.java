package com.seabank.cawms.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.common.ResponseCode;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * JWT认证入口点（处理未认证访问）
 */
@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(JwtAuthenticationEntryPoint.class);

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void commence(HttpServletRequest request,
                         HttpServletResponse response,
                         AuthenticationException authException) throws IOException, ServletException {
        
        log.warn("处理条件", 
                request.getMethod(), 
                request.getRequestURI(),
                authException.getMessage());
        
        // TODO: fix encoding comment
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        
        // TODO: fix encoding comment
        CommonResponse<Object> errorResponse;
        
        String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            errorResponse = CommonResponse.error(ResponseCode.UNAUTHORIZED, "缺少访问令牌");
        } else {
            errorResponse = CommonResponse.error(ResponseCode.UNAUTHORIZED, "访问令牌无效或已过期");
        }
        
        // TODO: fix encoding comment
        String jsonResponse = objectMapper.writeValueAsString(errorResponse);
        response.getWriter().write(jsonResponse);
    }
}