package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seabank.cawms.entity.SystemRoleEntity;
import com.seabank.cawms.mapper.SystemRoleMapper;
import com.seabank.cawms.service.SystemRoleService;
import org.springframework.stereotype.Service;

/**
 * 系统角色服务实现
 */
@Service
public class SystemRoleServiceImpl extends ServiceImpl<SystemRoleMapper, SystemRoleEntity> implements SystemRoleService {
}
