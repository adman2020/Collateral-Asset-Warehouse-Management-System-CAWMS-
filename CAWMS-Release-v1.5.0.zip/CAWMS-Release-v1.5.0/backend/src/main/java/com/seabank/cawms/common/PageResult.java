package com.seabank.cawms.common;


import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * 鍒嗛〉缁撴灉绫? * @param <T> 数据类型
 */
public class PageResult<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 当前页码
     */
    private Long current;

    /**
     * 每页大小
     */
    private Long size;

    /**
     * 鎬昏褰曟暟
     */
    private Long total;

    /**
     * 鎬婚〉鏁?     */

    private Long pages;

    /**
     * 数据列表
     */
    private List<T> records;

    /**
     * 绌哄垎椤电粨鏋?     */

    public static <T> PageResult<T> empty() {
        return new PageResult<>(0L, 0L, 0L, 0L, Collections.emptyList());
    }

    /**
     * 创建分页结果
     */
    public static <T> PageResult<T> of(Long current, Long size, Long total, List<T> records) {
        PageResult<T> result = new PageResult<>();
        result.setCurrent(current);
        result.setSize(size);
        result.setTotal(total);
        result.setPages(calculatePages(total, size));
        result.setRecords(records);
        return result;
    }

    /**
     * 创建分页结果锛堜粠MyBatis-Plus鐨凱age瀵硅薄杞崲锛?     */

    public static <T> PageResult<T> of(com.baomidou.mybatisplus.extension.plugins.pagination.Page<T> page) {
        return of(page.getCurrent(), page.getSize(), page.getTotal(), page.getRecords());
    }

    /**
     * 璁＄畻鎬婚〉鏁?     */

    private static Long calculatePages(Long total, Long size) {
        if (total == null || total <= 0 || size == null || size <= 0) {
            return 0L;
        }
        return (total + size - 1) / size;
    }

    /**
     * 鏄惁鏈変笂涓€椤?     */

    public boolean hasPrevious() {
        return current != null && current > 1;
    }

    /**
     * 鏄惁鏈変笅涓€椤?     */

    public boolean hasNext() {
        return current != null && pages != null && current < pages;
    }

    /**
     * 鑾峰彇涓婁竴椤甸〉鐮?     */

    public Long getPreviousPage() {
        return hasPrevious() ? current - 1 : 1L;
    }

    /**
     * 鑾峰彇涓嬩竴椤甸〉鐮?     */

    public Long getNextPage() {
        return hasNext() ? current + 1 : (pages != null ? pages : 1L);
    }

    /**
     * 鑾峰彇寮€濮嬬储寮曪紙鐢ㄤ簬鍒嗛〉鏌ヨ锛?     */

    public Long getStartIndex() {
        if (current == null || size == null || current <= 0 || size <= 0) {
            return 0L;
        }
        return (current - 1) * size;
    }

    /**
     * 鑾峰彇缁撴潫绱㈠紩锛堢敤浜庡垎椤垫煡璇級
     */
    public Long getEndIndex() {
        Long startIndex = getStartIndex();
        if (startIndex == null || size == null) {
            return 0L;
        }
        return startIndex + size - 1;
    }

    /**
     * 鍒ゆ柇鏄惁涓虹┖缁撴灉
     */
    public boolean isEmpty() {
        return records == null || records.isEmpty();
    }

    /**
     * 判断是否包含数据
     */
    public boolean hasData() {
        return !isEmpty();
    }

    /**
     * 转换为通用响应
     */
    public CommonResponse<PageResult<T>> toResponse() {
        return CommonResponse.success(this);
    }


    public PageResult() {
    }

    public PageResult(Long current, Long size, Long total, Long pages, List<T> records) {
        this.current = current;
        this.size = size;
        this.total = total;
        this.pages = pages;
        this.records = records;
    }

    public Long getCurrent() {
        return current;
    }

    public void setCurrent(Long current) {
        this.current = current;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Long getPages() {
        return pages;
    }

    public void setPages(Long pages) {
        this.pages = pages;
    }

    public List<T> getRecords() {
        return records;
    }

    public void setRecords(List<T> records) {
        this.records = records;
    }
}