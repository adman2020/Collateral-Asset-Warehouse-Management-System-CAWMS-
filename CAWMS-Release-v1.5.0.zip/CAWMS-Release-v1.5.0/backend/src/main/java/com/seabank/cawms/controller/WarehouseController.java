package com.seabank.cawms.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.entity.WarehouseEntity;
import com.seabank.cawms.service.WarehouseService;
import com.seabank.cawms.util.I18nUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/warehouses")
@Tag(name = "WarehouseController", description = "仓库管理API")
public class WarehouseController {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WarehouseController.class);

    private final WarehouseService warehouseService;

    @Autowired
    public WarehouseController(WarehouseService warehouseService) {
        this.warehouseService = warehouseService;
    }

    @Operation(summary = "创建仓库")
    @PostMapping
    public CommonResponse<WarehouseEntity> create(@Valid @RequestBody WarehouseEntity entity) {
        WarehouseEntity created = warehouseService.create(entity);
        return CommonResponse.success(created, I18nUtil.getMessage("system.warehouse.createSuccess"));
    }

    @Operation(summary = "更新仓库")
    @PutMapping("/{id}")
    public CommonResponse<WarehouseEntity> update(@PathVariable Long id, @Valid @RequestBody WarehouseEntity entity) {
        WarehouseEntity updated = warehouseService.update(id, entity);
        return CommonResponse.success(updated, I18nUtil.getMessage("system.warehouse.updateSuccess"));
    }

    @Operation(summary = "删除仓库")
    @DeleteMapping("/{id}")
    public CommonResponse<Boolean> delete(@PathVariable Long id) {
        boolean result = warehouseService.delete(id);
        return CommonResponse.success(result, result ? I18nUtil.getMessage("system.warehouse.deleteSuccess") : I18nUtil.getMessage("system.warehouse.notFound"));
    }

    @Operation(summary = "获取仓库详情")
    @GetMapping("/{id}")
    public CommonResponse<WarehouseEntity> getById(@PathVariable Long id) {
        WarehouseEntity entity = warehouseService.getById(id);
        if (entity == null) {
            return CommonResponse.error(404, I18nUtil.getMessage("system.warehouse.notFound"));
        }
        return CommonResponse.success(entity, "查询成功");
    }

    @Operation(summary = "获取仓库列表")
    @GetMapping
    public CommonResponse<Page<WarehouseEntity>> list(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) Long zoneId,
            @RequestParam(required = false) String keyword) {
        Page<WarehouseEntity> result = warehouseService.list(pageNum, pageSize, zoneId, keyword);
        return CommonResponse.success(result, I18nUtil.getMessage("common.success"));
    }

    @Operation(summary = "获取全部有效仓库（下拉用）")
    @GetMapping("/all-active")
    public CommonResponse<List<WarehouseEntity>> listAllActive() {
        List<WarehouseEntity> list = warehouseService.listAllActive();
        return CommonResponse.success(list, I18nUtil.getMessage("common.success"));
    }
}
