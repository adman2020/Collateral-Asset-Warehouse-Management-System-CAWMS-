package com.seabank.cawms.dto;


public class BatchSlipGenerationResult {
    private Boolean success;
    private Integer totalCount;
    private Integer successfulCount;
    private Integer failedCount;


    public BatchSlipGenerationResult() {
    }

    public BatchSlipGenerationResult(Boolean success, Integer totalCount, Integer successfulCount, Integer failedCount) {
        this.success = success;
        this.totalCount = totalCount;
        this.successfulCount = successfulCount;
        this.failedCount = failedCount;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public Integer getSuccessfulCount() {
        return successfulCount;
    }

    public void setSuccessfulCount(Integer successfulCount) {
        this.successfulCount = successfulCount;
    }

    public Integer getFailedCount() {
        return failedCount;
    }

    public void setFailedCount(Integer failedCount) {
        this.failedCount = failedCount;
    }
}
