package com.seabank.cawms.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.entity.WarehouseEntity;
import com.seabank.cawms.entity.WarehouseZoneEntity;
import com.seabank.cawms.service.WarehouseService;
import com.seabank.cawms.service.WarehouseZoneService;
import com.seabank.cawms.util.I18nUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/warehouse-zones")
@Tag(name = "WarehouseZoneController", description = "库区管理API")
public class WarehouseZoneController {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WarehouseZoneController.class);

    private final WarehouseZoneService warehouseZoneService;
    private final WarehouseService warehouseService;

    @Autowired
    public WarehouseZoneController(WarehouseZoneService warehouseZoneService, WarehouseService warehouseService) {
        this.warehouseZoneService = warehouseZoneService;
        this.warehouseService = warehouseService;
    }

    @Operation(summary = "创建库区")
    @PostMapping
    public CommonResponse<WarehouseZoneEntity> create(@Valid @RequestBody WarehouseZoneEntity entity) {
        WarehouseZoneEntity created = warehouseZoneService.create(entity);
        return CommonResponse.success(created, I18nUtil.getMessage("system.warehouseZone.createSuccess"));
    }

    @Operation(summary = "更新库区")
    @PutMapping("/{id}")
    public CommonResponse<WarehouseZoneEntity> update(@PathVariable Long id, @Valid @RequestBody WarehouseZoneEntity entity) {
        WarehouseZoneEntity updated = warehouseZoneService.update(id, entity);
        return CommonResponse.success(updated, I18nUtil.getMessage("system.warehouseZone.updateSuccess"));
    }

    @Operation(summary = "删除库区")
    @DeleteMapping("/{id}")
    public CommonResponse<Boolean> delete(@PathVariable Long id) {
        boolean result = warehouseZoneService.delete(id);
        return CommonResponse.success(result, result ? I18nUtil.getMessage("system.warehouseZone.deleteSuccess") : I18nUtil.getMessage("system.warehouseZone.notFound"));
    }

    @Operation(summary = "获取库区详情")
    @GetMapping("/{id}")
    public CommonResponse<WarehouseZoneEntity> getById(@PathVariable Long id) {
        WarehouseZoneEntity entity = warehouseZoneService.getById(id);
        if (entity == null) {
            return CommonResponse.error(404, I18nUtil.getMessage("system.warehouseZone.notFound"));
        }
        return CommonResponse.success(entity, "查询成功");
    }

    @Operation(summary = "获取库区列表")
    @GetMapping
    public CommonResponse<Page<WarehouseZoneEntity>> list(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword) {
        Page<WarehouseZoneEntity> result = warehouseZoneService.list(pageNum, pageSize, keyword);
        return CommonResponse.success(result, I18nUtil.getMessage("common.success"));
    }

    @Operation(summary = "获取全部有效库区（下拉用）")
    @GetMapping("/all-active")
    public CommonResponse<List<WarehouseZoneEntity>> listAllActive() {
        List<WarehouseZoneEntity> list = warehouseZoneService.listAllActive();
        return CommonResponse.success(list, I18nUtil.getMessage("common.success"));
    }

    @Operation(summary = "获取库区下的仓库列表")
    @GetMapping("/{id}/warehouses")
    public CommonResponse<List<WarehouseEntity>> getWarehousesByZoneId(@PathVariable Long id) {
        List<WarehouseEntity> list = warehouseService.listByZoneId(id);
        return CommonResponse.success(list, I18nUtil.getMessage("common.success"));
    }
}
