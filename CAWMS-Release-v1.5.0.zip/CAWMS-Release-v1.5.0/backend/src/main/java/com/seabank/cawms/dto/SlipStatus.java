package com.seabank.cawms.dto;

/**
 * Slip status enum
 */

public enum SlipStatus {
    DRAFT("Draft"),
    GENERATED("Generated"),
    SIGNED("Signed"),
    ARCHIVED("Archived"),
    CANCELLED("Cancelled");

    private final String description;

    SlipStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
