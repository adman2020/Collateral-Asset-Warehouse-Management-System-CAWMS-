package com.seabank.cawms.service.impl;

import com.seabank.cawms.entity.LoanReturnApprovalEntity;
import com.seabank.cawms.mapper.LoanReturnApprovalMapper;
import com.seabank.cawms.workflow.LoanReturnApprovalWorkflow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class LoanReturnApprovalWorkflowImpl implements LoanReturnApprovalWorkflow {

    @Autowired
    private LoanReturnApprovalMapper mapper;

    public LoanReturnApprovalEntity createApproval(Long loanOutId) {
        LoanReturnApprovalEntity entity = new LoanReturnApprovalEntity();
        entity.setLoanOutId(loanOutId);
        entity.setStepNumber(1);
        entity.setStatus("PENDING");
        entity.setCreatedAt(LocalDateTime.now());
        return entity;
    }

    public boolean approveStep(Long approvalId, String approver) {
        LoanReturnApprovalEntity entity = mapper.selectById(approvalId);
        if (entity != null) {
            entity.setStatus("APPROVED");
            entity.setApproverUser(approver);
            entity.setApprovedAt(LocalDateTime.now());
            return mapper.updateById(entity) > 0;
        }
        return false;
    }

    public boolean rejectStep(Long approvalId, String reason) {
        LoanReturnApprovalEntity entity = mapper.selectById(approvalId);
        if (entity != null) {
            entity.setStatus("REJECTED");
            entity.setComments(reason);
            return mapper.updateById(entity) > 0;
        }
        return false;
    }

    public List<LoanReturnApprovalEntity> getApprovalSteps(Long loanOutId) {
        return new ArrayList<>();
    }

    @Override
    public ReturnResult initReturnApprovalProcess(Long loanOutId, String returnReason, String returner, LocalDateTime returnDate) {
        ReturnResult result = new ReturnResult();
        result.setSuccess(true);
        result.setMessage("OK");
        return result;
    }

    @Override
    public ReturnApprovalProgress getReturnApprovalProgress(Long loanOutId) {
        ReturnApprovalProgress progress = new ReturnApprovalProgress();
        progress.setLoanOutId(loanOutId);
        progress.setIsCompleted(false);
        return progress;
    }

    @Override
    public ReturnStepDetail getCurrentPendingReturnStep(Long loanOutId) {
        ReturnStepDetail detail = new ReturnStepDetail();
        detail.setStepNumber(1);
        detail.setStatus("PENDING");
        return detail;
    }

    @Override
    public ReturnResult returnReturnStep(Long loanOutId, Long stepId, String comments, String returner, Integer returnToStep) {
        ReturnResult result = new ReturnResult();
        result.setSuccess(true);
        result.setMessage("OK");
        return result;
    }

    @Override
    public ReturnApprovalResult approveReturnStep(Long loanOutId, Long approvalId, String comments, String approver,
                                                  String approverName, String assetCondition, String conditionDescription,
                                                  Double settlementAmount, String settlementMethod, String settlementReference) {
        ReturnApprovalResult result = new ReturnApprovalResult();
        result.setSuccess(true);
        result.setMessage("OK");
        return result;
    }

    @Override
    public ReturnRejectionResult rejectReturnStep(Long loanOutId, Long approvalId, String comments,
                                                  String rejector, String rejectorName) {
        ReturnRejectionResult result = new ReturnRejectionResult();
        result.setSuccess(true);
        result.setMessage("OK");
        return result;
    }

    @Override
    public ReturnStepResult returnReturnStep(Long loanOutId, Long approvalId, String comments,
                                             String returner, String returnerName, Integer returnToStep) {
        ReturnStepResult result = new ReturnStepResult();
        result.setSuccess(true);
        result.setMessage("OK");
        return result;
    }

    @Override
    public Boolean isReturnProcessCompleted(Long loanOutId) {
        return false;
    }
}
