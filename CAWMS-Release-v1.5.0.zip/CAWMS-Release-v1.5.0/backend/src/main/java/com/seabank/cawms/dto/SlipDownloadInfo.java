package com.seabank.cawms.dto;


/**
 * 鍗曟嵁涓嬭浇淇℃伅 DTO
 */
public class SlipDownloadInfo {
    private String slipId;
    private String fileName;
    private String filePath;
    private String downloadUrl;
    private Long fileSize;
    private String contentType;
    private SlipFormat format;
    private Boolean requiresSignature;
    private String checksum;
    private Long expiresAt;
    private Boolean downloadable;
    private Integer downloadCount;
    private String lastDownloaded;


    public SlipDownloadInfo() {
    }

    public SlipDownloadInfo(String slipId, String fileName, String filePath, String downloadUrl, Long fileSize, String contentType, SlipFormat format, Boolean requiresSignature, String checksum, Long expiresAt, Boolean downloadable, Integer downloadCount, String lastDownloaded) {
        this.slipId = slipId;
        this.fileName = fileName;
        this.filePath = filePath;
        this.downloadUrl = downloadUrl;
        this.fileSize = fileSize;
        this.contentType = contentType;
        this.format = format;
        this.requiresSignature = requiresSignature;
        this.checksum = checksum;
        this.expiresAt = expiresAt;
        this.downloadable = downloadable;
        this.downloadCount = downloadCount;
        this.lastDownloaded = lastDownloaded;
    }

    public String getSlipId() {
        return slipId;
    }

    public void setSlipId(String slipId) {
        this.slipId = slipId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public SlipFormat getFormat() {
        return format;
    }

    public void setFormat(SlipFormat format) {
        this.format = format;
    }

    public Boolean getRequiresSignature() {
        return requiresSignature;
    }

    public void setRequiresSignature(Boolean requiresSignature) {
        this.requiresSignature = requiresSignature;
    }

    public String getChecksum() {
        return checksum;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public Long getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(Long expiresAt) {
        this.expiresAt = expiresAt;
    }

    public Boolean getDownloadable() {
        return downloadable;
    }

    public void setDownloadable(Boolean downloadable) {
        this.downloadable = downloadable;
    }

    public Integer getDownloadCount() {
        return downloadCount;
    }

    public void setDownloadCount(Integer downloadCount) {
        this.downloadCount = downloadCount;
    }

    public String getLastDownloaded() {
        return lastDownloaded;
    }

    public void setLastDownloaded(String lastDownloaded) {
        this.lastDownloaded = lastDownloaded;
    }
}
