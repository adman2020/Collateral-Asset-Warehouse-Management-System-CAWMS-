package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.WarehouseEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface WarehouseMapper extends BaseMapper<WarehouseEntity> {

    @Select("SELECT * FROM warehouse WHERE warehouse_code = #{warehouseCode} AND deleted = 0 LIMIT 1")
    WarehouseEntity selectByWarehouseCode(@Param("warehouseCode") String warehouseCode);

    @Select("SELECT * FROM warehouse WHERE zone_id = #{zoneId} AND deleted = 0 ORDER BY created_at DESC")
    List<WarehouseEntity> selectByZoneId(@Param("zoneId") Long zoneId);

    @Select("SELECT * FROM warehouse WHERE deleted = 0 ORDER BY created_at DESC")
    List<WarehouseEntity> selectAllActive();
}
