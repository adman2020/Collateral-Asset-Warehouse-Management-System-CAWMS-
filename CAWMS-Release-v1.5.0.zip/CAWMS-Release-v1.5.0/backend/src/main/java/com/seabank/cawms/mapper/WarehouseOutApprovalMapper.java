package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.WarehouseOutApprovalEntity;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface WarehouseOutApprovalMapper extends BaseMapper<WarehouseOutApprovalEntity> {

    @Select("SELECT * FROM warehouse_out_approval WHERE wh_out_id = #{warehouseOutId} AND status = 'PENDING' ORDER BY step_number LIMIT 1")
    WarehouseOutApprovalEntity selectCurrentPendingStep(@Param("warehouseOutId") Long warehouseOutId);

    @Select("SELECT * FROM warehouse_out_approval WHERE wh_out_id = #{warehouseOutId} ORDER BY step_number")
    List<WarehouseOutApprovalEntity> selectByWarehouseOutId(@Param("warehouseOutId") Long warehouseOutId);

    @Delete("DELETE FROM warehouse_out_approval WHERE wh_out_id = #{warehouseOutId}")
    void deleteByWarehouseOutId(@Param("warehouseOutId") Long warehouseOutId);
}
