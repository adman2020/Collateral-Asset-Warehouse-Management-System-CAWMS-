package com.seabank.cawms.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Optional;

/**
 * 瀹夊叏宸ュ叿绫? */

public class SecurityUtils {

    private SecurityUtils() {
        // TODO: fix encoding comment
        }

    /**
     * 鑾峰彇褰撳墠璁よ瘉淇℃伅
     */
    public static Optional<Authentication> getCurrentAuthentication() {
        return Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication());
    }

    /**
     * 鑾峰彇褰撳墠鐢ㄦ埛鍚?     */

    public static Optional<String> getCurrentUsername() {
        return getCurrentAuthentication()
                .map(authentication -> {
                    Object principal = authentication.getPrincipal();
                    if (principal instanceof UserDetails) {
                        return ((UserDetails) principal).getUsername();
                    } else if (principal instanceof String) {
                        return (String) principal;
                    }
                    return null;
                });
    }

    /**
     * 鑾峰彇褰撳墠鐢ㄦ埛璇︽儏
     */
    @SuppressWarnings("unchecked")
    public static <T extends UserDetails> Optional<T> getCurrentUserDetails() {
        return getCurrentAuthentication()
                .map(authentication -> {
                    Object principal = authentication.getPrincipal();
                    if (principal instanceof UserDetails) {
                        return (T) principal;
                    }
                    return null;
                });
    }

    /**
     * 获取当前用户ID锛堜粠UserDetails鎵╁睍绫讳腑鑾峰彇锛?     */

    public static Optional<Long> getCurrentUserId() {
        return getCurrentUserDetails()
                .map(userDetails -> {
                    // TODO: fix encoding comment
                    // TODO: fix encoding comment
                    if (userDetails instanceof CustomUserDetails) {
                        return ((CustomUserDetails) userDetails).getId();
                    }
                    return null;
                });
    }

    /**
     * 检查当前用户是否已认证
     */
    public static boolean isAuthenticated() {
        return getCurrentAuthentication()
                .map(Authentication::isAuthenticated)
                .orElse(false);
    }

    /**
     * 妫€鏌ュ綋鍓嶇敤鎴锋槸鍚﹀叿鏈夋寚瀹氭潈闄?     */

    public static boolean hasAuthority(String authority) {
        return getCurrentAuthentication()
                .map(authentication -> authentication.getAuthorities().stream()
                        .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals(authority)))
                .orElse(false);
    }

    /**
     * 妫€鏌ュ綋鍓嶇敤鎴锋槸鍚﹀叿鏈夋寚瀹氳鑹诧紙角色浠OLE_鍓嶇紑锛?     */

    public static boolean hasRole(String role) {
        String roleWithPrefix = role.startsWith("ROLE_") ? role : "ROLE_" + role;
        return hasAuthority(roleWithPrefix);
    }

    /**
     * 妫€鏌ュ綋鍓嶇敤鎴锋槸鍚﹀叿鏈変换鎰忎竴涓寚瀹氭潈闄?     */

    public static boolean hasAnyAuthority(String... authorities) {
        return getCurrentAuthentication()
                .map(authentication -> authentication.getAuthorities().stream()
                        .anyMatch(grantedAuthority -> {
                            for (String authority : authorities) {
                                if (grantedAuthority.getAuthority().equals(authority)) {
                                    return true;
                                }
                            }
                            return false;
                        }))
                .orElse(false);
    }

    /**
     * 妫€鏌ュ綋鍓嶇敤鎴锋槸鍚﹀叿鏈変换鎰忎竴涓寚瀹氳鑹?     */

    public static boolean hasAnyRole(String... roles) {
        String[] rolesWithPrefix = new String[roles.length];
        for (int i = 0; i < roles.length; i++) {
            rolesWithPrefix[i] = roles[i].startsWith("ROLE_") ? roles[i] : "ROLE_" + roles[i];
        }
        return hasAnyAuthority(rolesWithPrefix);
    }

    /**
     * 鑾峰彇褰撳墠鐢ㄦ埛鐨勪笟鍔″崟鍏冧唬鐮侊紙浠庣敤鎴蜂俊鎭腑鎻愬彇锛?     */

    public static Optional<String> getCurrentUserBuCode() {
        return getCurrentUserDetails()
                .map(userDetails -> {
                    // TODO: fix encoding comment
                    // TODO: fix encoding comment
                    if (userDetails instanceof CustomUserDetails) {
                        return ((CustomUserDetails) userDetails).getBuCode();
                    }
                    return null;
                });
    }

    /**
     * 璁板綍褰撳墠鐢ㄦ埛操作鏃ュ織鐨勮緟鍔╂柟娉?     */

    public static String getCurrentUserForLog() {
        return getCurrentUsername().orElse("anonymous");
    }
}