package com.seabank.cawms.dto;

import java.util.List;

/**
 * 鎵归噺缂栫爜鐢熸垚璇锋眰DTO
 */
public class BatchGenerationRequest {
    private List<GenerationRequest> requests;
    private Boolean sequential;
    private Boolean skipDuplicates;
    private Integer batchSize;
    private String batchId;
    private String description;


    public BatchGenerationRequest() {
    }

    public BatchGenerationRequest(List<GenerationRequest> requests, Boolean sequential, Boolean skipDuplicates, Integer batchSize, String batchId, String description) {
        this.requests = requests;
        this.sequential = sequential;
        this.skipDuplicates = skipDuplicates;
        this.batchSize = batchSize;
        this.batchId = batchId;
        this.description = description;
    }

    public List<GenerationRequest> getRequests() {
        return requests;
    }

    public void setRequests(List<GenerationRequest> requests) {
        this.requests = requests;
    }

    public Boolean getSequential() {
        return sequential;
    }

    public void setSequential(Boolean sequential) {
        this.sequential = sequential;
    }

    public Boolean getSkipDuplicates() {
        return skipDuplicates;
    }

    public void setSkipDuplicates(Boolean skipDuplicates) {
        this.skipDuplicates = skipDuplicates;
    }

    public Integer getBatchSize() {
        return batchSize;
    }

    public void setBatchSize(Integer batchSize) {
        this.batchSize = batchSize;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}