package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

@TableName("transfer_approval")
public class TransferApprovalEntity {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long transferId;
    private Integer stepNumber;
    private String stepName;
    private String approverRole;
    private String approverUser;

    @TableField(exist = false)
    private String approverName;

    private String status;

    @TableField(value = "comments")
    private String approvalOpinion;

    @TableField(value = "approved_at")
    private LocalDateTime approvalTime;

    @TableField(exist = false)
    private String assetCondition;

    @TableField(exist = false)
    private LocalDateTime returnDate;

    private String createdBy;
    private String updatedBy;
    private Integer deleted;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Long getTransferId() {
        return transferId;
    }
    public void setTransferId(Long transferId) {
        this.transferId = transferId;
    }

    public Integer getStepNumber() {
        return stepNumber;
    }
    public void setStepNumber(Integer stepNumber) {
        this.stepNumber = stepNumber;
    }

    public String getStepName() {
        return stepName;
    }
    public void setStepName(String stepName) {
        this.stepName = stepName;
    }

    public String getApproverRole() {
        return approverRole;
    }
    public void setApproverRole(String approverRole) {
        this.approverRole = approverRole;
    }

    public String getApproverUser() {
        return approverUser;
    }
    public void setApproverUser(String approverUser) {
        this.approverUser = approverUser;
    }

    public String getApproverName() {
        return approverName;
    }
    public void setApproverName(String approverName) {
        this.approverName = approverName;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getApprovalOpinion() {
        return approvalOpinion;
    }
    public void setApprovalOpinion(String approvalOpinion) {
        this.approvalOpinion = approvalOpinion;
    }

    public LocalDateTime getApprovalTime() {
        return approvalTime;
    }
    public void setApprovalTime(LocalDateTime approvalTime) {
        this.approvalTime = approvalTime;
    }

    public String getAssetCondition() {
        return assetCondition;
    }
    public void setAssetCondition(String assetCondition) {
        this.assetCondition = assetCondition;
    }

    public LocalDateTime getReturnDate() {
        return returnDate;
    }
    public void setReturnDate(LocalDateTime returnDate) {
        this.returnDate = returnDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Integer getDeleted() {
        return deleted;
    }
    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }
}
