package com.seabank.cawms.dto;


/**
 * 验证结果DTO
 */
public class ValidationResult {
    private Boolean valid;
    private String message;
    private String field;
    private String code;
    private String suggestedFix;
    private Integer errorCode;
    private Boolean canAutoFix;
    private String autoFixResult;
    private String validationType;


    public ValidationResult() {
    }

    public ValidationResult(Boolean valid, String message, String field, String code, String suggestedFix, Integer errorCode, Boolean canAutoFix, String autoFixResult, String validationType) {
        this.valid = valid;
        this.message = message;
        this.field = field;
        this.code = code;
        this.suggestedFix = suggestedFix;
        this.errorCode = errorCode;
        this.canAutoFix = canAutoFix;
        this.autoFixResult = autoFixResult;
        this.validationType = validationType;
    }

    public Boolean getValid() {
        return valid;
    }

    public void setValid(Boolean valid) {
        this.valid = valid;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSuggestedFix() {
        return suggestedFix;
    }

    public void setSuggestedFix(String suggestedFix) {
        this.suggestedFix = suggestedFix;
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public Boolean getCanAutoFix() {
        return canAutoFix;
    }

    public void setCanAutoFix(Boolean canAutoFix) {
        this.canAutoFix = canAutoFix;
    }

    public String getAutoFixResult() {
        return autoFixResult;
    }

    public void setAutoFixResult(String autoFixResult) {
        this.autoFixResult = autoFixResult;
    }

    public String getValidationType() {
        return validationType;
    }

    public void setValidationType(String validationType) {
        this.validationType = validationType;
    }
}