package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 閫炬湡预警记录瀹炰綋绫? * 瀵瑰簲鏁版嵁搴撹〃锛歰verdue_alert_log
 */
@TableName("overdue_alert_log")
public class OverdueAlertLogEntity {
    
    /**
     * 涓婚敭ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    
    /**
     * 借出记录ID锛堝閿級
     */
    private Long loanOutId;
    
    /**
     * 预警类型
     * 鍙栧€硷細WARNING锛堥璀︼級, OVERDUE锛堥€炬湡锛? REMINDER锛堟彁閱掞級
     */
    private String alertType;
    
    /**
     * 棰勮娑堟伅
     */
    private String alertMessage;
    
    /**
     * 棰勮鏃堕棿
     */
    private LocalDateTime alertTime;
    
    /**
     * 鎺ユ敹浜?     * JSON鏍煎紡锛歔"user1@seabank.com", "user2@seabank.com"]
     */
    private String recipients;
    
    /**
     * 鍙戦€佺姸鎬?     * 鍙栧€硷細PENDING锛堝緟鍙戦€侊級, SENT锛堝凡鍙戦€侊級, FAILED锛堝彂閫佸け璐ワ級
     */
    private String sentStatus;
    
    /**
     * 鍙戦€佹椂闂?     */

    private LocalDateTime sentTime;
    
    /**
     * 鍙戦€佹柟寮?     * 鍙栧€硷細EMAIL, SMS, SYSTEM_NOTIFICATION
     */
    private String sendMethod;
    
    /**
     * 鍙戦€佽鎯咃紙JSON鏍煎紡锛?     * 瀛樺偍鍙戦€佹棩蹇椼€侀敊璇俊鎭瓑
     */
    private String sendDetails;
    
    /**
     * 创建鏃堕棿
     */
    private LocalDateTime createdAt;
    
    /**
     * 更新鏃堕棿
     */
    private LocalDateTime updatedAt;
    
    /**
     * 鎵╁睍鏁版嵁锛圝SON鏍煎紡锛?     * 瀛樺偍棰濆淇℃伅
     */
    @TableField(exist = false)
    private String extData;
    
    /**
     * 鍏宠仈鐨勫€熷嚭璁板綍璇︽儏锛堥潪鏁版嵁搴撳瓧娈碉級
     */
    @TableField(exist = false)
    private LoanOutEntity loanOut;
    
    /**
     * 瀹㈡埛鍚嶇О锛堜粠鍏宠仈鍊熷嚭璁板綍鑾峰彇锛岄潪鏁版嵁搴撳瓧娈碉級
     */
    @TableField(exist = false)
    private String customerName;
    
    /**
     * 棰勮褰掕繕鏃ユ湡锛堜粠鍏宠仈鍊熷嚭璁板綍鑾峰彇锛岄潪鏁版嵁搴撳瓧娈碉級
     */
    @TableField(exist = false)
    private LocalDate expectedReturnDate;
    
    /**
     * 閫炬湡澶╂暟锛堣绠楀瓧娈碉紝闈炴暟鎹簱瀛楁锛?     */

    @TableField(exist = false)
    private Integer overdueDays;


    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Long getLoanOutId() {
        return loanOutId;
    }
    public void setLoanOutId(Long loanOutId) {
        this.loanOutId = loanOutId;
    }

    public String getAlertType() {
        return alertType;
    }
    public void setAlertType(String alertType) {
        this.alertType = alertType;
    }

    public String getAlertMessage() {
        return alertMessage;
    }
    public void setAlertMessage(String alertMessage) {
        this.alertMessage = alertMessage;
    }

    public LocalDateTime getAlertTime() {
        return alertTime;
    }
    public void setAlertTime(LocalDateTime alertTime) {
        this.alertTime = alertTime;
    }

    public String getRecipients() {
        return recipients;
    }
    public void setRecipients(String recipients) {
        this.recipients = recipients;
    }

    public String getSentStatus() {
        return sentStatus;
    }
    public void setSentStatus(String sentStatus) {
        this.sentStatus = sentStatus;
    }

    public LocalDateTime getSentTime() {
        return sentTime;
    }
    public void setSentTime(LocalDateTime sentTime) {
        this.sentTime = sentTime;
    }

    public String getSendMethod() {
        return sendMethod;
    }
    public void setSendMethod(String sendMethod) {
        this.sendMethod = sendMethod;
    }

    public String getSendDetails() {
        return sendDetails;
    }
    public void setSendDetails(String sendDetails) {
        this.sendDetails = sendDetails;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getExtData() {
        return extData;
    }
    public void setExtData(String extData) {
        this.extData = extData;
    }

    public LoanOutEntity getLoanOut() {
        return loanOut;
    }
    public void setLoanOut(LoanOutEntity loanOut) {
        this.loanOut = loanOut;
    }

    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public LocalDate getExpectedReturnDate() {
        return expectedReturnDate;
    }
    public void setExpectedReturnDate(LocalDate expectedReturnDate) {
        this.expectedReturnDate = expectedReturnDate;
    }

    public Integer getOverdueDays() {
        return overdueDays;
    }
    public void setOverdueDays(Integer overdueDays) {
        this.overdueDays = overdueDays;
    }
}