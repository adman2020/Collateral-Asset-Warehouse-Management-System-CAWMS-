package com.seabank.cawms.dto;

import java.util.List;
import java.util.Map;

/**
 * 鎵归噺缂栫爜鐢熸垚缁撴灉DTO
 */
public class BatchGenerationResult {
    private Boolean success;
    private Integer totalCount;
    private Integer successCount;
    private Integer failureCount;
    private List<String> generatedCodes;
    private List<GenerationResult> results;
    private String batchId;
    private Long generationTime;
    private Map<String, Object> statistics;
    private String errorMessage;
    


    public BatchGenerationResult() {
    }

    public BatchGenerationResult(Boolean success, Integer totalCount, Integer successCount, Integer failureCount, List<String> generatedCodes, List<GenerationResult> results, String batchId, Long generationTime, Map<String, Object> statistics, String errorMessage) {
        this.success = success;
        this.totalCount = totalCount;
        this.successCount = successCount;
        this.failureCount = failureCount;
        this.generatedCodes = generatedCodes;
        this.results = results;
        this.batchId = batchId;
        this.generationTime = generationTime;
        this.statistics = statistics;
        this.errorMessage = errorMessage;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public Integer getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(Integer successCount) {
        this.successCount = successCount;
    }

    public Integer getFailureCount() {
        return failureCount;
    }

    public void setFailureCount(Integer failureCount) {
        this.failureCount = failureCount;
    }

    public List<String> getGeneratedCodes() {
        return generatedCodes;
    }

    public void setGeneratedCodes(List<String> generatedCodes) {
        this.generatedCodes = generatedCodes;
    }

    public List<GenerationResult> getResults() {
        return results;
    }

    public void setResults(List<GenerationResult> results) {
        this.results = results;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public Long getGenerationTime() {
        return generationTime;
    }

    public void setGenerationTime(Long generationTime) {
        this.generationTime = generationTime;
    }

    public Map<String, Object> getStatistics() {
        return statistics;
    }

    public void setStatistics(Map<String, Object> statistics) {
        this.statistics = statistics;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
