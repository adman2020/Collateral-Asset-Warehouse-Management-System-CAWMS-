package com.seabank.cawms.integration.los;

import com.seabank.cawms.integration.IntegrationService;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * LOS锛堣捶娆惧彂璧风郴缁燂級闆嗘垚鏈嶅姟鎺ュ彛
 * 鐢ㄤ簬澶勭悊璐锋鐢宠銆佸鎵广€佸彂鏀剧瓑涓氬姟娴佺▼
 */
public interface LOSIntegrationService extends IntegrationService {
    
    /**
     * 鎻愪氦璐锋鐢宠
     * @param application 璐锋鐢宠淇℃伅
     * @return 璐锋鐢宠鍝嶅簲
     */
    LoanApplicationResponse submitLoanApplication(LoanApplication application);
    
    /**
     * 鏌ヨ璐锋鐢宠鐘舵€?     * @param applicationId 鐢宠ID
     * @return 璐锋鐢宠鐘舵€?     */

    LoanApplicationStatus queryApplicationStatus(String applicationId);
    
    /**
     * 鏌ヨ璐锋浜у搧鍒楄〃
     * @param customerType 瀹㈡埛绫诲瀷
     * @return 璐锋浜у搧鍒楄〃
     */
    List<LoanProduct> queryLoanProducts(String customerType);
    
    /**
     * 鏌ヨ瀹㈡埛淇＄敤璇勫垎
     * @param customerId 瀹㈡埛ID
     * @return 淇＄敤璇勫垎淇℃伅
     */
    CreditScore queryCreditScore(String customerId);
    
    /**
     * 鏌ヨ璐锋杩樻璁″垝
     * @param loanId 璐锋ID
     * @return 杩樻璁″垝
     */
    RepaymentSchedule queryRepaymentSchedule(String loanId);
    
    /**
     * 鏌ヨ璐锋璐︽埛淇℃伅
     * @param loanAccountNumber 璐锋璐︽埛鍙?     * @return 璐锋璐︽埛淇℃伅
     */
    LoanAccountInfo queryLoanAccountInfo(String loanAccountNumber);
    
    /**
     * 澶勭悊璐锋鍙戞斁
     * @param disbursementRequest 鍙戞斁璇锋眰
     * @return 鍙戞斁鍝嶅簲
     */
    LoanDisbursementResponse processLoanDisbursement(LoanDisbursementRequest disbursementRequest);
    
    /**
     * 鏌ヨ璐锋鍘嗗彶璁板綍
     * @param customerId 瀹㈡埛ID
     * @return 璐锋鍘嗗彶鍒楄〃
     */
    List<LoanHistory> queryLoanHistory(String customerId);
    
    /**
     * 楠岃瘉璐锋鐢宠璧勬牸
     * @param eligibilityRequest 璧勬牸楠岃瘉璇锋眰
     * @return 璧勬牸验证结果
     */
    EligibilityResult checkEligibility(EligibilityRequest eligibilityRequest);
    
    /**
     * 璐锋鐢宠
     */
    class LoanApplication {
        private String applicationId;
        private String customerId;
        private String customerName;
        private String loanProductCode;
        private BigDecimal requestedAmount;
        private String currency;
        private Integer loanTerm; // TODO: encoding issue
        private String loanPurpose;
        private String collateralType;
        private String collateralId;
        private BigDecimal collateralValue;
        private String applicationChannel; // BRANCH, ONLINE, MOBILE
        private String assignedOfficer;
        private LocalDateTime applicationDate;
        private Map<String, Object> additionalData;
        
        // Getters and Setters
        public String getApplicationId() {
            return applicationId;
        }
        
        public void setApplicationId(String applicationId) {
            this.applicationId = applicationId;
        }
        
        public String getCustomerId() {
            return customerId;
        }
        
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }
        
        public String getCustomerName() {
            return customerName;
        }
        
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }
        
        public String getLoanProductCode() {
            return loanProductCode;
        }
        
        public void setLoanProductCode(String loanProductCode) {
            this.loanProductCode = loanProductCode;
        }
        
        public BigDecimal getRequestedAmount() {
            return requestedAmount;
        }
        
        public void setRequestedAmount(BigDecimal requestedAmount) {
            this.requestedAmount = requestedAmount;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public Integer getLoanTerm() {
            return loanTerm;
        }
        
        public void setLoanTerm(Integer loanTerm) {
            this.loanTerm = loanTerm;
        }
        
        public String getLoanPurpose() {
            return loanPurpose;
        }
        
        public void setLoanPurpose(String loanPurpose) {
            this.loanPurpose = loanPurpose;
        }
        
        public String getCollateralType() {
            return collateralType;
        }
        
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }
        
        public String getCollateralId() {
            return collateralId;
        }
        
        public void setCollateralId(String collateralId) {
            this.collateralId = collateralId;
        }
        
        public BigDecimal getCollateralValue() {
            return collateralValue;
        }
        
        public void setCollateralValue(BigDecimal collateralValue) {
            this.collateralValue = collateralValue;
        }
        
        public String getApplicationChannel() {
            return applicationChannel;
        }
        
        public void setApplicationChannel(String applicationChannel) {
            this.applicationChannel = applicationChannel;
        }
        
        public String getAssignedOfficer() {
            return assignedOfficer;
        }
        
        public void setAssignedOfficer(String assignedOfficer) {
            this.assignedOfficer = assignedOfficer;
        }
        
        public LocalDateTime getApplicationDate() {
            return applicationDate;
        }
        
        public void setApplicationDate(LocalDateTime applicationDate) {
            this.applicationDate = applicationDate;
        }
        
        public Map<String, Object> getAdditionalData() {
            return additionalData;
        }
        
        public void setAdditionalData(Map<String, Object> additionalData) {
            this.additionalData = additionalData;
        }
    }
    
    /**
     * 璐锋鐢宠鍝嶅簲
     */
    class LoanApplicationResponse {
        private boolean success;
        private String applicationId;
        private String referenceNumber;
        private LocalDateTime submissionDate;
        private String status;
        private String message;
        private String nextStep;
        private LocalDateTime estimatedProcessingTime;
        private List<String> requiredDocuments;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public String getApplicationId() {
            return applicationId;
        }
        
        public void setApplicationId(String applicationId) {
            this.applicationId = applicationId;
        }
        
        public String getReferenceNumber() {
            return referenceNumber;
        }
        
        public void setReferenceNumber(String referenceNumber) {
            this.referenceNumber = referenceNumber;
        }
        
        public LocalDateTime getSubmissionDate() {
            return submissionDate;
        }
        
        public void setSubmissionDate(LocalDateTime submissionDate) {
            this.submissionDate = submissionDate;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public String getNextStep() {
            return nextStep;
        }
        
        public void setNextStep(String nextStep) {
            this.nextStep = nextStep;
        }
        
        public LocalDateTime getEstimatedProcessingTime() {
            return estimatedProcessingTime;
        }
        
        public void setEstimatedProcessingTime(LocalDateTime estimatedProcessingTime) {
            this.estimatedProcessingTime = estimatedProcessingTime;
        }
        
        public List<String> getRequiredDocuments() {
            return requiredDocuments;
        }
        
        public void setRequiredDocuments(List<String> requiredDocuments) {
            this.requiredDocuments = requiredDocuments;
        }
    }
    
    /**
     * 璐锋鐢宠鐘舵€?     */

    class LoanApplicationStatus {
        private String applicationId;
        private String status; // SUBMITTED, UNDER_REVIEW, APPROVED, REJECTED, DISBURSED
        private String currentStage;
        private String assignedTo;
        private LocalDateTime statusDate;
        private String remarks;
        private List<StatusHistory> statusHistory;
        private List<String> pendingTasks;
        
        // Getters and Setters
        public String getApplicationId() {
            return applicationId;
        }
        
        public void setApplicationId(String applicationId) {
            this.applicationId = applicationId;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public String getCurrentStage() {
            return currentStage;
        }
        
        public void setCurrentStage(String currentStage) {
            this.currentStage = currentStage;
        }
        
        public String getAssignedTo() {
            return assignedTo;
        }
        
        public void setAssignedTo(String assignedTo) {
            this.assignedTo = assignedTo;
        }
        
        public LocalDateTime getStatusDate() {
            return statusDate;
        }
        
        public void setStatusDate(LocalDateTime statusDate) {
            this.statusDate = statusDate;
        }
        
        public String getRemarks() {
            return remarks;
        }
        
        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }
        
        public List<StatusHistory> getStatusHistory() {
            return statusHistory;
        }
        
        public void setStatusHistory(List<StatusHistory> statusHistory) {
            this.statusHistory = statusHistory;
        }
        
        public List<String> getPendingTasks() {
            return pendingTasks;
        }
        
        public void setPendingTasks(List<String> pendingTasks) {
            this.pendingTasks = pendingTasks;
        }
    }
    
    /**
     * 璐锋浜у搧
     */
    class LoanProduct {
        private String productCode;
        private String productName;
        private String productType; // PERSONAL, BUSINESS, MORTGAGE, AUTO
        private BigDecimal minAmount;
        private BigDecimal maxAmount;
        private String currency;
        private Integer minTerm;
        private Integer maxTerm;
        private BigDecimal interestRate;
        private String interestType; // FIXED, VARIABLE
        private String calculationMethod;
        private BigDecimal processingFee;
        private String eligibilityCriteria;
        private List<String> requiredDocuments;
        private String status;
        
        // Getters and Setters
        public String getProductCode() {
            return productCode;
        }
        
        public void setProductCode(String productCode) {
            this.productCode = productCode;
        }
        
        public String getProductName() {
            return productName;
        }
        
        public void setProductName(String productName) {
            this.productName = productName;
        }
        
        public String getProductType() {
            return productType;
        }
        
        public void setProductType(String productType) {
            this.productType = productType;
        }
        
        public BigDecimal getMinAmount() {
            return minAmount;
        }
        
        public void setMinAmount(BigDecimal minAmount) {
            this.minAmount = minAmount;
        }
        
        public BigDecimal getMaxAmount() {
            return maxAmount;
        }
        
        public void setMaxAmount(BigDecimal maxAmount) {
            this.maxAmount = maxAmount;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public Integer getMinTerm() {
            return minTerm;
        }
        
        public void setMinTerm(Integer minTerm) {
            this.minTerm = minTerm;
        }
        
        public Integer getMaxTerm() {
            return maxTerm;
        }
        
        public void setMaxTerm(Integer maxTerm) {
            this.maxTerm = maxTerm;
        }
        
        public BigDecimal getInterestRate() {
            return interestRate;
        }
        
        public void setInterestRate(BigDecimal interestRate) {
            this.interestRate = interestRate;
        }
        
        public String getInterestType() {
            return interestType;
        }
        
        public void setInterestType(String interestType) {
            this.interestType = interestType;
        }
        
        public String getCalculationMethod() {
            return calculationMethod;
        }
        
        public void setCalculationMethod(String calculationMethod) {
            this.calculationMethod = calculationMethod;
        }
        
        public BigDecimal getProcessingFee() {
            return processingFee;
        }
        
        public void setProcessingFee(BigDecimal processingFee) {
            this.processingFee = processingFee;
        }
        
        public String getEligibilityCriteria() {
            return eligibilityCriteria;
        }
        
        public void setEligibilityCriteria(String eligibilityCriteria) {
            this.eligibilityCriteria = eligibilityCriteria;
        }
        
        public List<String> getRequiredDocuments() {
            return requiredDocuments;
        }
        
        public void setRequiredDocuments(List<String> requiredDocuments) {
            this.requiredDocuments = requiredDocuments;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
    }
    
    /**
     * 淇＄敤璇勫垎
     */
    class CreditScore {
        private String customerId;
        private Integer score;
        private String scoreBand; // EXCELLENT, GOOD, FAIR, POOR
        private LocalDateTime scoreDate;
        private String scoringModel;
        private List<ScoreFactor> scoreFactors;
        private String recommendation;
        private Integer maxScore;
        
        // Getters and Setters
        public String getCustomerId() {
            return customerId;
        }
        
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }
        
        public Integer getScore() {
            return score;
        }
        
        public void setScore(Integer score) {
            this.score = score;
        }
        
        public String getScoreBand() {
            return scoreBand;
        }
        
        public void setScoreBand(String scoreBand) {
            this.scoreBand = scoreBand;
        }
        
        public LocalDateTime getScoreDate() {
            return scoreDate;
        }
        
        public void setScoreDate(LocalDateTime scoreDate) {
            this.scoreDate = scoreDate;
        }
        
        public String getScoringModel() {
            return scoringModel;
        }
        
        public void setScoringModel(String scoringModel) {
            this.scoringModel = scoringModel;
        }
        
        public List<ScoreFactor> getScoreFactors() {
            return scoreFactors;
        }
        
        public void setScoreFactors(List<ScoreFactor> scoreFactors) {
            this.scoreFactors = scoreFactors;
        }
        
        public String getRecommendation() {
            return recommendation;
        }
        
        public void setRecommendation(String recommendation) {
            this.recommendation = recommendation;
        }
        
        public Integer getMaxScore() {
            return maxScore;
        }
        
        public void setMaxScore(Integer maxScore) {
            this.maxScore = maxScore;
        }
    }
    
    /**
     * 杩樻璁″垝
     */
    class RepaymentSchedule {
        private String loanId;
        private BigDecimal loanAmount;
        private String currency;
        private BigDecimal interestRate;
        private Integer loanTerm;
        private String repaymentFrequency; // MONTHLY, QUARTERLY, ANNUAL
        private BigDecimal installmentAmount;
        private LocalDateTime firstPaymentDate;
        private LocalDateTime maturityDate;
        private List<Installment> installments;
        private BigDecimal totalInterest;
        private BigDecimal totalRepayment;
        
        // Getters and Setters
        public String getLoanId() {
            return loanId;
        }
        
        public void setLoanId(String loanId) {
            this.loanId = loanId;
        }
        
        public BigDecimal getLoanAmount() {
            return loanAmount;
        }
        
        public void setLoanAmount(BigDecimal loanAmount) {
            this.loanAmount = loanAmount;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public BigDecimal getInterestRate() {
            return interestRate;
        }
        
        public void setInterestRate(BigDecimal interestRate) {
            this.interestRate = interestRate;
        }
        
        public Integer getLoanTerm() {
            return loanTerm;
        }
        
        public void setLoanTerm(Integer loanTerm) {
            this.loanTerm = loanTerm;
        }
        
        public String getRepaymentFrequency() {
            return repaymentFrequency;
        }
        
        public void setRepaymentFrequency(String repaymentFrequency) {
            this.repaymentFrequency = repaymentFrequency;
        }
        
        public BigDecimal getInstallmentAmount() {
            return installmentAmount;
        }
        
        public void setInstallmentAmount(BigDecimal installmentAmount) {
            this.installmentAmount = installmentAmount;
        }
        
        public LocalDateTime getFirstPaymentDate() {
            return firstPaymentDate;
        }
        
        public void setFirstPaymentDate(LocalDateTime firstPaymentDate) {
            this.firstPaymentDate = firstPaymentDate;
        }
        
        public LocalDateTime getMaturityDate() {
            return maturityDate;
        }
        
        public void setMaturityDate(LocalDateTime maturityDate) {
            this.maturityDate = maturityDate;
        }
        
        public List<Installment> getInstallments() {
            return installments;
        }
        
        public void setInstallments(List<Installment> installments) {
            this.installments = installments;
        }
        
        public BigDecimal getTotalInterest() {
            return totalInterest;
        }
        
        public void setTotalInterest(BigDecimal totalInterest) {
            this.totalInterest = totalInterest;
        }
        
        public BigDecimal getTotalRepayment() {
            return totalRepayment;
        }
        
        public void setTotalRepayment(BigDecimal totalRepayment) {
            this.totalRepayment = totalRepayment;
        }
    }
    
    /**
     * 璐锋璐︽埛淇℃伅
     */
    class LoanAccountInfo {
        private String loanAccountNumber;
        private String customerId;
        private String customerName;
        private String loanProductCode;
        private BigDecimal originalAmount;
        private BigDecimal currentBalance;
        private BigDecimal outstandingPrincipal;
        private BigDecimal accruedInterest;
        private BigDecimal overdueAmount;
        private LocalDateTime disbursementDate;
        private LocalDateTime maturityDate;
        private String accountStatus;
        private Integer daysPastDue;
        private BigDecimal interestRate;
        private String currency;
        
        // Getters and Setters
        public String getLoanAccountNumber() {
            return loanAccountNumber;
        }
        
        public void setLoanAccountNumber(String loanAccountNumber) {
            this.loanAccountNumber = loanAccountNumber;
        }
        
        public String getCustomerId() {
            return customerId;
        }
        
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }
        
        public String getCustomerName() {
            return customerName;
        }
        
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }
        
        public String getLoanProductCode() {
            return loanProductCode;
        }
        
        public void setLoanProductCode(String loanProductCode) {
            this.loanProductCode = loanProductCode;
        }
        
        public BigDecimal getOriginalAmount() {
            return originalAmount;
        }
        
        public void setOriginalAmount(BigDecimal originalAmount) {
            this.originalAmount = originalAmount;
        }
        
        public BigDecimal getCurrentBalance() {
            return currentBalance;
        }
        
        public void setCurrentBalance(BigDecimal currentBalance) {
            this.currentBalance = currentBalance;
        }
        
        public BigDecimal getOutstandingPrincipal() {
            return outstandingPrincipal;
        }
        
        public void setOutstandingPrincipal(BigDecimal outstandingPrincipal) {
            this.outstandingPrincipal = outstandingPrincipal;
        }
        
        public BigDecimal getAccruedInterest() {
            return accruedInterest;
        }
        
        public void setAccruedInterest(BigDecimal accruedInterest) {
            this.accruedInterest = accruedInterest;
        }
        
        public BigDecimal getOverdueAmount() {
            return overdueAmount;
        }
        
        public void setOverdueAmount(BigDecimal overdueAmount) {
            this.overdueAmount = overdueAmount;
        }
        
        public LocalDateTime getDisbursementDate() {
            return disbursementDate;
        }
        
        public void setDisbursementDate(LocalDateTime disbursementDate) {
            this.disbursementDate = disbursementDate;
        }
        
        public LocalDateTime getMaturityDate() {
            return maturityDate;
        }
        
        public void setMaturityDate(LocalDateTime maturityDate) {
            this.maturityDate = maturityDate;
        }
        
        public String getAccountStatus() {
            return accountStatus;
        }
        
        public void setAccountStatus(String accountStatus) {
            this.accountStatus = accountStatus;
        }
        
        public Integer getDaysPastDue() {
            return daysPastDue;
        }
        
        public void setDaysPastDue(Integer daysPastDue) {
            this.daysPastDue = daysPastDue;
        }
        
        public BigDecimal getInterestRate() {
            return interestRate;
        }
        
        public void setInterestRate(BigDecimal interestRate) {
            this.interestRate = interestRate;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
    }
    
    /**
     * 璐锋鍙戞斁璇锋眰
     */
    class LoanDisbursementRequest {
        private String loanId;
        private String applicationId;
        private BigDecimal disbursementAmount;
        private String currency;
        private String disbursementMethod; // BANK_TRANSFER, CHEQUE, CASH
        private String beneficiaryAccount;
        private String beneficiaryBank;
        private String beneficiaryName;
        private String disbursementPurpose;
        private LocalDateTime requestedDisbursementDate;
        
        // Getters and Setters
        public String getLoanId() {
            return loanId;
        }
        
        public void setLoanId(String loanId) {
            this.loanId = loanId;
        }
        
        public String getApplicationId() {
            return applicationId;
        }
        
        public void setApplicationId(String applicationId) {
            this.applicationId = applicationId;
        }
        
        public BigDecimal getDisbursementAmount() {
            return disbursementAmount;
        }
        
        public void setDisbursementAmount(BigDecimal disbursementAmount) {
            this.disbursementAmount = disbursementAmount;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public String getDisbursementMethod() {
            return disbursementMethod;
        }
        
        public void setDisbursementMethod(String disbursementMethod) {
            this.disbursementMethod = disbursementMethod;
        }
        
        public String getBeneficiaryAccount() {
            return beneficiaryAccount;
        }
        
        public void setBeneficiaryAccount(String beneficiaryAccount) {
            this.beneficiaryAccount = beneficiaryAccount;
        }
        
        public String getBeneficiaryBank() {
            return beneficiaryBank;
        }
        
        public void setBeneficiaryBank(String beneficiaryBank) {
            this.beneficiaryBank = beneficiaryBank;
        }
        
        public String getBeneficiaryName() {
            return beneficiaryName;
        }
        
        public void setBeneficiaryName(String beneficiaryName) {
            this.beneficiaryName = beneficiaryName;
        }
        
        public String getDisbursementPurpose() {
            return disbursementPurpose;
        }
        
        public void setDisbursementPurpose(String disbursementPurpose) {
            this.disbursementPurpose = disbursementPurpose;
        }
        
        public LocalDateTime getRequestedDisbursementDate() {
            return requestedDisbursementDate;
        }
        
        public void setRequestedDisbursementDate(LocalDateTime requestedDisbursementDate) {
            this.requestedDisbursementDate = requestedDisbursementDate;
        }
    }
    
    /**
     * 璐锋鍙戞斁鍝嶅簲
     */
    class LoanDisbursementResponse {
        private boolean success;
        private String disbursementId;
        private String loanId;
        private BigDecimal disbursedAmount;
        private String currency;
        private LocalDateTime disbursementDate;
        private String status;
        private String message;
        private String transactionReference;
        private String confirmationNumber;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public String getDisbursementId() {
            return disbursementId;
        }
        
        public void setDisbursementId(String disbursementId) {
            this.disbursementId = disbursementId;
        }
        
        public String getLoanId() {
            return loanId;
        }
        
        public void setLoanId(String loanId) {
            this.loanId = loanId;
        }
        
        public BigDecimal getDisbursedAmount() {
            return disbursedAmount;
        }
        
        public void setDisbursedAmount(BigDecimal disbursedAmount) {
            this.disbursedAmount = disbursedAmount;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public LocalDateTime getDisbursementDate() {
            return disbursementDate;
        }
        
        public void setDisbursementDate(LocalDateTime disbursementDate) {
            this.disbursementDate = disbursementDate;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public String getTransactionReference() {
            return transactionReference;
        }
        
        public void setTransactionReference(String transactionReference) {
            this.transactionReference = transactionReference;
        }
        
        public String getConfirmationNumber() {
            return confirmationNumber;
        }
        
        public void setConfirmationNumber(String confirmationNumber) {
            this.confirmationNumber = confirmationNumber;
        }
    }
    
    /**
     * 璐锋鍘嗗彶
     */
    class LoanHistory {
        private String loanId;
        private String loanProductCode;
        private BigDecimal loanAmount;
        private String currency;
        private LocalDateTime disbursementDate;
        private LocalDateTime maturityDate;
        private String loanStatus;
        private BigDecimal outstandingBalance;
        private Integer daysPastDue;
        
        // Getters and Setters
        public String getLoanId() {
            return loanId;
        }
        
        public void setLoanId(String loanId) {
            this.loanId = loanId;
        }
        
        public String getLoanProductCode() {
            return loanProductCode;
        }
        
        public void setLoanProductCode(String loanProductCode) {
            this.loanProductCode = loanProductCode;
        }
        
        public BigDecimal getLoanAmount() {
            return loanAmount;
        }
        
        public void setLoanAmount(BigDecimal loanAmount) {
            this.loanAmount = loanAmount;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public LocalDateTime getDisbursementDate() {
            return disbursementDate;
        }
        
        public void setDisbursementDate(LocalDateTime disbursementDate) {
            this.disbursementDate = disbursementDate;
        }
        
        public LocalDateTime getMaturityDate() {
            return maturityDate;
        }
        
        public void setMaturityDate(LocalDateTime maturityDate) {
            this.maturityDate = maturityDate;
        }
        
        public String getLoanStatus() {
            return loanStatus;
        }
        
        public void setLoanStatus(String loanStatus) {
            this.loanStatus = loanStatus;
        }
        
        public BigDecimal getOutstandingBalance() {
            return outstandingBalance;
        }
        
        public void setOutstandingBalance(BigDecimal outstandingBalance) {
            this.outstandingBalance = outstandingBalance;
        }
        
        public Integer getDaysPastDue() {
            return daysPastDue;
        }
        
        public void setDaysPastDue(Integer daysPastDue) {
            this.daysPastDue = daysPastDue;
        }
    }
    
    /**
     * 璧勬牸楠岃瘉璇锋眰
     */
    class EligibilityRequest {
        private String customerId;
        private String loanProductCode;
        private BigDecimal requestedAmount;
        private String currency;
        private Integer requestedTerm;
        private String collateralType;
        private BigDecimal collateralValue;
        private String customerType;
        
        // Getters and Setters
        public String getCustomerId() {
            return customerId;
        }
        
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }
        
        public String getLoanProductCode() {
            return loanProductCode;
        }
        
        public void setLoanProductCode(String loanProductCode) {
            this.loanProductCode = loanProductCode;
        }
        
        public BigDecimal getRequestedAmount() {
            return requestedAmount;
        }
        
        public void setRequestedAmount(BigDecimal requestedAmount) {
            this.requestedAmount = requestedAmount;
        }
        
        public String getCurrency() {
            return currency;
        }
        
        public void setCurrency(String currency) {
            this.currency = currency;
        }
        
        public Integer getRequestedTerm() {
            return requestedTerm;
        }
        
        public void setRequestedTerm(Integer requestedTerm) {
            this.requestedTerm = requestedTerm;
        }
        
        public String getCollateralType() {
            return collateralType;
        }
        
        public void setCollateralType(String collateralType) {
            this.collateralType = collateralType;
        }
        
        public BigDecimal getCollateralValue() {
            return collateralValue;
        }
        
        public void setCollateralValue(BigDecimal collateralValue) {
            this.collateralValue = collateralValue;
        }
        
        public String getCustomerType() {
            return customerType;
        }
        
        public void setCustomerType(String customerType) {
            this.customerType = customerType;
        }
    }
    
    /**
     * 璧勬牸验证结果
     */
    class EligibilityResult {
        private boolean eligible;
        private String customerId;
        private String loanProductCode;
        private BigDecimal eligibleAmount;
        private Integer eligibleTerm;
        private String eligibilityStatus;
        private List<String> eligibilityCriteria;
        private List<String> reasonsForIneligibility;
        private String recommendation;
        private BigDecimal maximumLoanAmount;
        private BigDecimal debtToIncomeRatio;
        
        // Getters and Setters
        public boolean isEligible() {
            return eligible;
        }
        
        public void setEligible(boolean eligible) {
            this.eligible = eligible;
        }
        
        public String getCustomerId() {
            return customerId;
        }
        
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }
        
        public String getLoanProductCode() {
            return loanProductCode;
        }
        
        public void setLoanProductCode(String loanProductCode) {
            this.loanProductCode = loanProductCode;
        }
        
        public BigDecimal getEligibleAmount() {
            return eligibleAmount;
        }
        
        public void setEligibleAmount(BigDecimal eligibleAmount) {
            this.eligibleAmount = eligibleAmount;
        }
        
        public Integer getEligibleTerm() {
            return eligibleTerm;
        }
        
        public void setEligibleTerm(Integer eligibleTerm) {
            this.eligibleTerm = eligibleTerm;
        }
        
        public String getEligibilityStatus() {
            return eligibilityStatus;
        }
        
        public void setEligibilityStatus(String eligibilityStatus) {
            this.eligibilityStatus = eligibilityStatus;
        }
        
        public List<String> getEligibilityCriteria() {
            return eligibilityCriteria;
        }
        
        public void setEligibilityCriteria(List<String> eligibilityCriteria) {
            this.eligibilityCriteria = eligibilityCriteria;
        }
        
        public List<String> getReasonsForIneligibility() {
            return reasonsForIneligibility;
        }
        
        public void setReasonsForIneligibility(List<String> reasonsForIneligibility) {
            this.reasonsForIneligibility = reasonsForIneligibility;
        }
        
        public String getRecommendation() {
            return recommendation;
        }
        
        public void setRecommendation(String recommendation) {
            this.recommendation = recommendation;
        }
        
        public BigDecimal getMaximumLoanAmount() {
            return maximumLoanAmount;
        }
        
        public void setMaximumLoanAmount(BigDecimal maximumLoanAmount) {
            this.maximumLoanAmount = maximumLoanAmount;
        }
        
        public BigDecimal getDebtToIncomeRatio() {
            return debtToIncomeRatio;
        }
        
        public void setDebtToIncomeRatio(BigDecimal debtToIncomeRatio) {
            this.debtToIncomeRatio = debtToIncomeRatio;
        }
    }
    
    /**
     * 鐘舵€佸巻鍙?     */

    class StatusHistory {
        private String status;
        private LocalDateTime timestamp;
        private String changedBy;
        private String remarks;
        
        // Getters and Setters
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public LocalDateTime getTimestamp() {
            return timestamp;
        }
        
        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }
        
        public String getChangedBy() {
            return changedBy;
        }
        
        public void setChangedBy(String changedBy) {
            this.changedBy = changedBy;
        }
        
        public String getRemarks() {
            return remarks;
        }
        
        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }
    }
    
    /**
     * 璇勫垎鍥犵礌
     */
    class ScoreFactor {
        private String factorName;
        private Integer score;
        private Integer maxScore;
        private String description;
        
        // Getters and Setters
        public String getFactorName() {
            return factorName;
        }
        
        public void setFactorName(String factorName) {
            this.factorName = factorName;
        }
        
        public Integer getScore() {
            return score;
        }
        
        public void setScore(Integer score) {
            this.score = score;
        }
        
        public Integer getMaxScore() {
            return maxScore;
        }
        
        public void setMaxScore(Integer maxScore) {
            this.maxScore = maxScore;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
    }
    
    /**
     * 鍒嗘湡浠樻
     */
    class Installment {
        private Integer installmentNumber;
        private LocalDateTime dueDate;
        private BigDecimal principalAmount;
        private BigDecimal interestAmount;
        private BigDecimal totalAmount;
        private BigDecimal remainingBalance;
        private String status; // PENDING, PAID, OVERDUE
        
        // Getters and Setters
        public Integer getInstallmentNumber() {
            return installmentNumber;
        }
        
        public void setInstallmentNumber(Integer installmentNumber) {
            this.installmentNumber = installmentNumber;
        }
        
        public LocalDateTime getDueDate() {
            return dueDate;
        }
        
        public void setDueDate(LocalDateTime dueDate) {
            this.dueDate = dueDate;
        }
        
        public BigDecimal getPrincipalAmount() {
            return principalAmount;
        }
        
        public void setPrincipalAmount(BigDecimal principalAmount) {
            this.principalAmount = principalAmount;
        }
        
        public BigDecimal getInterestAmount() {
            return interestAmount;
        }
        
        public void setInterestAmount(BigDecimal interestAmount) {
            this.interestAmount = interestAmount;
        }
        
        public BigDecimal getTotalAmount() {
            return totalAmount;
        }
        
        public void setTotalAmount(BigDecimal totalAmount) {
            this.totalAmount = totalAmount;
        }
        
        public BigDecimal getRemainingBalance() {
            return remainingBalance;
        }
        
        public void setRemainingBalance(BigDecimal remainingBalance) {
            this.remainingBalance = remainingBalance;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
    }
}