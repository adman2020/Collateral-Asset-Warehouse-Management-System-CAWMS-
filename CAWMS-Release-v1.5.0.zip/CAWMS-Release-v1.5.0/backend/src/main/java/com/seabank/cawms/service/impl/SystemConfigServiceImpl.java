package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seabank.cawms.entity.SystemConfigEntity;
import com.seabank.cawms.mapper.SystemConfigMapper;
import com.seabank.cawms.service.SystemConfigService;
import org.springframework.stereotype.Service;

/**
 * 系统配置服务实现
 */
@Service
public class SystemConfigServiceImpl extends ServiceImpl<SystemConfigMapper, SystemConfigEntity> implements SystemConfigService {
}
