package com.seabank.cawms.security;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 自定义用户详情类
 */
public class CustomUserDetails implements UserDetails {

    private Long id;
    private String username;
    private String password;
    private String fullName;
    private String email;
    private String phoneNumber;
    private String department;
    private String buCode;
    private List<String> roles;
    private String status;
    private LocalDateTime lastLoginTime;
    private String lastLoginIp;
    private boolean accountNonExpired = true;
    private boolean accountNonLocked = true;
    private boolean credentialsNonExpired = true;
    private boolean enabled = true;

    /**
     * 获取用户权限
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles.stream()
                .map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role)
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
    }

    /**
     * 获取用户ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 获取用户全名
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * 获取邮箱
     */
    public String getEmail() {
        return email;
    }

    /**
     * 鑾峰彇电话号码
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * 鑾峰彇部门
     */
    public String getDepartment() {
        return department;
    }

    /**
     * 获取业务单元代码
     */
    public String getBuCode() {
        return buCode;
    }

    /**
     * 获取角色列表
     */
    public List<String> getRoles() {
        return roles;
    }

    /**
     * 鑾峰彇鐢ㄦ埛鐘舵€?     */

    public String getStatus() {
        return status;
    }

    /**
     * 鑾峰彇鏈€鍚庣櫥褰曟椂闂?     */

    public LocalDateTime getLastLoginTime() {
        return lastLoginTime;
    }

    /**
     * 鑾峰彇最后登录IP
     */
    public String getLastLoginIp() {
        return lastLoginIp;
    }

    /**
     * 璐︽埛鏄惁鏈繃鏈?     */

    @Override
    public boolean isAccountNonExpired() {
        return accountNonExpired;
    }

    /**
     * 璐︽埛鏄惁鏈攣瀹?     */

    @Override
    public boolean isAccountNonLocked() {
        return accountNonLocked && !"LOCKED".equals(status);
    }

    /**
     * 鍑瘉鏄惁鏈繃鏈?     */

    @Override
    public boolean isCredentialsNonExpired() {
        return credentialsNonExpired;
    }

    /**
     * 璐︽埛鏄惁鍚敤
     */
    @Override
    public boolean isEnabled() {
        return enabled && "ACTIVE".equals(status);
    }

    /**
     * 妫€鏌ョ敤鎴锋槸鍚﹀叿鏈夋寚瀹氳鑹?     */

    public boolean hasRole(String role) {
        String roleWithPrefix = role.startsWith("ROLE_") ? role : "ROLE_" + role;
        return roles.stream()
                .anyMatch(r -> r.startsWith("ROLE_") ? r.equals(roleWithPrefix) : ("ROLE_" + r).equals(roleWithPrefix));
    }

    /**
     * 妫€鏌ョ敤鎴锋槸鍚﹀叿鏈夋寚瀹氭潈闄?     */

    public boolean hasAuthority(String authority) {
        return getAuthorities().stream()
                .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals(authority));
    }

    /**
     * 杞崲涓哄瓧绗︿覆锛堢敤浜庢棩蹇楄褰曪級
     */
    @Override
    public String toString() {
        return "CustomUserDetails{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", fullName='" + fullName + '\'' +
                ", buCode='" + buCode + '\'' +
                ", roles=" + roles +
                ", status='" + status + '\'' +
                '}';
    }

    /**
     * 创建鏋勫缓鍣?     */

    public static Builder builder() {
        return new Builder();
    }

    /**
     * 鏋勫缓鍣ㄧ被
     */
    public static class Builder {
        private final CustomUserDetails userDetails = new CustomUserDetails();

        public Builder id(Long id) {
            userDetails.id = id;
            return this;
        }

        public Builder username(String username) {
            userDetails.username = username;
            return this;
        }

        public Builder password(String password) {
            userDetails.password = password;
            return this;
        }

        public Builder fullName(String fullName) {
            userDetails.fullName = fullName;
            return this;
        }

        public Builder email(String email) {
            userDetails.email = email;
            return this;
        }

        public Builder phoneNumber(String phoneNumber) {
            userDetails.phoneNumber = phoneNumber;
            return this;
        }

        public Builder department(String department) {
            userDetails.department = department;
            return this;
        }

        public Builder buCode(String buCode) {
            userDetails.buCode = buCode;
            return this;
        }

        public Builder roles(List<String> roles) {
            userDetails.roles = roles;
            return this;
        }

        public Builder status(String status) {
            userDetails.status = status;
            return this;
        }

        public Builder lastLoginTime(LocalDateTime lastLoginTime) {
            userDetails.lastLoginTime = lastLoginTime;
            return this;
        }

        public Builder lastLoginIp(String lastLoginIp) {
            userDetails.lastLoginIp = lastLoginIp;
            return this;
        }

        public Builder accountNonExpired(boolean accountNonExpired) {
            userDetails.accountNonExpired = accountNonExpired;
            return this;
        }

        public Builder accountNonLocked(boolean accountNonLocked) {
            userDetails.accountNonLocked = accountNonLocked;
            return this;
        }

        public Builder credentialsNonExpired(boolean credentialsNonExpired) {
            userDetails.credentialsNonExpired = credentialsNonExpired;
            return this;
        }

        public Builder enabled(boolean enabled) {
            userDetails.enabled = enabled;
            return this;
        }

        public CustomUserDetails build() {
            return userDetails;
        }
    }


    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setBuCode(String buCode) {
        this.buCode = buCode;
    }

    public void setRoles(List<String> roles) {
        this.roles = roles;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setLastLoginTime(LocalDateTime lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public void setLastLoginIp(String lastLoginIp) {
        this.lastLoginIp = lastLoginIp;
    }

    public void setAccountNonExpired(boolean accountNonExpired) {
        this.accountNonExpired = accountNonExpired;
    }

    public void setAccountNonLocked(boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }

    public void setCredentialsNonExpired(boolean credentialsNonExpired) {
        this.credentialsNonExpired = credentialsNonExpired;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

}