package com.seabank.cawms.integration.esign;

import com.seabank.cawms.integration.IntegrationService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 鐢靛瓙绛剧珷鏈嶅姟鎺ュ彛
 * 鐢ㄤ簬澶勭悊鏂囨。鐨勬暟瀛楃鍚嶅拰楠岃瘉
 */
public interface ElectronicSignatureService extends IntegrationService {
    
    /**
     * 创建绛惧悕璇锋眰
     * @param request 绛惧悕璇锋眰
     * @return 绛惧悕璇锋眰鍝嶅簲
     */
    SignatureRequestResponse createSignatureRequest(SignatureRequest request);
    
    /**
     * 鏌ヨ绛惧悕鐘舵€?     * @param requestId 璇锋眰ID
     * @return 绛惧悕鐘舵€?     */

    SignatureStatus querySignatureStatus(String requestId);
    
    /**
     * 鍙戦€佺鍚嶆彁閱?     * @param requestId 璇锋眰ID
     * @return 鎻愰啋鍙戦€佺粨鏋?     */

    ReminderResponse sendSignatureReminder(String requestId);
    
    /**
     * 楠岃瘉绛惧悕
     * @param documentId 鏂囨。ID
     * @return 验证结果
     */
    VerificationResult verifySignature(String documentId);
    
    /**
     * 鎵归噺创建绛惧悕璇锋眰
     * @param requests 绛惧悕璇锋眰鍒楄〃
     * @return 鎵归噺创建鍝嶅簲
     */
    BatchSignatureResponse createBatchSignatureRequests(List<SignatureRequest> requests);
    
    /**
     * 鎾ら攢绛惧悕璇锋眰
     * @param requestId 璇锋眰ID
     * @param reason 鎾ら攢鍘熷洜
     * @return 鎾ら攢缁撴灉
     */
    RevocationResponse revokeSignatureRequest(String requestId, String reason);
    
    /**
     * 涓嬭浇宸茬鍚嶆枃妗?     * @param requestId 璇锋眰ID
     * @return 鏂囨。涓嬭浇淇℃伅
     */
    DocumentDownload downloadSignedDocument(String requestId);
    
    /**
     * 鏌ヨ绛惧悕鍘嗗彶
     * @param documentId 鏂囨。ID
     * @return 绛惧悕鍘嗗彶
     */
    SignatureHistory querySignatureHistory(String documentId);
    
    /**
     * 创建绛惧悕妯℃澘
     * @param template 妯℃澘淇℃伅
     * @return 妯℃澘创建鍝嶅簲
     */
    TemplateResponse createSignatureTemplate(SignatureTemplate template);
    
    /**
     * 绛惧悕璇锋眰
     */
    class SignatureRequest {
        private String requestId;
        private String documentId;
        private String documentName;
        private String documentType;
        private byte[] documentContent;
        private String documentHash;
        private List<Signer> signers;
        private String signingMethod; // DIGITAL, ELECTRONIC, ADVANCED
        private LocalDateTime expirationDate;
        private String callbackUrl;
        private Map<String, Object> metadata;
        
        // Getters and Setters
        public String getRequestId() {
            return requestId;
        }
        
        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }
        
        public String getDocumentId() {
            return documentId;
        }
        
        public void setDocumentId(String documentId) {
            this.documentId = documentId;
        }
        
        public String getDocumentName() {
            return documentName;
        }
        
        public void setDocumentName(String documentName) {
            this.documentName = documentName;
        }
        
        public String getDocumentType() {
            return documentType;
        }
        
        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }
        
        public byte[] getDocumentContent() {
            return documentContent;
        }
        
        public void setDocumentContent(byte[] documentContent) {
            this.documentContent = documentContent;
        }
        
        public String getDocumentHash() {
            return documentHash;
        }
        
        public void setDocumentHash(String documentHash) {
            this.documentHash = documentHash;
        }
        
        public List<Signer> getSigners() {
            return signers;
        }
        
        public void setSigners(List<Signer> signers) {
            this.signers = signers;
        }
        
        public String getSigningMethod() {
            return signingMethod;
        }
        
        public void setSigningMethod(String signingMethod) {
            this.signingMethod = signingMethod;
        }
        
        public LocalDateTime getExpirationDate() {
            return expirationDate;
        }
        
        public void setExpirationDate(LocalDateTime expirationDate) {
            this.expirationDate = expirationDate;
        }
        
        public String getCallbackUrl() {
            return callbackUrl;
        }
        
        public void setCallbackUrl(String callbackUrl) {
            this.callbackUrl = callbackUrl;
        }
        
        public Map<String, Object> getMetadata() {
            return metadata;
        }
        
        public void setMetadata(Map<String, Object> metadata) {
            this.metadata = metadata;
        }
    }
    
    /**
     * 绛惧悕浜?     */

    class Signer {
        private String signerId;
        private String name;
        private String email;
        private String phoneNumber;
        private String identificationType;
        private String identificationNumber;
        private String role; // SIGNER, APPROVER, WITNESS
        private Integer signingOrder;
        private String signatureType; // TEXT, IMAGE, DIGITAL_CERTIFICATE
        private String signatureField;
        private boolean notified;
        
        // Getters and Setters
        public String getSignerId() {
            return signerId;
        }
        
        public void setSignerId(String signerId) {
            this.signerId = signerId;
        }
        
        public String getName() {
            return name;
        }
        
        public void setName(String name) {
            this.name = name;
        }
        
        public String getEmail() {
            return email;
        }
        
        public void setEmail(String email) {
            this.email = email;
        }
        
        public String getPhoneNumber() {
            return phoneNumber;
        }
        
        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }
        
        public String getIdentificationType() {
            return identificationType;
        }
        
        public void setIdentificationType(String identificationType) {
            this.identificationType = identificationType;
        }
        
        public String getIdentificationNumber() {
            return identificationNumber;
        }
        
        public void setIdentificationNumber(String identificationNumber) {
            this.identificationNumber = identificationNumber;
        }
        
        public String getRole() {
            return role;
        }
        
        public void setRole(String role) {
            this.role = role;
        }
        
        public Integer getSigningOrder() {
            return signingOrder;
        }
        
        public void setSigningOrder(Integer signingOrder) {
            this.signingOrder = signingOrder;
        }
        
        public String getSignatureType() {
            return signatureType;
        }
        
        public void setSignatureType(String signatureType) {
            this.signatureType = signatureType;
        }
        
        public String getSignatureField() {
            return signatureField;
        }
        
        public void setSignatureField(String signatureField) {
            this.signatureField = signatureField;
        }
        
        public boolean isNotified() {
            return notified;
        }
        
        public void setNotified(boolean notified) {
            this.notified = notified;
        }
    }
    
    /**
     * 绛惧悕璇锋眰鍝嶅簲
     */
    class SignatureRequestResponse {
        private boolean success;
        private String requestId;
        private LocalDateTime createdDate;
        private String status;
        private String message;
        private List<SignerUrl> signerUrls;
        private String trackingUrl;
        private String qrCodeUrl;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public String getRequestId() {
            return requestId;
        }
        
        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }
        
        public LocalDateTime getCreatedDate() {
            return createdDate;
        }
        
        public void setCreatedDate(LocalDateTime createdDate) {
            this.createdDate = createdDate;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public List<SignerUrl> getSignerUrls() {
            return signerUrls;
        }
        
        public void setSignerUrls(List<SignerUrl> signerUrls) {
            this.signerUrls = signerUrls;
        }
        
        public String getTrackingUrl() {
            return trackingUrl;
        }
        
        public void setTrackingUrl(String trackingUrl) {
            this.trackingUrl = trackingUrl;
        }
        
        public String getQrCodeUrl() {
            return qrCodeUrl;
        }
        
        public void setQrCodeUrl(String qrCodeUrl) {
            this.qrCodeUrl = qrCodeUrl;
        }
    }
    
    /**
     * 绛惧悕鐘舵€?     */

    class SignatureStatus {
        private String requestId;
        private String status; // PENDING, IN_PROGRESS, COMPLETED, EXPIRED, REVOKED
        private String message;
        private LocalDateTime createdDate;
        private LocalDateTime expirationDate;
        private LocalDateTime completedDate;
        private LocalDateTime revokedDate;
        private String revocationReason;
        private Integer remainingSigners;
        private List<SignatureProgress> signingProgress;
        
        // Getters and Setters
        public String getRequestId() {
            return requestId;
        }
        
        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public LocalDateTime getCreatedDate() {
            return createdDate;
        }
        
        public void setCreatedDate(LocalDateTime createdDate) {
            this.createdDate = createdDate;
        }
        
        public LocalDateTime getExpirationDate() {
            return expirationDate;
        }
        
        public void setExpirationDate(LocalDateTime expirationDate) {
            this.expirationDate = expirationDate;
        }
        
        public LocalDateTime getCompletedDate() {
            return completedDate;
        }
        
        public void setCompletedDate(LocalDateTime completedDate) {
            this.completedDate = completedDate;
        }
        
        public LocalDateTime getRevokedDate() {
            return revokedDate;
        }
        
        public void setRevokedDate(LocalDateTime revokedDate) {
            this.revokedDate = revokedDate;
        }
        
        public String getRevocationReason() {
            return revocationReason;
        }
        
        public void setRevocationReason(String revocationReason) {
            this.revocationReason = revocationReason;
        }
        
        public Integer getRemainingSigners() {
            return remainingSigners;
        }
        
        public void setRemainingSigners(Integer remainingSigners) {
            this.remainingSigners = remainingSigners;
        }
        
        public List<SignatureProgress> getSigningProgress() {
            return signingProgress;
        }
        
        public void setSigningProgress(List<SignatureProgress> signingProgress) {
            this.signingProgress = signingProgress;
        }
    }
    
    /**
     * 绛惧悕杩涘睍
     */
    class SignatureProgress {
        private String signerName;
        private String signerRole;
        private String status; // PENDING, COMPLETED
        private LocalDateTime signedDate;
        
        // Getters and Setters
        public String getSignerName() {
            return signerName;
        }
        
        public void setSignerName(String signerName) {
            this.signerName = signerName;
        }
        
        public String getSignerRole() {
            return signerRole;
        }
        
        public void setSignerRole(String signerRole) {
            this.signerRole = signerRole;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public LocalDateTime getSignedDate() {
            return signedDate;
        }
        
        public void setSignedDate(LocalDateTime signedDate) {
            this.signedDate = signedDate;
        }
    }
    
    /**
     * 绛惧悕浜篣RL
     */
    class SignerUrl {
        private String signerId;
        private String signerName;
        private String signingUrl;
        private LocalDateTime expiryTime;
        
        // Getters and Setters
        public String getSignerId() {
            return signerId;
        }
        
        public void setSignerId(String signerId) {
            this.signerId = signerId;
        }
        
        public String getSignerName() {
            return signerName;
        }
        
        public void setSignerName(String signerName) {
            this.signerName = signerName;
        }
        
        public String getSigningUrl() {
            return signingUrl;
        }
        
        public void setSigningUrl(String signingUrl) {
            this.signingUrl = signingUrl;
        }
        
        public LocalDateTime getExpiryTime() {
            return expiryTime;
        }
        
        public void setExpiryTime(LocalDateTime expiryTime) {
            this.expiryTime = expiryTime;
        }
    }
    
    /**
     * 鎻愰啋鍝嶅簲
     */
    class ReminderResponse {
        private boolean success;
        private String requestId;
        private Integer remindersSent;
        private String message;
        private List<ReminderDetail> reminderDetails;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public String getRequestId() {
            return requestId;
        }
        
        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }
        
        public Integer getRemindersSent() {
            return remindersSent;
        }
        
        public void setRemindersSent(Integer remindersSent) {
            this.remindersSent = remindersSent;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public List<ReminderDetail> getReminderDetails() {
            return reminderDetails;
        }
        
        public void setReminderDetails(List<ReminderDetail> reminderDetails) {
            this.reminderDetails = reminderDetails;
        }
    }
    
    /**
     * 鎻愰啋璇︽儏
     */
    class ReminderDetail {
        private String signerId;
        private String signerName;
        private String sentVia; // EMAIL, SMS, PUSH
        private LocalDateTime sentTime;
        private String status; // DELIVERED, FAILED
        
        // Getters and Setters
        public String getSignerId() {
            return signerId;
        }
        
        public void setSignerId(String signerId) {
            this.signerId = signerId;
        }
        
        public String getSignerName() {
            return signerName;
        }
        
        public void setSignerName(String signerName) {
            this.signerName = signerName;
        }
        
        public String getSentVia() {
            return sentVia;
        }
        
        public void setSentVia(String sentVia) {
            this.sentVia = sentVia;
        }
        
        public LocalDateTime getSentTime() {
            return sentTime;
        }
        
        public void setSentTime(LocalDateTime sentTime) {
            this.sentTime = sentTime;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
    }
    
    /**
     * 验证结果
     */
    class VerificationResult {
        private boolean valid;
        private String documentId;
        private String message;
        private String verificationDetails;
        private LocalDateTime verificationDate;
        private String verificationMethod;
        private List<SignatureChain> signatureChain;
        
        // Getters and Setters
        public boolean isValid() {
            return valid;
        }
        
        public void setValid(boolean valid) {
            this.valid = valid;
        }
        
        public String getDocumentId() {
            return documentId;
        }
        
        public void setDocumentId(String documentId) {
            this.documentId = documentId;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public String getVerificationDetails() {
            return verificationDetails;
        }
        
        public void setVerificationDetails(String verificationDetails) {
            this.verificationDetails = verificationDetails;
        }
        
        public LocalDateTime getVerificationDate() {
            return verificationDate;
        }
        
        public void setVerificationDate(LocalDateTime verificationDate) {
            this.verificationDate = verificationDate;
        }
        
        public String getVerificationMethod() {
            return verificationMethod;
        }
        
        public void setVerificationMethod(String verificationMethod) {
            this.verificationMethod = verificationMethod;
        }
        
        public List<SignatureChain> getSignatureChain() {
            return signatureChain;
        }
        
        public void setSignatureChain(List<SignatureChain> signatureChain) {
            this.signatureChain = signatureChain;
        }
    }
    
    /**
     * 绛惧悕閾?     */

    class SignatureChain {
        private String signerName;
        private String certificateIssuer;
        private LocalDateTime timestamp;
        private boolean valid;
        
        // Getters and Setters
        public String getSignerName() {
            return signerName;
        }
        
        public void setSignerName(String signerName) {
            this.signerName = signerName;
        }
        
        public String getCertificateIssuer() {
            return certificateIssuer;
        }
        
        public void setCertificateIssuer(String certificateIssuer) {
            this.certificateIssuer = certificateIssuer;
        }
        
        public LocalDateTime getTimestamp() {
            return timestamp;
        }
        
        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }
        
        public boolean isValid() {
            return valid;
        }
        
        public void setValid(boolean valid) {
            this.valid = valid;
        }
    }
    
    /**
     * 鎵归噺绛惧悕鍝嶅簲
     */
    class BatchSignatureResponse {
        private String batchId;
        private Integer totalRequests;
        private Integer successfulRequests;
        private Integer failedRequests;
        private String message;
        private List<SignatureRequestResponse> responses;
        
        // Getters and Setters
        public String getBatchId() {
            return batchId;
        }
        
        public void setBatchId(String batchId) {
            this.batchId = batchId;
        }
        
        public Integer getTotalRequests() {
            return totalRequests;
        }
        
        public void setTotalRequests(Integer totalRequests) {
            this.totalRequests = totalRequests;
        }
        
        public Integer getSuccessfulRequests() {
            return successfulRequests;
        }
        
        public void setSuccessfulRequests(Integer successfulRequests) {
            this.successfulRequests = successfulRequests;
        }
        
        public Integer getFailedRequests() {
            return failedRequests;
        }
        
        public void setFailedRequests(Integer failedRequests) {
            this.failedRequests = failedRequests;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
        
        public List<SignatureRequestResponse> getResponses() {
            return responses;
        }
        
        public void setResponses(List<SignatureRequestResponse> responses) {
            this.responses = responses;
        }
    }
    
    /**
     * 鎾ら攢鍝嶅簲
     */
    class RevocationResponse {
        private boolean success;
        private String requestId;
        private LocalDateTime revokedDate;
        private String reason;
        private String message;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public String getRequestId() {
            return requestId;
        }
        
        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }
        
        public LocalDateTime getRevokedDate() {
            return revokedDate;
        }
        
        public void setRevokedDate(LocalDateTime revokedDate) {
            this.revokedDate = revokedDate;
        }
        
        public String getReason() {
            return reason;
        }
        
        public void setReason(String reason) {
            this.reason = reason;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
    }
    
    /**
     * 鏂囨。涓嬭浇
     */
    class DocumentDownload {
        private String requestId;
        private String documentId;
        private String documentName;
        private String documentType;
        private Long documentSize;
        private String downloadUrl;
        private LocalDateTime downloadExpiry;
        private String hash;
        
        // Getters and Setters
        public String getRequestId() {
            return requestId;
        }
        
        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }
        
        public String getDocumentId() {
            return documentId;
        }
        
        public void setDocumentId(String documentId) {
            this.documentId = documentId;
        }
        
        public String getDocumentName() {
            return documentName;
        }
        
        public void setDocumentName(String documentName) {
            this.documentName = documentName;
        }
        
        public String getDocumentType() {
            return documentType;
        }
        
        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }
        
        public Long getDocumentSize() {
            return documentSize;
        }
        
        public void setDocumentSize(Long documentSize) {
            this.documentSize = documentSize;
        }
        
        public String getDownloadUrl() {
            return downloadUrl;
        }
        
        public void setDownloadUrl(String downloadUrl) {
            this.downloadUrl = downloadUrl;
        }
        
        public LocalDateTime getDownloadExpiry() {
            return downloadExpiry;
        }
        
        public void setDownloadExpiry(LocalDateTime downloadExpiry) {
            this.downloadExpiry = downloadExpiry;
        }
        
        public String getHash() {
            return hash;
        }
        
        public void setHash(String hash) {
            this.hash = hash;
        }
    }
    
    /**
     * 绛惧悕鍘嗗彶
     */
    class SignatureHistory {
        private String documentId;
        private String requestId;
        private String documentName;
        private List<SignatureEvent> events;
        private Integer totalEvents;
        private LocalDateTime lastUpdated;
        
        // Getters and Setters
        public String getDocumentId() {
            return documentId;
        }
        
        public void setDocumentId(String documentId) {
            this.documentId = documentId;
        }
        
        public String getRequestId() {
            return requestId;
        }
        
        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }
        
        public String getDocumentName() {
            return documentName;
        }
        
        public void setDocumentName(String documentName) {
            this.documentName = documentName;
        }
        
        public List<SignatureEvent> getEvents() {
            return events;
        }
        
        public void setEvents(List<SignatureEvent> events) {
            this.events = events;
        }
        
        public Integer getTotalEvents() {
            return totalEvents;
        }
        
        public void setTotalEvents(Integer totalEvents) {
            this.totalEvents = totalEvents;
        }
        
        public LocalDateTime getLastUpdated() {
            return lastUpdated;
        }
        
        public void setLastUpdated(LocalDateTime lastUpdated) {
            this.lastUpdated = lastUpdated;
        }
    }
    
    /**
     * 绛惧悕浜嬩欢
     */
    class SignatureEvent {
        private String eventType; // REQUEST_CREATED, SIGNED, COMPLETED, REVOKED
        private LocalDateTime timestamp;
        private String actor;
        private String description;
        
        // Getters and Setters
        public String getEventType() {
            return eventType;
        }
        
        public void setEventType(String eventType) {
            this.eventType = eventType;
        }
        
        public LocalDateTime getTimestamp() {
            return timestamp;
        }
        
        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }
        
        public String getActor() {
            return actor;
        }
        
        public void setActor(String actor) {
            this.actor = actor;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
    }
    
    /**
     * 绛惧悕妯℃澘
     */
    class SignatureTemplate {
        private String templateId;
        private String templateName;
        private String templateType; // LOAN_AGREEMENT, COLLATERAL_AGREEMENT, POWER_OF_ATTORNEY
        private String description;
        private List<String> signatureFields;
        private LocalDateTime createdDate;
        private LocalDateTime lastModified;
        private String status; // ACTIVE, INACTIVE
        private Map<String, Object> metadata;
        
        // Getters and Setters
        public String getTemplateId() {
            return templateId;
        }
        
        public void setTemplateId(String templateId) {
            this.templateId = templateId;
        }
        
        public String getTemplateName() {
            return templateName;
        }
        
        public void setTemplateName(String templateName) {
            this.templateName = templateName;
        }
        
        public String getTemplateType() {
            return templateType;
        }
        
        public void setTemplateType(String templateType) {
            this.templateType = templateType;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
        
        public List<String> getSignatureFields() {
            return signatureFields;
        }
        
        public void setSignatureFields(List<String> signatureFields) {
            this.signatureFields = signatureFields;
        }
        
        public LocalDateTime getCreatedDate() {
            return createdDate;
        }
        
        public void setCreatedDate(LocalDateTime createdDate) {
            this.createdDate = createdDate;
        }
        
        public LocalDateTime getLastModified() {
            return lastModified;
        }
        
        public void setLastModified(LocalDateTime lastModified) {
            this.lastModified = lastModified;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        public Map<String, Object> getMetadata() {
            return metadata;
        }
        
        public void setMetadata(Map<String, Object> metadata) {
            this.metadata = metadata;
        }
    }
    
    /**
     * 妯℃澘鍝嶅簲
     */
    class TemplateResponse {
        private boolean success;
        private String templateId;
        private LocalDateTime createdDate;
        private String message;
        
        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public String getTemplateId() {
            return templateId;
        }
        
        public void setTemplateId(String templateId) {
            this.templateId = templateId;
        }
        
        public LocalDateTime getCreatedDate() {
            return createdDate;
        }
        
        public void setCreatedDate(LocalDateTime createdDate) {
            this.createdDate = createdDate;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
    }
}