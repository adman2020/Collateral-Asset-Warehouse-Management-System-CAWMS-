package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.seabank.cawms.entity.AuditLogEntity;
import com.seabank.cawms.common.PageResult;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 审计日志服务接口
 */
public interface AuditLogService extends IService<AuditLogEntity> {
    
    /**
     * 异步保存审计日志
     */
    void saveAuditLogAsync(AuditLogEntity auditLog);
    
    /**
     * 查询审计日志
     */
    PageResult<AuditLogEntity> queryAuditLogs(String module, String operation, String username,
                                              LocalDateTime startTime, LocalDateTime endTime,
                                              Long current, Long size);
    
    /**
     * 清理过期审计日志
     */
    int cleanupExpiredAuditLogs(int retentionDays);
    
    /**
     * 获取模块列表
     */
    List<String> getModuleList();
    
    /**
     * 获取操作列表
     */
    List<String> getOperationList();
    
    /**
     * 统计审计日志
     */
    AuditLogStats getAuditLogStats(LocalDateTime startTime, LocalDateTime endTime);
    
    /**
     * 审计日志统计信息
     */
    class AuditLogStats {
        private Long totalCount;
        private Long successCount;
        private Long failureCount;
        private Long averageExecutionTime;

        public Long getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(Long totalCount) {
            this.totalCount = totalCount;
        }

        public Long getSuccessCount() {
            return successCount;
        }

        public void setSuccessCount(Long successCount) {
            this.successCount = successCount;
        }

        public Long getFailureCount() {
            return failureCount;
        }

        public void setFailureCount(Long failureCount) {
            this.failureCount = failureCount;
        }

        public Long getAverageExecutionTime() {
            return averageExecutionTime;
        }

        public void setAverageExecutionTime(Long averageExecutionTime) {
            this.averageExecutionTime = averageExecutionTime;
        }
    }
}
