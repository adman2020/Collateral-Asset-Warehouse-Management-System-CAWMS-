package com.seabank.cawms.config;

import com.seabank.cawms.security.JwtAuthenticationFilter;
import com.seabank.cawms.security.JwtTokenProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

/**
 * Spring Security閰嶇疆
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    private final JwtTokenProvider jwtTokenProvider;
    private final UserDetailsService userDetailsService;

    /**
     * 瀹夊叏杩囨护鍣ㄩ摼閰嶇疆
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            
            // TODO: fix encoding comment
                .sessionManagement(session -> session
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
            
            // TODO: fix encoding comment
            .authorizeHttpRequests(authz -> authz
                // TODO: fix encoding comment
                .requestMatchers(
                    "/api/auth/**",
                    "/api/v1/auth/**",
                    "/swagger-ui/**",
                    "/v3/api-docs/**",
                    "/swagger-resources/**",
                    "/webjars/**",
                    "/actuator/health",
                    "/error"
                ).permitAll()
                
                // TODO: fix encoding comment
                .requestMatchers(
                    "/uploads/**",
                    "/static/**"
                ).permitAll()
                
                // TODO: fix encoding comment
                .requestMatchers("/api/v1/**").authenticated()
                .requestMatchers("/api/system/**").authenticated()
                .requestMatchers("/api/warehouse-in/**").authenticated()
                .requestMatchers("/api/loan-out/**").authenticated()
                
                // TODO: fix encoding comment
                .anyRequest().authenticated()
            )
            
            // TODO: fix encoding comment
            .addFilterBefore(
                new JwtAuthenticationFilter(jwtTokenProvider, userDetailsService),
                UsernamePasswordAuthenticationFilter.class
            )
            
            // TODO: fix encoding comment
            .exceptionHandling(exception -> exception
                .authenticationEntryPoint(new JwtAuthenticationEntryPoint())
                .accessDeniedHandler(new JwtAccessDeniedHandler())
            );

        return http.build();
    }

    /**
     * 閰嶇疆CORS
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        
        // TODO: fix encoding comment
        configuration.setAllowedOrigins(Arrays.asList(
            "http://localhost:3000",
            "http://localhost:3001",
            "https://app.seabank.com"
        ));
        
        // TODO: fix encoding comment
        configuration.setAllowedMethods(Arrays.asList(
            "GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"
        ));
        
        // TODO: fix encoding comment
        configuration.setAllowedHeaders(Arrays.asList(
            "Authorization", "Content-Type", "X-Requested-With", "Accept", "Origin",
            "Access-Control-Request-Method", "Access-Control-Request-Headers",
            "X-Request-Id", "X-User-Id"
        ));
        
        // TODO: fix encoding comment
        configuration.setExposedHeaders(Arrays.asList(
            "Authorization", "Content-Type", "Content-Disposition", "X-Total-Count"
        ));
        
        // TODO: fix encoding comment
        configuration.setAllowCredentials(true);
        
        // TODO: fix encoding comment
        configuration.setMaxAge(3600L);
        
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        
        return source;
    }

    /**
     * 璁よ瘉绠＄悊鍣?     */
    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    /**
     * 璁よ瘉鎻愪緵鑰呴厤缃紙濡傛灉闇€瑕佽嚜瀹氫箟锛?     */

    // @Bean
    // public DaoAuthenticationProvider authenticationProvider() {
    //     DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
    // TODO: fix encoding comment
    // authProvider.setUserDetailsService(userDetailsService);
    // TODO: fix encoding comment
    // authProvider.setPasswordEncoder(passwordEncoder());
    // TODO: fix encoding comment
    // return authProvider;
    // }


    public SecurityConfig(JwtTokenProvider jwtTokenProvider, UserDetailsService userDetailsService) {
        this.jwtTokenProvider = jwtTokenProvider;
        this.userDetailsService = userDetailsService;
    }
}