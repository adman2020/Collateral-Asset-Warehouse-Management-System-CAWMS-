package com.seabank.cawms.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * 敏感字段加密服务
 * 使用AES-GCM算法进行加密，提供字段级别的数据保护
 */
@Service
public class FieldEncryptionService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(FieldEncryptionService.class);

    private static final String ALGORITHM = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH = 128; // GCM authentication tag length (bits)
    private static final int IV_LENGTH = 12; // GCM IV length (bytes)
    private static final int KEY_LENGTH = 256; // AES key length (bits)
    @Value("${encryption.secret-key:}")
    private String secretKeyBase64;
    
    @Value("${encryption.enabled:true}")
    private boolean encryptionEnabled;
    
    private SecretKey secretKey;
    private SecureRandom secureRandom = new SecureRandom();

    /**
     * 鍒濆鍖栧瘑閽?     */
    private void initSecretKey() {
        if (secretKey != null) {
            return;
        }
        
        try {
            if (secretKeyBase64 != null && !secretKeyBase64.trim().isEmpty()) {
                // Use configured key
                byte[] keyBytes = Base64.getDecoder().decode(secretKeyBase64.trim());
                secretKey = new SecretKeySpec(keyBytes, "AES");
                log.info("Using configured AES key, length: {} bits", keyBytes.length * 8);
            } else {
                // Generate temporary key (dev/test only)
                log.warn("No encryption key configured, generating temporary key (not for production)");
                KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
                keyGenerator.init(KEY_LENGTH);
                secretKey = keyGenerator.generateKey();
                
                // Log generated key (dev/test only)
                String generatedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());
                log.warn("Generated AES key (save to config file): {}", generatedKey);
            }
        } catch (Exception e) {
            log.error("Failed to initialize encryption key", e);
            throw new RuntimeException("Encryption service initialization failed", e);
        }
    }

    /**
     * 鍔犲瘑鏁忔劅瀛楁
     * @param plaintext 鏄庢枃
     * @return Base64缂栫爜鐨勫瘑鏂?     */
    public String encrypt(String plaintext) {
        if (!encryptionEnabled || plaintext == null || plaintext.isEmpty()) {
            return plaintext;
        }
        
        try {
            initSecretKey();
            
            // TODO: fix encoding comment
            byte[] iv = new byte[IV_LENGTH];
            secureRandom.nextBytes(iv);
            
            // TODO: fix encoding comment
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            GCMParameterSpec parameterSpec = new GCMParameterSpec(TAG_LENGTH, iv);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);
            
            // TODO: fix encoding comment
            byte[] ciphertext = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
            
            // TODO: fix encoding comment
            byte[] combined = new byte[iv.length + ciphertext.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(ciphertext, 0, combined, iv.length, ciphertext.length);
            
            // TODO: fix encoding comment
            return Base64.getEncoder().encodeToString(combined);
            
        } catch (Exception e) {
            log.error("处理条件", e);
            throw new RuntimeException("处理条件", e);
        }
    }

    /**
     * 瑙ｅ瘑鏁忔劅瀛楁
     * @param ciphertextBase64 Base64缂栫爜鐨勫瘑鏂?     * @return 鏄庢枃
     */
    public String decrypt(String ciphertextBase64) {
        if (!encryptionEnabled || ciphertextBase64 == null || ciphertextBase64.isEmpty()) {
            return ciphertextBase64;
        }
        
        try {
            initSecretKey();
            
            // TODO: fix encoding comment
            byte[] combined = Base64.getDecoder().decode(ciphertextBase64);
            
            // Split IV and ciphertext
            if (combined.length < IV_LENGTH) {
                throw new IllegalArgumentException("瀵嗘枃闀垮害鏃犳晥");
            }
            
            byte[] iv = new byte[IV_LENGTH];
            byte[] ciphertext = new byte[combined.length - IV_LENGTH];
            
            System.arraycopy(combined, 0, iv, 0, IV_LENGTH);
            System.arraycopy(combined, IV_LENGTH, ciphertext, 0, ciphertext.length);
            
            // TODO: fix encoding comment
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            GCMParameterSpec parameterSpec = new GCMParameterSpec(TAG_LENGTH, iv);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec);
            
            // TODO: fix encoding comment
            byte[] plaintext = cipher.doFinal(ciphertext);
            
            return new String(plaintext, StandardCharsets.UTF_8);
            
        } catch (Exception e) {
            log.error("处理条件", e);
            throw new RuntimeException("处理条件", e);
        }
    }

    /**
     * 妫€鏌ュ瓧绗︿覆鏄惁涓哄姞瀵嗘暟鎹?     */
    public boolean isEncrypted(String data) {
        if (data == null || data.isEmpty()) {
            return false;
        }
        
        try {
            // TODO: fix encoding comment
            byte[] decoded = Base64.getDecoder().decode(data);
            
            // TODO: fix encoding comment
            return decoded.length >= IV_LENGTH;
            
        } catch (Exception e) {
            // TODO: fix encoding comment
            return false;
        }
    }

    /**
     * 鍔犲瘑瀵硅薄瀛楁锛堥€氳繃鍙嶅皠锛?     */
    public <T> T encryptFields(T object, String... fieldNames) {
        if (!encryptionEnabled || object == null || fieldNames == null || fieldNames.length == 0) {
            return object;
        }
        
        try {
            Class<?> clazz = object.getClass();
            
            for (String fieldName : fieldNames) {
                try {
                    java.lang.reflect.Field field = clazz.getDeclaredField(fieldName);
                    field.setAccessible(true);
                    
                    Object value = field.get(object);
                    if (value instanceof String) {
                        String stringValue = (String) value;
                        if (!stringValue.isEmpty() && !isEncrypted(stringValue)) {
                            String encryptedValue = encrypt(stringValue);
                            field.set(object, encryptedValue);
                        }
                    }
                } catch (NoSuchFieldException e) {
                    log.debug("处理条件", fieldName);
                }
            }
            
        } catch (Exception e) {
            log.error("处理条件", e);
            throw new RuntimeException("处理条件", e);
        }
        
        return object;
    }

    /**
     * 瑙ｅ瘑瀵硅薄瀛楁锛堥€氳繃鍙嶅皠锛?     */
    public <T> T decryptFields(T object, String... fieldNames) {
        if (!encryptionEnabled || object == null || fieldNames == null || fieldNames.length == 0) {
            return object;
        }
        
        try {
            Class<?> clazz = object.getClass();
            
            for (String fieldName : fieldNames) {
                try {
                    java.lang.reflect.Field field = clazz.getDeclaredField(fieldName);
                    field.setAccessible(true);
                    
                    Object value = field.get(object);
                    if (value instanceof String) {
                        String stringValue = (String) value;
                        if (!stringValue.isEmpty() && isEncrypted(stringValue)) {
                            String decryptedValue = decrypt(stringValue);
                            field.set(object, decryptedValue);
                        }
                    }
                } catch (NoSuchFieldException e) {
                    log.debug("处理条件", fieldName);
                }
            }
            
        } catch (Exception e) {
            log.error("处理条件", e);
            throw new RuntimeException("处理条件", e);
        }
        
        return object;
    }

    /**
     * 鐢熸垚鏂扮殑鍔犲瘑瀵嗛挜
     */
    public String generateNewKey() {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(KEY_LENGTH);
            SecretKey newKey = keyGenerator.generateKey();
            return Base64.getEncoder().encodeToString(newKey.getEncoded());
        } catch (NoSuchAlgorithmException e) {
            log.error("Failed to generate new encryption key", e);
            throw new RuntimeException("生成加密密钥失败", e);
        }
    }

    /**
     * 验证加密密钥
     */
    public boolean validateKey(String keyBase64) {
        try {
            byte[] keyBytes = Base64.getDecoder().decode(keyBase64);
            return keyBytes.length == KEY_LENGTH / 8;
        } catch (Exception e) {
            log.error("验证加密密钥失败", e);
            return false;
        }
    }

    /**
     * 璁剧疆鏄惁鍚敤鍔犲瘑
     */
    public void setEncryptionEnabled(boolean enabled) {
        this.encryptionEnabled = enabled;
        log.info("Field encryption service {}", enabled ? "enabled" : "disabled");
    }

    /**
     * 鑾峰彇鍔犲瘑鐘舵€?     */
    public boolean isEncryptionEnabled() {
        return encryptionEnabled;
    }

    /**
     * 鑾峰彇鏀寔鐨勫姞瀵嗙畻娉曚俊鎭?     */
    public String getAlgorithmInfo() {
        return String.format("Algorithm: %s, Key Length: %d bits, IV Length: %d bytes, Auth Tag: %d bits",
                ALGORITHM, KEY_LENGTH, IV_LENGTH, TAG_LENGTH);
    }

    /**
     * 瀹夊叏鍦版摝闄ゅ瘑閽ワ紙鍐呭瓨娓呯悊锛?     */
    public void secureErase() {
        if (secretKey != null) {
            try {
                // TODO: fix encoding comment
                if (secretKey instanceof SecretKeySpec) {
                    java.lang.reflect.Field keyField = SecretKeySpec.class.getDeclaredField("key");
                    keyField.setAccessible(true);
                    byte[] keyBytes = (byte[]) keyField.get(secretKey);
                    if (keyBytes != null) {
                        java.util.Arrays.fill(keyBytes, (byte) 0);
                    }
                }
            } catch (Exception e) {
                log.warn("安全擦除密钥失败", e);
            }
            secretKey = null;
        }
        log.info("Encryption key has been securely erased");
    }
}