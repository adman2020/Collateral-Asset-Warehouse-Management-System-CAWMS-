package com.seabank.cawms.service;

import com.seabank.cawms.entity.LoanOutEntity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * T24鏍稿績閾惰绯荤粺闆嗘垚鏈嶅姟鎺ュ彛
 * 璐熻矗涓嶵24鏍稿績閾惰绯荤粺杩涜鏁版嵁鍚屾鍜岀姸鎬佷氦浜? */


public interface T24IntegrationService {
    
    /**
     * 鏌ヨT24璐︽埛淇℃伅
     * @param accountNumber 璐︽埛鍙风爜
     * @return 璐︽埛淇℃伅
     */
    AccountInfo queryAccountInfo(String accountNumber);
    
    /**
     * 鍚屾鍊熷嚭璁板綍鍒癟24
     * @param loanOut 鍊熷嚭璁板綍
     * @return 鍚屾缁撴灉
     */
    SyncResult syncLoanToT24(LoanOutEntity loanOut);
    
    /**
     * 鍚屾褰掕繕璁板綍鍒癟24
     * @param loanOut 鍊熷嚭璁板綍
     * @param returnDate 褰掕繕鏃ユ湡
     * @param settlementAmount 缁撶畻閲戦
     * @return 鍚屾缁撴灉
     */
    SyncResult syncReturnToT24(LoanOutEntity loanOut, LocalDate returnDate, BigDecimal settlementAmount);
    
    /**
     * 鍚屾閫炬湡鐘舵€佸埌T24
     * @param loanOut 鍊熷嚭璁板綍
     * @param overdueDays 閫炬湡澶╂暟
     * @return 鍚屾缁撴灉
     */
    SyncResult syncOverdueToT24(LoanOutEntity loanOut, Integer overdueDays);
    
    /**
     * 鎵归噺鍚屾鍊熷嚭璁板綍鐘舵€佸埌T24
     * @param loanOutIds 借出记录ID鍒楄〃
     * @return 鎵归噺鍚屾缁撴灉
     */
    BatchSyncResult batchSyncLoansToT24(List<Long> loanOutIds);
    
    /**
     * 浠嶵24鏌ヨ璐锋璐︽埛浣欓
     * @param loanAccountNumber 璐锋璐︽埛鍙风爜
     * @return 璐︽埛浣欓淇℃伅
     */
    AccountBalance queryLoanAccountBalance(String loanAccountNumber);
    
    /**
     * 妫€鏌24鏈嶅姟杩炴帴鐘舵€?     * @return 杩炴帴鐘舵€?     */


    ConnectionStatus checkConnection();
    
    /**
     * 閲嶈瘯澶辫触鐨凾24鍚屾操作
     * @param maxRetryCount 鏈€澶ч噸璇曟鏁?     * @return 閲嶈瘯缁撴灉
     */
    RetryResult retryFailedSyncs(Integer maxRetryCount);
    
    /**
     * 鑾峰彇T24鍚屾缁熻淇℃伅
     * @return 鍚屾缁熻
     */
    SyncStatistics getSyncStatistics();
    
    /**
     * 娴嬭瘯T24杩炴帴鍜屾帴鍙?     * @param testConfig 娴嬭瘯閰嶇疆
     * @return 娴嬭瘯缁撴灉
     */
    TestResult testT24Connection(TestConfig testConfig);
    
    /**
     * 璐︽埛淇℃伅
     */
    class AccountInfo {
        private String accountNumber;
        private String customerId;
        private String customerName;
        private String accountType;
        private String currency;
        private BigDecimal currentBalance;
        private BigDecimal availableBalance;
        private BigDecimal ledgerBalance;
        private LocalDate openDate;
        private String status;
        private Map<String, Object> additionalInfo;
        
        public String getAccountNumber() { return accountNumber; }
        public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
        public String getCustomerId() { return customerId; }
        public void setCustomerId(String customerId) { this.customerId = customerId; }
        public String getCustomerName() { return customerName; }
        public void setCustomerName(String customerName) { this.customerName = customerName; }
        public String getAccountType() { return accountType; }
        public void setAccountType(String accountType) { this.accountType = accountType; }
        public String getCurrency() { return currency; }
        public void setCurrency(String currency) { this.currency = currency; }
        public BigDecimal getCurrentBalance() { return currentBalance; }
        public void setCurrentBalance(BigDecimal currentBalance) { this.currentBalance = currentBalance; }
        public BigDecimal getAvailableBalance() { return availableBalance; }
        public void setAvailableBalance(BigDecimal availableBalance) { this.availableBalance = availableBalance; }
        public BigDecimal getLedgerBalance() { return ledgerBalance; }
        public void setLedgerBalance(BigDecimal ledgerBalance) { this.ledgerBalance = ledgerBalance; }
        public LocalDate getOpenDate() { return openDate; }
        public void setOpenDate(LocalDate openDate) { this.openDate = openDate; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public Map<String, Object> getAdditionalInfo() { return additionalInfo; }
        public void setAdditionalInfo(Map<String, Object> additionalInfo) { this.additionalInfo = additionalInfo; }
    }
    
    /**
     * 鍚屾缁撴灉
     */
    class SyncResult {
        private Boolean success;
        private String syncType;
        private String t24TransactionId;
        private String t24ReferenceNumber;
        private LocalDateTime syncTime;
        private String message;
        private String errorCode;
        private String errorMessage;
        private Map<String, Object> syncDetails;
        private Long loanOutId;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getSyncType() { return syncType; }
        public void setSyncType(String syncType) { this.syncType = syncType; }
        public String getT24TransactionId() { return t24TransactionId; }
        public void setT24TransactionId(String t24TransactionId) { this.t24TransactionId = t24TransactionId; }
        public String getT24ReferenceNumber() { return t24ReferenceNumber; }
        public void setT24ReferenceNumber(String t24ReferenceNumber) { this.t24ReferenceNumber = t24ReferenceNumber; }
        public LocalDateTime getSyncTime() { return syncTime; }
        public void setSyncTime(LocalDateTime syncTime) { this.syncTime = syncTime; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getErrorCode() { return errorCode; }
        public void setErrorCode(String errorCode) { this.errorCode = errorCode; }
        public String getErrorMessage() { return errorMessage; }
        public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
        public Map<String, Object> getSyncDetails() { return syncDetails; }
        public void setSyncDetails(Map<String, Object> syncDetails) { this.syncDetails = syncDetails; }
        public Long getLoanOutId() { return loanOutId; }
        public void setLoanOutId(Long loanOutId) { this.loanOutId = loanOutId; }
    }
    
    /**
     * 鎵归噺鍚屾缁撴灉
     */
    class BatchSyncResult {
        private Boolean success;
        private Integer totalCount;
        private Integer successCount;
        private Integer failCount;
        private Long executionTimeMs;
        private String message;
        private List<SyncResult> detailedResults;
        private List<Long> successfulIds;
        private List<Long> failedIds;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Integer getTotalCount() { return totalCount; }
        public void setTotalCount(Integer totalCount) { this.totalCount = totalCount; }
        public Integer getSuccessCount() { return successCount; }
        public void setSuccessCount(Integer successCount) { this.successCount = successCount; }
        public Integer getFailCount() { return failCount; }
        public void setFailCount(Integer failCount) { this.failCount = failCount; }
        public Long getExecutionTimeMs() { return executionTimeMs; }
        public void setExecutionTimeMs(Long executionTimeMs) { this.executionTimeMs = executionTimeMs; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public List<SyncResult> getDetailedResults() { return detailedResults; }
        public void setDetailedResults(List<SyncResult> detailedResults) { this.detailedResults = detailedResults; }
        public List<Long> getSuccessfulIds() { return successfulIds; }
        public void setSuccessfulIds(List<Long> successfulIds) { this.successfulIds = successfulIds; }
        public List<Long> getFailedIds() { return failedIds; }
        public void setFailedIds(List<Long> failedIds) { this.failedIds = failedIds; }
    }
    
    /**
     * 璐︽埛浣欓淇℃伅
     */
    class AccountBalance {
        private String accountNumber;
        private BigDecimal currentBalance;
        private BigDecimal availableBalance;
        private BigDecimal ledgerBalance;
        private String currency;
        private LocalDate balanceDate;
        private BigDecimal creditLimit;
        private BigDecimal overdraftLimit;
        private Map<String, Object> additionalInfo;
        
        public String getAccountNumber() { return accountNumber; }
        public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
        public BigDecimal getCurrentBalance() { return currentBalance; }
        public void setCurrentBalance(BigDecimal currentBalance) { this.currentBalance = currentBalance; }
        public BigDecimal getAvailableBalance() { return availableBalance; }
        public void setAvailableBalance(BigDecimal availableBalance) { this.availableBalance = availableBalance; }
        public BigDecimal getLedgerBalance() { return ledgerBalance; }
        public void setLedgerBalance(BigDecimal ledgerBalance) { this.ledgerBalance = ledgerBalance; }
        public String getCurrency() { return currency; }
        public void setCurrency(String currency) { this.currency = currency; }
        public LocalDate getBalanceDate() { return balanceDate; }
        public void setBalanceDate(LocalDate balanceDate) { this.balanceDate = balanceDate; }
        public BigDecimal getCreditLimit() { return creditLimit; }
        public void setCreditLimit(BigDecimal creditLimit) { this.creditLimit = creditLimit; }
        public BigDecimal getOverdraftLimit() { return overdraftLimit; }
        public void setOverdraftLimit(BigDecimal overdraftLimit) { this.overdraftLimit = overdraftLimit; }
        public Map<String, Object> getAdditionalInfo() { return additionalInfo; }
        public void setAdditionalInfo(Map<String, Object> additionalInfo) { this.additionalInfo = additionalInfo; }
    }
    
    /**
     * 杩炴帴鐘舵€?     */


    class ConnectionStatus {
        private Boolean connected;
        private String t24Version;
        private LocalDateTime lastConnectedTime;
        private Long responseTimeMs;
        private String connectionType;
        private String message;
        private Map<String, Object> connectionDetails;
        
        public Boolean getConnected() { return connected; }
        public void setConnected(Boolean connected) { this.connected = connected; }
        public String getT24Version() { return t24Version; }
        public void setT24Version(String t24Version) { this.t24Version = t24Version; }
        public LocalDateTime getLastConnectedTime() { return lastConnectedTime; }
        public void setLastConnectedTime(LocalDateTime lastConnectedTime) { this.lastConnectedTime = lastConnectedTime; }
        public Long getResponseTimeMs() { return responseTimeMs; }
        public void setResponseTimeMs(Long responseTimeMs) { this.responseTimeMs = responseTimeMs; }
        public String getConnectionType() { return connectionType; }
        public void setConnectionType(String connectionType) { this.connectionType = connectionType; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public Map<String, Object> getConnectionDetails() { return connectionDetails; }
        public void setConnectionDetails(Map<String, Object> connectionDetails) { this.connectionDetails = connectionDetails; }
    }
    
    /**
     * 閲嶈瘯缁撴灉
     */
    class RetryResult {
        private Boolean success;
        private Integer totalRetried;
        private Integer retrySuccessCount;
        private Integer retryFailCount;
        private Long executionTimeMs;
        private String message;
        private List<Long> retriedIds;
        private List<SyncResult> detailedResults;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public Integer getTotalRetried() { return totalRetried; }
        public void setTotalRetried(Integer totalRetried) { this.totalRetried = totalRetried; }
        public Integer getRetrySuccessCount() { return retrySuccessCount; }
        public void setRetrySuccessCount(Integer retrySuccessCount) { this.retrySuccessCount = retrySuccessCount; }
        public Integer getRetryFailCount() { return retryFailCount; }
        public void setRetryFailCount(Integer retryFailCount) { this.retryFailCount = retryFailCount; }
        public Long getExecutionTimeMs() { return executionTimeMs; }
        public void setExecutionTimeMs(Long executionTimeMs) { this.executionTimeMs = executionTimeMs; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public List<Long> getRetriedIds() { return retriedIds; }
        public void setRetriedIds(List<Long> retriedIds) { this.retriedIds = retriedIds; }
        public List<SyncResult> getDetailedResults() { return detailedResults; }
        public void setDetailedResults(List<SyncResult> detailedResults) { this.detailedResults = detailedResults; }
    }
    
    /**
     * 鍚屾缁熻
     */
    class SyncStatistics {
        private Integer totalSyncs;
        private Integer successSyncs;
        private Integer failSyncs;
        private Integer pendingSyncs;
        private Map<String, Integer> syncsByType;
        private Map<String, Integer> syncsByStatus;
        private Double averageSyncTimeMs;
        private Double successRate;
        private List<SyncResult> recentSyncs;
        private LocalDateTime statisticsTime;
        
        public Integer getTotalSyncs() { return totalSyncs; }
        public void setTotalSyncs(Integer totalSyncs) { this.totalSyncs = totalSyncs; }
        public Integer getSuccessSyncs() { return successSyncs; }
        public void setSuccessSyncs(Integer successSyncs) { this.successSyncs = successSyncs; }
        public Integer getFailSyncs() { return failSyncs; }
        public void setFailSyncs(Integer failSyncs) { this.failSyncs = failSyncs; }
        public Integer getPendingSyncs() { return pendingSyncs; }
        public void setPendingSyncs(Integer pendingSyncs) { this.pendingSyncs = pendingSyncs; }
        public Map<String, Integer> getSyncsByType() { return syncsByType; }
        public void setSyncsByType(Map<String, Integer> syncsByType) { this.syncsByType = syncsByType; }
        public Map<String, Integer> getSyncsByStatus() { return syncsByStatus; }
        public void setSyncsByStatus(Map<String, Integer> syncsByStatus) { this.syncsByStatus = syncsByStatus; }
        public Double getAverageSyncTimeMs() { return averageSyncTimeMs; }
        public void setAverageSyncTimeMs(Double averageSyncTimeMs) { this.averageSyncTimeMs = averageSyncTimeMs; }
        public Double getSuccessRate() { return successRate; }
        public void setSuccessRate(Double successRate) { this.successRate = successRate; }
        public List<SyncResult> getRecentSyncs() { return recentSyncs; }
        public void setRecentSyncs(List<SyncResult> recentSyncs) { this.recentSyncs = recentSyncs; }
        public LocalDateTime getStatisticsTime() { return statisticsTime; }
        public void setStatisticsTime(LocalDateTime statisticsTime) { this.statisticsTime = statisticsTime; }
    }
    
    /**
     * 娴嬭瘯缁撴灉
     */
    class TestResult {
        private Boolean success;
        private String testType;
        private LocalDateTime testTime;
        private Long responseTimeMs;
        private String resultMessage;
        private String errorDetails;
        private Map<String, Object> testDetails;
        
        public Boolean getSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getTestType() { return testType; }
        public void setTestType(String testType) { this.testType = testType; }
        public LocalDateTime getTestTime() { return testTime; }
        public void setTestTime(LocalDateTime testTime) { this.testTime = testTime; }
        public Long getResponseTimeMs() { return responseTimeMs; }
        public void setResponseTimeMs(Long responseTimeMs) { this.responseTimeMs = responseTimeMs; }
        public String getResultMessage() { return resultMessage; }
        public void setResultMessage(String resultMessage) { this.resultMessage = resultMessage; }
        public String getErrorDetails() { return errorDetails; }
        public void setErrorDetails(String errorDetails) { this.errorDetails = errorDetails; }
        public Map<String, Object> getTestDetails() { return testDetails; }
        public void setTestDetails(Map<String, Object> testDetails) { this.testDetails = testDetails; }
    }
    
    /**
     * 娴嬭瘯閰嶇疆
     */
    class TestConfig {
        private String testType;
        private String accountNumber;
        private String transactionType;
        private Map<String, Object> additionalParams;
        
        public String getTestType() { return testType; }
        public void setTestType(String testType) { this.testType = testType; }
        public String getAccountNumber() { return accountNumber; }
        public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
        public String getTransactionType() { return transactionType; }
        public void setTransactionType(String transactionType) { this.transactionType = transactionType; }
        public Map<String, Object> getAdditionalParams() { return additionalParams; }
        public void setAdditionalParams(Map<String, Object> additionalParams) { this.additionalParams = additionalParams; }
    }
}