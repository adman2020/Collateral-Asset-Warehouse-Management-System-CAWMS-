package com.seabank.cawms.service.impl;

import com.seabank.cawms.service.WarehouseCodeGenerator;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Warehouse code generator implementation
 */
@Service
public class WarehouseCodeGeneratorImpl implements WarehouseCodeGenerator {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WarehouseCodeGeneratorImpl.class);

    private final AtomicLong counter = new AtomicLong(0);
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

    @Override
    public String generateWarehouseCode(String prefix, String dateStr) {
        log.info("Generating warehouse code: prefix={}, dateStr={}", prefix, dateStr);
        String date = dateStr != null ? dateStr : LocalDateTime.now().format(DATE_FORMATTER);
        long seq = counter.incrementAndGet() % 10000;
        return String.format("%s-%s-%05d", prefix, date, seq);
    }

    public String generateCode(Object request) {
        log.warn("Temp mock: generateCode called, type={}", request.getClass().getSimpleName());
        return "TEMP-CODE-" + System.currentTimeMillis();
    }

    public boolean validateRequest(Object request) {
        log.warn("Mock: validateRequest called");
        return true;
    }

    public String generateBatch(Object request) {
        log.warn("Mock: generateBatch called");
        return "TEMP-BATCH-CODE";
    }

    public String parseCode(String code) {
        log.warn("Mock: parseCode called, code={}", code);
        return "TEMP-BU";
    }

    public long getStatistics() {
        log.warn("Mock: getStatistics called");
        return 0L;
    }

    public static WarehouseCodeGenerator createMock() {
        return new WarehouseCodeGeneratorImpl();
    }
}
