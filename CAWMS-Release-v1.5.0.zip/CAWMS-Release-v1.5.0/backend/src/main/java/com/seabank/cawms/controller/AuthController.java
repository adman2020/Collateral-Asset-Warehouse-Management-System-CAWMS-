package com.seabank.cawms.controller;

import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.entity.SystemUserEntity;
import com.seabank.cawms.security.CustomUserDetails;
import com.seabank.cawms.security.JwtTokenProvider;
import com.seabank.cawms.security.UserDetailsServiceImpl;
import com.seabank.cawms.service.SystemUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Authentication Controller
 */
@Validated
@RestController
@RequestMapping("/api/auth")
@Tag(name = "AuthController", description = "Authentication API")
public class AuthController {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AuthController.class);

    private final SystemUserService systemUserService;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;
    private final UserDetailsServiceImpl userDetailsService;

    public AuthController(SystemUserService systemUserService,
                          PasswordEncoder passwordEncoder,
                          JwtTokenProvider jwtTokenProvider,
                          UserDetailsServiceImpl userDetailsService) {
        this.systemUserService = systemUserService;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenProvider = jwtTokenProvider;
        this.userDetailsService = userDetailsService;
    }

    @Operation(summary = "User Login")
    @PostMapping("/login")
    public CommonResponse<LoginResponse> login(@Valid @RequestBody LoginRequest request,
                                                HttpServletRequest httpRequest) {
        log.info("Login attempt: {}", request.getUsername());

        SystemUserEntity user = systemUserService.findByUsername(request.getUsername());
        if (user == null) {
            return CommonResponse.error(401, "Invalid username or password");
        }

        String rawPassword = request.getPassword();
        String storedPassword = user.getPassword();
        boolean passwordMatched = false;

        if (passwordEncoder.matches(rawPassword, storedPassword)) {
            passwordMatched = true;
        } else if (rawPassword.equals(storedPassword)) {
            // Plain text compatibility: migrate to BCrypt
            passwordMatched = true;
            try {
                user.setPassword(passwordEncoder.encode(rawPassword));
                systemUserService.updateById(user);
                log.info("Migrated plain text password to BCrypt for user: {}", user.getUsername());
            } catch (Exception e) {
                log.warn("Failed to migrate password for user: {}", user.getUsername(), e);
            }
        }

        if (!passwordMatched) {
            return CommonResponse.error(401, "Invalid username or password");
        }

        if (!"ACTIVE".equals(user.getStatus())) {
            return CommonResponse.error(403, "Account is " + user.getStatus().toLowerCase());
        }

        // Update last login info
        try {
            userDetailsService.updateLastLoginInfo(user.getUsername(), getClientIp(httpRequest));
        } catch (Exception e) {
            log.warn("Failed to update last login info for user: {}", user.getUsername(), e);
        }

        // Generate JWT
        List<String> roles = resolveRoles(user.getRole());
        List<GrantedAuthority> authorities = roles.stream()
                .map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role)
                .map(org.springframework.security.core.authority.SimpleGrantedAuthority::new)
                .collect(Collectors.toList());

        String token = jwtTokenProvider.generateToken(user.getUsername(), authorities);
        long expiresIn = jwtTokenProvider.getRemainingExpirationMs(token);
        if (expiresIn <= 0) {
            expiresIn = 28800000L; // fallback 8 hours
        }

        List<String> permissions = resolvePermissions(user.getRole());
        UserInfo userInfo = toUserInfo(user, permissions);

        LoginResponse response = new LoginResponse();
        response.setToken(token);
        response.setUser(userInfo);
        response.setExpiresIn((int) (expiresIn / 1000));
        response.setPermissions(permissions);
        response.setRoles(roles);

        return CommonResponse.success(response, "Login successful");
    }

    @Operation(summary = "User Logout")
    @PostMapping("/logout")
    public CommonResponse<Boolean> logout() {
        SecurityContextHolder.clearContext();
        return CommonResponse.success(true, "Logout successful");
    }

    @Operation(summary = "Get Current User")
    @GetMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<UserInfo> me() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()
                || "anonymousUser".equals(authentication.getPrincipal())) {
            return CommonResponse.error(401, "Not authenticated");
        }

        String username = authentication.getName();
        SystemUserEntity user = systemUserService.findByUsername(username);
        if (user == null) {
            return CommonResponse.error(404, "User not found");
        }

        List<String> permissions = resolvePermissions(user.getRole());
        return CommonResponse.success(toUserInfo(user, permissions));
    }

    @Operation(summary = "Change Password")
    @PostMapping("/change-password")
    @PreAuthorize("isAuthenticated()")
    public CommonResponse<Boolean> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        SystemUserEntity user = systemUserService.findByUsername(username);
        if (user == null) {
            return CommonResponse.error(404, "User not found");
        }

        String oldPassword = request.getOldPassword();
        String storedPassword = user.getPassword();
        boolean matched = passwordEncoder.matches(oldPassword, storedPassword) || oldPassword.equals(storedPassword);
        if (!matched) {
            return CommonResponse.error(400, "Old password is incorrect");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        systemUserService.updateById(user);
        return CommonResponse.success(true, "Password changed successfully");
    }

    // ==================== Helpers ====================

    private UserInfo toUserInfo(SystemUserEntity user, List<String> permissions) {
        UserInfo info = new UserInfo();
        info.setId(user.getId());
        info.setUsername(user.getUsername());
        info.setEmail(user.getEmail());
        info.setPhone(user.getPhoneNumber());
        info.setFullName(user.getFullName());
        info.setDepartment(user.getDepartment());
        info.setRole(user.getRole());
        info.setPermissions(permissions);
        info.setLastLogin(user.getLastLoginTime() != null ? user.getLastLoginTime().toString() : null);
        info.setStatus(user.getStatus() != null ? user.getStatus().toLowerCase() : "active");
        return info;
    }

    private List<String> resolveRoles(String role) {
        if (role == null || role.isBlank()) {
            return List.of("user");
        }
        return List.of(role);
    }

    private List<String> resolvePermissions(String role) {
        if (role == null) {
            return List.of("user:read");
        }
        String r = role.toLowerCase();
        if (r.contains("admin") || r.contains("super_admin")) {
            return List.of("*");
        }
        return List.of(
                "user:read", "user:write",
                "warehouse-in:read", "warehouse-in:write",
                "loan-out:read", "loan-out:write",
                "system:read"
        );
    }

    private String getClientIp(HttpServletRequest request) {
        String xff = request.getHeader("X-Forwarded-For");
        if (xff != null && !xff.isBlank()) {
            return xff.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    // ==================== DTOs ====================

    @Validated
    public static class LoginRequest {
        @NotBlank(message = "Username is required")
        private String username;
        @NotBlank(message = "Password is required")
        private String password;
        private Boolean rememberMe;

        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public Boolean getRememberMe() { return rememberMe; }
        public void setRememberMe(Boolean rememberMe) { this.rememberMe = rememberMe; }
    }

    @Validated
    public static class ChangePasswordRequest {
        @NotBlank(message = "Old password is required")
        private String oldPassword;
        @NotBlank(message = "New password is required")
        private String newPassword;

        public String getOldPassword() { return oldPassword; }
        public void setOldPassword(String oldPassword) { this.oldPassword = oldPassword; }
        public String getNewPassword() { return newPassword; }
        public void setNewPassword(String newPassword) { this.newPassword = newPassword; }
    }

    public static class UserInfo {
        private Long id;
        private String username;
        private String email;
        private String phone;
        private String fullName;
        private String department;
        private String role;
        private List<String> permissions;
        private String lastLogin;
        private String status;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        public String getDepartment() { return department; }
        public void setDepartment(String department) { this.department = department; }
        public String getRole() { return role; }
        public void setRole(String role) { this.role = role; }
        public List<String> getPermissions() { return permissions; }
        public void setPermissions(List<String> permissions) { this.permissions = permissions; }
        public String getLastLogin() { return lastLogin; }
        public void setLastLogin(String lastLogin) { this.lastLogin = lastLogin; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    public static class LoginResponse {
        private String token;
        private UserInfo user;
        private Integer expiresIn;
        private List<String> permissions;
        private List<String> roles;

        public String getToken() { return token; }
        public void setToken(String token) { this.token = token; }
        public UserInfo getUser() { return user; }
        public void setUser(UserInfo user) { this.user = user; }
        public Integer getExpiresIn() { return expiresIn; }
        public void setExpiresIn(Integer expiresIn) { this.expiresIn = expiresIn; }
        public List<String> getPermissions() { return permissions; }
        public void setPermissions(List<String> permissions) { this.permissions = permissions; }
        public List<String> getRoles() { return roles; }
        public void setRoles(List<String> roles) { this.roles = roles; }
    }
}
