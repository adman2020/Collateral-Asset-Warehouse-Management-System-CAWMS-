package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.AuditLogEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 瀹¤鏃ュ織Mapper鎺ュ彛
 */
@Mapper
public interface AuditLogMapper extends BaseMapper<AuditLogEntity> {
    
}