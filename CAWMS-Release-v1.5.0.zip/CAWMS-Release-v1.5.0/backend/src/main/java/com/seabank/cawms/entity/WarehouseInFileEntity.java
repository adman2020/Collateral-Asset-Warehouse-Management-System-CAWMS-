package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("warehouse_in_files")
public class WarehouseInFileEntity extends BaseEntity {
    @TableField("wh_in_id")
    private Long warehouseInId;
    private String fileName;
    private String fileType;
    private String filePath;
    private Long fileSize;
    private String fileHash;
    private String mimeType;
    private String checksum;
    private String uploadedBy;
    private String uploadUser;
    private java.time.LocalDateTime uploadTime;
    private String description;
    private String status;
    private Integer downloadCount;
    private java.time.LocalDateTime lastDownloadAt;


    public Long getWarehouseInId() {
        return warehouseInId;
    }
    public void setWarehouseInId(Long warehouseInId) {
        this.warehouseInId = warehouseInId;
    }

    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }
    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getFilePath() {
        return filePath;
    }
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public Long getFileSize() {
        return fileSize;
    }
    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileHash() {
        return fileHash;
    }
    public void setFileHash(String fileHash) {
        this.fileHash = fileHash;
    }

    public String getMimeType() {
        return mimeType;
    }
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getChecksum() {
        return checksum;
    }
    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public String getUploadedBy() {
        return uploadedBy;
    }
    public void setUploadedBy(String uploadedBy) {
        this.uploadedBy = uploadedBy;
    }

    public String getUploadUser() {
        return uploadUser;
    }
    public void setUploadUser(String uploadUser) {
        this.uploadUser = uploadUser;
    }

    public java.time.LocalDateTime getUploadTime() {
        return uploadTime;
    }
    public void setUploadTime(java.time.LocalDateTime uploadTime) {
        this.uploadTime = uploadTime;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getDownloadCount() {
        return downloadCount;
    }
    public void setDownloadCount(Integer downloadCount) {
        this.downloadCount = downloadCount;
    }

    public java.time.LocalDateTime getLastDownloadAt() {
        return lastDownloadAt;
    }
    public void setLastDownloadAt(java.time.LocalDateTime lastDownloadAt) {
        this.lastDownloadAt = lastDownloadAt;
    }
}
