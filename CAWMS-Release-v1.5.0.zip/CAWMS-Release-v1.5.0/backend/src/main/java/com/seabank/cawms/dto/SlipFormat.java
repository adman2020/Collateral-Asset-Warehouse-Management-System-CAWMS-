package com.seabank.cawms.dto;

public enum SlipFormat {
    PDF("pdf"), HTML("html"), DOCX("docx"), XLSX("xlsx");

    private final String code;

    SlipFormat(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
