package com.seabank.cawms.service;

import org.springframework.web.multipart.MultipartFile;
import java.util.List;
import java.util.Map;

/**
 * 数据导入服务接口
 */
public interface DataImportService {
    ImportResult importDataFile(MultipartFile file, String importType, String importer);
    BatchImportResult importBatchData(List<ImportRequest> importRequests);
    ValidationResult validateImportData(Map<String, Object> importData, String importType);
    Map<String, Object> parseImportFile(MultipartFile file);
    List<String> getSupportedImportTypes();
    Map<String, Object> getImportTemplate(String importType);

    class ImportResult {
        private boolean success;
        private Integer importedCount;
        private String message;
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }
        public Integer getImportedCount() { return importedCount; }
        public void setImportedCount(Integer importedCount) { this.importedCount = importedCount; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }

    class BatchImportResult {
        private boolean success;
        private Integer totalRequests;
        private Integer successfulRequests;
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }
        public Integer getTotalRequests() { return totalRequests; }
        public void setTotalRequests(Integer totalRequests) { this.totalRequests = totalRequests; }
        public Integer getSuccessfulRequests() { return successfulRequests; }
        public void setSuccessfulRequests(Integer successfulRequests) { this.successfulRequests = successfulRequests; }
    }

    class ValidationResult {
        private boolean valid;
        public boolean isValid() { return valid; }
        public void setValid(boolean valid) { this.valid = valid; }
    }

    class ImportRequest {
        private String importType;
        private Map<String, Object> data;
        public String getImportType() { return importType; }
        public void setImportType(String importType) { this.importType = importType; }
        public Map<String, Object> getData() { return data; }
        public void setData(Map<String, Object> data) { this.data = data; }
    }
}
