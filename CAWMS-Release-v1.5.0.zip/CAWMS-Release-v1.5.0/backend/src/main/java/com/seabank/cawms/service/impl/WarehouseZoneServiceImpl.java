package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.WarehouseZoneEntity;
import com.seabank.cawms.mapper.WarehouseZoneMapper;
import com.seabank.cawms.service.WarehouseZoneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class WarehouseZoneServiceImpl implements WarehouseZoneService {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WarehouseZoneServiceImpl.class);

    private final WarehouseZoneMapper warehouseZoneMapper;

    @Autowired
    public WarehouseZoneServiceImpl(WarehouseZoneMapper warehouseZoneMapper) {
        this.warehouseZoneMapper = warehouseZoneMapper;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseZoneEntity create(WarehouseZoneEntity entity) {
        entity.setDeleted(0);
        entity.setStatus(StringUtils.hasText(entity.getStatus()) ? entity.getStatus() : "ACTIVE");
        if (entity.getCreatedAt() == null) {
            entity.setCreatedAt(LocalDateTime.now());
        }
        warehouseZoneMapper.insert(entity);
        return entity;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public WarehouseZoneEntity update(Long id, WarehouseZoneEntity entity) {
        WarehouseZoneEntity existing = warehouseZoneMapper.selectById(id);
        if (existing == null || existing.getDeleted() != null && existing.getDeleted() == 1) {
            throw new IllegalArgumentException("库区不存在: " + id);
        }
        entity.setId(id);
        warehouseZoneMapper.updateById(entity);
        return warehouseZoneMapper.selectById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(Long id) {
        WarehouseZoneEntity existing = warehouseZoneMapper.selectById(id);
        if (existing == null) {
            return false;
        }
        existing.setDeleted(1);
        existing.setUpdatedAt(LocalDateTime.now());
        warehouseZoneMapper.updateById(existing);
        return true;
    }

    @Override
    public WarehouseZoneEntity getById(Long id) {
        WarehouseZoneEntity entity = warehouseZoneMapper.selectById(id);
        if (entity == null || entity.getDeleted() != null && entity.getDeleted() == 1) {
            return null;
        }
        return entity;
    }

    @Override
    public Page<WarehouseZoneEntity> list(int page, int size, String keyword) {
        LambdaQueryWrapper<WarehouseZoneEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(WarehouseZoneEntity::getDeleted, 0);
        if (StringUtils.hasText(keyword)) {
            wrapper.and(w -> w.like(WarehouseZoneEntity::getZoneCode, keyword)
                    .or()
                    .like(WarehouseZoneEntity::getZoneName, keyword));
        }
        wrapper.orderByDesc(WarehouseZoneEntity::getCreatedAt);
        return warehouseZoneMapper.selectPage(new Page<>(page, size), wrapper);
    }

    @Override
    public List<WarehouseZoneEntity> listAllActive() {
        LambdaQueryWrapper<WarehouseZoneEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(WarehouseZoneEntity::getDeleted, 0)
               .eq(WarehouseZoneEntity::getStatus, "ACTIVE")
               .orderByDesc(WarehouseZoneEntity::getCreatedAt);
        return warehouseZoneMapper.selectList(wrapper);
    }
}
