package com.seabank.cawms.workflow;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 褰掕繕瀹℃壒宸ヤ綔娴佹帴鍙? * 璐熻矗绠＄悊褰掕繕瀹℃壒鐨勭姸鎬佹祦杞拰杩涘害璺熻釜
 * 4姝ラ褰掕繕娴佺▼锛? * 1. 申请归还 (APPLY_RETURN)
 * 2. 浠撳簱纭 (WAREHOUSE_CONFIRM)
 * 3. 璐㈠姟缁撶畻 (FINANCE_SETTLEMENT)
 * 4. 瀹屾垚褰掕繕 (COMPLETE_RETURN)
 */
public interface LoanReturnApprovalWorkflow {
    
    /**
     * 操作缁撴灉
     */
        class ReturnResult {
        private Boolean success;
        private String message;
        private String nextStep;
        private String nextApprover;
        private Long approvalRecordId;
        public Boolean isSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getNextStep() { return nextStep; }
        public void setNextStep(String nextStep) { this.nextStep = nextStep; }
        public String getNextApprover() { return nextApprover; }
        public void setNextApprover(String nextApprover) { this.nextApprover = nextApprover; }
        public Long getApprovalRecordId() { return approvalRecordId; }
        public void setApprovalRecordId(Long approvalRecordId) { this.approvalRecordId = approvalRecordId; }
    }
    
    /**
     * 褰掕繕瀹℃壒缁撴灉
     */
        class ReturnApprovalResult {
        private Boolean success;
        private String message;
        private String nextStep;
        private String nextApprover;
        private Long approvalRecordId;
        private Boolean isProcessCompleted;
        private String assetCondition;
        private BigDecimal settlementAmount;
        private String settlementMethod;
        private String settlementReference;
        private Integer stepNumber;
        public Boolean isSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getNextStep() { return nextStep; }
        public void setNextStep(String nextStep) { this.nextStep = nextStep; }
        public String getNextApprover() { return nextApprover; }
        public void setNextApprover(String nextApprover) { this.nextApprover = nextApprover; }
        public Long getApprovalRecordId() { return approvalRecordId; }
        public void setApprovalRecordId(Long approvalRecordId) { this.approvalRecordId = approvalRecordId; }
        public Boolean isIsProcessCompleted() { return isProcessCompleted; }
        public void setIsProcessCompleted(Boolean isProcessCompleted) { this.isProcessCompleted = isProcessCompleted; }
        public String getAssetCondition() { return assetCondition; }
        public void setAssetCondition(String assetCondition) { this.assetCondition = assetCondition; }
        public BigDecimal getSettlementAmount() { return settlementAmount; }
        public void setSettlementAmount(BigDecimal settlementAmount) { this.settlementAmount = settlementAmount; }
        public String getSettlementMethod() { return settlementMethod; }
        public void setSettlementMethod(String settlementMethod) { this.settlementMethod = settlementMethod; }
        public String getSettlementReference() { return settlementReference; }
        public void setSettlementReference(String settlementReference) { this.settlementReference = settlementReference; }
        public Integer getStepNumber() { return stepNumber; }
        public void setStepNumber(Integer stepNumber) { this.stepNumber = stepNumber; }
    }
    
    /**
     * 归还拒绝结果
     */
        class ReturnRejectionResult {
        private Boolean success;
        private String message;
        private String currentStep;
        private Long approvalRecordId;
        private String rejectionReason;
        private Integer stepNumber;
        public Boolean isSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getCurrentStep() { return currentStep; }
        public void setCurrentStep(String currentStep) { this.currentStep = currentStep; }
        public Long getApprovalRecordId() { return approvalRecordId; }
        public void setApprovalRecordId(Long approvalRecordId) { this.approvalRecordId = approvalRecordId; }
        public String getRejectionReason() { return rejectionReason; }
        public void setRejectionReason(String rejectionReason) { this.rejectionReason = rejectionReason; }
        public Integer getStepNumber() { return stepNumber; }
        public void setStepNumber(Integer stepNumber) { this.stepNumber = stepNumber; }
    }
    
    /**
     * 褰掕繕审批进度淇℃伅
     */
        class ReturnApprovalProgress {
        private Long loanOutId;
        private String currentStep;
        private Integer currentStepNumber;
        private Integer totalSteps;
        private Boolean isCompleted;
        private String status;
        private String approver;
        private String approvalTime;
        private String comments;
        private String assetCondition;
        private BigDecimal settlementAmount;
        private String settlementCurrency;
        
        // TODO: fix encoding comment
        // private List<ReturnStepDetail> stepDetails;
        public Long getLoanOutId() { return loanOutId; }
        public void setLoanOutId(Long loanOutId) { this.loanOutId = loanOutId; }
        public String getCurrentStep() { return currentStep; }
        public void setCurrentStep(String currentStep) { this.currentStep = currentStep; }
        public Integer getCurrentStepNumber() { return currentStepNumber; }
        public void setCurrentStepNumber(Integer currentStepNumber) { this.currentStepNumber = currentStepNumber; }
        public Integer getTotalSteps() { return totalSteps; }
        public void setTotalSteps(Integer totalSteps) { this.totalSteps = totalSteps; }
        public Boolean isIsCompleted() { return isCompleted; }
        public void setIsCompleted(Boolean isCompleted) { this.isCompleted = isCompleted; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getApprover() { return approver; }
        public void setApprover(String approver) { this.approver = approver; }
        public String getApprovalTime() { return approvalTime; }
        public void setApprovalTime(String approvalTime) { this.approvalTime = approvalTime; }
        public String getComments() { return comments; }
        public void setComments(String comments) { this.comments = comments; }
        public String getAssetCondition() { return assetCondition; }
        public void setAssetCondition(String assetCondition) { this.assetCondition = assetCondition; }
        public BigDecimal getSettlementAmount() { return settlementAmount; }
        public void setSettlementAmount(BigDecimal settlementAmount) { this.settlementAmount = settlementAmount; }
        public String getSettlementCurrency() { return settlementCurrency; }
        public void setSettlementCurrency(String settlementCurrency) { this.settlementCurrency = settlementCurrency; }
    }
    
    /**
     * 归还步骤详情
     */
        class ReturnStepDetail {
        private Integer stepNumber;
        private String stepName;
        private String stepDescription;
        private String approverRole;
        private String approver;
        private String status;
        private String approvalTime;
        private String comments;
        private String assetConditionNote;
        private BigDecimal settlementAmount;
        public Integer getStepNumber() { return stepNumber; }
        public void setStepNumber(Integer stepNumber) { this.stepNumber = stepNumber; }
        public String getStepName() { return stepName; }
        public void setStepName(String stepName) { this.stepName = stepName; }
        public String getStepDescription() { return stepDescription; }
        public void setStepDescription(String stepDescription) { this.stepDescription = stepDescription; }
        public String getApproverRole() { return approverRole; }
        public void setApproverRole(String approverRole) { this.approverRole = approverRole; }
        public String getApprover() { return approver; }
        public void setApprover(String approver) { this.approver = approver; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getApprovalTime() { return approvalTime; }
        public void setApprovalTime(String approvalTime) { this.approvalTime = approvalTime; }
        public String getComments() { return comments; }
        public void setComments(String comments) { this.comments = comments; }
        public String getAssetConditionNote() { return assetConditionNote; }
        public void setAssetConditionNote(String assetConditionNote) { this.assetConditionNote = assetConditionNote; }
        public BigDecimal getSettlementAmount() { return settlementAmount; }
        public void setSettlementAmount(BigDecimal settlementAmount) { this.settlementAmount = settlementAmount; }
    }
    
    /**
     * 鍒濆鍖栧綊杩樺鎵规祦绋?     * @param loanOutId 借出记录ID
     * @param returnReason 归还原因
     * @param returner 褰掕繕浜?     * @param returnDate 褰掕繕鏃ユ湡
     * @return 鍒濆鍖栫粨鏋?     */

    ReturnResult initReturnApprovalProcess(Long loanOutId, String returnReason, String returner, LocalDateTime returnDate);
    
    /**
     * 获取归还审批进度
     * @param loanOutId 借出记录ID
     * @return 褰掕繕审批进度
     */
    ReturnApprovalProgress getReturnApprovalProgress(Long loanOutId);
    
    /**
     * 获取当前待审批的归还步骤
     * @param loanOutId 借出记录ID
     * @return 当前待审批的归还步骤详情
     */
    ReturnStepDetail getCurrentPendingReturnStep(Long loanOutId);
    

    
    /**
     * 閫€鍥炲綊杩樻楠?     * @param loanOutId 借出记录ID
     * @param stepId 姝ラID
     * @param comments 閫€鍥炴剰瑙?     * @param returner 閫€鍥炰汉
     * @param returnToStep 閫€鍥炲埌鐨勬楠?     * @return 閫€鍥炵粨鏋?     */

    ReturnResult returnReturnStep(Long loanOutId, Long stepId, String comments, String returner, Integer returnToStep);
    
    /**
     * 瀹℃壒褰掕繕姝ラ锛堣缁嗗弬鏁扮増鏈級
     * @param loanOutId 借出记录ID
     * @param approvalId 审批记录ID
     * @param comments 瀹℃壒鎰忚
     * @param approver 瀹℃壒浜?     * @param approverName 瀹℃壒浜哄鍚?     * @param assetCondition 璧勪骇鐘跺喌
     * @param conditionDescription 鐘跺喌鎻忚堪
     * @param settlementAmount 缁撶畻閲戦
     * @param settlementMethod 缁撶畻鏂瑰紡
     * @param settlementReference 缁撶畻鍙傝€?     * @return 褰掕繕瀹℃壒缁撴灉
     */
    ReturnApprovalResult approveReturnStep(Long loanOutId, Long approvalId, String comments, String approver, 
                                         String approverName, String assetCondition, String conditionDescription,
                                         Double settlementAmount, String settlementMethod, String settlementReference);
    
    /**
     * 拒绝归还步骤
     * @param loanOutId 借出记录ID
     * @param approvalId 审批记录ID
     * @param comments 拒绝意见
     * @param rejector 鎷掔粷浜?     * @param rejectorName 鎷掔粷浜哄鍚?     * @return 归还拒绝结果
     */
    ReturnRejectionResult rejectReturnStep(Long loanOutId, Long approvalId, String comments, 
                                          String rejector, String rejectorName);
    
    /**
     * 褰掕繕姝ラ操作缁撴灉
     */
        class ReturnStepResult {
        private Boolean success;
        private String message;
        private String nextStep;
        private String nextApprover;
        private Long approvalRecordId;
        private Integer stepNumber;
        private String currentStep;
        public Boolean isSuccess() { return success; }
        public void setSuccess(Boolean success) { this.success = success; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getNextStep() { return nextStep; }
        public void setNextStep(String nextStep) { this.nextStep = nextStep; }
        public String getNextApprover() { return nextApprover; }
        public void setNextApprover(String nextApprover) { this.nextApprover = nextApprover; }
        public Long getApprovalRecordId() { return approvalRecordId; }
        public void setApprovalRecordId(Long approvalRecordId) { this.approvalRecordId = approvalRecordId; }
        public Integer getStepNumber() { return stepNumber; }
        public void setStepNumber(Integer stepNumber) { this.stepNumber = stepNumber; }
        public String getCurrentStep() { return currentStep; }
        public void setCurrentStep(String currentStep) { this.currentStep = currentStep; }
    }
    
    /**
     * 閫€鍥炲綊杩樻楠わ紙6鍙傛暟鐗堟湰锛?     * @param loanOutId 借出记录ID
     * @param approvalId 审批记录ID
     * @param comments 閫€鍥炴剰瑙?     * @param returner 閫€鍥炰汉
     * @param returnerName 閫€鍥炰汉濮撳悕
     * @param returnToStep 閫€鍥炲埌鐨勬楠?     * @return 閫€鍥炵粨鏋?     */

    ReturnStepResult returnReturnStep(Long loanOutId, Long approvalId, String comments, 
                                     String returner, String returnerName, Integer returnToStep);
    
    /**
     * 妫€鏌ュ綊杩樻祦绋嬫槸鍚﹀凡瀹屾垚
     * @param loanOutId 借出记录ID
     * @return 鏄惁宸插畬鎴?     */

    Boolean isReturnProcessCompleted(Long loanOutId);
}