package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public interface TransferService {

    TransferDetail create(TransferCreateRequest request, String creator);

    TransferDetail update(Long id, TransferUpdateRequest request, String updater);

    boolean delete(Long id, String deleter);

    TransferDetail getById(Long id);

    Page<TransferDetail> query(TransferQuery query);

    TransferDetail submit(Long id, String submitter);

    TransferDetail approve(Long id, String approverId, String approverName, String comments);

    TransferDetail reject(Long id, String rejectorId, String rejectorName, String comments);

    TransferDetail complete(Long id, String operator);

    TransferDetail cancel(Long id, String operator);

    List<TransferApproval> getApprovalProgress(Long transferId);

    TransferApproval getCurrentPendingStep(Long transferId);

    TransferStatistics getStatistics();

    Page<TransferDetail> getPendingApprovals(String approverRole, String approverUser, Integer pageNum, Integer pageSize);

    Page<TransferDetail> getMyApplications(String userId, String status, Integer pageNum, Integer pageSize);

    Page<TransferDetail> getMyApprovals(String approverUser, String approverRole, String type, Integer pageNum, Integer pageSize);

    List<TransferHistory> getHistory(Long transferId);

    class TransferDetail {
        private Long id;
        private String transferNo;
        private Long warehouseInId;
        private String warehouseInNo;
        private String collateralName;
        private String collateralType;
        private BigDecimal collateralValue;
        private Long sourceWarehouseId;
        private String sourceWarehouseName;
        private String sourceWarehouseLocation;
        private Long targetWarehouseId;
        private String targetWarehouseName;
        private String targetWarehouseLocation;
        private String transferType;
        private String transferReason;
        private String status;
        private Long applicantId;
        private String applicantName;
        private LocalDateTime applyTime;
        private LocalDateTime actualTransferTime;
        private String remarks;
        private LocalDateTime createTime;
        private LocalDateTime updateTime;
        private List<TransferApproval> approvals;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getTransferNo() { return transferNo; }
        public void setTransferNo(String transferNo) { this.transferNo = transferNo; }
        public Long getWarehouseInId() { return warehouseInId; }
        public void setWarehouseInId(Long warehouseInId) { this.warehouseInId = warehouseInId; }
        public String getWarehouseInNo() { return warehouseInNo; }
        public void setWarehouseInNo(String warehouseInNo) { this.warehouseInNo = warehouseInNo; }
        public String getCollateralName() { return collateralName; }
        public void setCollateralName(String collateralName) { this.collateralName = collateralName; }
        public String getCollateralType() { return collateralType; }
        public void setCollateralType(String collateralType) { this.collateralType = collateralType; }
        public BigDecimal getCollateralValue() { return collateralValue; }
        public void setCollateralValue(BigDecimal collateralValue) { this.collateralValue = collateralValue; }
        public Long getSourceWarehouseId() { return sourceWarehouseId; }
        public void setSourceWarehouseId(Long sourceWarehouseId) { this.sourceWarehouseId = sourceWarehouseId; }
        public String getSourceWarehouseName() { return sourceWarehouseName; }
        public void setSourceWarehouseName(String sourceWarehouseName) { this.sourceWarehouseName = sourceWarehouseName; }
        public String getSourceWarehouseLocation() { return sourceWarehouseLocation; }
        public void setSourceWarehouseLocation(String sourceWarehouseLocation) { this.sourceWarehouseLocation = sourceWarehouseLocation; }
        public Long getTargetWarehouseId() { return targetWarehouseId; }
        public void setTargetWarehouseId(Long targetWarehouseId) { this.targetWarehouseId = targetWarehouseId; }
        public String getTargetWarehouseName() { return targetWarehouseName; }
        public void setTargetWarehouseName(String targetWarehouseName) { this.targetWarehouseName = targetWarehouseName; }
        public String getTargetWarehouseLocation() { return targetWarehouseLocation; }
        public void setTargetWarehouseLocation(String targetWarehouseLocation) { this.targetWarehouseLocation = targetWarehouseLocation; }
        public String getTransferType() { return transferType; }
        public void setTransferType(String transferType) { this.transferType = transferType; }
        public String getTransferReason() { return transferReason; }
        public void setTransferReason(String transferReason) { this.transferReason = transferReason; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public Long getApplicantId() { return applicantId; }
        public void setApplicantId(Long applicantId) { this.applicantId = applicantId; }
        public String getApplicantName() { return applicantName; }
        public void setApplicantName(String applicantName) { this.applicantName = applicantName; }
        public LocalDateTime getApplyTime() { return applyTime; }
        public void setApplyTime(LocalDateTime applyTime) { this.applyTime = applyTime; }
        public LocalDateTime getActualTransferTime() { return actualTransferTime; }
        public void setActualTransferTime(LocalDateTime actualTransferTime) { this.actualTransferTime = actualTransferTime; }
        public String getRemarks() { return remarks; }
        public void setRemarks(String remarks) { this.remarks = remarks; }
        public LocalDateTime getCreateTime() { return createTime; }
        public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }
        public LocalDateTime getUpdateTime() { return updateTime; }
        public void setUpdateTime(LocalDateTime updateTime) { this.updateTime = updateTime; }
        public List<TransferApproval> getApprovals() { return approvals; }
        public void setApprovals(List<TransferApproval> approvals) { this.approvals = approvals; }
    }

    class TransferCreateRequest {
        private Long warehouseInId;
        private Long targetWarehouseId;
        private String transferType;
        private String transferReason;
        private String remarks;

        public Long getWarehouseInId() { return warehouseInId; }
        public void setWarehouseInId(Long warehouseInId) { this.warehouseInId = warehouseInId; }
        public Long getTargetWarehouseId() { return targetWarehouseId; }
        public void setTargetWarehouseId(Long targetWarehouseId) { this.targetWarehouseId = targetWarehouseId; }
        public String getTransferType() { return transferType; }
        public void setTransferType(String transferType) { this.transferType = transferType; }
        public String getTransferReason() { return transferReason; }
        public void setTransferReason(String transferReason) { this.transferReason = transferReason; }
        public String getRemarks() { return remarks; }
        public void setRemarks(String remarks) { this.remarks = remarks; }
    }

    class TransferUpdateRequest {
        private Long targetWarehouseId;
        private String transferType;
        private String transferReason;
        private String remarks;

        public Long getTargetWarehouseId() { return targetWarehouseId; }
        public void setTargetWarehouseId(Long targetWarehouseId) { this.targetWarehouseId = targetWarehouseId; }
        public String getTransferType() { return transferType; }
        public void setTransferType(String transferType) { this.transferType = transferType; }
        public String getTransferReason() { return transferReason; }
        public void setTransferReason(String transferReason) { this.transferReason = transferReason; }
        public String getRemarks() { return remarks; }
        public void setRemarks(String remarks) { this.remarks = remarks; }
    }

    class TransferQuery {
        private Integer page;
        private Integer size;
        private String status;
        private String transferType;
        private String warehouseInNo;
        private String collateralName;
        private String startDate;
        private String endDate;

        public Integer getPage() { return page; }
        public void setPage(Integer page) { this.page = page; }
        public Integer getSize() { return size; }
        public void setSize(Integer size) { this.size = size; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getTransferType() { return transferType; }
        public void setTransferType(String transferType) { this.transferType = transferType; }
        public String getWarehouseInNo() { return warehouseInNo; }
        public void setWarehouseInNo(String warehouseInNo) { this.warehouseInNo = warehouseInNo; }
        public String getCollateralName() { return collateralName; }
        public void setCollateralName(String collateralName) { this.collateralName = collateralName; }
        public String getStartDate() { return startDate; }
        public void setStartDate(String startDate) { this.startDate = startDate; }
        public String getEndDate() { return endDate; }
        public void setEndDate(String endDate) { this.endDate = endDate; }
    }

    class TransferApproval {
        private Long id;
        private Long transferId;
        private Integer step;
        private String stepName;
        private String approverRole;
        private Long approverId;
        private String approverName;
        private String approvalStatus;
        private String approvalOpinion;
        private LocalDateTime approvalTime;
        private LocalDateTime createTime;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getTransferId() { return transferId; }
        public void setTransferId(Long transferId) { this.transferId = transferId; }
        public Integer getStep() { return step; }
        public void setStep(Integer step) { this.step = step; }
        public String getStepName() { return stepName; }
        public void setStepName(String stepName) { this.stepName = stepName; }
        public String getApproverRole() { return approverRole; }
        public void setApproverRole(String approverRole) { this.approverRole = approverRole; }
        public Long getApproverId() { return approverId; }
        public void setApproverId(Long approverId) { this.approverId = approverId; }
        public String getApproverName() { return approverName; }
        public void setApproverName(String approverName) { this.approverName = approverName; }
        public String getApprovalStatus() { return approvalStatus; }
        public void setApprovalStatus(String approvalStatus) { this.approvalStatus = approvalStatus; }
        public String getApprovalOpinion() { return approvalOpinion; }
        public void setApprovalOpinion(String approvalOpinion) { this.approvalOpinion = approvalOpinion; }
        public LocalDateTime getApprovalTime() { return approvalTime; }
        public void setApprovalTime(LocalDateTime approvalTime) { this.approvalTime = approvalTime; }
        public LocalDateTime getCreateTime() { return createTime; }
        public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }
    }

    class TransferStatistics {
        private Integer total;
        private Map<String, Integer> byStatus;
        private Map<String, Integer> byType;
        private Integer pendingApprovals;
        private Integer completedToday;

        public Integer getTotal() { return total; }
        public void setTotal(Integer total) { this.total = total; }
        public Map<String, Integer> getByStatus() { return byStatus; }
        public void setByStatus(Map<String, Integer> byStatus) { this.byStatus = byStatus; }
        public Map<String, Integer> getByType() { return byType; }
        public void setByType(Map<String, Integer> byType) { this.byType = byType; }
        public Integer getPendingApprovals() { return pendingApprovals; }
        public void setPendingApprovals(Integer pendingApprovals) { this.pendingApprovals = pendingApprovals; }
        public Integer getCompletedToday() { return completedToday; }
        public void setCompletedToday(Integer completedToday) { this.completedToday = completedToday; }
    }

    class TransferHistory {
        private Long id;
        private Long transferId;
        private String operationType;
        private String operationDesc;
        private Long operatorId;
        private String operatorName;
        private LocalDateTime operationTime;
        private String beforeValue;
        private String afterValue;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getTransferId() { return transferId; }
        public void setTransferId(Long transferId) { this.transferId = transferId; }
        public String getOperationType() { return operationType; }
        public void setOperationType(String operationType) { this.operationType = operationType; }
        public String getOperationDesc() { return operationDesc; }
        public void setOperationDesc(String operationDesc) { this.operationDesc = operationDesc; }
        public Long getOperatorId() { return operatorId; }
        public void setOperatorId(Long operatorId) { this.operatorId = operatorId; }
        public String getOperatorName() { return operatorName; }
        public void setOperatorName(String operatorName) { this.operatorName = operatorName; }
        public LocalDateTime getOperationTime() { return operationTime; }
        public void setOperationTime(LocalDateTime operationTime) { this.operationTime = operationTime; }
        public String getBeforeValue() { return beforeValue; }
        public void setBeforeValue(String beforeValue) { this.beforeValue = beforeValue; }
        public String getAfterValue() { return afterValue; }
        public void setAfterValue(String afterValue) { this.afterValue = afterValue; }
    }
}
