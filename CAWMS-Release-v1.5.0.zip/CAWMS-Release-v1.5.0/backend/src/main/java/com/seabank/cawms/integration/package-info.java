/**
 * Integration package for CAWMS application
 * Contains integration services for external systems (T24, SeaOps, LOS, etc.)
 * Supports both Mock and Real implementations
 */
package com.seabank.cawms.integration;
