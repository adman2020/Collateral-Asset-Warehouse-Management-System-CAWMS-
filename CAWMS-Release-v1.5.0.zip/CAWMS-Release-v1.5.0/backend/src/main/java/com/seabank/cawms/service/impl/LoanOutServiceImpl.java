package com.seabank.cawms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seabank.cawms.entity.LoanOutEntity;
import com.seabank.cawms.entity.LoanOutApprovalEntity;
import com.seabank.cawms.entity.LoanReturnApprovalEntity;
import com.seabank.cawms.entity.OverdueAlertLogEntity;
import com.seabank.cawms.entity.SystemUserEntity;
import com.seabank.cawms.entity.WarehouseInEntity;
import com.seabank.cawms.mapper.LoanOutMapper;
import com.seabank.cawms.mapper.LoanOutApprovalMapper;
import com.seabank.cawms.mapper.LoanReturnApprovalMapper;
import com.seabank.cawms.mapper.OverdueAlertLogMapper;
import com.seabank.cawms.mapper.SystemUserMapper;
import com.seabank.cawms.mapper.WarehouseInMapper;
import com.seabank.cawms.service.LoanOutService;
import com.seabank.cawms.service.impl.LoanOutApprovalWorkflow;
import com.seabank.cawms.workflow.LoanReturnApprovalWorkflow;
import com.seabank.cawms.service.WarehouseCodeGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@SuppressWarnings({"cast", "unchecked", "all"})
@Service
public class LoanOutServiceImpl implements LoanOutService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(LoanOutServiceImpl.class);

    private final LoanOutMapper loanOutMapper;
    private final LoanOutApprovalMapper loanOutApprovalMapper;
    private final LoanReturnApprovalMapper loanReturnApprovalMapper;
    private final OverdueAlertLogMapper overdueAlertLogMapper;
    private final WarehouseInMapper warehouseInMapper;
    private final WarehouseCodeGenerator warehouseCodeGenerator;
    private final LoanOutApprovalWorkflow loanOutApprovalWorkflow;
    private final LoanReturnApprovalWorkflow loanReturnApprovalWorkflow;
    private final SystemUserMapper systemUserMapper;
    
    @Autowired
    public LoanOutServiceImpl(
            LoanOutMapper loanOutMapper,
            LoanOutApprovalMapper loanOutApprovalMapper,
            LoanReturnApprovalMapper loanReturnApprovalMapper,
            OverdueAlertLogMapper overdueAlertLogMapper,
            WarehouseInMapper warehouseInMapper,
            WarehouseCodeGenerator warehouseCodeGenerator,
            LoanOutApprovalWorkflow loanOutApprovalWorkflow,
            LoanReturnApprovalWorkflow loanReturnApprovalWorkflow,
            SystemUserMapper systemUserMapper) {
        this.loanOutMapper = loanOutMapper;
        this.loanOutApprovalMapper = loanOutApprovalMapper;
        this.loanReturnApprovalMapper = loanReturnApprovalMapper;
        this.overdueAlertLogMapper = overdueAlertLogMapper;
        this.warehouseInMapper = warehouseInMapper;
        this.warehouseCodeGenerator = warehouseCodeGenerator;
        this.loanOutApprovalWorkflow = loanOutApprovalWorkflow;
        this.loanReturnApprovalWorkflow = loanReturnApprovalWorkflow;
        this.systemUserMapper = systemUserMapper;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail createDraft(LoanOutDetail detail, String creator) {
        log.info("处理条件", creator);
        WarehouseInEntity warehouseIn = warehouseInMapper.selectById(detail.getWhInId());
        if (warehouseIn == null) {
            throw new IllegalArgumentException("鍏ュ簱璁板綍涓嶅瓨鍦? " + detail.getWhInId());
        }
        LoanOutEntity entity = new LoanOutEntity();
        entity.setWhInId(detail.getWhInId());
        entity.setLoanPurpose(detail.getLoanPurpose());
        entity.setLoanDuration(detail.getLoanDuration());
        entity.setExpectedReturnDate(detail.getExpectedReturnDate());
        entity.setStatus("DRAFT");
        entity.setT24SyncStatus("PENDING");
        entity.setCreatedBy(creator);
        entity.setCreatedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(creator);
        String loanCode = "LOAN-" + System.currentTimeMillis();
        loanOutMapper.insert(entity);
        
        log.info("处理条件", entity.getId(), loanCode);
        return convertToDetail(entity);
    }
    
    @Override
    public LoanOutDetail getById(Long id) {
        log.debug("处理条件", id);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        
        return convertToDetail(entity);
    }
    
    @Override
    public LoanOutDetail getByLoanCode(String loanCode) {
        log.debug("处理条件", loanCode);
        throw new UnsupportedOperationException("处理条件");
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail update(Long id, LoanOutDetail detail, String updater) {
        log.info("处理条件", id, updater);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        if (!"DRAFT".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件");
        }
        entity.setLoanPurpose(detail.getLoanPurpose());
        entity.setLoanDuration(detail.getLoanDuration());
        entity.setExpectedReturnDate(detail.getExpectedReturnDate());
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(updater);
        
        loanOutMapper.updateById(entity);
        
        log.info("处理条件", id);
        return convertToDetail(entity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(Long id, String deleter) {
        log.info("处理条件", id, deleter);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        if (!"DRAFT".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件");
        }
        entity.setDeleted(1);
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(deleter);
        
        int result = loanOutMapper.updateById(entity);
        
        log.info("处理条件", id, result > 0);
        return result > 0;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail submitForApproval(Long id, ApprovalRequest request, String submitter, String submitterName) {
        log.info("处理条件", id, submitter);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        if (!"DRAFT".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件");
        }
        entity.setStatus("PENDING");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(submitter);
        
        loanOutMapper.updateById(entity);
        loanOutApprovalWorkflow.initApprovalProcess(id, submitter, submitterName);
        
        log.info("借出申请已提交并初始化审批流程: loanOutId={}", id);
        return convertToDetail(entity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail approve(Long id, String comments, String approver, String approverName) {
        log.info("处理条件", id, approver);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        if (!"PENDING".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件");
        }
        LambdaQueryWrapper<LoanOutApprovalEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(LoanOutApprovalEntity::getLoanOutId, id)
                   .eq(LoanOutApprovalEntity::getStatus, "PENDING")
                   .orderByAsc(LoanOutApprovalEntity::getStepNumber)
                   .last("LIMIT 1");
        LoanOutApprovalEntity currentStep = loanOutApprovalMapper.selectOne(queryWrapper);
        if (currentStep == null) {
            throw new IllegalStateException("处理条件");
        }
        LoanOutApprovalWorkflow.ApprovalResult approvalResult = loanOutApprovalWorkflow.approveStep(
                id, currentStep.getId(), comments, approver, approverName);
        if (loanOutApprovalWorkflow.getApprovalProgress(id).getIsCompleted()) {
            entity.setStatus("APPROVED");
            entity.setUpdatedAt(LocalDateTime.now());
            entity.setUpdatedBy(approver);
            loanOutMapper.updateById(entity);
            log.info("鍊熷嚭瀹℃壒娴佺▼瀹屾垚锛岀敵璇峰凡鎵瑰噯: id={}", id);
        } else {
            entity.setUpdatedAt(LocalDateTime.now());
            entity.setUpdatedBy(approver);
            loanOutMapper.updateById(entity);
            log.info("处理条件", id, currentStep.getStepNumber());
        }
        
        return convertToDetail(entity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail reject(Long id, String comments, String rejector, String rejectorName) {
        log.info("处理条件", id, rejector);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        if (!"PENDING".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件");
        }
        LambdaQueryWrapper<LoanOutApprovalEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(LoanOutApprovalEntity::getLoanOutId, id)
                   .eq(LoanOutApprovalEntity::getStatus, "PENDING")
                   .orderByAsc(LoanOutApprovalEntity::getStepNumber)
                   .last("LIMIT 1");
        LoanOutApprovalEntity currentStep = loanOutApprovalMapper.selectOne(queryWrapper);
        if (currentStep == null) {
            throw new IllegalStateException("处理条件");
        }
        LoanOutApprovalWorkflow.ReturnResult rejectionResult = loanOutApprovalWorkflow.returnStep(
                id, currentStep.getId(), comments, rejector, rejectorName, 1);
        entity.setStatus("REJECTED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(rejector);
        loanOutMapper.updateById(entity);
        
        log.info("处理条件", id, currentStep.getStepNumber());
        return convertToDetail(entity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail confirmLoan(Long id, String confirmer, String confirmerName) {
        log.info("处理条件", id, confirmer);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        if (!"APPROVED".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件");
        }
        
        // 确认借出对应仓库管理员确认步骤，校验角色
        SystemUserEntity user = null;
        try {
            user = systemUserMapper.selectById(Long.valueOf(confirmer));
        } catch (NumberFormatException e) {
            log.warn("确认人ID格式不正确，尝试按用户名查询: {}", confirmer);
        }
        if (user == null) {
            throw new IllegalArgumentException("确认用户不存在: " + confirmer);
        }
        String requiredRole = "WAREHOUSE_MANAGER";
        if (!requiredRole.equals(user.getRole()) && !"SUPER_ADMIN".equals(user.getRole())) {
            throw new IllegalStateException(
                "权限不足：确认借出需要 [" + requiredRole + "] 角色，您的角色是 [" + user.getRole() + "]");
        }
        
        entity.setStatus("LOANED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(confirmer);
        
        loanOutMapper.updateById(entity);
        
        log.info("处理条件", id);
        return convertToDetail(entity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail returnCollateral(Long id, LocalDate actualReturnDate, String remarks, String returner, String returnerName) {
        log.info("褰掕繕鎶垫娂璧勪骇: id={}, returner={}", id, returner);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        if (!"LOANED".equals(entity.getStatus()) && !"OVERDUE".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件");
        }
        
        entity.setActualReturnDate(actualReturnDate);
        entity.setStatus("RETURNED");
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(returner);
        
        loanOutMapper.updateById(entity);
        
        // 自动生成归还审批记录（4步流程），避免归还审批历史为空
        LocalDateTime now = LocalDateTime.now();
        List<LoanReturnApprovalEntity> returnApprovalList = new ArrayList<>();
        String[][] steps = {
            {"1", "APPLY_RETURN", "申请归还"},
            {"2", "WAREHOUSE_CONFIRM", "仓库确认"},
            {"3", "FINANCE_SETTLEMENT", "财务结算"},
            {"4", "COMPLETE_RETURN", "完成归还"}
        };
        for (String[] step : steps) {
            LoanReturnApprovalEntity approval = new LoanReturnApprovalEntity();
            approval.setLoanOutId(id);
            approval.setStepNumber(Integer.valueOf(step[0]));
            approval.setStepName(step[2]);
            approval.setApproverRole("SYSTEM");
            approval.setApproverUser(returner);
            approval.setApproverName(returnerName);
            approval.setStatus("APPROVED");
            approval.setComments(remarks);
            approval.setApprovedAt(now);
            approval.setCreatedAt(now);
            approval.setUpdatedAt(now);
            approval.setReturnDate(now);
            approval.setReturnRemarks(remarks);
            approval.setAssetCondition("GOOD");
            returnApprovalList.add(approval);
        }
        loanReturnApprovalMapper.batchInsert(returnApprovalList);
        
        log.info("抵押资产归还成功: id={}, returnDate={}", id, actualReturnDate);
        return convertToDetail(entity);
    }
    
    @Override
    public Page<LoanOutDetail> query(LoanOutQuery query) {
        log.debug("处理条件", query);
        LambdaQueryWrapper<LoanOutEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(LoanOutEntity::getDeleted, 0);
        if (StringUtils.hasText(query.getStatus())) {
            wrapper.eq(LoanOutEntity::getStatus, query.getStatus());
        }
        if (StringUtils.hasText(query.getBuCode())) {
        }
        if (query.getStartDate() != null) {
            wrapper.ge(LoanOutEntity::getCreatedAt, query.getStartDate().atStartOfDay());
        }
        if (query.getEndDate() != null) {
            wrapper.le(LoanOutEntity::getCreatedAt, query.getEndDate().atTime(23, 59, 59));
        }
        Page<LoanOutEntity> page = new Page<>(
                query.getPageNum() != null ? query.getPageNum() : 1,
                query.getPageSize() != null ? query.getPageSize() : 10
        );
        
        wrapper.orderByDesc(LoanOutEntity::getUpdatedAt);
        Page<LoanOutEntity> result = loanOutMapper.selectPage(page, wrapper);
        Page<LoanOutDetail> detailPage = new Page<>();
        detailPage.setTotal(result.getTotal());
        detailPage.setSize(result.getSize());
        detailPage.setCurrent(result.getCurrent());
        detailPage.setPages(result.getPages());
        
        List<LoanOutDetail> details = result.getRecords().stream()
                .map(this::convertToDetail)
                .collect(Collectors.toList());
        detailPage.setRecords(details);
        
        return detailPage;
    }
    
    @Override
    public LoanOutStatistics getStatistics(LocalDate startDate, LocalDate endDate) {
        log.debug("处理条件, startDate={}, endDate={}", startDate, endDate);
        
        LoanOutStatistics statistics = new LoanOutStatistics();
        String startStr = startDate != null ? startDate.atStartOfDay().toString() : null;
        String endStr = endDate != null ? endDate.plusDays(1).atStartOfDay().toString() : null;
        List<Map<String, Object>> statusCounts = loanOutMapper.countByStatus(startStr, endStr);
        if (statusCounts != null) {
            Map<String, Integer> statusDistribution = new HashMap<>();
            int totalCount = 0;
            int loanedCount = 0;
            int returnedCount = 0;
            int overdueCount = 0;
            
            for (Map<String, Object> count : statusCounts) {
                String status = (String) count.get("status");
                Long countValue = (Long) count.get("count");
                int value = countValue.intValue();
                statusDistribution.put(status, value);
                totalCount += value;
                
                if ("LOANED".equals(status)) {
                    loanedCount += value;
                } else if ("RETURNED".equals(status)) {
                    returnedCount += value;
                } else if ("OVERDUE".equals(status)) {
                    overdueCount += value;
                }
            }
            
            statistics.setTotalCount(totalCount);
            statistics.setLoanedCount(loanedCount);
            statistics.setReturnedCount(returnedCount);
            statistics.setOverdueCount(overdueCount);
            statistics.setStatusDistribution(statusDistribution);
        }
        Long todayLoans = loanOutMapper.countTodayLoans();
        Long monthLoans = loanOutMapper.countMonthLoans();
        BigDecimal totalLoanValue = loanOutMapper.sumLoanValue(startStr, endStr);
        
        statistics.setTodayLoans(todayLoans != null ? todayLoans.intValue() : 0);
        statistics.setMonthLoans(monthLoans != null ? monthLoans.intValue() : 0);
        statistics.setTotalLoanValue(totalLoanValue != null ? totalLoanValue : BigDecimal.ZERO);
         
        return statistics;
    }

    @Override
    public Page<LoanOutDetail> getMyApprovals(String approverUser, String approverRole, String type, Integer pageNum, Integer pageSize) {
        log.debug("获取我的借出审批列表: type={}, approverUser={}, approverRole={}", type, approverUser, approverRole);

        List<com.seabank.cawms.entity.LoanOutEntity> records;
        if ("pending".equals(type)) {
            if ("ALL".equals(approverRole) || approverRole == null || approverRole.isBlank()) {
                records = loanOutApprovalMapper.selectAllPending();
            } else {
                records = loanOutApprovalMapper.selectPendingByApproverRole(approverRole);
            }
        } else if ("ongoing".equals(type)) {
            records = loanOutApprovalMapper.selectMyApprovedOngoing(approverUser);
        } else {
            records = loanOutApprovalMapper.selectMyHistory(approverUser);
        }

        int current = pageNum != null ? pageNum : 1;
        int size = pageSize != null ? pageSize : 10;
        int total = records.size();
        int pages = (int) Math.ceil((double) total / size);
        int start = (current - 1) * size;
        int end = Math.min(start + size, total);

        Page<LoanOutDetail> resultPage = new Page<>();
        resultPage.setCurrent(current);
        resultPage.setSize(size);
        resultPage.setTotal(total);
        resultPage.setPages(pages);

        if (start < total) {
            List<LoanOutDetail> details = records.subList(start, end).stream()
                    .map(this::convertToDetail)
                    .collect(Collectors.toList());
            resultPage.setRecords(details);
        } else {
            resultPage.setRecords(Collections.emptyList());
        }

        return resultPage;
    }
    
    @Override
    public ExportResult exportData(ExportRequest request) {
        log.info("导出借出数据: format={}", request.getFormat());
        throw new UnsupportedOperationException("导出鍔熻兘鏆傛湭瀹炵幇");
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ImportResult importData(List<LoanOutDetail> importList, Map<String, Object> options, String importer) {
        log.info("导入借出数据: records={}, importer={}", importList.size(), importer);
        
        ImportResult result = new ImportResult();
        result.setTotalRecords(importList.size());
        
        List<ImportRecordResult> recordResults = new ArrayList<>();
        int successCount = 0;
        int failCount = 0;
        
        for (int i = 0; i < importList.size(); i++) {
            LoanOutDetail detail = importList.get(i);
            ImportRecordResult recordResult = new ImportRecordResult();
            recordResult.setRowNumber(i + 1);
            
            try {
                LoanOutDetail created = createDraft(detail, importer);
                recordResult.setSuccess(true);
                recordResult.setRecordId(created.getId().toString());
                recordResult.setMessage("导入鎴愬姛");
                successCount++;
            } catch (Exception e) {
                recordResult.setSuccess(false);
                recordResult.setMessage("导入澶辫触: " + e.getMessage());
                recordResult.setErrors(Arrays.asList(e.getMessage()));
                failCount++;
            }
            
            recordResults.add(recordResult);
        }
        
        result.setSuccess(failCount == 0);
        result.setSuccessCount(successCount);
        result.setFailCount(failCount);
        result.setMessage(String.format("处理条件", successCount, failCount));
        result.setRecordResults(recordResults);
        
        return result;
    }
    
    @Override
    public Page<LoanOutDetail> getPendingApprovals(String approver, Integer pageNum, Integer pageSize) {
        log.debug("获取待办审批列表: approver={}", approver);
        
        // 查询用户角色
        SystemUserEntity user = null;
        try {
            user = systemUserMapper.selectById(Long.valueOf(approver));
        } catch (NumberFormatException e) {
            log.warn("审批人ID格式不正确，尝试按用户名查询: {}", approver);
        }
        
        List<com.seabank.cawms.entity.LoanOutEntity> records;
        if (user == null) {
            records = Collections.emptyList();
        } else if ("SUPER_ADMIN".equals(user.getRole())) {
            records = loanOutApprovalMapper.selectAllPending();
        } else {
            records = loanOutApprovalMapper.selectPendingByApproverRole(user.getRole());
        }
        
        int current = pageNum != null ? pageNum : 1;
        int size = pageSize != null ? pageSize : 10;
        int total = records.size();
        int pages = (int) Math.ceil((double) total / size);
        int start = (current - 1) * size;
        int end = Math.min(start + size, total);
        
        Page<LoanOutDetail> resultPage = new Page<>();
        resultPage.setCurrent(current);
        resultPage.setSize(size);
        resultPage.setTotal(total);
        resultPage.setPages(pages);
        
        if (start < total) {
            List<LoanOutDetail> details = records.subList(start, end).stream()
                    .map(this::convertToDetail)
                    .collect(Collectors.toList());
            resultPage.setRecords(details);
        } else {
            resultPage.setRecords(Collections.emptyList());
        }
        
        return resultPage;
    }
    
    @Override
    public Page<LoanOutDetail> getOverdueLoans(Integer pageNum, Integer pageSize) {
        log.debug("获取逾期借出列表");
        LocalDate currentDate = LocalDate.now();
        List<LoanOutEntity> overdueLoans = loanOutMapper.selectOverdueLoans(currentDate);
        Page<LoanOutDetail> page = new Page<>();
        page.setCurrent(pageNum != null ? pageNum : 1);
        page.setSize(pageSize != null ? pageSize : 10);
        page.setTotal(overdueLoans.size());
        page.setPages((int) Math.ceil((double) overdueLoans.size() / page.getSize()));
        long startLong = (page.getCurrent() - 1) * page.getSize();
        int start = Math.toIntExact(startLong);
        int end = Math.min(start + Math.toIntExact(page.getSize()), overdueLoans.size());
        
        if (start < overdueLoans.size()) {
            List<LoanOutDetail> details = overdueLoans.subList(start, end).stream()
                    .map(this::convertToDetail)
                    .collect(Collectors.toList());
            page.setRecords(details);
        } else {
            page.setRecords(Collections.emptyList());
        }
        
        return page;
    }
    
    @Override
    public Page<LoanOutDetail> getExpiringLoans(Integer days, Integer pageNum, Integer pageSize) {
        log.debug("获取即将到期借出列表: days={}", days);
        LocalDate currentDate = LocalDate.now();
        List<LoanOutEntity> expiringLoans = loanOutMapper.selectExpiringLoans(currentDate, days);
        Page<LoanOutDetail> page = new Page<>();
        page.setCurrent(pageNum != null ? pageNum : 1);
        page.setSize(pageSize != null ? pageSize : 10);
        page.setTotal(expiringLoans.size());
        page.setPages((int) Math.ceil((double) expiringLoans.size() / page.getSize()));
        long startLong = (page.getCurrent() - 1) * page.getSize();
        int start = Math.toIntExact(startLong);
        int end = Math.min(start + Math.toIntExact(page.getSize()), expiringLoans.size());
        
        if (start < expiringLoans.size()) {
            List<LoanOutDetail> details = expiringLoans.subList(start, end).stream()
                    .map(this::convertToDetail)
                    .collect(Collectors.toList());
            page.setRecords(details);
        } else {
            page.setRecords(Collections.emptyList());
        }
        
        return page;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail syncT24Status(Long id, T24SyncResult syncResult, String syncer) {
        log.info("处理条件", id, syncer);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        
        entity.setT24SyncStatus(syncResult.getSuccess() ? "SYNCED" : "FAILED");
        entity.setT24SyncTime(syncResult.getSyncTime());
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(syncer);
        
        loanOutMapper.updateById(entity);
        
        log.info("T24鐘舵€佸悓姝ユ垚鍔? id={}, status={}", id, entity.getT24SyncStatus());
        return convertToDetail(entity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public AlertSendResult sendOverdueAlert(Long loanOutId, String alertType) {
        log.info("处理条件", loanOutId, alertType);
        
        LoanOutEntity loanOut = loanOutMapper.selectById(loanOutId);
        if (loanOut == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + loanOutId);
        }
        OverdueAlertLogEntity alertLog = new OverdueAlertLogEntity();
        alertLog.setLoanOutId(loanOutId);
        alertLog.setAlertType(alertType);
        alertLog.setAlertMessage("处理条件");
        alertLog.setAlertTime(LocalDateTime.now());
        alertLog.setSentStatus("SENT");
        alertLog.setSentTime(LocalDateTime.now());
        alertLog.setCreatedAt(LocalDateTime.now());
        alertLog.setUpdatedAt(LocalDateTime.now());
        
        overdueAlertLogMapper.insert(alertLog);
        
        AlertSendResult result = new AlertSendResult();
        result.setSuccess(true);
        result.setAlertId(alertLog.getId().toString());
        result.setMessage("处理条件");
        result.setSentTime(LocalDateTime.now());
        
        log.info("处理条件", alertLog.getId());
        return result;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail returnStep(Long id, String comments, String returner, String returnerName, Integer returnToStep) {
        log.info("处理条件", id, returner, returnToStep);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        if (!"PENDING".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件");
        }
        LambdaQueryWrapper<LoanOutApprovalEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(LoanOutApprovalEntity::getLoanOutId, id)
                   .eq(LoanOutApprovalEntity::getStatus, "PENDING")
                   .orderByAsc(LoanOutApprovalEntity::getStepNumber)
                   .last("LIMIT 1");
        LoanOutApprovalEntity currentStep = loanOutApprovalMapper.selectOne(queryWrapper);
        if (currentStep == null) {
            throw new IllegalStateException("处理条件");
        }
        LoanOutApprovalWorkflow.ReturnResult returnResult = loanOutApprovalWorkflow.returnStep(
                id, currentStep.getId(), comments, returner, returnerName, returnToStep);
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setUpdatedBy(returner);
        loanOutMapper.updateById(entity);
        
        log.info("处理条件", id, returnToStep);
        return convertToDetail(entity);
    }

    @Override
    public LoanOutApprovalWorkflow.ApprovalProgress getApprovalProgress(Long id) {
        log.debug("鑾峰彇鍊熷嚭审批进度: id={}", id);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        
        return loanOutApprovalWorkflow.getApprovalProgress(id);
    }

    @Override
    public LoanOutApprovalEntity getCurrentPendingStep(Long id) {
        log.debug("处理条件", id);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        LambdaQueryWrapper<LoanOutApprovalEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(LoanOutApprovalEntity::getLoanOutId, id)
                   .eq(LoanOutApprovalEntity::getStatus, "PENDING")
                   .orderByAsc(LoanOutApprovalEntity::getStepNumber)
                   .last("LIMIT 1");
        return loanOutApprovalMapper.selectOne(queryWrapper);
    }

    private LoanOutDetail convertToDetail(LoanOutEntity entity) {
        LoanOutDetail detail = new LoanOutDetail();
        detail.setId(entity.getId());
        detail.setLoanCode("LOAN-" + String.format("%05d", entity.getId()));
        detail.setWhInId(entity.getWhInId());
        detail.setLoanPurpose(entity.getLoanPurpose());
        detail.setLoanDuration(entity.getLoanDuration());
        detail.setExpectedReturnDate(entity.getExpectedReturnDate());
        detail.setActualReturnDate(entity.getActualReturnDate());
        detail.setStatus(entity.getStatus());
        detail.setT24SyncStatus(entity.getT24SyncStatus());
        detail.setT24SyncTime(entity.getT24SyncTime());
        detail.setCreatedAt(entity.getCreatedAt());
        detail.setCreatedBy(entity.getCreatedBy());
        detail.setUpdatedAt(entity.getUpdatedAt());
        detail.setUpdatedBy(entity.getUpdatedBy());
        if (entity.getExpectedReturnDate() != null) {
            LocalDate currentDate = LocalDate.now();
            LocalDate expectedDate = entity.getExpectedReturnDate();
            
            if (currentDate.isAfter(expectedDate) && 
                !"RETURNED".equals(entity.getStatus())) {
                detail.setOverdue(true);
                detail.setRemainingDays(-(int) ChronoUnit.DAYS.between(expectedDate, currentDate));
            } else {
                detail.setOverdue(false);
                detail.setRemainingDays((int) ChronoUnit.DAYS.between(currentDate, expectedDate));
            }
        }
        WarehouseInEntity warehouseIn = warehouseInMapper.selectById(entity.getWhInId());
        if (warehouseIn != null) {
            detail.setWhCode(warehouseIn.getWhCode());
            detail.setCustomerName(warehouseIn.getCustomerName());
            detail.setCollateralType(warehouseIn.getCollateralType());
            detail.setCollateralValue(warehouseIn.getCollateralValue());
            detail.setBuCode(warehouseIn.getBuCode());
            detail.setBuName(warehouseIn.getBuName());
        }
        List<LoanOutApprovalEntity> approvals = loanOutApprovalMapper.selectByLoanOutId(entity.getId());
        detail.setApprovals(approvals);
        List<OverdueAlertLogEntity> alertLogs = overdueAlertLogMapper.selectByLoanOutId(entity.getId());
        detail.setAlertLogs(alertLogs);
        List<LoanReturnApprovalEntity> returnApprovals = loanReturnApprovalMapper.selectByLoanOutId(entity.getId());
        detail.setReturnApprovals(returnApprovals);
        
        return detail;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail applyForReturn(Long id, String returnRemarks, java.time.LocalDateTime returnDate, String applicant, String applicantName) {
        log.info("处理条件", id, applicant);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        if (!"LOANED".equals(entity.getStatus()) && !"OVERDUE".equals(entity.getStatus())) {
            throw new IllegalStateException("处理条件");
        }
        loanReturnApprovalWorkflow.initReturnApprovalProcess(id, applicant, returnRemarks, returnDate);
        entity.setStatus("RETURN_IN_PROGRESS");
        entity.setUpdatedAt(java.time.LocalDateTime.now());
        entity.setUpdatedBy(applicant);
        loanOutMapper.updateById(entity);
        
        log.info("处理条件", id);
        return convertToDetail(entity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail approveReturnStep(
            Long id, Long approvalId, String comments, String approver, String approverName,
            String assetCondition, String conditionDescription,
            Double settlementAmount, String settlementMethod, String settlementReference) {
        log.info("处理条件", id, approvalId, approver);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        LoanReturnApprovalWorkflow.ReturnApprovalResult approvalResult = 
                loanReturnApprovalWorkflow.approveReturnStep(
                        id, approvalId, comments, approver, approverName,
                        assetCondition, conditionDescription,
                        settlementAmount, settlementMethod, settlementReference);
        if (loanReturnApprovalWorkflow.isReturnProcessCompleted(id)) {
            entity.setStatus("RETURNED");
            entity.setActualReturnDate(java.time.LocalDate.now());
            entity.setUpdatedAt(java.time.LocalDateTime.now());
            entity.setUpdatedBy(approver);
            loanOutMapper.updateById(entity);
            log.info("褰掕繕娴佺▼瀹屾垚锛岃祫浜у凡褰掕繕: id={}", id);
        } else {
            entity.setUpdatedAt(java.time.LocalDateTime.now());
            entity.setUpdatedBy(approver);
            loanOutMapper.updateById(entity);
            log.info("处理条件", id, approvalResult.getStepNumber());
        }
        
        return convertToDetail(entity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail rejectReturnStep(Long id, Long approvalId, String comments, String rejector, String rejectorName) {
        log.info("处理条件", id, approvalId, rejector);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        LoanReturnApprovalWorkflow.ReturnRejectionResult rejectionResult = 
                loanReturnApprovalWorkflow.rejectReturnStep(id, approvalId, comments, rejector, rejectorName);
        entity.setUpdatedAt(java.time.LocalDateTime.now());
        entity.setUpdatedBy(rejector);
        loanOutMapper.updateById(entity);
        
        log.info("处理条件", id, rejectionResult.getStepNumber());
        return convertToDetail(entity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoanOutDetail returnReturnStep(Long id, Long approvalId, String comments, String returner, 
                                         String returnerName, Integer returnToStep) {
        log.info("处理条件", 
                id, approvalId, returnToStep, returner);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        LoanReturnApprovalWorkflow.ReturnStepResult returnResult = 
                loanReturnApprovalWorkflow.returnReturnStep(id, approvalId, comments, returner, returnerName, returnToStep);
        entity.setUpdatedAt(java.time.LocalDateTime.now());
        entity.setUpdatedBy(returner);
        loanOutMapper.updateById(entity);
        
        log.info("处理条件", id, returnToStep);
        return convertToDetail(entity);
    }
    
    @Override
    public LoanReturnApprovalWorkflow.ReturnApprovalProgress getReturnApprovalProgress(Long id) {
        log.debug("获取归还审批进度: id={}", id);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        
        return loanReturnApprovalWorkflow.getReturnApprovalProgress(id);
    }
    
    @Override
    public LoanReturnApprovalEntity getCurrentPendingReturnStep(Long id) {
        log.debug("处理条件", id);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        log.warn("getCurrentPendingReturnStep not fully implemented, returning null");
        return null;
    }
    
    @Override
    public Boolean isReturnProcessCompleted(Long id) {
        log.debug("检查归还流程是否完成? id={}", id);
        
        LoanOutEntity entity = loanOutMapper.selectById(id);
        if (entity == null) {
            throw new IllegalArgumentException("鍊熷嚭璁板綍涓嶅瓨鍦? " + id);
        }
        
        return loanReturnApprovalWorkflow.isReturnProcessCompleted(id);
    }
    
    @Override
    public ReturnProcessStatistics getReturnProcessStatistics() {
        log.debug("处理条件");
        
        ReturnProcessStatistics statistics = new ReturnProcessStatistics();
        List<LoanOutEntity> allLoanOuts = loanOutMapper.selectList(null);
        int totalReturnProcesses = 0;
        int completedReturns = 0;
        int inProgressReturns = 0;
        int rejectedReturns = 0;
        
        for (LoanOutEntity loanOut : allLoanOuts) {
            if ("RETURN_IN_PROGRESS".equals(loanOut.getStatus()) || 
                "RETURNED".equals(loanOut.getStatus())) {
                totalReturnProcesses++;
                
                if ("RETURNED".equals(loanOut.getStatus())) {
                    completedReturns++;
                } else if ("RETURN_IN_PROGRESS".equals(loanOut.getStatus())) {
                    inProgressReturns++;
                }
            }
        }
        Map<String, Integer> stepDistribution = new HashMap<>();
        List<Map<String, Object>> stepCounts = loanReturnApprovalMapper.countByStepNumber();
        if (stepCounts != null) {
            for (Map<String, Object> count : stepCounts) {
                Integer stepNumber = (Integer) count.get("step_number");
                Long countValue = (Long) count.get("count");
                stepDistribution.put("处理条件" + stepNumber, countValue.intValue());
            }
        }
        Map<String, Integer> assetConditionDistribution = new HashMap<>();
        Map<String, Integer> settlementMethodDistribution = new HashMap<>();
        
        statistics.setTotalReturnProcesses(totalReturnProcesses);
        statistics.setCompletedReturns(completedReturns);
        statistics.setInProgressReturns(inProgressReturns);
        statistics.setRejectedReturns(rejectedReturns);
        statistics.setStepDistribution(stepDistribution);
        statistics.setAssetConditionDistribution(assetConditionDistribution);
        statistics.setSettlementMethodDistribution(settlementMethodDistribution);
        
        return statistics;
    }
}