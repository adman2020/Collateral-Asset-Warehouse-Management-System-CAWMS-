package com.seabank.cawms.service.impl;

import com.seabank.cawms.entity.WarehouseInFileEntity;
import com.seabank.cawms.mapper.WarehouseInFileMapper;
import com.seabank.cawms.service.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 鏂囦欢涓婁紶鏈嶅姟瀹炵幇绫? * 浣跨敤鏈湴鏂囦欢绯荤粺瀛樺偍鏂囦欢
 */
@Service
public class FileUploadServiceImpl implements FileUploadService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(FileUploadServiceImpl.class);

    private final WarehouseInFileMapper warehouseInFileMapper;
    
    @Value("${file.upload.base-dir:./uploads}")
    private String baseDir;
    
    @Value("${file.upload.max-size:10485760}") // 10MB
    private long maxFileSize;
    
    @Value("${file.upload.allowed-types:jpg,jpeg,png,pdf,doc,docx,xls,xlsx}")
    private List<String> allowedTypes;
    
    @Value("${file.upload.temp-expire-hours:24}")
    private int tempExpireHours;
    
    private Path basePath;
    private Path tempPath;
    
    // TODO: fix encoding comment
    private static final Map<String, String> MIME_TYPE_MAP = new HashMap<>();
    
    static {
        MIME_TYPE_MAP.put("jpg", "image/jpeg");
        MIME_TYPE_MAP.put("jpeg", "image/jpeg");
        MIME_TYPE_MAP.put("png", "image/png");
        MIME_TYPE_MAP.put("pdf", "application/pdf");
        MIME_TYPE_MAP.put("doc", "application/msword");
        MIME_TYPE_MAP.put("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        MIME_TYPE_MAP.put("xls", "application/vnd.ms-excel");
        MIME_TYPE_MAP.put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    }
    
    @Autowired
    public FileUploadServiceImpl(WarehouseInFileMapper warehouseInFileMapper) {
        this.warehouseInFileMapper = warehouseInFileMapper;
    }
    
    @PostConstruct
    public void init() {
        try {
            // TODO: fix encoding comment
            basePath = Paths.get(baseDir).toAbsolutePath().normalize();
            tempPath = basePath.resolve("temp");
            
            Files.createDirectories(basePath);
            Files.createDirectories(tempPath);
            
            log.info("处理条件", basePath);
            log.info("处理条件", tempPath);
            log.info("鏈€澶ф枃浠跺ぇ灏? {} bytes ({} MB)", maxFileSize, maxFileSize / 1024 / 1024);
            
        } catch (IOException e) {
            log.error("处理条件", e);
            throw new RuntimeException("处理条件", e);
        }
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public FileUploadResult uploadFile(MultipartFile file, String uploader, String fileType, String description) {
        log.info("涓婁紶鍗曚釜鏂囦欢: fileName={}, uploader={}, fileType={}", 
                file.getOriginalFilename(), uploader, fileType);
        
        FileUploadResult result = new FileUploadResult();
        
        try {
            // TODO: fix encoding comment
            FileValidationResult validation = validateFile(file, allowedTypes);
            if (!validation.isValid()) {
                result.setSuccess(false);
                result.setMessage("鏂囦欢楠岃瘉澶辫触: " + String.join(", ", validation.getErrors()));
                return result;
            }
            
            // TODO: fix encoding comment
            validation = validateFileSize(file, maxFileSize);
            if (!validation.isValid()) {
                result.setSuccess(false);
                result.setMessage("文件大小超过限制: " + file.getSize() + " > " + maxFileSize);
                return result;
            }
            
            // TODO: fix encoding comment
            String fileHash = calculateFileHash(file);
            result.setFileHash(fileHash);
            
            // TODO: fix encoding comment
            List<FileInfo> existingFiles = findFilesByHash(fileHash);
            if (!existingFiles.isEmpty()) {
                // TODO: fix encoding comment
                FileInfo existingFile = existingFiles.get(0);
                log.info("处理条件", fileHash, existingFile.getFileId());
                
                result.setSuccess(true);
                result.setFileId(existingFile.getFileId());
                result.setFileName(existingFile.getFileName());
                result.setFilePath(existingFile.getFilePath());
                result.setFileSize(existingFile.getFileSize());
                result.setMessage("处理条件");
                
                // TODO: fix encoding comment
                incrementDownloadCount(existingFile.getFileId());
                
                return result;
            }
            
            // TODO: fix encoding comment
            String storagePath = generateStoragePath(file.getOriginalFilename(), fileType);
            Path targetPath = basePath.resolve(storagePath);
            
            // TODO: fix encoding comment
            Files.createDirectories(targetPath.getParent());
            
            // TODO: fix encoding comment
            Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);
            
            // TODO: fix encoding comment
            WarehouseInFileEntity fileEntity = new WarehouseInFileEntity();
            fileEntity.setFileName(file.getOriginalFilename());
            fileEntity.setFileType(fileType);
            fileEntity.setFilePath(storagePath);
            fileEntity.setFileSize(file.getSize());
            fileEntity.setMimeType(detectMimeType(file.getOriginalFilename()));
            fileEntity.setFileHash(fileHash);
            fileEntity.setUploadUser(uploader);
            fileEntity.setUploadTime(LocalDateTime.now());
            fileEntity.setDescription(description);
            fileEntity.setStatus("ACTIVE");
            fileEntity.setDownloadCount(0);
            fileEntity.setDeleted(0);
            
            warehouseInFileMapper.insert(fileEntity);
            
            // TODO: fix encoding comment
            result.setSuccess(true);
            result.setFileId(fileEntity.getId());
            result.setFileName(fileEntity.getFileName());
            result.setFilePath(fileEntity.getFilePath());
            result.setFileSize(fileEntity.getFileSize());
            result.setMessage("鏂囦欢涓婁紶鎴愬姛");
            
            Map<String, Object> metadata = new HashMap<>();
            metadata.put("uploadTime", fileEntity.getUploadTime());
            metadata.put("mimeType", fileEntity.getMimeType());
            result.setMetadata(metadata);
            
            log.info("鏂囦欢涓婁紶鎴愬姛: fileId={}, fileName={}, filePath={}", 
                    fileEntity.getId(), fileEntity.getFileName(), fileEntity.getFilePath());
            
        } catch (IOException e) {
            log.error("鏂囦欢涓婁紶澶辫触", e);
            result.setSuccess(false);
            result.setMessage("鏂囦欢涓婁紶澶辫触: " + e.getMessage());
        } catch (Exception e) {
            log.error("鏂囦欢涓婁紶澶勭悊澶辫触", e);
            result.setSuccess(false);
            result.setMessage("鏂囦欢澶勭悊澶辫触: " + e.getMessage());
        }
        
        return result;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public BatchUploadResult uploadFiles(List<MultipartFile> files, String uploader, 
                                         String fileType, List<String> descriptions) {
        log.info("鎵归噺涓婁紶鏂囦欢: fileCount={}, uploader={}, fileType={}", 
                files.size(), uploader, fileType);
        
        BatchUploadResult batchResult = new BatchUploadResult();
        batchResult.setTotalFiles(files.size());
        batchResult.setSuccessfulFiles(0);
        batchResult.setFailedFiles(0);
        
        List<FileUploadResult> results = new ArrayList<>();
        
        for (int i = 0; i < files.size(); i++) {
            MultipartFile file = files.get(i);
            String description = (descriptions != null && i < descriptions.size()) ? 
                    descriptions.get(i) : null;
            
            FileUploadResult singleResult = uploadFile(file, uploader, fileType, description);
            results.add(singleResult);
            
            if (singleResult.isSuccess()) {
                batchResult.setSuccessfulFiles(batchResult.getSuccessfulFiles() + 1);
            } else {
                batchResult.setFailedFiles(batchResult.getFailedFiles() + 1);
            }
        }
        
        batchResult.setResults(results);
        batchResult.setSuccess(batchResult.getFailedFiles() == 0);
        batchResult.setMessage(String.format("处理条件", 
                batchResult.getSuccessfulFiles(), batchResult.getFailedFiles()));
        
        log.info("鎵归噺涓婁紶瀹屾垚: successful={}, failed={}", 
                batchResult.getSuccessfulFiles(), batchResult.getFailedFiles());
        
        return batchResult;
    }
    
    @Override
    public FileDownloadInfo downloadFile(Long fileId) {
        log.info("涓嬭浇鏂囦欢: fileId={}", fileId);
        
        // TODO: fix encoding comment
        WarehouseInFileEntity fileEntity = warehouseInFileMapper.selectById(fileId);
        if (fileEntity == null || !"ACTIVE".equals(fileEntity.getStatus())) {
            throw new IllegalArgumentException("鏂囦欢涓嶅瓨鍦ㄦ垨宸插垹闄? fileId=" + fileId);
        }
        
        // TODO: fix encoding comment
        Path filePath = basePath.resolve(fileEntity.getFilePath());
        if (!Files.exists(filePath) || !Files.isReadable(filePath)) {
            throw new IllegalStateException("鏂囦欢鏃犳硶璁块棶: " + filePath);
        }
        
        // TODO: fix encoding comment
        incrementDownloadCount(fileId);
        
        // TODO: fix encoding comment
        FileDownloadInfo downloadInfo = new FileDownloadInfo();
        downloadInfo.setFileName(fileEntity.getFileName());
        downloadInfo.setFilePath(fileEntity.getFilePath());
        downloadInfo.setContentType(fileEntity.getMimeType());
        downloadInfo.setFileSize(fileEntity.getFileSize());
        
        // TODO: fix encoding comment
        String downloadUrl = "/api/files/download/" + fileId;
        downloadInfo.setDownloadUrl(downloadUrl);
        downloadInfo.setRequiresAuthentication(true);
        downloadInfo.setExpiresAt(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // TODO: encoding issue
        log.info("文件下载信息鐢熸垚: fileId={}, fileName={}", fileId, fileEntity.getFileName());
        
        return downloadInfo;
    }
    
    @Override
    public List<FileInfo> findFilesByHash(String fileHash) {
        log.debug("根据文件哈希查找文件: fileHash={}", fileHash);
        
        List<WarehouseInFileEntity> fileEntities = warehouseInFileMapper.selectByFileHash(fileHash);
        List<FileInfo> fileInfos = new ArrayList<>();
        
        for (WarehouseInFileEntity entity : fileEntities) {
            if ("ACTIVE".equals(entity.getStatus())) {
                fileInfos.add(convertToFileInfo(entity));
            }
        }
        
        return fileInfos;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteFile(Long fileId, String deletedBy) {
        log.info("閫昏緫删除鏂囦欢: fileId={}, deletedBy={}", fileId, deletedBy);
        
        // TODO: fix encoding comment
        WarehouseInFileEntity fileEntity = warehouseInFileMapper.selectById(fileId);
        if (fileEntity == null) {
            throw new IllegalArgumentException("鏂囦欢涓嶅瓨鍦? fileId=" + fileId);
        }
        
        // TODO: fix encoding comment
        fileEntity.setStatus("DELETED");
        fileEntity.setUploadTime(LocalDateTime.now()); // TODO: fix encoding comment
        
        int rows = warehouseInFileMapper.updateById(fileEntity);
        
        // TODO: fix encoding comment
        log.info("鏂囦欢閫昏緫删除鎴愬姛: fileId={}, fileName={}, deletedBy={}", 
                fileId, fileEntity.getFileName(), deletedBy);
        
        return rows > 0;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean permanentlyDeleteFile(Long fileId) {
        log.info("姘镐箙删除鏂囦欢: fileId={}", fileId);
        
        // TODO: fix encoding comment
        WarehouseInFileEntity fileEntity = warehouseInFileMapper.selectById(fileId);
        if (fileEntity == null) {
            throw new IllegalArgumentException("鏂囦欢涓嶅瓨鍦? fileId=" + fileId);
        }
        
        try {
            // TODO: fix encoding comment
            Path filePath = basePath.resolve(fileEntity.getFilePath());
            if (Files.exists(filePath)) {
                Files.delete(filePath);
                log.debug("鐗╃悊鏂囦欢删除鎴愬姛: path={}", filePath);
            }
            
            // TODO: fix encoding comment
            int rows = warehouseInFileMapper.deleteById(fileId);
            
            log.info("鏂囦欢姘镐箙删除鎴愬姛: fileId={}, fileName={}", fileId, fileEntity.getFileName());
            
            return rows > 0;
            
        } catch (IOException e) {
            log.error("鐗╃悊鏂囦欢删除失败", e);
            throw new RuntimeException("鐗╃悊鏂囦欢删除失败: " + e.getMessage(), e);
        }
    }
    
    @Override
    public FileInfo getFileInfo(Long fileId) {
        log.debug("鑾峰彇文件信息: fileId={}", fileId);
        
        WarehouseInFileEntity fileEntity = warehouseInFileMapper.selectById(fileId);
        if (fileEntity == null) {
            throw new IllegalArgumentException("鏂囦欢涓嶅瓨鍦? fileId=" + fileId);
        }
        
        return convertToFileInfo(fileEntity);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateFileInfo(Long fileId, String description, String updatedBy) {
        log.info("更新文件信息: fileId={}, description={}, updatedBy={}", 
                fileId, description, updatedBy);
        
        WarehouseInFileEntity fileEntity = warehouseInFileMapper.selectById(fileId);
        if (fileEntity == null) {
            throw new IllegalArgumentException("鏂囦欢涓嶅瓨鍦? fileId=" + fileId);
        }
        
        fileEntity.setDescription(description);
        // TODO: fix encoding comment
        fileEntity.setUploadTime(LocalDateTime.now());
        
        int rows = warehouseInFileMapper.updateById(fileEntity);
        
        log.info("文件信息更新鎴愬姛: fileId={}, description={}", fileId, description);
        
        return rows > 0;
    }
    
    @Override
    public FileValidationResult validateFile(MultipartFile file, List<String> allowedTypes) {
        FileValidationResult result = new FileValidationResult();
        result.setValid(true);
        
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        
        // TODO: fix encoding comment
        if (file.isEmpty()) {
            errors.add("鏂囦欢涓虹┖");
            result.setValid(false);
        }
        
        // TODO: fix encoding comment
        String originalFilename = file.getOriginalFilename();
        if (!StringUtils.hasText(originalFilename)) {
            errors.add("处理条件");
            result.setValid(false);
        }
        
        // TODO: fix encoding comment
        if (originalFilename != null) {
            String extension = getFileExtension(originalFilename).toLowerCase();
            if (allowedTypes != null && !allowedTypes.contains(extension)) {
                errors.add("涓嶆敮鎸佺殑文件类型: " + extension + "锛屽厑璁哥殑绫诲瀷: " + allowedTypes);
                result.setValid(false);
            }
        }
        
        // TODO: fix encoding comment
        String contentType = file.getContentType();
        if (contentType != null && contentType.contains("application/octet-stream")) {
            warnings.add("处理条件");
        }
        
        result.setErrors(errors);
        result.setWarnings(warnings);
        
        if (!result.isValid()) {
            result.setMessage("鏂囦欢楠岃瘉澶辫触");
        } else {
            result.setMessage("鏂囦欢楠岃瘉閫氳繃");
        }
        
        return result;
    }
    
    @Override
    public FileValidationResult validateFileSize(MultipartFile file, long maxSize) {
        FileValidationResult result = new FileValidationResult();
        
        long fileSize = file.getSize();
        if (fileSize > maxSize) {
            result.setValid(false);
            result.setMessage("文件大小超过限制: " + formatFileSize(fileSize) + " > " + formatFileSize(maxSize));
            result.setErrors(List.of("文件大小超过限制"));
        } else {
            result.setValid(true);
            result.setMessage("鏂囦欢澶у皬楠岃瘉閫氳繃");
        }
        
        return result;
    }
    
    @Override
    public StorageStatistics getStorageStatistics() {
        log.debug("处理条件");
        
        StorageStatistics statistics = new StorageStatistics();
        
        try {
            // TODO: fix encoding comment
            long totalSize = calculateDirectorySize(basePath);
            statistics.setTotalSize(totalSize);
            
            // TODO: fix encoding comment
            long fileCount = Files.walk(basePath)
                    .filter(path -> Files.isRegularFile(path))
                    .count();
            statistics.setTotalFiles(fileCount);
            
            // TODO: fix encoding comment
            FileStore fileStore = Files.getFileStore(basePath);
            long totalSpace = fileStore.getTotalSpace();
            long usableSpace = fileStore.getUsableSpace();
            long usedSpace = totalSpace - usableSpace;
            
            statistics.setUsedSpace(usedSpace);
            statistics.setAvailableSpace(usableSpace);
            
            // TODO: fix encoding comment
            Map<String, Long> sizeByType = new HashMap<>();
            Map<String, Long> countByType = new HashMap<>();
            
            // TODO: fix encoding comment
            // TODO: fix encoding comment
            statistics.setSizeByFileType(sizeByType);
            statistics.setCountByFileType(countByType);
            
            // TODO: fix encoding comment
            if (fileCount > 0) {
                statistics.setAverageFileSize((double) totalSize / fileCount);
            } else {
                statistics.setAverageFileSize(0.0);
            }
            
            log.debug("处理条件", 
                    fileCount, totalSize / 1024 / 1024);
            
        } catch (IOException e) {
            log.error("处理条件", e);
            throw new RuntimeException("处理条件", e);
        }
        
        return statistics;
    }
    
    @Override
    public CleanupResult cleanupExpiredTempFiles() {
        log.info("清理过期临时文件");
        
        CleanupResult result = new CleanupResult();
        int deletedFiles = 0;
        long freedSpace = 0;
        List<String> deletedFileNames = new ArrayList<>();
        
        try {
            // TODO: fix encoding comment
            if (Files.exists(tempPath) && Files.isDirectory(tempPath)) {
                for (java.nio.file.Path path : Files.walk(tempPath)
                        .filter(path -> Files.isRegularFile(path))
                        .toList()) {
                    try {
                        // TODO: fix encoding comment
                        long lastModified = Files.getLastModifiedTime(path).toMillis();
                        long expireTime = System.currentTimeMillis() - (tempExpireHours * 60 * 60 * 1000);
                        
                        if (lastModified < expireTime) {
                            // TODO: fix encoding comment
                            long fileSize = Files.size(path);
                            Files.delete(path);
                            
                            deletedFiles++;
                            freedSpace += fileSize;
                            deletedFileNames.add(path.getFileName().toString());
                            
                            log.debug("删除杩囨湡涓存椂鏂囦欢: {}, size={} bytes", 
                                    path.getFileName(), fileSize);
                        }
                    } catch (IOException e) {
                        log.warn("澶勭悊涓存椂鏂囦欢澶辫触: {}", path, e);
                    }
                }
            }
            
            result.setSuccess(true);
            result.setDeletedFiles(deletedFiles);
            result.setFreedSpace(freedSpace);
            result.setDeletedFileNames(deletedFileNames);
            result.setMessage(String.format("处理条件", 
                    deletedFiles, formatFileSize(freedSpace)));
            
            log.info("涓存椂鏂囦欢娓呯悊瀹屾垚: deletedFiles={}, freedSpace={} MB", 
                    deletedFiles, freedSpace / 1024 / 1024);
            
        } catch (IOException e) {
            log.error("娓呯悊涓存椂鏂囦欢澶辫触", e);
            result.setSuccess(false);
            result.setMessage("娓呯悊澶辫触: " + e.getMessage());
        }
        
        return result;
    }
    
    // TODO: fix encoding comment
    
    /**
     * 璁＄畻文件MD5哈希
     */
    private String calculateFileHash(MultipartFile file) throws IOException {
        try (InputStream inputStream = file.getInputStream()) {
            byte[] hashBytes = DigestUtils.md5Digest(inputStream);
            return DigestUtils.md5DigestAsHex(hashBytes);
        }
    }
    
    /**
     * 鐢熸垚瀛樺偍璺緞
     * 鏍煎紡锛歿type}/{yyyy-MM}/{dd}/{uuid}_{originalFilename}
     */
    private String generateStoragePath(String originalFilename, String fileType) {
        LocalDateTime now = LocalDateTime.now();
        String datePath = now.format(DateTimeFormatter.ofPattern("yyyy-MM/dd"));
        
        // TODO: fix encoding comment
        String uuid = UUID.randomUUID().toString().replace("-", "");
        
        // TODO: fix encoding comment
        String extension = getFileExtension(originalFilename);
        String safeFilename = uuid + "_" + sanitizeFilename(originalFilename);
        
        // TODO: fix encoding comment
        return fileType + "/" + datePath + "/" + safeFilename;
    }
    
    /**
     * 妫€娴婱IME绫诲瀷
     */
    private String detectMimeType(String filename) {
        String extension = getFileExtension(filename).toLowerCase();
        return MIME_TYPE_MAP.getOrDefault(extension, "application/octet-stream");
    }
    
    /**
     * 鑾峰彇鏂囦欢鎵╁睍鍚?     */

    private String getFileExtension(String filename) {
        if (filename == null) {
            return "";
        }
        int lastDot = filename.lastIndexOf('.');
        return (lastDot == -1) ? "" : filename.substring(lastDot + 1);
    }
    
    /**
     * 娓呯悊鏂囦欢鍚嶏紝绉婚櫎璺緞鍜岀壒娈婂瓧绗?     */

    private String sanitizeFilename(String filename) {
        if (filename == null) {
            return "unknown";
        }
        // TODO: fix encoding comment
        String name = filename.substring(filename.lastIndexOf('/') + 1);
        name = name.substring(name.lastIndexOf('\\') + 1);
        
        // TODO: fix encoding comment
        return name.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
    
    /**
     * 澧炲姞涓嬭浇娆℃暟
     */
    private void incrementDownloadCount(Long fileId) {
        warehouseInFileMapper.incrementDownloadCount(fileId);
        
    }
    
    /**
     * 杞崲瀹炰綋涓篎ileInfo
     */
    private FileInfo convertToFileInfo(WarehouseInFileEntity entity) {
        FileInfo info = new FileInfo();
        info.setFileId(entity.getId());
        info.setFileName(entity.getFileName());
        info.setFileType(entity.getFileType());
        info.setFilePath(entity.getFilePath());
        info.setFileHash(entity.getFileHash());
        info.setFileSize(entity.getFileSize());
        info.setContentType(entity.getMimeType());
        info.setUploader(entity.getUploadUser());
        info.setUploadTime(entity.getUploadTime() != null ? 
                entity.getUploadTime().atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() : null);
        info.setDescription(entity.getDescription());
        info.setStatus(entity.getStatus());
        info.setDownloadCount(entity.getDownloadCount());
        info.setLastDownloadTime(entity.getLastDownloadAt() != null ? 
                entity.getLastDownloadAt().atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() : null);
        
        // TODO: fix encoding comment
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("uploadTime", entity.getUploadTime());
        metadata.put("lastDownloadAt", entity.getLastDownloadAt());
        info.setMetadata(metadata);
        
        return info;
    }
    
    /**
     * 璁＄畻鐩綍澶у皬
     */
    private long calculateDirectorySize(Path directory) throws IOException {
        return Files.walk(directory)
                .filter(path -> Files.isRegularFile(path))
                .mapToLong(path -> {
                    try {
                        return Files.size(path);
                    } catch (IOException e) {
                        log.warn("鑾峰彇鏂囦欢澶у皬澶辫触: {}", path, e);
                        return 0L;
                    }
                })
                .sum();
    }
    
    /**
     * 鏍煎紡鍖栨枃浠跺ぇ灏?     */

    private String formatFileSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.1f MB", size / (1024.0 * 1024.0));
        } else {
            return String.format("%.1f GB", size / (1024.0 * 1024.0 * 1024.0));
        }
    }
}