package com.seabank.cawms.service.workflow;

import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Warehouse entry approval workflow state machine
 * Manages 5-step approval workflow state transitions and business rules
 */
@Component
public class ApprovalWorkflowStateMachine {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ApprovalWorkflowStateMachine.class);
    
    // TODO: fix encoding comment
    
    /**
     // TODO: fix encoding comment
     */
    public enum ApprovalStep {
        STEP_1(1, "Business Department Submission", "BUSINESS_MANAGER", "Business Manager Review"),
        STEP_2(2, "Risk Department Review", "RISK_OFFICER", "Risk Officer Review"),
        STEP_3(3, "Compliance Department Review", "COMPLIANCE_OFFICER", "Compliance Officer Review"),
        STEP_4(4, "Warehouse Manager Confirmation", "WAREHOUSE_MANAGER", "Warehouse Manager Confirmation"),
        STEP_5(5, "Complete Warehouse Entry", "SYSTEM", "System Auto Complete");
        
        private final int stepNumber;
        private final String stepName;
        private final String approverRole;
        private final String description;
        
        ApprovalStep(int stepNumber, String stepName, String approverRole, String description) {
            this.stepNumber = stepNumber;
            this.stepName = stepName;
            this.approverRole = approverRole;
            this.description = description;
        }
        
        public int getStepNumber() {
            return stepNumber;
        }
        
        public String getStepName() {
            return stepName;
        }
        
        public String getApproverRole() {
            return approverRole;
        }
        
        public String getDescription() {
            return description;
        }
        
        public static ApprovalStep fromStepNumber(int stepNumber) {
            for (ApprovalStep step : values()) {
                if (step.stepNumber == stepNumber) {
                    return step;
                }
            }
            throw new IllegalArgumentException("Invalid step number: " + stepNumber);
        }
        
        public static boolean isValidStep(int stepNumber) {
            return stepNumber >= 1 && stepNumber <= 5;
        }
        
        public ApprovalStep next() {
            if (this == STEP_5) {
                return null;
            }
            return fromStepNumber(this.stepNumber + 1);
        }
        
        public ApprovalStep previous() {
            if (this == STEP_1) {
                return null;
            }
            return fromStepNumber(this.stepNumber - 1);
        }
    }
    
    // TODO: fix encoding comment
    
    /**
     * Warehouse entry application status enumeration
     */
    public enum ApplicationStatus {
        DRAFT("Draft", "Application created but not submitted"),
        SUBMITTED("Submitted", "Application submitted, waiting for first step approval"),
        UNDER_REVIEW("Under Review", "Application is in approval workflow"),
        APPROVED("Approved", "All approval steps completed"),
        REJECTED("Rejected", "Application rejected"),
        RETURNED("Returned", "Application returned for modification"),
        CANCELLED("Cancelled", "Application cancelled"),
        COMPLETED("Completed", "Warehouse entry process fully completed");
        
        private final String displayName;
        private final String description;
        
        ApplicationStatus(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }
        
        public String getDisplayName() {
            return displayName;
        }
        
        public String getDescription() {
            return description;
        }
        
        public boolean isFinalStatus() {
            return this == REJECTED || this == CANCELLED || this == COMPLETED;
        }
        
        public boolean isActive() {
            return this == SUBMITTED || this == UNDER_REVIEW || this == RETURNED;
        }
        
        public boolean canBeUpdated() {
            return this == DRAFT || this == RETURNED;
        }
        
        public boolean canBeDeleted() {
            return this == DRAFT;
        }
    }
    
    /**
     * Approval action enumeration
     */
    public enum ApprovalAction {
        SUBMIT("Submit", "Submit application into approval workflow"),
        APPROVE("Approve", "Approve current step"),
        REJECT("Reject", "Reject application"),
        RETURN("Return", "Return application to specified step"),
        CANCEL("Cancel", "Cancel application");
        
        private final String displayName;
        private final String description;
        
        ApprovalAction(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }
        
        public String getDisplayName() {
            return displayName;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
    /**
     * Approval record status enumeration
     */
    public enum ApprovalRecordStatus {
        NOT_STARTED("Not Started", "Approval step has not started"),
        PENDING("Pending", "Waiting for approval"),
        APPROVED("Approved", "Approval passed"),
        REJECTED("Rejected", "Approval rejected"),
        RETURNED("Returned", "Approval returned"),
        CANCELLED("Cancelled", "Approval cancelled");
        
        private final String displayName;
        private final String description;
        
        ApprovalRecordStatus(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }
        
        public String getDisplayName() {
            return displayName;
        }
        
        public String getDescription() {
            return description;
        }
        
        public boolean isFinalStatus() {
            return this == APPROVED || this == REJECTED || this == RETURNED || this == CANCELLED;
        }
    }
    
    // TODO: fix encoding comment
    
    /**
     // TODO: fix encoding comment
     */
    private static class StateTransition {
        final ApplicationStatus fromStatus;
        final ApprovalAction action;
        final ApplicationStatus toStatus;
        final String requiredRole;
        final String description;
        
        StateTransition(ApplicationStatus fromStatus, ApprovalAction action, 
                       ApplicationStatus toStatus, String requiredRole, String description) {
            this.fromStatus = fromStatus;
            this.action = action;
            this.toStatus = toStatus;
            this.requiredRole = requiredRole;
            this.description = description;
        }
    }
    
    private final Map<ApplicationStatus, Map<ApprovalAction, StateTransition>> transitionRules = new HashMap<>();
    
    public ApprovalWorkflowStateMachine() {
        initializeTransitionRules();
    }
    
    private void initializeTransitionRules() {
        // TODO: fix encoding comment
        addTransition(ApplicationStatus.DRAFT, ApprovalAction.SUBMIT, 
                     ApplicationStatus.SUBMITTED, "BUSINESS_MANAGER", "处理条件");
        
        // TODO: fix encoding comment
        addTransition(ApplicationStatus.SUBMITTED, ApprovalAction.APPROVE, 
                     ApplicationStatus.UNDER_REVIEW, "BUSINESS_MANAGER", "处理条件");
        addTransition(ApplicationStatus.UNDER_REVIEW, ApprovalAction.APPROVE, 
                     ApplicationStatus.UNDER_REVIEW, "*", "处理条件");
        addTransition(ApplicationStatus.UNDER_REVIEW, ApprovalAction.APPROVE, 
                     ApplicationStatus.APPROVED, "WAREHOUSE_MANAGER", "处理条件");
        addTransition(ApplicationStatus.APPROVED, ApprovalAction.APPROVE, 
                     ApplicationStatus.COMPLETED, "SYSTEM", "处理条件");
        
        // TODO: fix encoding comment
        addTransition(ApplicationStatus.SUBMITTED, ApprovalAction.REJECT, 
                     ApplicationStatus.REJECTED, "BUSINESS_MANAGER", "处理条件");
        addTransition(ApplicationStatus.UNDER_REVIEW, ApprovalAction.REJECT, 
                     ApplicationStatus.REJECTED, "*", "处理条件");
        
        // TODO: fix encoding comment
        addTransition(ApplicationStatus.SUBMITTED, ApprovalAction.RETURN, 
                     ApplicationStatus.RETURNED, "BUSINESS_MANAGER", "处理条件");
        addTransition(ApplicationStatus.UNDER_REVIEW, ApprovalAction.RETURN, 
                     ApplicationStatus.RETURNED, "*", "处理条件");
        
        // TODO: fix encoding comment
        addTransition(ApplicationStatus.DRAFT, ApprovalAction.CANCEL, 
                     ApplicationStatus.CANCELLED, "CREATOR", "处理条件");
        addTransition(ApplicationStatus.RETURNED, ApprovalAction.CANCEL, 
                     ApplicationStatus.CANCELLED, "CREATOR", "处理条件");
    }
    
    private void addTransition(ApplicationStatus fromStatus, ApprovalAction action,
                              ApplicationStatus toStatus, String requiredRole, String description) {
        StateTransition transition = new StateTransition(fromStatus, action, toStatus, requiredRole, description);
        transitionRules
                .computeIfAbsent(fromStatus, k -> new HashMap<>())
                .put(action, transition);
    }
    
    // TODO: fix encoding comment
    
    /**
     // TODO: fix encoding comment
     * @param currentStep description
     * @param userRole 用户角色
     * @return 验证结果
     */
    public ValidationResult validateTransition(ApplicationStatus currentStatus, 
                                              ApprovalAction action, 
                                              Integer currentStep,
                                              String userRole) {
        ValidationResult result = new ValidationResult();
        
        // TODO: fix encoding comment
        Map<ApprovalAction, StateTransition> fromTransitions = transitionRules.get(currentStatus);
        if (fromTransitions == null || !fromTransitions.containsKey(action)) {
            result.addError("处理条件" + currentStatus + " -> " + action);
            return result;
        }
        
        StateTransition transition = fromTransitions.get(action);
        
        // TODO: fix encoding comment
        if (!"*".equals(transition.requiredRole) && !transition.requiredRole.equals(userRole)) {
            result.addError("处理条件" + userRole + "处理条件" + transition.requiredRole);
        }
        
        // TODO: fix encoding comment
        if (action == ApprovalAction.APPROVE) {
            validateApprovalAction(result, currentStatus, currentStep, userRole);
        } else if (action == ApprovalAction.RETURN) {
            validateReturnAction(result, currentStatus, currentStep);
        }
        
        if (result.isValid()) {
            result.setTargetStatus(transition.toStatus);
            result.setDescription(transition.description);
        }
        
        return result;
    }
    
    /**
     // TODO: fix encoding comment
     * @param currentStep description
     * @param action description
     */
    public Integer getNextStep(Integer currentStep, ApprovalAction action, boolean allStepsApproved) {
        if (currentStep == null) {
            return null;
        }
        
        if (action == ApprovalAction.APPROVE) {
            if (allStepsApproved) {
                return null; // TODO: fix encoding comment
            }
            ApprovalStep current = ApprovalStep.fromStepNumber(currentStep);
            ApprovalStep next = current.next();
            return next != null ? next.getStepNumber() : null;
        } else if (action == ApprovalAction.RETURN) {
            // TODO: fix encoding comment
            return null;
        } else if (action == ApprovalAction.REJECT || action == ApprovalAction.CANCEL) {
            return null; // TODO: fix encoding comment
        }
        
        return currentStep;
    }
    
    /**
     // TODO: fix encoding comment
     * @return result description
     */
    public String getApproverRoleForStep(int stepNumber) {
        return ApprovalStep.fromStepNumber(stepNumber).getApproverRole();
    }
    
    /**
     // TODO: fix encoding comment
     * @param stepNumber description
     * @return result description
     */
    public String getStepName(int stepNumber) {
        return ApprovalStep.fromStepNumber(stepNumber).getStepName();
    }
    
    /**
     // TODO: fix encoding comment
     */
    public List<ApprovalStep> getAllSteps() {
        return Arrays.asList(ApprovalStep.values());
    }
    
    /**
     // TODO: fix encoding comment
     */
    public boolean areAllStepsApproved(Map<Integer, ApprovalRecordStatus> approvalStatuses) {
        for (ApprovalStep step : ApprovalStep.values()) {
            ApprovalRecordStatus status = approvalStatuses.get(step.getStepNumber());
            if (status != ApprovalRecordStatus.APPROVED) {
                return false;
            }
        }
        return true;
    }
    
    /**
     // TODO: fix encoding comment
     */
    public Integer getCurrentPendingStep(Map<Integer, ApprovalRecordStatus> approvalStatuses) {
        for (ApprovalStep step : ApprovalStep.values()) {
            ApprovalRecordStatus status = approvalStatuses.get(step.getStepNumber());
            if (status == ApprovalRecordStatus.PENDING) {
                return step.getStepNumber();
            }
        }
        return null;
    }
    
    /**
     // TODO: fix encoding comment
     */
    public int getHighestApprovedStep(Map<Integer, ApprovalRecordStatus> approvalStatuses) {
        int highest = 0;
        for (ApprovalStep step : ApprovalStep.values()) {
            ApprovalRecordStatus status = approvalStatuses.get(step.getStepNumber());
            if (status == ApprovalRecordStatus.APPROVED) {
                highest = Math.max(highest, step.getStepNumber());
            }
        }
        return highest;
    }
    
    /**
     // TODO: fix encoding comment
     */
    public Map<Integer, ApprovalRecordStatus> initializeApprovalStatuses() {
        Map<Integer, ApprovalRecordStatus> statuses = new HashMap<>();
        for (ApprovalStep step : ApprovalStep.values()) {
            if (step.getStepNumber() == 1) {
                statuses.put(step.getStepNumber(), ApprovalRecordStatus.NOT_STARTED);
            } else {
                statuses.put(step.getStepNumber(), ApprovalRecordStatus.NOT_STARTED);
            }
        }
        return statuses;
    }
    
    /**
     // TODO: fix encoding comment
     * @return result description
     */
    public Map<Integer, ApprovalRecordStatus> activateStep(
            Map<Integer, ApprovalRecordStatus> statuses, int stepNumber) {
        if (ApprovalStep.isValidStep(stepNumber)) {
            statuses.put(stepNumber, ApprovalRecordStatus.PENDING);
        }
        return statuses;
    }
    
    /**
     // TODO: fix encoding comment
     * @param recordStatus description
     */
    public Map<Integer, ApprovalRecordStatus> completeStep(
            Map<Integer, ApprovalRecordStatus> statuses, int stepNumber, 
            ApprovalRecordStatus recordStatus) {
        if (ApprovalStep.isValidStep(stepNumber) && recordStatus.isFinalStatus()) {
            statuses.put(stepNumber, recordStatus);
        }
        return statuses;
    }
    
    // TODO: fix encoding comment
    
    private void validateApprovalAction(ValidationResult result, 
                                       ApplicationStatus currentStatus, 
                                       Integer currentStep, 
                                       String userRole) {
        if (currentStep == null) {
            // TODO: fix encoding comment
            return;
        }
        
        // TODO: fix encoding comment
        String requiredRole = getApproverRoleForStep(currentStep);
        if (!requiredRole.equals(userRole) && !"SYSTEM".equals(userRole)) {
            result.addError("处理条件" + currentStep + "处理条件" + requiredRole + "处理条件" + userRole + "'");
        }
        
        // TODO: fix encoding comment
        if (currentStep == 4 && currentStatus != ApplicationStatus.UNDER_REVIEW && currentStatus != ApplicationStatus.APPROVED) {
            result.addError("处理条件");
        }
    }
    
    private void validateReturnAction(ValidationResult result, 
                                     ApplicationStatus currentStatus, 
                                     Integer currentStep) {
        if (currentStep == null) {
            // TODO: fix encoding comment
            return;
        }
        
        // TODO: fix encoding comment
        if (currentStep <= 1) {
            // TODO: fix encoding comment
        }
        
        // TODO: fix encoding comment
        if (currentStatus != ApplicationStatus.SUBMITTED && currentStatus != ApplicationStatus.UNDER_REVIEW) {
            // TODO: fix encoding comment
        }
    }
    
    // TODO: fix encoding comment
    
    /**
     * 验证结果
     */
    public static class ValidationResult {
        private boolean valid = true;
        private List<String> errors = new ArrayList<>();
        private ApplicationStatus targetStatus;
        private String description;
        
        public void addError(String error) {
            this.errors.add(error);
            this.valid = false;
        }
        
        public void addErrors(List<String> errors) {
            this.errors.addAll(errors);
            this.valid = false;
        }
        
        public boolean isValid() {
            return valid;
        }
        
        public List<String> getErrors() {
            return errors;
        }
        
        public ApplicationStatus getTargetStatus() {
            return targetStatus;
        }
        
        public void setTargetStatus(ApplicationStatus targetStatus) {
            this.targetStatus = targetStatus;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
        
        public String getErrorMessage() {
            return String.join("; ", errors);
        }
    }
}
