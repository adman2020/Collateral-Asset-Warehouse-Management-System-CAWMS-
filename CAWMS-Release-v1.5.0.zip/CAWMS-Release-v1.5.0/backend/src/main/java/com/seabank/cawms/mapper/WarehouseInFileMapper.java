package com.seabank.cawms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seabank.cawms.entity.WarehouseInFileEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface WarehouseInFileMapper extends BaseMapper<WarehouseInFileEntity> {
    List<WarehouseInFileEntity> selectByFileHash(String fileHash);
    List<WarehouseInFileEntity> selectByWarehouseInId(Long warehouseInId);
    int deleteByWarehouseInId(Long warehouseInId);
    int incrementDownloadCount(Long id);
}
