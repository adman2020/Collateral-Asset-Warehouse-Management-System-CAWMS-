package com.seabank.cawms.controller;

import com.seabank.cawms.common.CommonResponse;
import com.seabank.cawms.common.ResponseCode;
import com.seabank.cawms.service.LoanOutService;
import com.seabank.cawms.service.LoanOutService.*;
import com.seabank.cawms.workflow.LoanReturnApprovalWorkflow;
import com.seabank.cawms.entity.LoanReturnApprovalEntity;
import com.seabank.cawms.util.I18nUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;

/**
 * 鎶垫娂璧勪骇借出管理鎺у埗鍣? */
@RestController
@RequestMapping("/api/loan-out")
@Tag(name = "LoanOutController", description = "抵押资产借出管理API")
public class LoanOutController {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(LoanOutController.class);

    private final LoanOutService loanOutService;
    
    @Autowired
    public LoanOutController(LoanOutService loanOutService) {
        this.loanOutService = loanOutService;
    }
    
    /**
     * 创建借出申请草稿
     */
    @Operation(summary = "Create Draft")
    @PostMapping("/drafts")
    public ResponseEntity<CommonResponse<LoanOutDetail>> createDraft(
            @Valid @RequestBody LoanOutDetail detail,
            @RequestHeader("X-User-Id") String userId) {
        log.info("处理条件", userId);
        
        try {
            LoanOutDetail created = loanOutService.createDraft(detail, userId);
            return ResponseEntity.ok(CommonResponse.success(created, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 根据ID查询借出申请详情
     */
    @Operation(summary = "Get By Id")
    @GetMapping("/{id}")
    public ResponseEntity<CommonResponse<LoanOutDetail>> getById(
            @PathVariable Long id) {
        log.debug("处理条件", id);
        
        try {
            LoanOutDetail detail = loanOutService.getById(id);
            return ResponseEntity.ok(CommonResponse.success(detail, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(CommonResponse.error(ResponseCode.NOT_FOUND, e.getMessage()));
        }
    }
    
    /**
     * 更新借出申请
     */
    @Operation(summary = "Update")
    @PutMapping("/{id}")
    public ResponseEntity<CommonResponse<LoanOutDetail>> update(
            @PathVariable Long id,
            @Valid @RequestBody LoanOutDetail detail,
            @RequestHeader("X-User-Id") String userId) {
        log.info("处理条件", id, userId);
        
        try {
            LoanOutDetail updated = loanOutService.update(id, detail, userId);
            return ResponseEntity.ok(CommonResponse.success(updated, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 删除借出申请
     */
    @Operation(summary = "Delete")
    @DeleteMapping("/{id}")
    public ResponseEntity<CommonResponse<Void>> delete(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String userId) {
        log.info("处理条件", id, userId);
        
        try {
            boolean result = loanOutService.delete(id, userId);
            if (result) {
                return ResponseEntity.ok(CommonResponse.success(null, "处理条件"));
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(CommonResponse.error(ResponseCode.ERROR, I18nUtil.getMessage("common.error")));
            }
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 提交借出申请瀹℃壒
     */
    @Operation(summary = "Submit For Approval")
    @PostMapping("/{id}/submit")
    public ResponseEntity<CommonResponse<LoanOutDetail>> submitForApproval(
            @PathVariable Long id,
            @Valid @RequestBody ApprovalRequest request,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader(value = "X-User-Name", required = false) String userName) {
        log.info("处理条件", id, userId);
        
        try {
            String submitterName = userName != null ? userName : userId;
            LoanOutDetail result = loanOutService.submitForApproval(id, request, userId, submitterName);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 审批借出申请
     */
    @Operation(summary = "Approve")
    @PostMapping("/{id}/approve")
    public ResponseEntity<CommonResponse<LoanOutDetail>> approve(
            @PathVariable Long id,
            @RequestParam String comments,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader(value = "X-User-Name", required = false) String userName) {
        log.info("处理条件", id, userId);
        
        try {
            String approverName = userName != null ? userName : userId;
            LoanOutDetail result = loanOutService.approve(id, comments, userId, approverName);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 拒绝借出申请
     */
    @Operation(summary = "Reject")
    @PostMapping("/{id}/reject")
    public ResponseEntity<CommonResponse<LoanOutDetail>> reject(
            @PathVariable Long id,
            @RequestParam String comments,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader(value = "X-User-Name", required = false) String userName) {
        log.info("处理条件", id, userId);
        
        try {
            String rejectorName = userName != null ? userName : userId;
            LoanOutDetail result = loanOutService.reject(id, comments, userId, rejectorName);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 确认借出
     */
    @Operation(summary = "Confirm Loan")
    @PostMapping("/{id}/confirm")
    public ResponseEntity<CommonResponse<LoanOutDetail>> confirmLoan(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader(value = "X-User-Name", required = false) String userName) {
        log.info("处理条件", id, userId);
        
        try {
            String confirmerName = userName != null ? userName : userId;
            LoanOutDetail result = loanOutService.confirmLoan(id, userId, confirmerName);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 褰掕繕鎶垫娂璧勪骇
     */
    @Operation(summary = "褰掕繕鎶垫娂璧勪骇")
    @PostMapping("/{id}/return")
    public ResponseEntity<CommonResponse<LoanOutDetail>> returnCollateral(
            @PathVariable Long id,
            @RequestParam String actualReturnDate,
            @RequestParam(required = false) String remarks,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader(value = "X-User-Name", required = false) String userName) {
        log.info("褰掕繕鎶垫娂璧勪骇: id={}, userId={}", id, userId);
        
        try {
            java.time.LocalDate returnDate = java.time.LocalDate.parse(actualReturnDate);
            String returnerName = userName != null ? userName : userId;
            LoanOutDetail result = loanOutService.returnCollateral(id, returnDate, remarks, userId, returnerName);
            return ResponseEntity.ok(CommonResponse.success(result, I18nUtil.getMessage("loanOut.returnSuccess")));
        } catch (Exception e) {
            log.error("褰掕繕鎶垫娂璧勪骇澶辫触", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 鏌ヨ鍊熷嚭鐢宠鍒楄〃
     */
    @Operation(summary = "Query")
    @GetMapping
    public ResponseEntity<CommonResponse<Page<LoanOutDetail>>> query(
            @ModelAttribute LoanOutQuery query) {
        log.debug("处理条件", query);
        
        try {
            Page<LoanOutDetail> result = loanOutService.query(query);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 鑾峰彇鍊熷嚭缁熻淇℃伅
     */
    @Operation(summary = "Get Statistics")
    @GetMapping("/statistics")
    public ResponseEntity<CommonResponse<LoanOutStatistics>> getStatistics(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) java.time.LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) java.time.LocalDate endDate) {
        log.debug("处理条件, startDate={}, endDate={}", startDate, endDate);
        
        try {
            LoanOutStatistics statistics = loanOutService.getStatistics(startDate, endDate);
            return ResponseEntity.ok(CommonResponse.success(statistics, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }
    
    /**
     * 获取待办审批列表
     */
    @Operation(summary = "获取待办审批列表")
    @GetMapping("/pending-approvals")
    public ResponseEntity<CommonResponse<Page<LoanOutDetail>>> getPendingApprovals(
            @RequestHeader("X-User-Id") String userId,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        log.debug("获取待办审批列表: userId={}", userId);
        
        try {
            Page<LoanOutDetail> result = loanOutService.getPendingApprovals(userId, pageNum, pageSize);
            return ResponseEntity.ok(CommonResponse.success(result, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("获取待办审批列表澶辫触", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }
    
    /**
     * 获取我的审批列表
     */
    @Operation(summary = "获取我的审批列表")
    @GetMapping("/my-approvals")
    public ResponseEntity<CommonResponse<Page<LoanOutDetail>>> getMyApprovals(
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestParam(required = false) String approverUser,
            @RequestParam(required = false) String approverRole,
            @RequestParam String type,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        String actualApproverUser = (approverUser == null || approverUser.isBlank()) ? userId : approverUser;
        log.debug("获取我的借出审批列表: type={}, approverUser={}, approverRole={}", type, actualApproverUser, approverRole);
        
        try {
            String role = (approverRole == null || approverRole.isBlank()) ? "ALL" : approverRole;
            Page<LoanOutDetail> result = loanOutService.getMyApprovals(actualApproverUser, role, type, pageNum, pageSize);
            return ResponseEntity.ok(CommonResponse.success(result, "查询成功"));
        } catch (Exception e) {
            log.error("获取我的借出审批列表失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }
    
    /**
     * 获取逾期借出列表
     */
    @Operation(summary = "获取逾期借出列表")
    @GetMapping("/overdue-loans")
    public ResponseEntity<CommonResponse<Page<LoanOutDetail>>> getOverdueLoans(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        log.debug("获取逾期借出列表");
        
        try {
            Page<LoanOutDetail> result = loanOutService.getOverdueLoans(pageNum, pageSize);
            return ResponseEntity.ok(CommonResponse.success(result, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("获取逾期借出列表澶辫触", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }
    
    /**
     * 获取即将到期借出列表
     */
    @Operation(summary = "获取即将到期借出列表")
    @GetMapping("/expiring-loans")
    public ResponseEntity<CommonResponse<Page<LoanOutDetail>>> getExpiringLoans(
            @RequestParam(defaultValue = "7") Integer days,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        log.debug("获取即将到期借出列表: days={}", days);
        
        try {
            Page<LoanOutDetail> result = loanOutService.getExpiringLoans(days, pageNum, pageSize);
            return ResponseEntity.ok(CommonResponse.success(result, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("获取即将到期借出列表澶辫触", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }
    
    /**
     * 同步T24状态?     */
    @Operation(summary = "Sync T24 Status")
    @PostMapping("/{id}/sync-t24")
    public ResponseEntity<CommonResponse<LoanOutDetail>> syncT24Status(
            @PathVariable Long id,
            @RequestBody T24SyncResult syncResult,
            @RequestHeader("X-User-Id") String userId) {
        log.info("处理条件", id, userId);
        
        try {
            LoanOutDetail result = loanOutService.syncT24Status(id, syncResult, userId);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 鍙戦€侀€炬湡棰勮
     */
    @Operation(summary = "Send Overdue Alert")
    @PostMapping("/{id}/send-alert")
    public ResponseEntity<CommonResponse<AlertSendResult>> sendOverdueAlert(
            @PathVariable Long id,
            @RequestParam(defaultValue = "OVERDUE") String alertType) {
        log.info("处理条件", id, alertType);
        
        try {
            AlertSendResult result = loanOutService.sendOverdueAlert(id, alertType);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 导入借出数据
     */
    @Operation(summary = "导入借出数据")
    @PostMapping("/import")
    public ResponseEntity<CommonResponse<ImportResult>> importData(
            @RequestBody ImportDataRequest request,
            @RequestHeader("X-User-Id") String userId) {
        log.info("导入借出数据: userId={}, records={}", userId, request.getData().size());
        
        try {
            ImportResult result = loanOutService.importData(request.getData(), request.getOptions(), userId);
            return ResponseEntity.ok(CommonResponse.success(result, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("导入借出数据澶辫触", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 导出借出数据
     */
    @Operation(summary = "导出借出数据")
    @PostMapping("/export")
    public ResponseEntity<CommonResponse<ExportResult>> exportData(
            @RequestBody ExportRequest request) {
        log.info("导出借出数据: format={}", request.getFormat());
        
        try {
            ExportResult result = loanOutService.exportData(request);
            return ResponseEntity.ok(CommonResponse.success(result, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("导出借出数据澶辫触", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }
    
    /**
     * 鑾峰彇鑽夌鏁伴噺缁熻
     */
    @Operation(summary = "Get Draft Count")
    @GetMapping("/counts/drafts")
    public ResponseEntity<CommonResponse<Map<String, Object>>> getDraftCount() {
        log.debug("处理条件");
        
        try {
            Map<String, Object> counts = new HashMap<>();
            // TODO: fix encoding comment
            counts.put("draftCount", 0);
            counts.put("pendingCount", 0);
            counts.put("totalCount", 0);
            
            return ResponseEntity.ok(CommonResponse.success(counts, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }
    
    /**
     * 导入数据请求
     */
    static class ImportDataRequest {
        private java.util.List<LoanOutDetail> data;
        private java.util.Map<String, Object> options;
        
        public java.util.List<LoanOutDetail> getData() { return data; }
        public void setData(java.util.List<LoanOutDetail> data) { this.data = data; }
        public java.util.Map<String, Object> getOptions() { return options; }
        public void setOptions(java.util.Map<String, Object> options) { this.options = options; }
    }
    
    // TODO: fix encoding comment
    
    /**
     * 申请归还鎶垫娂璧勪骇
     */
    @Operation(summary = "Apply For Return")
    @PostMapping("/{id}/apply-return")
    public ResponseEntity<CommonResponse<LoanOutDetail>> applyForReturn(
            @PathVariable Long id,
            @RequestParam String returnRemarks,
            @RequestParam String returnDate,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader(value = "X-User-Name", required = false) String userName) {
        log.info("处理条件", id, userId);
        
        try {
            java.time.LocalDateTime parsedReturnDate = java.time.LocalDateTime.parse(returnDate);
            String applicantName = userName != null ? userName : userId;
            LoanOutDetail result = loanOutService.applyForReturn(id, returnRemarks, parsedReturnDate, userId, applicantName);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 瀹℃壒閫氳繃褰掕繕姝ラ
     */
    @Operation(summary = "Approve Return Step")
    @PostMapping("/{id}/approve-return-step")
    public ResponseEntity<CommonResponse<LoanOutDetail>> approveReturnStep(
            @PathVariable Long id,
            @RequestParam Long approvalId,
            @RequestParam String comments,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Name") String userName,
            @RequestParam(required = false) String assetCondition,
            @RequestParam(required = false) String conditionDescription,
            @RequestParam(required = false) Double settlementAmount,
            @RequestParam(required = false) String settlementMethod,
            @RequestParam(required = false) String settlementReference) {
        log.info("处理条件", id, approvalId, userId);
        
        try {
            LoanOutDetail result = loanOutService.approveReturnStep(
                    id, approvalId, comments, userId, userName,
                    assetCondition, conditionDescription,
                    settlementAmount, settlementMethod, settlementReference);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 拒绝归还步骤
     */
    @Operation(summary = "Reject Return Step")
    @PostMapping("/{id}/reject-return-step")
    public ResponseEntity<CommonResponse<LoanOutDetail>> rejectReturnStep(
            @PathVariable Long id,
            @RequestParam Long approvalId,
            @RequestParam String comments,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Name") String userName) {
        log.info("处理条件", id, approvalId, userId);
        
        try {
            LoanOutDetail result = loanOutService.rejectReturnStep(id, approvalId, comments, userId, userName);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 閫€鍥炲綊杩樻楠?     */
    @Operation(summary = "Return Return Step")
    @PostMapping("/{id}/return-return-step")
    public ResponseEntity<CommonResponse<LoanOutDetail>> returnReturnStep(
            @PathVariable Long id,
            @RequestParam Long approvalId,
            @RequestParam String comments,
            @RequestParam Integer returnToStep,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Name") String userName) {
        log.info("处理条件", 
                id, approvalId, returnToStep, userId);
        
        try {
            LoanOutDetail result = loanOutService.returnReturnStep(
                    id, approvalId, comments, userId, userName, returnToStep);
            return ResponseEntity.ok(CommonResponse.success(result, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 获取归还审批进度
     */
    @Operation(summary = "获取归还审批进度")
    @GetMapping("/{id}/return-approval-progress")
    public ResponseEntity<CommonResponse<LoanReturnApprovalWorkflow.ReturnApprovalProgress>> getReturnApprovalProgress(
            @PathVariable Long id) {
        log.debug("获取归还审批进度: id={}", id);
        
        try {
            LoanReturnApprovalWorkflow.ReturnApprovalProgress progress = loanOutService.getReturnApprovalProgress(id);
            return ResponseEntity.ok(CommonResponse.success(progress, I18nUtil.getMessage("common.success")));
        } catch (Exception e) {
            log.error("获取归还审批进度澶辫触", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 获取当前待审批的归还步骤
     */
    @Operation(summary = "Get Current Pending Return Step")
    @GetMapping("/{id}/current-pending-return-step")
    public ResponseEntity<CommonResponse<LoanReturnApprovalEntity>> getCurrentPendingReturnStep(
            @PathVariable Long id) {
        log.debug("处理条件", id);
        
        try {
            LoanReturnApprovalEntity currentStep = loanOutService.getCurrentPendingReturnStep(id);
            return ResponseEntity.ok(CommonResponse.success(currentStep, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 检查归还流程是否完成?     */
    @Operation(summary = "Is Return Process Completed")
    @GetMapping("/{id}/is-return-process-completed")
    public ResponseEntity<CommonResponse<Boolean>> isReturnProcessCompleted(
            @PathVariable Long id) {
        log.debug("处理条件 id={}", id);
        
        try {
            Boolean completed = loanOutService.isReturnProcessCompleted(id);
            return ResponseEntity.ok(CommonResponse.success(completed, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(CommonResponse.error(ResponseCode.BAD_REQUEST, e.getMessage()));
        }
    }
    
    /**
     * 获取归还流程统计信息
     */
    @Operation(summary = "API Operation")
    @GetMapping("/return-process-statistics")
    public ResponseEntity<CommonResponse<LoanOutService.ReturnProcessStatistics>> getReturnProcessStatistics() {
        log.debug("处理条件");
        
        try {
            LoanOutService.ReturnProcessStatistics statistics = loanOutService.getReturnProcessStatistics();
            return ResponseEntity.ok(CommonResponse.success(statistics, "处理条件"));
        } catch (Exception e) {
            log.error("处理条件", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(CommonResponse.error(ResponseCode.ERROR, e.getMessage()));
        }
    }
}