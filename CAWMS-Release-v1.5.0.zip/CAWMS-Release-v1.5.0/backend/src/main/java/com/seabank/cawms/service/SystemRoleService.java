package com.seabank.cawms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.seabank.cawms.entity.SystemRoleEntity;

/**
 * 系统角色服务接口
 */
public interface SystemRoleService extends IService<SystemRoleEntity> {
}
