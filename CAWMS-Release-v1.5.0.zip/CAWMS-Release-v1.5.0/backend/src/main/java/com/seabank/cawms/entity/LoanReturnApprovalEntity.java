package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;

import java.time.LocalDateTime;

/**
 * 褰掕繕审批记录瀹炰綋绫? * 瀵瑰簲鏁版嵁搴撹〃锛歭oan_return_approval
 * 4姝ラ褰掕繕娴佺▼锛? * 1. 申请归还 (APPLY_RETURN)
 * 2. 浠撳簱纭 (WAREHOUSE_CONFIRM)
 * 3. 璐㈠姟缁撶畻 (FINANCE_SETTLEMENT)
 * 4. 瀹屾垚褰掕繕 (COMPLETE_RETURN)
 */
@TableName("loan_return_approval")
public class LoanReturnApprovalEntity {
    
    /**
     * 涓婚敭ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    
    /**
     * 借出记录ID锛堝閿級
     */
    private Long loanOutId;
    
    /**
     * 步骤编号锛?-4锛?     * 1: 申请归还
     * 2: 浠撳簱纭
     * 3: 璐㈠姟缁撶畻
     * 4: 瀹屾垚褰掕繕
     */
    private Integer stepNumber;
    
    /**
     * 姝ラ鍚嶇О
     */
    private String stepName;
    
    /**
     * 审批角色
     * 鍙栧€硷細APPLICANT锛堢敵璇蜂汉锛? WAREHOUSE_MANAGER锛堜粨搴撶鐞嗗憳锛? 
     * FINANCE_OFFICER锛堣储鍔′笓鍛橈級, SYSTEM锛堢郴缁燂級
     */
    private String approverRole;
    
    /**
     * 审批用户锛堢敤鎴稩D锛?     */

    private String approverUser;
    
    /**
     * 审批用户濮撳悕
     */
    private String approverName;
    
    /**
     * 瀹℃壒鐘舵€?     * 鍙栧€硷細PENDING锛堝緟瀹℃壒锛? APPROVED锛堝凡鎵瑰噯锛? REJECTED锛堝凡鎷掔粷锛? 
     * RETURNED锛堝凡閫€鍥烇級, CANCELLED锛堝凡鍙栨秷锛? WAITING锛堢瓑寰呬腑锛?     */

    private String status;
    
    /**
     * 瀹℃壒鎰忚
     */
    private String comments;
    
    /**
     * 瀹℃壒鏃堕棿
     */
    private LocalDateTime approvedAt;
    
    /**
     * 创建鏃堕棿
     */
    private LocalDateTime createdAt;
    
    /**
     * 更新鏃堕棿
     */
    private LocalDateTime updatedAt;
    
    /**
     * 棰勮瀹屾垚鏃堕棿
     */
    private LocalDateTime dueDate;
    
    /**
     * 瀹為檯瀹屾垚鏃堕棿
     */
    private LocalDateTime completedAt;
    
    /**
     * 澶勭悊鏃堕暱锛堝垎閽燂級
     */
    private Integer processingMinutes;
    
    /**
     * 鏄惁鑷姩瀹℃壒
     */
    private Boolean autoApproved;
    
    /**
     * 褰掕繕澶囨敞锛堢壒娈婂瓧娈碉紝璁板綍褰掕繕鐩稿叧淇℃伅锛?     */

    private String returnRemarks;
    
    /**
     * 褰掕繕鏃ユ湡
     */
    private LocalDateTime returnDate;
    
    /**
     * 褰掕繕璧勪骇鐘跺喌
     * 鍙栧€硷細GOOD锛堣壇濂斤級, DAMAGED锛堟崯鍧忥級, LOST锛堜涪澶憋級, OTHER锛堝叾浠栵級
     */
    private String assetCondition;
    
    /**
     * 璧勪骇鐘跺喌鎻忚堪
     */
    private String conditionDescription;
    
    /**
     * 缁撶畻閲戦
     */
    private Double settlementAmount;
    
    /**
     * 缁撶畻鏂瑰紡
     * 鍙栧€硷細CASH锛堢幇閲戯級, BANK_TRANSFER锛堥摱琛岃浆璐︼級, CHECK锛堟敮绁級, OTHER锛堝叾浠栵級
     */
    private String settlementMethod;
    
    /**
     * 缁撶畻鍑瘉鍙?     */

    private String settlementReference;
    
    /**
     * 瀹℃壒闄勪欢锛圝SON鏍煎紡锛屽瓨鍌ㄧ浉鍏虫枃浠禝D锛?     */

    private String approvalAttachments;
    
    /**
     * 鎵╁睍瀛楁 - JSON鏍煎紡瀛樺偍棰濆淇℃伅
     */
    private String extData;
    
    /**
     * 鐗堟湰鍙凤紙涔愯閿侊級
     */
    @Version
    private Integer version;
    
    /**
     * 鍏宠仈鐨勫€熷嚭璁板綍璇︽儏锛堥潪鏁版嵁搴撳瓧娈碉級
     */
    @TableField(exist = false)
    private LoanOutEntity loanOut;


    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Long getLoanOutId() {
        return loanOutId;
    }
    public void setLoanOutId(Long loanOutId) {
        this.loanOutId = loanOutId;
    }

    public Integer getStepNumber() {
        return stepNumber;
    }
    public void setStepNumber(Integer stepNumber) {
        this.stepNumber = stepNumber;
    }

    public String getStepName() {
        return stepName;
    }
    public void setStepName(String stepName) {
        this.stepName = stepName;
    }

    public String getApproverRole() {
        return approverRole;
    }
    public void setApproverRole(String approverRole) {
        this.approverRole = approverRole;
    }

    public String getApproverUser() {
        return approverUser;
    }
    public void setApproverUser(String approverUser) {
        this.approverUser = approverUser;
    }

    public String getApproverName() {
        return approverName;
    }
    public void setApproverName(String approverName) {
        this.approverName = approverName;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getComments() {
        return comments;
    }
    public void setComments(String comments) {
        this.comments = comments;
    }

    public LocalDateTime getApprovedAt() {
        return approvedAt;
    }
    public void setApprovedAt(LocalDateTime approvedAt) {
        this.approvedAt = approvedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public LocalDateTime getDueDate() {
        return dueDate;
    }
    public void setDueDate(LocalDateTime dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }
    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public Integer getProcessingMinutes() {
        return processingMinutes;
    }
    public void setProcessingMinutes(Integer processingMinutes) {
        this.processingMinutes = processingMinutes;
    }

    public Boolean getAutoApproved() {
        return autoApproved;
    }
    public void setAutoApproved(Boolean autoApproved) {
        this.autoApproved = autoApproved;
    }

    public String getReturnRemarks() {
        return returnRemarks;
    }
    public void setReturnRemarks(String returnRemarks) {
        this.returnRemarks = returnRemarks;
    }

    public LocalDateTime getReturnDate() {
        return returnDate;
    }
    public void setReturnDate(LocalDateTime returnDate) {
        this.returnDate = returnDate;
    }

    public String getAssetCondition() {
        return assetCondition;
    }
    public void setAssetCondition(String assetCondition) {
        this.assetCondition = assetCondition;
    }

    public String getConditionDescription() {
        return conditionDescription;
    }
    public void setConditionDescription(String conditionDescription) {
        this.conditionDescription = conditionDescription;
    }

    public Double getSettlementAmount() {
        return settlementAmount;
    }
    public void setSettlementAmount(Double settlementAmount) {
        this.settlementAmount = settlementAmount;
    }

    public String getSettlementMethod() {
        return settlementMethod;
    }
    public void setSettlementMethod(String settlementMethod) {
        this.settlementMethod = settlementMethod;
    }

    public String getSettlementReference() {
        return settlementReference;
    }
    public void setSettlementReference(String settlementReference) {
        this.settlementReference = settlementReference;
    }

    public String getApprovalAttachments() {
        return approvalAttachments;
    }
    public void setApprovalAttachments(String approvalAttachments) {
        this.approvalAttachments = approvalAttachments;
    }

    public String getExtData() {
        return extData;
    }
    public void setExtData(String extData) {
        this.extData = extData;
    }

    public Integer getVersion() {
        return version;
    }
    public void setVersion(Integer version) {
        this.version = version;
    }

    public LoanOutEntity getLoanOut() {
        return loanOut;
    }
    public void setLoanOut(LoanOutEntity loanOut) {
        this.loanOut = loanOut;
    }
}