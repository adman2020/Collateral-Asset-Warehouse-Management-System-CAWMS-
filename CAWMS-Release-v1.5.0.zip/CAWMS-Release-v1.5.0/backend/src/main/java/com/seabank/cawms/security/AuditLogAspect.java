package com.seabank.cawms.security;

import com.seabank.cawms.entity.AuditLogEntity;
import com.seabank.cawms.service.AuditLogService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * 审计日志AOP切面
 */
@Aspect
@Component
public class AuditLogAspect {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AuditLogAspect.class);

    private final AuditLogService auditLogService;
    
    private static final ThreadLocal<Map<String, Object>> AUDIT_LOG_CONTEXT = new ThreadLocal<>();

    /**
     * 瀹氫箟鍒囧叆鐐癸細鎵€鏈塁ontroller鏂规硶
     */
    @Pointcut("@within(org.springframework.web.bind.annotation.RestController) || " +
              "@within(org.springframework.stereotype.Controller)")
    public void controllerPointcut() {}

    /**
     * 瀹氫箟鍒囧叆鐐癸細甯︽湁@AuditLog娉ㄨВ鐨勬柟娉?     */

    @Pointcut("@annotation(com.seabank.cawms.security.AuditLog)")
    public void auditLogPointcut() {}

    /**
     * 鏂规硶鎵ц鍓嶈褰?     */

    @Before("controllerPointcut() || auditLogPointcut()")
    public void doBefore(JoinPoint joinPoint) {
        try {
            // TODO: fix encoding comment
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attributes == null) {
                return;
            }
            
            HttpServletRequest request = attributes.getRequest();
            
            // TODO: fix encoding comment
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            Method method = signature.getMethod();
            
            // TODO: fix encoding comment
            AuditLog auditLogAnnotation = method.getAnnotation(AuditLog.class);
            
            // TODO: fix encoding comment
            Map<String, Object> context = new HashMap<>();
            context.put("startTime", System.currentTimeMillis());
            context.put("method", method.getName());
            context.put("className", joinPoint.getTarget().getClass().getName());
            context.put("operation", getOperationName(auditLogAnnotation, method));
            context.put("module", getModuleName(auditLogAnnotation, joinPoint.getTarget().getClass()));
            context.put("requestUri", request.getRequestURI());
            context.put("requestMethod", request.getMethod());
            context.put("clientIp", getClientIp(request));
            context.put("userAgent", request.getHeader("User-Agent"));
            
            // TODO: fix encoding comment
            String username = SecurityUtils.getCurrentUsername().orElse("anonymous");
            context.put("username", username);
            
            // TODO: fix encoding comment
            AUDIT_LOG_CONTEXT.set(context);
            
        } catch (Exception e) {
            log.error("处理条件", e);
        }
    }

    /**
     * 鏂规硶鎵ц鎴愬姛鍚庤褰?     */

    @AfterReturning(pointcut = "controllerPointcut() || auditLogPointcut()", returning = "result")
    public void doAfterReturning(JoinPoint joinPoint, Object result) {
        try {
            Map<String, Object> context = AUDIT_LOG_CONTEXT.get();
            if (context == null) {
                return;
            }
            
            // TODO: fix encoding comment
            Long startTime = (Long) context.get("startTime");
            Long executionTime = System.currentTimeMillis() - startTime;
            
            // TODO: fix encoding comment
            AuditLogEntity auditLog = new AuditLogEntity();
            auditLog.setModule((String) context.get("module"));
            auditLog.setOperation((String) context.get("operation"));
            auditLog.setResourceType(getResourceType(joinPoint));
            auditLog.setResourceId(getResourceId(result));
            auditLog.setUserId(SecurityUtils.getCurrentUserId().orElse(null));
            auditLog.setUsername((String) context.get("username"));
            auditLog.setClientIp((String) context.get("clientIp"));
            auditLog.setUserAgent((String) context.get("userAgent"));
            auditLog.setRequestUri((String) context.get("requestUri"));
            auditLog.setRequestMethod((String) context.get("requestMethod"));
            auditLog.setAction("SUCCESS");
            auditLog.setStatusCode("200");
            auditLog.setExecutionTime(executionTime.intValue());
            auditLog.setTimestamp(LocalDateTime.now());
            
            // TODO: fix encoding comment
            auditLogService.saveAuditLogAsync(auditLog);
            
            log.debug("处理条件", 
                    context.get("username"), 
                    context.get("operation"), 
                    executionTime);
            
        } catch (Exception e) {
            log.error("处理条件", e);
        } finally {
            // TODO: fix encoding comment
            AUDIT_LOG_CONTEXT.remove();
        }
    }

    /**
     * 鏂规硶鎵ц寮傚父鍚庤褰?     */

    @AfterThrowing(pointcut = "controllerPointcut() || auditLogPointcut()", throwing = "exception")
    public void doAfterThrowing(JoinPoint joinPoint, Exception exception) {
        try {
            Map<String, Object> context = AUDIT_LOG_CONTEXT.get();
            if (context == null) {
                return;
            }
            
            // TODO: fix encoding comment
            Long startTime = (Long) context.get("startTime");
            Long executionTime = System.currentTimeMillis() - startTime;
            
            // TODO: fix encoding comment
            AuditLogEntity auditLog = new AuditLogEntity();
            auditLog.setModule((String) context.get("module"));
            auditLog.setOperation((String) context.get("operation"));
            auditLog.setResourceType(getResourceType(joinPoint));
            auditLog.setUserId(SecurityUtils.getCurrentUserId().orElse(null));
            auditLog.setUsername((String) context.get("username"));
            auditLog.setClientIp((String) context.get("clientIp"));
            auditLog.setUserAgent((String) context.get("userAgent"));
            auditLog.setRequestUri((String) context.get("requestUri"));
            auditLog.setRequestMethod((String) context.get("requestMethod"));
            auditLog.setAction("FAILURE");
            auditLog.setStatusCode("500");
            auditLog.setErrorMessage(exception.getMessage());
            auditLog.setErrorStack(getErrorStack(exception));
            auditLog.setExecutionTime(executionTime.intValue());
            auditLog.setTimestamp(LocalDateTime.now());
            
            // TODO: fix encoding comment
            auditLogService.saveAuditLogAsync(auditLog);
            
            log.debug("处理条件", 
                    context.get("username"), 
                    context.get("operation"), 
                    exception.getClass().getSimpleName(),
                    executionTime);
            
        } catch (Exception e) {
            log.error("处理条件", e);
        } finally {
            // TODO: fix encoding comment
            AUDIT_LOG_CONTEXT.remove();
        }
    }

    /**
     * 获取操作名称
     */
    private String getOperationName(AuditLog auditLogAnnotation, Method method) {
        if (auditLogAnnotation != null && !auditLogAnnotation.value().isEmpty()) {
            return auditLogAnnotation.value();
        }
        
        // TODO: fix encoding comment
        String methodName = method.getName().toLowerCase();
        if (methodName.contains("create") || methodName.contains("add") || methodName.contains("save")) {
            return "创建";
        } else if (methodName.contains("update") || methodName.contains("modify") || methodName.contains("edit")) {
            return "更新";
        } else if (methodName.contains("delete") || methodName.contains("remove")) {
            return "删除";
        } else if (methodName.contains("get") || methodName.contains("find") || methodName.contains("query")) {
            return "处理条件";
        } else if (methodName.contains("login") || methodName.contains("auth")) {
            return "鐧诲綍";
        } else if (methodName.contains("logout")) {
            return "鐧诲嚭";
        } else if (methodName.contains("export")) {
            return "导出";
        } else if (methodName.contains("import")) {
            return "导入";
        } else if (methodName.contains("approve")) {
            return "瀹℃壒";
        } else if (methodName.contains("reject")) {
            return "椹冲洖";
        } else {
            return "操作";
        }
    }

    /**
     * 获取模块名称
     */
    private String getModuleName(AuditLog auditLogAnnotation, Class<?> clazz) {
        if (auditLogAnnotation != null && !auditLogAnnotation.module().isEmpty()) {
            return auditLogAnnotation.module();
        }
        
        // TODO: fix encoding comment
        String className = clazz.getSimpleName().toLowerCase();
        if (className.contains("warehousein")) {
            return "入库管理";
        } else if (className.contains("loanout")) {
            return "借出管理";
        } else if (className.contains("transfer")) {
            return "处理条件";
        } else if (className.contains("warehouseout")) {
            return "出库管理";
        } else if (className.contains("user") || className.contains("auth")) {
            return "用户管理";
        } else if (className.contains("role")) {
            return "角色管理";
        } else if (className.contains("config")) {
            return "绯荤粺閰嶇疆";
        } else if (className.contains("audit")) {
            return "处理条件";
        } else {
            return "系统管理";
        }
    }

    /**
     * 鑾峰彇瀹㈡埛绔疘P
     */
    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        
        // TODO: fix encoding comment
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        
        return ip;
    }

    /**
     * 获取资源类型
     */
    private String getResourceType(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Class<?> returnType = signature.getReturnType();
        
        if (returnType.getSimpleName().contains("Entity") || returnType.getSimpleName().contains("VO")) {
            return returnType.getSimpleName();
        }
        
        // TODO: fix encoding comment
        String methodName = signature.getMethod().getName().toLowerCase();
        if (methodName.contains("warehouse") || methodName.contains("in")) {
            return "Warehouse";
        } else if (methodName.contains("loan")) {
            return "Loan";
        } else if (methodName.contains("transfer")) {
            return "Transfer";
        } else if (methodName.contains("user")) {
            return "User";
        } else if (methodName.contains("role")) {
            return "Role";
        } else {
            return "Unknown";
        }
    }

    /**
     * 鑾峰彇璧勬簮ID
     */
    private Long getResourceId(Object result) {
        if (result == null) {
            return null;
        }
        
        try {
            // TODO: fix encoding comment
            // TODO: fix encoding comment
            if (result instanceof Map) {
                Map<?, ?> map = (Map<?, ?>) result;
                Object id = map.get("id");
                if (id instanceof Long) {
                    return (Long) id;
                } else if (id instanceof Number) {
                    return ((Number) id).longValue();
                }
            }
            
            // TODO: fix encoding comment
            java.lang.reflect.Field idField = result.getClass().getDeclaredField("id");
            idField.setAccessible(true);
            Object idValue = idField.get(result);
            if (idValue instanceof Long) {
                return (Long) idValue;
            } else if (idValue instanceof Number) {
                return ((Number) idValue).longValue();
            }
        } catch (Exception e) {
            // Ignore exception, ID may not exist
        }
        
        return null;
    }

    /**
     * 鑾峰彇閿欒鍫嗘爤
     */
    private String getErrorStack(Exception exception) {
        if (exception == null) {
            return null;
        }
        
        // Limit stack trace length to avoid oversized logs
        StringBuilder stackTrace = new StringBuilder();
        stackTrace.append(exception.getClass().getName()).append(": ").append(exception.getMessage()).append("\n");
        
        StackTraceElement[] stackTraceElements = exception.getStackTrace();
        int maxLines = Math.min(stackTraceElements.length, 10);
        for (int i = 0; i < maxLines; i++) {
            stackTrace.append("\tat ").append(stackTraceElements[i]).append("\n");
        }
        
        if (stackTraceElements.length > maxLines) {
            stackTrace.append("\t... ").append(stackTraceElements.length - maxLines).append(" more lines\n");
        }
        
        return stackTrace.toString();
    }


    public AuditLogAspect(AuditLogService auditLogService) {
        this.auditLogService = auditLogService;
    }
}