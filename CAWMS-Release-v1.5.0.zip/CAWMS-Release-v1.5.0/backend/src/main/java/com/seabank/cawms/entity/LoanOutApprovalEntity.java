package com.seabank.cawms.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;

import java.time.LocalDateTime;

@TableName("loan_out_approval")
public class LoanOutApprovalEntity {
    
        @TableId(type = IdType.AUTO)
    private Long id;
    
        private Long loanOutId;
    
        private Integer stepNumber;
    
        private String stepName;
    
        private String approverRole;
    
    
    private String approverUser;
    
        private String approverName;
    
    
    private String status;
    
        private String comments;
    
        private LocalDateTime approvedAt;
    
        private LocalDateTime createdAt;
    
        private LocalDateTime updatedAt;
    
        private LocalDateTime dueDate;
    
        private LocalDateTime completedAt;
    
        private Integer processingMinutes;
    
        private Boolean autoApproved;
    
    
    private String approvalAttachments;
    
        private String extData;
    
        @Version
    private Integer version;
    
        @TableField(exist = false)
    private LoanOutEntity loanOut;


    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Long getLoanOutId() {
        return loanOutId;
    }
    public void setLoanOutId(Long loanOutId) {
        this.loanOutId = loanOutId;
    }

    public Integer getStepNumber() {
        return stepNumber;
    }
    public void setStepNumber(Integer stepNumber) {
        this.stepNumber = stepNumber;
    }

    public String getStepName() {
        return stepName;
    }
    public void setStepName(String stepName) {
        this.stepName = stepName;
    }

    public String getApproverRole() {
        return approverRole;
    }
    public void setApproverRole(String approverRole) {
        this.approverRole = approverRole;
    }

    public String getApproverUser() {
        return approverUser;
    }
    public void setApproverUser(String approverUser) {
        this.approverUser = approverUser;
    }

    public String getApproverName() {
        return approverName;
    }
    public void setApproverName(String approverName) {
        this.approverName = approverName;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getComments() {
        return comments;
    }
    public void setComments(String comments) {
        this.comments = comments;
    }

    public LocalDateTime getApprovedAt() {
        return approvedAt;
    }
    public void setApprovedAt(LocalDateTime approvedAt) {
        this.approvedAt = approvedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public LocalDateTime getDueDate() {
        return dueDate;
    }
    public void setDueDate(LocalDateTime dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }
    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public Integer getProcessingMinutes() {
        return processingMinutes;
    }
    public void setProcessingMinutes(Integer processingMinutes) {
        this.processingMinutes = processingMinutes;
    }

    public Boolean getAutoApproved() {
        return autoApproved;
    }
    public void setAutoApproved(Boolean autoApproved) {
        this.autoApproved = autoApproved;
    }

    public String getApprovalAttachments() {
        return approvalAttachments;
    }
    public void setApprovalAttachments(String approvalAttachments) {
        this.approvalAttachments = approvalAttachments;
    }

    public String getExtData() {
        return extData;
    }
    public void setExtData(String extData) {
        this.extData = extData;
    }

    public Integer getVersion() {
        return version;
    }
    public void setVersion(Integer version) {
        this.version = version;
    }

    public LoanOutEntity getLoanOut() {
        return loanOut;
    }
    public void setLoanOut(LoanOutEntity loanOut) {
        this.loanOut = loanOut;
    }
}