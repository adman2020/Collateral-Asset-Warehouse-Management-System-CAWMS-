package com.seabank.cawms.common;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * 瀹夊叏宸ュ叿绫? */

public class SecurityUtils {
    
    /**
     * 鑾峰彇褰撳墠鐧诲綍鐢ㄦ埛鍚?     * @return 褰撳墠鐢ㄦ埛鍚嶏紝濡傛灉鏈璇佸垯杩斿洖"anonymous"
     */
    public static String getCurrentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return "anonymous";
        }
        
        Object principal = authentication.getPrincipal();
        if (principal instanceof UserDetails) {
            return ((UserDetails) principal).getUsername();
        } else if (principal instanceof String) {
            return (String) principal;
        } else {
            return principal.toString();
        }
    }
    
    /**
     * 获取当前用户ID
     * @return 当前用户ID，如果未认证则返回null
     */
    public static String getCurrentUserId() {
        // TODO: fix encoding comment
        // TODO: fix encoding comment
        return getCurrentUsername();
    }
    
    /**
     * 检查当前用户是否已认证
     * @return 鏄惁宸茶璇?     */

    public static boolean isAuthenticated() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.isAuthenticated();
    }
    
    /**
     * 妫€鏌ュ綋鍓嶇敤鎴锋槸鍚︽嫢鏈夋寚瀹氳鑹?     * @param role 角色名称
     * @return 鏄惁鎷ユ湁璇ヨ鑹?     */

    public static boolean hasRole(String role) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            return false;
        }
        return authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals("ROLE_" + role));
    }
}