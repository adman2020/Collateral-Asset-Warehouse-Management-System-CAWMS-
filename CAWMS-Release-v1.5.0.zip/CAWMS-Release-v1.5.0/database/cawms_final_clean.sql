
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `request_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `execution_time` int DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_time` (`user_id`,`timestamp`),
  KEY `idx_resource` (`resource_type`,`resource_id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_audit_user_time_resource` (`user_id`,`timestamp`,`resource_type`),
  KEY `idx_audit_action_time` (`action`,`timestamp`),
  KEY `idx_audit_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `collateral_loan_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collateral_loan_out` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint DEFAULT NULL,
  `loan_purpose` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loan_duration` int DEFAULT NULL,
  `expected_return_date` date DEFAULT NULL,
  `actual_return_date` date DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t24_sync_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t24_sync_time` datetime DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_return_date` (`expected_return_date`),
  KEY `idx_sync_status` (`t24_sync_status`),
  KEY `idx_loan_out_status_return` (`status`,`expected_return_date`),
  KEY `idx_loan_out_wh_in_status` (`wh_in_id`,`status`),
  KEY `idx_loan_out_created` (`created_at`),
  KEY `idx_loan_out_sync` (`t24_sync_status`,`t24_sync_time`),
  CONSTRAINT `collateral_loan_out_ibfk_1` FOREIGN KEY (`wh_in_id`) REFERENCES `collateral_warehouse_in` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `collateral_loan_out` WRITE;
/*!40000 ALTER TABLE `collateral_loan_out` DISABLE KEYS */;
INSERT INTO `collateral_loan_out` VALUES (4,8,'项目融资',1,'2026-05-25','2026-04-17','RETURNED','PENDING',NULL,'1','1','2026-04-16 20:36:43','2026-04-18 04:51:42',0),(5,4,'经营周转',6,'2026-10-30','2026-04-21','RETURNED','PENDING',NULL,'2','1','2026-04-16 20:39:21','2026-04-21 09:59:51',0),(6,1,'供应链金融',5,'2026-09-29','2026-04-17','RETURNED','PENDING',NULL,'2','1','2026-04-16 20:40:01','2026-04-17 19:35:20',0),(7,3,'供应链金融',1,'2026-05-18','2026-04-19','RETURNED','PENDING',NULL,'2','9','2026-04-17 09:47:09','2026-04-19 08:29:19',0),(8,10,'项目融资',1,'2026-05-19',NULL,'APPROVED','PENDING',NULL,'3','2','2026-04-18 10:06:44','2026-04-19 15:52:27',0),(9,3,'消费贷款',1,'2026-04-28',NULL,'APPROVED','PENDING',NULL,'2','8','2026-04-18 13:04:46','2026-04-21 09:48:40',0),(10,19,'其他',1,'2026-05-01',NULL,'APPROVED','PENDING',NULL,'2','2','2026-04-20 18:12:21','2026-04-21 11:47:53',0),(11,17,'其他',1,'2026-04-30',NULL,'LOANED','PENDING',NULL,'2','8','2026-04-20 18:14:19','2026-04-21 17:24:47',0),(12,19,'其他',1,'2026-04-28','2026-04-21','RETURNED','PENDING',NULL,'2','8','2026-04-21 11:49:01','2026-04-21 12:17:28',0),(13,18,'其他',1,'2026-04-28',NULL,'LOANED','PENDING',NULL,'8','8','2026-04-21 12:47:25','2026-04-21 17:24:30',0);
/*!40000 ALTER TABLE `collateral_loan_out` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `collateral_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collateral_transfer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint DEFAULT NULL,
  `source_wh_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_wh_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transfer_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transfer_reason` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_source_wh` (`source_wh_code`),
  KEY `idx_target_wh` (`target_wh_code`),
  KEY `idx_transfer_wh_in_status` (`wh_in_id`,`status`),
  KEY `idx_transfer_date` (`transfer_date`),
  KEY `idx_transfer_type_status` (`transfer_type`,`status`),
  KEY `idx_transfer_created` (`created_at`),
  CONSTRAINT `collateral_transfer_ibfk_1` FOREIGN KEY (`wh_in_id`) REFERENCES `collateral_warehouse_in` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `collateral_transfer` WRITE;
/*!40000 ALTER TABLE `collateral_transfer` DISABLE KEYS */;
INSERT INTO `collateral_transfer` VALUES (1,10,'WH-SH-001','上海监管仓A库','WH-SH-002','上海监管仓B库','INTERNAL','','2026-04-18','COMPLETED','1','1','2026-04-18 05:03:50','2026-04-18 05:12:59',0),(2,1,'','','WH-SZ-003','深圳国际仓','INTERNAL','安保升级需求',NULL,'DRAFT','2','2','2026-04-18 08:58:25','2026-04-18 20:08:09',1),(3,1,'','','WH-SZ-003','深圳国际仓','INTERNAL','安保升级需求',NULL,'DRAFT','2','2','2026-04-18 08:59:25','2026-04-18 20:08:09',1),(4,9,'','','WH-SZ-002','深圳福保库','CROSS_WAREHOUSE','安保升级','2026-04-20','COMPLETED','3','8','2026-04-18 09:53:07','2026-04-20 18:17:03',0),(5,10,'WH-SH-001','上海监管仓A库','WH-SH-002','上海监管仓B库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','3','3','2026-04-18 09:54:23','2026-04-18 20:08:09',1),(6,10,'WH-SH-001','上海监管仓A库','WH-SH-002','上海监管仓B库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','3','3','2026-04-18 09:54:52','2026-04-18 20:08:09',1),(7,10,'WH-SH-001','上海监管仓A库','WH-XJ-002','乌鲁木齐A仓','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','3','3','2026-04-18 11:15:09','2026-04-18 20:08:09',1),(8,10,'WH-SH-001','上海监管仓A库','WH-XJ-002','乌鲁木齐A仓','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','3','3','2026-04-18 11:15:11','2026-04-18 20:08:09',1),(9,10,'WH-SH-001','上海监管仓A库','WH-XJ-002','乌鲁木齐A仓','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','3','3','2026-04-18 11:15:25','2026-04-18 20:08:09',1),(10,10,'WH-SH-001','上海监管仓A库','WH-XJ-002','乌鲁木齐A仓','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','3','3','2026-04-18 11:15:33','2026-04-18 20:08:09',1),(11,10,'WH-SH-001','上海监管仓A库','WH-SH-002','上海监管仓B库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','2','2','2026-04-18 11:22:16','2026-04-18 20:08:09',1),(12,10,'WH-SH-001','上海监管仓A库','WH-SH-002','上海监管仓B库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','2','2','2026-04-18 11:22:21','2026-04-18 20:08:09',1),(13,10,'WH-SH-001','上海监管仓A库','WH-SH-002','上海监管仓B库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','2','2','2026-04-18 12:57:41','2026-04-18 20:08:09',1),(14,10,'WH-SH-001','上海监管仓A库','WH-SH-002','上海监管仓B库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','2','2','2026-04-18 12:57:45','2026-04-18 20:08:09',1),(15,10,'WH-SH-001','上海监管仓A库','WH-SH-002','上海监管仓B库','CROSS_WAREHOUSE','安保升级',NULL,'CANCELLED','2','8','2026-04-18 12:57:54','2026-04-19 14:03:17',0),(16,1,'','','WH-SZ-002','深圳福保库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','1','1','2026-04-18 13:15:39','2026-04-18 20:08:09',1),(17,1,'','','WH-SZ-002','深圳福保库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','1','1','2026-04-18 13:16:03','2026-04-18 20:08:09',1),(18,1,'','','WH-SZ-002','深圳福保库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','1','1','2026-04-18 13:16:08','2026-04-18 20:08:09',1),(19,1,'','','WH-SZ-002','深圳福保库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','1','1','2026-04-18 13:16:13','2026-04-18 20:08:09',1),(20,1,'','','WH-SZ-002','深圳福保库','INTERNAL','安保升级',NULL,'DRAFT','2','2','2026-04-18 13:25:55','2026-04-18 20:08:09',1),(21,1,'','','WH-SZ-002','深圳福保库','INTERNAL','安保升级',NULL,'DRAFT','2','2','2026-04-18 13:28:40','2026-04-18 20:08:09',1),(22,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:25','2026-04-18 20:08:09',1),(23,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:29','2026-04-18 20:08:09',1),(24,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:33','2026-04-18 20:08:09',1),(25,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:45','2026-04-18 20:08:09',1),(26,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:46','2026-04-18 20:08:09',1),(27,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:46','2026-04-18 20:08:09',1),(28,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:46','2026-04-18 20:08:09',1),(29,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:47','2026-04-18 20:08:09',1),(30,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:47','2026-04-18 20:08:09',1),(31,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:47','2026-04-18 20:08:09',1),(32,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:47','2026-04-18 20:08:09',1),(33,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:47','2026-04-18 20:08:09',1),(34,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级','2026-04-18','COMPLETED','8','9','2026-04-18 14:10:48','2026-04-18 17:36:26',0),(35,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:48','2026-04-18 20:08:09',1),(36,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级',NULL,'DRAFT','8','8','2026-04-18 14:10:48','2026-04-18 20:08:09',1),(37,1,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级','2026-04-18','COMPLETED','8','9','2026-04-18 14:10:48','2026-04-18 17:36:23',0),(38,18,'WH-SZ-001','深圳自管仓主库','WH-SZ-003','深圳国际仓','CROSS_WAREHOUSE','安保升级','2026-04-18','COMPLETED','2','8','2026-04-18 14:12:22','2026-04-18 17:35:33',0),(39,18,'WH-SZ-001','深圳自管仓主库','WH-SZ-003','深圳国际仓','CROSS_WAREHOUSE','安保升级','2026-04-18','COMPLETED','2','8','2026-04-18 14:12:34','2026-04-18 17:22:29',0),(40,18,'WH-SZ-001','深圳自管仓主库','WH-SZ-002','深圳福保库','CROSS_WAREHOUSE','安保升级','2026-04-18','COMPLETED','2','8','2026-04-18 14:42:12','2026-04-18 17:22:31',0),(41,8,'','','WH-SZ-001','深圳自管仓主库','CROSS_WAREHOUSE','安保升级','2026-04-18','COMPLETED','2','8','2026-04-18 15:13:40','2026-04-18 17:22:24',0),(42,8,'','','WH-SZ-002','深圳福保库','CROSS_WAREHOUSE','安保升级需求','2026-04-18','COMPLETED','2','8','2026-04-18 15:36:43','2026-04-18 17:35:41',0),(43,4,'','','WH-SH-001','上海监管仓A库','CROSS_WAREHOUSE','安保升级','2026-04-19','COMPLETED','2','9','2026-04-18 20:12:09','2026-04-19 08:02:14',0),(44,9,'','','WH-XJ-002','乌鲁木齐A仓','CROSS_WAREHOUSE','转移到新的仓库','2026-04-19','COMPLETED','2','8','2026-04-19 09:39:23','2026-04-19 09:41:22',0),(45,2,'','','WH-SZ-003','深圳国际仓','CROSS_WAREHOUSE','安保升级','2026-04-19','COMPLETED','2','9','2026-04-19 12:11:05','2026-04-19 13:19:25',0),(46,7,'','','WH-SZ-002','深圳福保库','CROSS_WAREHOUSE','安保要求','2026-04-19','COMPLETED','8','8','2026-04-19 12:17:25','2026-04-19 12:53:47',0),(47,3,'','','WH-SZ-001','深圳自管仓主库','INTERNAL','安保升级',NULL,'CANCELLED','9','9','2026-04-19 14:06:19','2026-04-19 14:25:14',0);
/*!40000 ALTER TABLE `collateral_transfer` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `collateral_warehouse_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collateral_warehouse_in` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zone_id` bigint DEFAULT NULL,
  `warehouse_id` bigint DEFAULT NULL,
  `bu_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bu_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collateral_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collateral_value` decimal(18,2) DEFAULT NULL,
  `credit_agreement_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intake_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_step` int DEFAULT NULL,
  `data_source` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ext_data` text COLLATE utf8mb4_unicode_ci,
  `submitted_at` datetime DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int DEFAULT '0',
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wh_code` (`wh_code`),
  KEY `idx_status` (`status`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_bu` (`bu_code`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_wh_in_status_bu_created` (`status`,`bu_code`,`created_at`),
  KEY `idx_wh_in_customer_created` (`customer_id`,`created_at`),
  KEY `idx_wh_in_type_status` (`intake_type`,`status`),
  KEY `idx_wh_in_data_source` (`data_source`),
  KEY `idx_zone_id` (`zone_id`),
  KEY `idx_warehouse_id` (`warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `collateral_warehouse_in` WRITE;
/*!40000 ALTER TABLE `collateral_warehouse_in` DISABLE KEYS */;
INSERT INTO `collateral_warehouse_in` VALUES (1,'WH-SZ-001',NULL,3,'Test BU','BU001','Test',NULL,'REAL_ESTATE',100000.00,NULL,'NEW','COMPLETED',4,'MANUAL',NULL,NULL,NULL,NULL,'2026-04-16 15:49:35','admin','wm01','2026-04-15 18:25:02','2026-04-16 15:49:35',0,6),(2,'CBU-NEW-00003',2,8,'押品管理','CBU','东君','WH-2026-007','REAL_ESTATE',5000000.00,'202604150123','NEW','COMPLETED',5,'MANUAL','万达中心',NULL,'2026-04-15 19:46:27',NULL,'2026-04-18 09:34:06','System Administrator','9','2026-04-15 18:54:36','2026-04-18 09:34:06',0,6),(3,'CBU-NEW-00001',NULL,NULL,'车贷部','CBU','虾道友','WH-2026-008','MOVABLE',1500000.00,'20260415009','NEW','COMPLETED',4,'MANUAL','S800',NULL,'2026-04-15 19:46:18',NULL,'2026-04-16 15:49:35','System Administrator','仓库经理 吴九','2026-04-15 19:46:17','2026-04-16 15:49:35',0,5),(4,'WH-SH-001',1,1,'','FMU','金童','WH-2026-0401','RIGHTS',5080000.00,'2026041801','NEW','COMPLETED',4,'MANUAL','股权质押',NULL,'2026-04-15 21:06:16',NULL,'2026-04-16 15:49:35','System Administrator','9','2026-04-15 21:06:16','2026-04-16 15:49:35',0,6),(6,'CBU-NEW-00002',NULL,NULL,'信贷','CBU','甘九真','20260108','MARGIN',10000000.00,'202604160128','NEW','COMPLETED',5,'MANUAL','轮回殿股权',NULL,'2026-04-16 14:59:48',NULL,'2026-04-20 11:59:27','业务经理 张三','wm01','2026-04-16 14:59:47','2026-04-20 11:59:27',0,5),(7,'RMU-NEW-00003',2,7,'风险一部','RMU','元媱','20890011','MOVABLE',8800000.00,'202604160145','NEW','COMPLETED',5,'MANUAL','万年灵液',NULL,'2026-04-16 15:07:58',NULL,'2026-04-17 20:25:57','业务经理 张三','8','2026-04-16 15:07:58','2026-04-17 20:25:57',0,6),(8,'WH-SZ-002',NULL,7,'金融一部','FMU','古或今','305001','OTHER',11000000.00,'20260416987','NEW','COMPLETED',4,'MANUAL','道果5枚',NULL,'2026-04-16 15:10:43',NULL,'2026-04-16 15:49:35','业务经理 李四','wm01','2026-04-16 15:10:43','2026-04-16 15:49:35',0,7),(9,'WH-XJ-002',2,7,'金融二部','FMU','李元究','5038','RIGHTS',90000000.00,'20260416563','NEW','COMPLETED',5,'MANUAL','掌天瓶',NULL,'2026-04-18 08:23:19',NULL,'2026-04-18 09:34:41','业务经理 李四','8','2026-04-16 15:12:46','2026-04-18 09:34:41',0,12),(10,'CBU-NEW-00004',1,1,'公司一部','CBU','呼言道人','201898376','MOVABLE',1000000.00,'202604170123','NEW','COMPLETED',5,'MANUAL','灵酒一滘',NULL,'2026-04-17 19:42:24',NULL,'2026-04-17 20:26:04','业务经理 张三','wm01','2026-04-17 19:42:24','2026-04-17 20:26:04',0,5),(11,'FMU-NEW-00002',2,3,'金融一部','FMU','弥罗老祖','2018387766','RIGHTS',10000000.00,'202604170932','NEW','SUBMITTED',1,'MANUAL','真言门股权10%',NULL,'2026-04-17 19:51:29',NULL,NULL,'业务经理 李四','业务经理 李四','2026-04-17 19:51:29','2026-04-17 19:51:29',0,1),(12,'CBU-NEW-00005',2,3,'公司一部','CBU','冰魄仙子','50380125','REAL_ESTATE',8000000.00,'202604170143','NEW','COMPLETED',5,'MANUAL','虚天鼎一座',NULL,'2026-04-17 19:57:38',NULL,'2026-04-21 09:48:14','业务经理 李四','wm01','2026-04-17 19:57:38','2026-04-21 09:48:14',0,5),(13,'RBU-NEW-00001',2,3,'零售一部','RBU','东君','201892137891','REAL_ESTATE',600000.00,'202604180128','NEW','COMPLETED',5,'MANUAL','杭州湾库里南 极氪9X ',NULL,'2026-04-18 09:51:36',NULL,'2026-04-20 11:59:33','业务经理 李四','wm01','2026-04-18 09:51:36','2026-04-20 11:59:33',0,5),(14,'RBU-NEW-00002',2,7,'零售一部','RBU','银月','2302182147','MOVABLE',1000000.00,'202604180321','NEW','IN_REVIEW',2,'MANUAL','S800 一辆，银灰双拼色',NULL,'2026-04-18 09:59:15',NULL,NULL,'业务经理 李四','bm01','2026-04-18 09:59:15','2026-04-20 12:10:27',0,2),(15,'RBU-NEW-00003',1,1,'零售三部','RBU','南宫婉','20880888','MOVABLE',1800000.00,'202604180543','NEW','COMPLETED',5,'MANUAL','问界M9一辆',NULL,'2026-04-18 10:02:48',NULL,'2026-04-20 11:59:45','业务经理 李四','wm01','2026-04-18 10:02:48','2026-04-20 11:59:45',0,5),(16,'RBU-NEW-00004',2,7,'零售三部','RBU','金童','','MOVABLE',20000000.00,'202604180923','NEW','COMPLETED',5,'MANUAL','上品灵石，10万块',NULL,'2026-04-18 10:05:19',NULL,'2026-04-21 17:45:17','业务经理 李四','wm01','2026-04-18 10:05:19','2026-04-21 17:45:17',0,5),(17,'RBU-NEW-00005',2,7,'零售二部','RBU','冰凤','','MOVABLE',580000.00,'20260418329','NEW','COMPLETED',5,'MANUAL','迈巴赫 一辆',NULL,'2026-04-18 13:48:50',NULL,'2026-04-18 13:57:17','业务经理 张三','wm01','2026-04-18 13:48:50','2026-04-18 13:57:17',0,5),(18,'WH-SZ-003',2,8,'零售二部','RBU','柳乐儿','','MOVABLE',800000.00,'202604280123','NEW','COMPLETED',5,'MANUAL','S800 一辆',NULL,'2026-04-18 13:50:41',NULL,'2026-04-18 13:54:55','业务经理 张三','wm01','2026-04-18 13:50:41','2026-04-18 13:54:55',0,8),(19,'RBU-NEW-00006',2,8,'零售一部','RBU','云霓','2123489218093','MOVABLE',500000.00,'202604200123','NEW','COMPLETED',5,'MANUAL','问界M9一辆',NULL,'2026-04-20 09:17:12',NULL,'2026-04-20 12:00:10','业务经理 张三','wm01','2026-04-20 09:17:12','2026-04-20 12:00:10',0,5),(20,'RBU-NEW-00007',2,3,'零售二部','RBU','紫灵','2123120938','MOVABLE',600000.00,'2026042001234','NEW','COMPLETED',5,'MANUAL','极氪9X',NULL,'2026-04-20 11:20:05',NULL,'2026-04-20 17:44:18','业务经理 张三','wm01','2026-04-20 11:20:05','2026-04-20 17:44:18',0,5),(21,'RBU-NEW-00008',2,8,'零售三部','RBU','啼魂','2342309840','MOVABLE',500000.00,'202604200154','NEW','COMPLETED',5,'MANUAL','',NULL,'2026-04-20 11:27:10',NULL,'2026-04-20 17:44:09','业务经理 张三','wm01','2026-04-20 11:27:10','2026-04-20 17:44:09',0,5),(22,'RBU-NEW-00009',2,7,'零售二部','RBU','冰魄仙子','2134209890412','MOVABLE',600000.00,'202604201387','NEW','COMPLETED',5,'MANUAL','极氪9X 一辆',NULL,'2026-04-20 12:12:59',NULL,'2026-04-21 17:45:01','业务经理 张三','wm01','2026-04-20 12:12:59','2026-04-21 17:45:01',0,5),(23,'RBU-NEW-00010',2,7,'零售一部','RBU','萧晋寒','3534898752','MOVABLE',600000.00,'20260420987','NEW','COMPLETED',5,'MANUAL','方程豹一辆',NULL,'2026-04-20 15:48:39',NULL,'2026-04-20 17:43:59','合规专员 孙七','wm01','2026-04-20 13:46:36','2026-04-20 17:43:59',0,5),(24,'RBU-NEW-00011',2,7,'零售二部','RBU','厉飞雨','2343214156','MOVABLE',6000000.00,'202604210123','NEW','COMPLETED',5,'MANUAL','贵金属一批',NULL,'2026-04-21 08:27:56',NULL,'2026-04-21 12:44:34','业务经理 张三','wm01','2026-04-21 08:27:50','2026-04-21 12:44:34',0,5);
/*!40000 ALTER TABLE `collateral_warehouse_in` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `collateral_warehouse_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collateral_warehouse_out` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint NOT NULL,
  `out_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `out_reason` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `out_amount` decimal(18,2) DEFAULT NULL,
  `out_percentage` decimal(5,2) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_step` int DEFAULT '1',
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_wh_in` (`wh_in_id`),
  KEY `idx_wh_out_type_status` (`out_type`,`status`),
  KEY `idx_wh_out_reason` (`out_reason`),
  KEY `idx_wh_out_created` (`created_at`),
  KEY `idx_wh_out_wh_in_status` (`wh_in_id`,`status`),
  CONSTRAINT `collateral_warehouse_out_ibfk_1` FOREIGN KEY (`wh_in_id`) REFERENCES `collateral_warehouse_in` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `collateral_warehouse_out` WRITE;
/*!40000 ALTER TABLE `collateral_warehouse_out` DISABLE KEYS */;
INSERT INTO `collateral_warehouse_out` VALUES (1,10,'PARTIAL','',500000.00,50.00,'COMPLETED',1,'1','1','2026-04-18 07:18:28','2026-04-18 07:18:56',0),(2,10,'PARTIAL','',500000.00,50.00,'DRAFT',1,'1','1','2026-04-18 08:35:29','2026-04-18 20:08:10',1),(3,7,'PARTIAL','已还贷款80%',4000000.00,50.00,'DRAFT',1,'2','2','2026-04-18 11:26:07','2026-04-18 20:08:10',1),(4,7,'PARTIAL','已还贷款80%',4000000.00,50.00,'DRAFT',1,'2','2','2026-04-18 11:26:19','2026-04-18 20:08:10',1),(5,2,'PARTIAL','还贷款超50%',1000000.00,20.00,'DRAFT',1,'1','1','2026-04-18 13:20:21','2026-04-18 20:08:10',1),(6,2,'PARTIAL','还贷款超50%',1000000.00,20.00,'DRAFT',1,'1','1','2026-04-18 13:20:26','2026-04-18 20:08:10',1),(7,2,'PARTIAL','还贷款超50%',1000000.00,20.00,'DRAFT',1,'1','1','2026-04-18 13:21:02','2026-04-18 20:08:10',1),(8,2,'PARTIAL','还贷款超50%',1000000.00,20.00,'DRAFT',1,'1','1','2026-04-18 13:21:24','2026-04-18 20:08:10',1),(9,7,'PARTIAL','已经还款超50%',880000.00,10.00,'DRAFT',1,'2','2','2026-04-18 15:16:22','2026-04-18 20:08:10',1),(10,1,'PARTIAL','已还清60%贷款',50000.00,50.00,'COMPLETED',1,'9','2','2026-04-18 18:06:25','2026-04-19 07:57:21',0),(11,1,'FULL','已还清贷款',NULL,NULL,'COMPLETED',1,'2','4','2026-04-20 18:16:07','2026-04-20 18:23:50',0),(12,3,'FULL','贷款还清',NULL,NULL,'CANCELLED',1,'6','6','2026-04-21 13:03:07','2026-04-21 13:54:03',0),(13,7,'FULL','贷款还清',8800000.00,100.00,'COMPLETED',1,'6','2','2026-04-21 14:27:01','2026-04-21 14:30:42',0);
/*!40000 ALTER TABLE `collateral_warehouse_out` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','<< Flyway Baseline >>','BASELINE','<< Flyway Baseline >>',NULL,'cawms_user','2026-04-15 10:40:32',0,1),(2,'2','Fix warehouse in base columns','SQL','V2__Fix_warehouse_in_base_columns.sql',78787420,'cawms_user','2026-04-15 10:40:33',12,1),(3,'3','Fix all missing columns','SQL','V3__Fix_all_missing_columns.sql',78787420,'cawms_user','2026-04-15 10:40:33',5,1),(4,'4','Add warehouse zone and warehouse tables','SQL','V4__Add_warehouse_zone_and_warehouse_tables.sql',918888774,'cawms_user','2026-04-17 01:44:45',62,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `loan_out_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan_out_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `loan_out_id` bigint NOT NULL,
  `step_number` int NOT NULL,
  `step_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci,
  `approved_at` datetime DEFAULT NULL,
  `approver_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `due_date` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `processing_minutes` int DEFAULT NULL,
  `auto_approved` tinyint(1) DEFAULT NULL,
  `approval_attachments` text COLLATE utf8mb4_unicode_ci,
  `ext_data` text COLLATE utf8mb4_unicode_ci,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_loan_out_step` (`loan_out_id`,`step_number`),
  CONSTRAINT `loan_out_approval_ibfk_1` FOREIGN KEY (`loan_out_id`) REFERENCES `collateral_loan_out` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `loan_out_approval` WRITE;
/*!40000 ALTER TABLE `loan_out_approval` DISABLE KEYS */;
INSERT INTO `loan_out_approval` VALUES (1,4,1,'业务部门提交申请','BUSINESS_MANAGER','2','APPROVED','同意借出','2026-04-16 20:57:46','2','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,10,0,NULL,NULL,1),(2,4,2,'风险部门初审','RISK_OFFICER','5','APPROVED','同意借出','2026-04-16 22:31:08','5','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,103,0,NULL,NULL,2),(3,4,3,'合规部门审核','COMPLIANCE_OFFICER','6','APPROVED','同意借出','2026-04-17 07:38:57','6','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,651,0,NULL,NULL,2),(4,4,4,'资金部门审批','TREASURY_OFFICER','6','APPROVED','同意借出','2026-04-17 07:40:45','6','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,653,0,NULL,NULL,2),(5,4,5,'仓库管理员确认','WAREHOUSE_MANAGER','6','APPROVED','同意借出','2026-04-17 07:40:56','6','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,653,0,NULL,NULL,2),(6,4,6,'完成借出','SYSTEM','SYSTEM','APPROVED','系统自动完成借出','2026-04-17 09:05:06','SYSTEM','2026-04-16 20:47:30','2026-04-19 15:44:19',NULL,NULL,NULL,0,NULL,NULL,1),(7,5,1,'业务部门提交申请','BUSINESS_MANAGER','2','APPROVED','同意借出','2026-04-16 20:58:04','2','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,10,0,NULL,NULL,1),(8,5,2,'风险部门初审','RISK_OFFICER','5','APPROVED','同意借出','2026-04-16 22:30:53','5','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,103,0,NULL,NULL,2),(9,5,3,'合规部门审核','COMPLIANCE_OFFICER','6','APPROVED','同意借出','2026-04-17 07:38:46','6','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,651,0,NULL,NULL,2),(10,5,4,'资金部门审批','TREASURY_OFFICER','6','APPROVED','同意借出','2026-04-17 07:40:47','6','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,653,0,NULL,NULL,2),(11,5,5,'仓库管理员确认','WAREHOUSE_MANAGER','8','APPROVED','同意借出','2026-04-17 07:43:58','8','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,656,0,NULL,NULL,2),(12,5,6,'完成借出','SYSTEM','SYSTEM','APPROVED','系统自动完成借出','2026-04-17 09:05:06','SYSTEM','2026-04-16 20:47:30','2026-04-19 15:44:19',NULL,NULL,NULL,0,NULL,NULL,1),(13,6,1,'业务部门提交申请','BUSINESS_MANAGER','2','APPROVED','同意借出','2026-04-16 20:58:08','2','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,10,0,NULL,NULL,1),(14,6,2,'风险部门初审','RISK_OFFICER','4','APPROVED','同意借出','2026-04-16 22:28:42','4','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,101,0,NULL,NULL,2),(15,6,3,'合规部门审核','COMPLIANCE_OFFICER','6','APPROVED','同意借出','2026-04-17 07:36:28','6','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,648,0,NULL,NULL,2),(16,6,4,'资金部门审批','TREASURY_OFFICER','6','APPROVED','同意借出','2026-04-17 07:40:51','6','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,653,0,NULL,NULL,2),(17,6,5,'仓库管理员确认','WAREHOUSE_MANAGER','8','APPROVED','同意借出','2026-04-17 07:43:45','8','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,656,0,NULL,NULL,2),(18,6,6,'完成借出','SYSTEM','8','APPROVED','同意借出','2026-04-17 07:44:04','8','2026-04-16 20:47:30','2026-04-17 08:45:47',NULL,NULL,656,0,NULL,NULL,2),(19,7,1,'业务部门提交申请','BUSINESS_MANAGER','1','APPROVED','同意借出','2026-04-17 19:33:22','1','2026-04-17 09:47:09','2026-04-17 19:33:22',NULL,NULL,586,NULL,NULL,NULL,NULL),(20,7,2,'风险部门初审','RISK_OFFICER','1','APPROVED','同意借出','2026-04-17 19:33:29','1','2026-04-17 09:47:09','2026-04-17 19:33:29',NULL,NULL,586,NULL,NULL,NULL,NULL),(21,7,3,'合规部门审核','COMPLIANCE_OFFICER','1','APPROVED','同意借出','2026-04-17 19:33:32','1','2026-04-17 09:47:09','2026-04-17 19:33:32',NULL,NULL,586,NULL,NULL,NULL,NULL),(22,7,4,'资金部门审批','TREASURY_OFFICER','1','APPROVED','同意借出','2026-04-17 19:37:22','1','2026-04-17 09:47:09','2026-04-17 19:37:22',NULL,NULL,590,NULL,NULL,NULL,NULL),(23,7,5,'仓库管理员确认','WAREHOUSE_MANAGER','8','APPROVED','同意借出','2026-04-17 20:31:38','8','2026-04-17 09:47:09','2026-04-17 20:31:38',NULL,NULL,644,NULL,NULL,NULL,NULL),(24,7,6,'完成借出','SYSTEM','SYSTEM','APPROVED','系统自动完成借出','2026-04-17 20:31:38','SYSTEM','2026-04-17 09:47:09','2026-04-17 20:31:38',NULL,NULL,644,NULL,NULL,NULL,NULL),(25,8,1,'业务部门提交申请','BUSINESS_MANAGER','3','APPROVED','同意借出','2026-04-18 10:06:55','3','2026-04-18 10:06:44','2026-04-18 10:06:55',NULL,NULL,0,NULL,NULL,NULL,NULL),(26,8,2,'风险部门初审','RISK_OFFICER','2','APPROVED','同意借出','2026-04-18 13:58:42','2','2026-04-18 10:06:44','2026-04-18 13:58:42',NULL,NULL,231,NULL,NULL,NULL,NULL),(27,8,3,'合规部门审核','COMPLIANCE_OFFICER','7','APPROVED','同意借出','2026-04-18 14:00:10','7','2026-04-18 10:06:44','2026-04-18 14:00:10',NULL,NULL,233,NULL,NULL,NULL,NULL),(28,8,4,'资金部门审批','TREASURY_OFFICER','8','APPROVED','同意借出','2026-04-19 14:32:23','8','2026-04-18 10:06:44','2026-04-19 14:32:23',NULL,NULL,1705,NULL,NULL,NULL,NULL),(29,8,5,'仓库管理员确认','WAREHOUSE_MANAGER','2','APPROVED','同意借出','2026-04-19 15:52:27','2','2026-04-18 10:06:44','2026-04-19 15:52:27',NULL,NULL,1785,NULL,NULL,NULL,NULL),(30,8,6,'完成借出','SYSTEM','SYSTEM','APPROVED','系统自动完成借出','2026-04-19 15:52:27','SYSTEM','2026-04-18 10:06:44','2026-04-19 15:52:27',NULL,NULL,1785,NULL,NULL,NULL,NULL),(31,9,1,'业务部门提交申请','BUSINESS_MANAGER','2','APPROVED','同意借出','2026-04-18 13:58:46','2','2026-04-18 13:04:46','2026-04-18 13:58:46',NULL,NULL,54,NULL,NULL,NULL,NULL),(32,9,2,'风险部门初审','RISK_OFFICER','5','APPROVED','同意借出','2026-04-18 14:02:35','5','2026-04-18 13:04:46','2026-04-18 14:02:35',NULL,NULL,57,NULL,NULL,NULL,NULL),(33,9,3,'合规部门审核','COMPLIANCE_OFFICER','8','APPROVED','同意借出','2026-04-19 14:32:26','8','2026-04-18 13:04:46','2026-04-19 14:32:26',NULL,NULL,1527,NULL,NULL,NULL,NULL),(34,9,4,'资金部门审批','TREASURY_OFFICER','2','APPROVED','同意借出','2026-04-21 09:46:36','2','2026-04-18 13:04:46','2026-04-21 09:46:36',NULL,NULL,4121,NULL,NULL,NULL,NULL),(35,9,5,'仓库管理员确认','WAREHOUSE_MANAGER','8','APPROVED','同意借出','2026-04-21 09:48:40','8','2026-04-18 13:04:46','2026-04-21 09:48:40',NULL,NULL,4123,NULL,NULL,NULL,NULL),(36,9,6,'完成借出','SYSTEM','SYSTEM','APPROVED','系统自动完成借出','2026-04-21 09:48:40','SYSTEM','2026-04-18 13:04:46','2026-04-21 09:48:40',NULL,NULL,4123,NULL,NULL,NULL,NULL),(37,10,1,'业务部门提交申请','BUSINESS_MANAGER','2','APPROVED','同意借出','2026-04-21 09:47:13','2','2026-04-20 18:12:21','2026-04-21 09:47:13',NULL,NULL,934,NULL,NULL,NULL,NULL),(38,10,2,'风险部门初审','RISK_OFFICER','8','APPROVED','同意借出','2026-04-21 09:48:42','8','2026-04-20 18:12:21','2026-04-21 09:48:42',NULL,NULL,936,NULL,NULL,NULL,NULL),(39,10,3,'合规部门审核','COMPLIANCE_OFFICER','6','APPROVED','同意借出','2026-04-21 09:50:06','6','2026-04-20 18:12:21','2026-04-21 09:50:06',NULL,NULL,937,NULL,NULL,NULL,NULL),(40,10,4,'资金部门审批','TREASURY_OFFICER','2','APPROVED','同意借出','2026-04-21 11:44:50','2','2026-04-20 18:12:21','2026-04-21 11:44:50',NULL,NULL,1052,NULL,NULL,NULL,NULL),(41,10,5,'仓库管理员确认','WAREHOUSE_MANAGER','2','APPROVED','同意借出','2026-04-21 11:47:53','2','2026-04-20 18:12:21','2026-04-21 11:47:53',NULL,NULL,1055,NULL,NULL,NULL,NULL),(42,10,6,'完成借出','SYSTEM','SYSTEM','APPROVED','系统自动完成借出','2026-04-21 11:47:53','SYSTEM','2026-04-20 18:12:21','2026-04-21 11:47:53',NULL,NULL,1055,NULL,NULL,NULL,NULL),(43,11,1,'业务部门提交申请','BUSINESS_MANAGER','2','APPROVED','同意借出','2026-04-21 09:47:16','2','2026-04-20 18:14:19','2026-04-21 09:47:16',NULL,NULL,932,NULL,NULL,NULL,NULL),(44,11,2,'风险部门初审','RISK_OFFICER','8','APPROVED','同意借出','2026-04-21 09:48:45','8','2026-04-20 18:14:19','2026-04-21 09:48:45',NULL,NULL,934,NULL,NULL,NULL,NULL),(45,11,3,'合规部门审核','COMPLIANCE_OFFICER','6','APPROVED','同意借出','2026-04-21 09:49:43','6','2026-04-20 18:14:19','2026-04-21 09:49:43',NULL,NULL,935,NULL,NULL,NULL,NULL),(46,11,4,'资金部门审批','TREASURY_OFFICER','2','APPROVED','同意借出','2026-04-21 11:47:57','2','2026-04-20 18:14:19','2026-04-21 11:47:57',NULL,NULL,1053,NULL,NULL,NULL,NULL),(47,11,5,'仓库管理员确认','WAREHOUSE_MANAGER','8','APPROVED','同意借出','2026-04-21 17:24:17','wm01','2026-04-20 18:14:19','2026-04-21 17:24:17',NULL,NULL,1389,NULL,NULL,NULL,NULL),(48,11,6,'完成借出','SYSTEM','SYSTEM','APPROVED','系统自动完成借出','2026-04-21 17:24:17','SYSTEM','2026-04-20 18:14:19','2026-04-21 17:24:17',NULL,NULL,1389,NULL,NULL,NULL,NULL),(49,12,1,'业务部门提交申请','BUSINESS_MANAGER','2','APPROVED','同意借出','2026-04-21 12:04:29','bm01','2026-04-21 11:49:02','2026-04-21 12:04:29',NULL,NULL,15,NULL,NULL,NULL,NULL),(50,12,2,'风险部门初审','RISK_OFFICER','2','APPROVED','同意借出','2026-04-21 12:04:39','bm01','2026-04-21 11:49:02','2026-04-21 12:04:39',NULL,NULL,15,NULL,NULL,NULL,NULL),(51,12,3,'合规部门审核','COMPLIANCE_OFFICER','4','APPROVED','同意借出','2026-04-21 12:09:05','ro01','2026-04-21 11:49:02','2026-04-21 12:09:05',NULL,NULL,20,NULL,NULL,NULL,NULL),(52,12,4,'资金部门审批','TREASURY_OFFICER','4','APPROVED','同意借出','2026-04-21 12:09:40','ro01','2026-04-21 11:49:02','2026-04-21 12:09:40',NULL,NULL,20,NULL,NULL,NULL,NULL),(53,12,5,'仓库管理员确认','WAREHOUSE_MANAGER','4','APPROVED','同意借出','2026-04-21 12:09:52','ro01','2026-04-21 11:49:02','2026-04-21 12:09:52',NULL,NULL,20,NULL,NULL,NULL,NULL),(54,12,6,'完成借出','SYSTEM','SYSTEM','APPROVED','系统自动完成借出','2026-04-21 12:09:52','SYSTEM','2026-04-21 11:49:02','2026-04-21 12:09:52',NULL,NULL,20,NULL,NULL,NULL,NULL),(55,13,1,'业务部门提交申请','BUSINESS_MANAGER','2','APPROVED','同意借出','2026-04-21 13:14:02','bm01','2026-04-21 12:47:25','2026-04-21 13:14:02',NULL,NULL,26,NULL,NULL,NULL,NULL),(56,13,2,'风险部门初审','RISK_OFFICER','4','APPROVED','同意借出','2026-04-21 13:27:00','ro01','2026-04-21 12:47:25','2026-04-21 13:27:00',NULL,NULL,39,NULL,NULL,NULL,NULL),(57,13,3,'合规部门审核','COMPLIANCE_OFFICER','6','APPROVED','同意借出','2026-04-21 13:29:49','co01','2026-04-21 12:47:25','2026-04-21 13:29:49',NULL,NULL,42,NULL,NULL,NULL,NULL),(58,13,4,'资金部门审批','TREASURY_OFFICER','10','APPROVED','同意借出','2026-04-21 17:23:04','th01','2026-04-21 12:47:25','2026-04-21 17:23:04',NULL,NULL,275,NULL,NULL,NULL,NULL),(59,13,5,'仓库管理员确认','WAREHOUSE_MANAGER','8','APPROVED','同意借出','2026-04-21 17:24:27','wm01','2026-04-21 12:47:25','2026-04-21 17:24:27',NULL,NULL,277,NULL,NULL,NULL,NULL),(60,13,6,'完成借出','SYSTEM','SYSTEM','APPROVED','系统自动完成借出','2026-04-21 17:24:27','SYSTEM','2026-04-21 12:47:25','2026-04-21 17:24:27',NULL,NULL,277,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `loan_out_approval` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `loan_return_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan_return_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `loan_out_id` bigint NOT NULL,
  `step_number` int NOT NULL,
  `step_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `due_date` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `processing_minutes` int DEFAULT NULL,
  `auto_approved` tinyint(1) DEFAULT NULL,
  `return_remarks` text COLLATE utf8mb4_unicode_ci,
  `return_date` datetime DEFAULT NULL,
  `asset_condition` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condition_description` text COLLATE utf8mb4_unicode_ci,
  `settlement_amount` decimal(15,2) DEFAULT NULL,
  `settlement_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settlement_reference` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approval_attachments` text COLLATE utf8mb4_unicode_ci,
  `ext_data` text COLLATE utf8mb4_unicode_ci,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_loan_out_step` (`loan_out_id`,`step_number`),
  KEY `idx_status` (`status`),
  KEY `idx_approver_user` (`approver_user`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_loan_return_approval_loan_out_id` (`loan_out_id`),
  KEY `idx_loan_return_approval_step_status` (`step_number`,`status`),
  KEY `idx_loan_return_approval_approver_role` (`approver_role`),
  CONSTRAINT `loan_return_approval_ibfk_1` FOREIGN KEY (`loan_out_id`) REFERENCES `collateral_loan_out` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `loan_return_approval` WRITE;
/*!40000 ALTER TABLE `loan_return_approval` DISABLE KEYS */;
INSERT INTO `loan_return_approval` VALUES (1,5,1,'申请归还','SYSTEM','1','1','APPROVED','正常归还','2026-04-21 09:59:51','2026-04-21 09:59:51','2026-04-21 09:59:51',NULL,NULL,NULL,NULL,'正常归还','2026-04-21 09:59:51','GOOD',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,5,2,'仓库确认','SYSTEM','1','1','APPROVED','正常归还','2026-04-21 09:59:51','2026-04-21 09:59:51','2026-04-21 09:59:51',NULL,NULL,NULL,NULL,'正常归还','2026-04-21 09:59:51','GOOD',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,5,3,'财务结算','SYSTEM','1','1','APPROVED','正常归还','2026-04-21 09:59:51','2026-04-21 09:59:51','2026-04-21 09:59:51',NULL,NULL,NULL,NULL,'正常归还','2026-04-21 09:59:51','GOOD',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,5,4,'完成归还','SYSTEM','1','1','APPROVED','正常归还','2026-04-21 09:59:51','2026-04-21 09:59:51','2026-04-21 09:59:51',NULL,NULL,NULL,NULL,'正常归还','2026-04-21 09:59:51','GOOD',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,12,1,'申请归还','SYSTEM','8','wm01','APPROVED','正常归还','2026-04-21 12:17:28','2026-04-21 12:17:28','2026-04-21 12:17:28',NULL,NULL,NULL,NULL,'正常归还','2026-04-21 12:17:28','GOOD',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,12,2,'仓库确认','SYSTEM','8','wm01','APPROVED','正常归还','2026-04-21 12:17:28','2026-04-21 12:17:28','2026-04-21 12:17:28',NULL,NULL,NULL,NULL,'正常归还','2026-04-21 12:17:28','GOOD',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,12,3,'财务结算','SYSTEM','8','wm01','APPROVED','正常归还','2026-04-21 12:17:28','2026-04-21 12:17:28','2026-04-21 12:17:28',NULL,NULL,NULL,NULL,'正常归还','2026-04-21 12:17:28','GOOD',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,12,4,'完成归还','SYSTEM','8','wm01','APPROVED','正常归还','2026-04-21 12:17:28','2026-04-21 12:17:28','2026-04-21 12:17:28',NULL,NULL,NULL,NULL,'正常归还','2026-04-21 12:17:28','GOOD',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `loan_return_approval` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `overdue_alert_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `overdue_alert_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `alert_days_before` int DEFAULT NULL,
  `alert_recipients` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) DEFAULT NULL,
  `alert_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alert_template_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alert_frequency_hours` int DEFAULT NULL,
  `max_alert_count` int DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `overdue_alert_config` WRITE;
/*!40000 ALTER TABLE `overdue_alert_config` DISABLE KEYS */;
INSERT INTO `overdue_alert_config` VALUES (1,3,'admin@seabank.com.vn',1,NULL,NULL,24,0,NULL,'2026-04-15 17:39:05','2026-04-15 17:39:05',NULL,0);
/*!40000 ALTER TABLE `overdue_alert_config` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `overdue_alert_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `overdue_alert_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `loan_out_id` bigint NOT NULL,
  `alert_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alert_message` text COLLATE utf8mb4_unicode_ci,
  `alert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `recipients` text COLLATE utf8mb4_unicode_ci,
  `sent_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `sent_time` datetime DEFAULT NULL,
  `send_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `send_details` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_loan_out` (`loan_out_id`),
  KEY `idx_alert_time` (`alert_time`),
  KEY `idx_overdue_alert_type_time` (`alert_type`,`alert_time`),
  KEY `idx_overdue_alert_sent_status` (`sent_status`),
  CONSTRAINT `overdue_alert_log_ibfk_1` FOREIGN KEY (`loan_out_id`) REFERENCES `collateral_loan_out` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `overdue_alert_log` WRITE;
/*!40000 ALTER TABLE `overdue_alert_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `overdue_alert_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci,
  `config_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `editable` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`),
  KEY `idx_config_type` (`config_type`),
  KEY `idx_config_editable` (`editable`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_config` WRITE;
/*!40000 ALTER TABLE `system_config` DISABLE KEYS */;
INSERT INTO `system_config` VALUES (1,'system.name','CAWMS','STRING','系统名称',1,'2026-04-15 17:39:05','2026-04-24 18:51:04',NULL,NULL,0),(2,'system.version','1.0.0','STRING','系统版本',1,'2026-04-15 17:39:05','2026-04-16 08:56:55',NULL,NULL,0),(3,'integration.mode','demo','STRING','集成模式: demo, production',1,'2026-04-15 17:39:05','2026-04-16 08:56:55',NULL,NULL,0),(4,'jwt.expiration','28800000','NUMBER','JWT过期时间(毫秒): 8小时',1,'2026-04-15 17:39:05','2026-04-16 08:56:55',NULL,NULL,0);
/*!40000 ALTER TABLE `system_config` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `data_scope` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_roles` WRITE;
/*!40000 ALTER TABLE `system_roles` DISABLE KEYS */;
INSERT INTO `system_roles` VALUES (1,'SUPER_ADMIN','超级管理员','系统超级管理员，拥有所有权限','[\"系统超级管理员，拥有所有权限\",\"warehouse\",\"warehouse:list\",\"warehouse:create\",\"warehouse:edit\",\"warehouse:delete\",\"warehouse:approve\",\"warehouse:export\",\"loan\",\"loan:list\",\"loan:create\",\"loan:edit\",\"loan:delete\",\"loan:approve\",\"loan:return\",\"transfer\",\"transfer:list\",\"transfer:create\",\"transfer:edit\",\"transfer:delete\",\"reports\",\"reports:inbound\",\"reports:loan\",\"reports:overdue\",\"reports:financial\",\"approval\",\"approval:pending\",\"approval:completed\",\"approval:history\",\"system\",\"system:users\",\"system:roles\",\"system:permissions\",\"system:audit-logs\",\"system:config\"]','ALL','ACTIVE','2026-04-15 17:39:05','2026-04-16 09:18:23',NULL,NULL,0),(2,'SYSTEM_ADMIN','系统管理员','系统管理员','[\"系统管理员\",\"system\",\"system:users\",\"system:roles\",\"system:permissions\",\"system:audit-logs\",\"system:config\"]','ALL','ACTIVE','2026-04-15 17:39:05','2026-04-16 09:20:13',NULL,NULL,0),(3,'CTS_CLUSTER_HEAD','CTS集群主管','CTS集群主管','[\"CTS集群主管\",\"warehouse:approve\",\"reports\",\"reports:inbound\",\"reports:loan\",\"reports:overdue\",\"reports:financial\",\"approval\",\"approval:pending\",\"approval:completed\",\"approval:history\",\"loan:approve\"]','CLUSTER','ACTIVE','2026-04-15 17:39:05','2026-04-16 09:18:42',NULL,NULL,0),(4,'PROVINCIAL_OPS_HEAD','省级运营主管','省级运营主管','[\"省级运营主管\",\"warehouse:approve\",\"loan:approve\",\"approval\",\"approval:pending\",\"approval:completed\",\"approval:history\",\"reports\",\"reports:inbound\",\"reports:loan\",\"reports:overdue\",\"reports:financial\"]','PROVINCE','ACTIVE','2026-04-15 17:39:05','2026-04-16 09:18:52',NULL,NULL,0),(5,'TREASURY_HEAD','资金中心主管','资金中心主管','[\"资金中心主管\",\"loan:list\",\"loan:edit\",\"loan:delete\",\"loan:approve\",\"loan:return\",\"transfer\",\"transfer:list\",\"transfer:create\",\"transfer:edit\",\"transfer:delete\",\"reports\",\"reports:inbound\",\"reports:loan\",\"reports:overdue\",\"reports:financial\",\"approval\",\"approval:pending\",\"approval:completed\",\"approval:history\",\"warehouse:approve\",\"warehouse:list\"]','TREASURY','ACTIVE','2026-04-15 17:39:05','2026-04-21 17:16:06',NULL,NULL,0),(6,'WAREHOUSE_MANAGER','仓库管理员','仓库管理员','[\"仓库管理员\",\"warehouse\",\"warehouse:list\",\"warehouse:create\",\"warehouse:edit\",\"warehouse:delete\",\"warehouse:approve\",\"warehouse:export\",\"loan\",\"loan:list\",\"loan:create\",\"loan:edit\",\"loan:delete\",\"loan:approve\",\"loan:return\",\"transfer\",\"transfer:list\",\"transfer:create\",\"transfer:edit\",\"transfer:delete\",\"reports\",\"reports:inbound\",\"reports:loan\",\"reports:overdue\",\"reports:financial\"]','BU','ACTIVE','2026-04-15 17:39:05','2026-04-16 09:19:15',NULL,NULL,0),(7,'CREDIT_OFFICER','信贷处理人员','信贷处理人员','[\"信贷处理人员\",\"warehouse\",\"warehouse:list\",\"warehouse:create\",\"warehouse:edit\",\"warehouse:delete\",\"warehouse:approve\",\"warehouse:export\",\"loan\",\"loan:list\",\"loan:create\",\"loan:edit\",\"loan:delete\",\"loan:approve\",\"loan:return\",\"transfer\",\"transfer:list\",\"transfer:create\",\"transfer:edit\",\"transfer:delete\",\"reports\",\"reports:inbound\",\"reports:loan\",\"reports:overdue\",\"reports:financial\"]','BU','ACTIVE','2026-04-15 17:39:05','2026-04-16 09:19:24',NULL,NULL,0),(8,'BU_OFFICER','BU/CTS官员','BU/CTS官员','[\"BU/CTS官员\",\"warehouse:approve\",\"loan:approve\",\"loan:return\",\"approval\",\"approval:pending\",\"approval:completed\",\"approval:history\",\"reports\",\"reports:inbound\",\"reports:loan\",\"reports:overdue\",\"reports:financial\"]','BU','ACTIVE','2026-04-15 17:39:05','2026-04-16 09:19:37',NULL,NULL,0),(9,'BUSINESS_MANAGER','业务经理','负责业务初审与申请提交审核','[\"负责业务初审与申请提交审核\",\"warehouse\",\"warehouse:list\",\"warehouse:create\",\"warehouse:edit\",\"warehouse:delete\",\"warehouse:approve\",\"warehouse:export\",\"loan\",\"loan:list\",\"loan:create\",\"loan:edit\",\"loan:delete\",\"loan:approve\",\"loan:return\",\"transfer\",\"transfer:list\",\"transfer:create\",\"transfer:edit\",\"transfer:delete\",\"reports\",\"reports:inbound\",\"reports:loan\",\"reports:overdue\",\"reports:financial\",\"approval\",\"approval:pending\",\"approval:completed\",\"approval:history\"]','BU','ACTIVE','2026-04-15 21:39:24','2026-04-16 09:19:57','admin','admin',0),(10,'RISK_OFFICER','风控专员','负责风险审查与评估','[\"负责风险审查与评估\",\"warehouse:approve\",\"approval\",\"approval:pending\",\"approval:completed\",\"approval:history\",\"loan:approve\"]','BU','ACTIVE','2026-04-15 21:39:24','2026-04-16 09:18:04','admin','admin',0),(11,'COMPLIANCE_OFFICER','合规专员','负责合规性审查','[\"负责合规性审查\",\"loan:approve\",\"warehouse:approve\",\"reports\",\"reports:inbound\",\"reports:loan\",\"reports:overdue\",\"reports:financial\",\"approval\",\"approval:pending\",\"approval:completed\",\"approval:history\"]','BU','ACTIVE','2026-04-15 21:39:24','2026-04-16 09:18:15','admin','admin',0),(12,'TREASURY_OFFICER','资金中心专员','资金中心专员,资金中心审核 ',NULL,'ALL','ACTIVE','2026-04-21 17:20:09','2026-04-21 17:20:09',NULL,NULL,0);
/*!40000 ALTER TABLE `system_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bu_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`),
  KEY `idx_bu_code` (`bu_code`),
  KEY `idx_role` (`role`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_last_login` (`last_login_time`),
  KEY `idx_users_bu_role` (`bu_code`,`role`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_users` WRITE;
/*!40000 ALTER TABLE `system_users` DISABLE KEYS */;
INSERT INTO `system_users` VALUES (1,'admin','{bcrypt}$2a$10$ui4x8LbkZutC9ik1i9wtZe3RsMs/m4y9IuXVqsbTCd.UKLPE4r/IO','System Administrator','admin@seabank.com.vn','13332995668','科技部',NULL,'SUPER_ADMIN','ACTIVE','2026-04-21 17:17:07','172.18.0.1','2026-04-15 17:39:05','2026-04-16 09:37:54',NULL,NULL,0),(2,'bm01','{bcrypt}$2a$10$ui4x8LbkZutC9ik1i9wtZe3RsMs/m4y9IuXVqsbTCd.UKLPE4r/IO','呼庆雷','bm01@seabank.local','13876543790','零售银行部',NULL,'BUSINESS_MANAGER','ACTIVE','2026-04-24 18:49:09','172.18.0.1','2026-04-15 21:39:44','2026-04-22 08:16:20','admin','admin',0),(3,'bm02','{bcrypt}$2a$10$ui4x8LbkZutC9ik1i9wtZe3RsMs/m4y9IuXVqsbTCd.UKLPE4r/IO','玄骨上人','bm02@seabank.local','','公司银行部',NULL,'BUSINESS_MANAGER','ACTIVE','2026-04-18 21:07:06','172.18.0.1','2026-04-15 21:39:44','2026-04-22 08:16:49','admin','admin',0),(4,'ro01','{bcrypt}$2a$10$ui4x8LbkZutC9ik1i9wtZe3RsMs/m4y9IuXVqsbTCd.UKLPE4r/IO','向之礼','ro01@seabank.local','','风险管理部',NULL,'RISK_OFFICER','ACTIVE','2026-04-21 14:28:43','172.18.0.1','2026-04-15 21:39:44','2026-04-22 08:15:43','admin','admin',0),(5,'ro02','{bcrypt}$2a$10$ui4x8LbkZutC9ik1i9wtZe3RsMs/m4y9IuXVqsbTCd.UKLPE4r/IO','万三姑','ro02@seabank.local','','风险管理部',NULL,'RISK_OFFICER','ACTIVE','2026-04-18 14:01:18','172.18.0.1','2026-04-15 21:39:44','2026-04-22 08:17:49','admin','admin',0),(6,'co01','{bcrypt}$2a$10$ui4x8LbkZutC9ik1i9wtZe3RsMs/m4y9IuXVqsbTCd.UKLPE4r/IO','温青','co01@seabank.local','','合规部',NULL,'COMPLIANCE_OFFICER','ACTIVE','2026-04-21 17:43:57','172.18.0.1','2026-04-15 21:39:44','2026-04-22 08:18:45','admin','admin',0),(7,'co02','{bcrypt}$2a$10$ui4x8LbkZutC9ik1i9wtZe3RsMs/m4y9IuXVqsbTCd.UKLPE4r/IO','凌啸风','co02@seabank.local','','合规部',NULL,'COMPLIANCE_OFFICER','ACTIVE','2026-04-18 13:59:44','172.18.0.1','2026-04-15 21:39:44','2026-04-22 08:20:07','admin','admin',0),(8,'wm01','{bcrypt}$2a$10$ui4x8LbkZutC9ik1i9wtZe3RsMs/m4y9IuXVqsbTCd.UKLPE4r/IO','凌玉灵','wm01@seabank.local','','运营部',NULL,'WAREHOUSE_MANAGER','ACTIVE','2026-04-21 17:44:46','172.18.0.1','2026-04-15 21:39:44','2026-04-22 08:20:59','admin','admin',0),(9,'wm02','{bcrypt}$2a$10$ui4x8LbkZutC9ik1i9wtZe3RsMs/m4y9IuXVqsbTCd.UKLPE4r/IO','金魁','wm02@seabank.local','','运营部',NULL,'WAREHOUSE_MANAGER','ACTIVE','2026-04-20 18:20:14','172.18.0.1','2026-04-15 21:39:44','2026-04-22 08:21:37','admin','admin',0),(10,'th01','{bcrypt}$2a$10$ttNcQEDL55mxBMRJkB.YpeSPy4h9jmDscO4BipfBgeKvq2tER28.S','李化元','th01@seabank.com','13278932489','资金中心专员',NULL,'TREASURY_OFFICER','ACTIVE','2026-04-21 17:22:44','172.18.0.1','2026-04-21 15:28:17','2026-04-21 17:21:04',NULL,NULL,0),(11,'th02','{bcrypt}$2a$10$uCb.BQm/zWr7SkeFDRuNHusrJY0gJ0xcGLKDa9MuAnm4sOC5bZ88C','吕洛','th02@seabank.com','13978653452','资金中心主管',NULL,'TREASURY_HEAD','ACTIVE','2026-04-21 17:21:41','172.18.0.1','2026-04-21 15:30:15','2026-04-21 15:30:15',NULL,NULL,0);
/*!40000 ALTER TABLE `system_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transfer_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transfer_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `transfer_id` bigint NOT NULL,
  `step_number` int NOT NULL,
  `step_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `comments` text COLLATE utf8mb4_unicode_ci,
  `approved_at` datetime DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_transfer_step` (`transfer_id`,`step_number`),
  KEY `idx_transfer_approval_status` (`transfer_id`,`step_number`,`status`),
  KEY `idx_transfer_approval_role` (`approver_role`,`status`),
  CONSTRAINT `transfer_approval_ibfk_1` FOREIGN KEY (`transfer_id`) REFERENCES `collateral_transfer` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transfer_approval` WRITE;
/*!40000 ALTER TABLE `transfer_approval` DISABLE KEYS */;
INSERT INTO `transfer_approval` VALUES (1,1,1,'仓库主管审批','WAREHOUSE_MANAGER','1','APPROVED','','2026-04-18 05:12:51',NULL,NULL,0),(2,34,1,'仓库主管审批','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:22:41',NULL,NULL,0),(3,41,1,'仓库主管审批','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:19:05',NULL,NULL,0),(4,42,1,'仓库主管审批','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:22:22',NULL,NULL,0),(5,40,1,'仓库主管审批','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:19:14',NULL,NULL,0),(6,39,1,'仓库主管审批','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:19:19',NULL,NULL,0),(7,38,1,'仓库主管审批','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:22:36',NULL,NULL,0),(8,37,1,'仓库主管审批','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:19:22',NULL,NULL,0),(9,15,1,'仓库主管审批','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-19 08:01:44',NULL,NULL,0),(10,4,1,'仓库主管审批','WAREHOUSE_MANAGER','9','APPROVED','同意','2026-04-18 18:35:24',NULL,NULL,0),(11,41,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:22:24',NULL,NULL,0),(12,40,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:22:31',NULL,NULL,0),(13,39,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:22:29',NULL,NULL,0),(14,37,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','9','APPROVED','同意','2026-04-18 17:36:23',NULL,NULL,0),(15,42,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:35:41',NULL,NULL,0),(16,38,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 17:35:33',NULL,NULL,0),(17,34,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','9','APPROVED','同意','2026-04-18 17:36:26',NULL,NULL,0),(18,4,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-20 18:17:03',NULL,NULL,0),(19,43,1,'源仓库主管审批出库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-19 08:01:19',NULL,NULL,0),(20,43,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','9','APPROVED','同意','2026-04-19 08:02:14',NULL,NULL,0),(21,15,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER',NULL,'PENDING',NULL,NULL,NULL,NULL,0),(22,44,1,'源仓库主管审批出库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-19 09:41:12',NULL,NULL,0),(23,44,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-19 09:41:22',NULL,NULL,0),(24,45,1,'源仓库主管审批出库','WAREHOUSE_MANAGER','bm01','APPROVED','同意','2026-04-19 12:11:15',NULL,NULL,0),(25,45,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','wm02','APPROVED','同意','2026-04-19 13:19:25',NULL,NULL,0),(26,46,1,'源仓库主管审批出库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-19 12:17:32',NULL,NULL,0),(27,46,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-19 12:53:47',NULL,NULL,0),(28,47,1,'源仓库主管审批出库','WAREHOUSE_MANAGER','wm02','APPROVED','同意','2026-04-19 14:06:25',NULL,NULL,0),(29,47,2,'目标仓库主管确认入库','WAREHOUSE_MANAGER',NULL,'PENDING',NULL,NULL,NULL,NULL,0),(30,47,0,'取消申请','OPERATOR','wm02','CANCELLED','用户取消申请','2026-04-19 14:25:14',NULL,NULL,0);
/*!40000 ALTER TABLE `transfer_approval` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `warehouse_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_id` bigint NOT NULL,
  `manager` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacity` decimal(18,2) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE',
  `deleted` int DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `warehouse_code` (`warehouse_code`),
  KEY `idx_zone_id` (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warehouse` WRITE;
/*!40000 ALTER TABLE `warehouse` DISABLE KEYS */;
INSERT INTO `warehouse` VALUES (1,'WH-SH-001','上海监管仓A库',1,'王五',10000.00,'ACTIVE',0,'2026-04-17 07:40:38',NULL,'2026-04-17 08:48:36',NULL),(2,'WH-SH-002','上海监管仓B库',1,'赵六',8000.00,'ACTIVE',0,'2026-04-17 07:40:38',NULL,'2026-04-17 08:48:36',NULL),(3,'WH-SZ-001','深圳自管仓主库',2,'孙七',12000.00,'ACTIVE',0,'2026-04-17 07:40:38',NULL,'2026-04-17 08:48:36',NULL),(7,'WH-SZ-002','深圳福保库',2,'莫简离',8000.00,'ACTIVE',0,'2026-04-18 04:55:33',NULL,NULL,NULL),(8,'WH-SZ-003','深圳国际仓',2,'熬啸',10000.00,'ACTIVE',0,'2026-04-18 04:57:14',NULL,NULL,NULL),(9,'WH-XJ-001','喀什A仓库',5,'百里炎',1200000.00,'ACTIVE',0,'2026-04-18 11:03:43',NULL,NULL,NULL),(10,'WH-XJ-002','乌鲁木齐A仓',5,'百里炎',8900.00,'ACTIVE',0,'2026-04-18 11:04:45',NULL,NULL,NULL);
/*!40000 ALTER TABLE `warehouse` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warehouse_in_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_in_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint DEFAULT NULL,
  `step_number` int DEFAULT NULL,
  `step_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comments` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approver_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `due_date` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `processing_minutes` int DEFAULT NULL,
  `auto_approved` tinyint(1) DEFAULT '0',
  `approval_attachments` text COLLATE utf8mb4_unicode_ci,
  `ext_data` text COLLATE utf8mb4_unicode_ci,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wh_in_step` (`wh_in_id`,`step_number`),
  KEY `idx_wh_in_approval_status` (`wh_in_id`,`step_number`,`status`),
  KEY `idx_wh_in_approval_role` (`approver_role`,`status`),
  KEY `idx_wh_in_approval_user` (`approver_user`,`approved_at`),
  CONSTRAINT `warehouse_in_approval_ibfk_1` FOREIGN KEY (`wh_in_id`) REFERENCES `collateral_warehouse_in` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warehouse_in_approval` WRITE;
/*!40000 ALTER TABLE `warehouse_in_approval` DISABLE KEYS */;
INSERT INTO `warehouse_in_approval` VALUES (1,1,1,'TODO_FIX_ENCODING','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-16 14:39:51',NULL,'2026-04-15 18:25:02','2026-04-15 18:25:02',NULL,'2026-04-16 14:39:51',1214,0,NULL,NULL,1),(2,1,2,'TODO_FIX_ENCODING','RISK_OFFICER','ro01','APPROVED','同意','2026-04-16 15:17:30',NULL,'2026-04-15 18:25:02','2026-04-16 14:39:51',NULL,'2026-04-16 15:17:30',1252,0,NULL,NULL,2),(3,1,3,'TODO_FIX_ENCODING','COMPLIANCE_OFFICER','co02','APPROVED','同意','2026-04-16 15:18:34',NULL,'2026-04-15 18:25:02','2026-04-16 15:17:30',NULL,'2026-04-16 15:18:34',1253,0,NULL,NULL,2),(4,1,4,'TODO_FIX_ENCODING','WAREHOUSE_MANAGER','wm01','APPROVED','同意，已入库','2026-04-16 15:20:14',NULL,'2026-04-15 18:25:02','2026-04-16 15:18:34',NULL,'2026-04-16 15:20:14',1255,0,NULL,NULL,2),(6,2,1,'TODO_FIX_ENCODING','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-15 20:59:28',NULL,'2026-04-15 18:54:36','2026-04-16 14:36:16',NULL,'2026-04-15 20:59:28',124,0,NULL,NULL,2),(7,2,2,'TODO_FIX_ENCODING','RISK_OFFICER','ro01','APPROVED','同意','2026-04-16 13:03:40',NULL,'2026-04-15 18:54:36','2026-04-16 14:37:17',NULL,'2026-04-16 13:03:40',1089,0,NULL,NULL,2),(8,2,3,'TODO_FIX_ENCODING','COMPLIANCE_OFFICER','co02','APPROVED','同意','2026-04-18 09:33:14',NULL,'2026-04-15 18:54:36','2026-04-16 13:03:40',NULL,'2026-04-18 09:33:14',3758,0,NULL,NULL,2),(9,2,4,'TODO_FIX_ENCODING','WAREHOUSE_MANAGER','wm02','APPROVED','同意','2026-04-18 09:34:06',NULL,'2026-04-15 18:54:36','2026-04-18 09:33:14',NULL,'2026-04-18 09:34:06',3759,0,NULL,NULL,2),(11,3,1,'TODO_FIX_ENCODING','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-15 20:18:52',NULL,'2026-04-15 19:46:17','2026-04-16 14:36:16',NULL,'2026-04-15 20:18:52',32,0,NULL,NULL,2),(12,3,2,'TODO_FIX_ENCODING','RISK_OFFICER','ro01','APPROVED','同意','2026-04-15 20:19:23',NULL,'2026-04-15 19:46:17','2026-04-16 14:36:16',NULL,'2026-04-15 20:19:23',33,0,NULL,NULL,2),(13,3,3,'TODO_FIX_ENCODING','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-15 20:59:12',NULL,'2026-04-15 19:46:17','2026-04-16 14:36:16',NULL,'2026-04-15 20:59:12',72,0,NULL,NULL,2),(14,3,4,'TODO_FIX_ENCODING','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-16 12:53:52',NULL,'2026-04-15 19:46:17','2026-04-16 14:37:17',NULL,'2026-04-16 12:53:52',1027,0,NULL,NULL,2),(16,4,1,'TODO_FIX_ENCODING','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-16 12:53:38',NULL,'2026-04-15 21:06:16','2026-04-16 14:37:17',NULL,'2026-04-16 12:53:38',947,0,NULL,NULL,2),(17,4,2,'TODO_FIX_ENCODING','RISK_OFFICER','ro01','APPROVED','同意','2026-04-16 13:00:01',NULL,'2026-04-15 21:06:16','2026-04-16 14:37:17',NULL,'2026-04-16 13:00:01',953,0,NULL,NULL,2),(18,4,3,'TODO_FIX_ENCODING','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-16 13:04:11',NULL,'2026-04-15 21:06:16','2026-04-16 14:37:17',NULL,'2026-04-16 13:04:11',957,0,NULL,NULL,2),(19,4,4,'TODO_FIX_ENCODING','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-16 13:04:32',NULL,'2026-04-15 21:06:16','2026-04-16 14:37:17',NULL,'2026-04-16 13:04:32',958,0,NULL,NULL,2),(21,6,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-16 20:40:54',NULL,'2026-04-16 14:59:47','2026-04-16 14:59:48',NULL,'2026-04-16 20:40:54',341,0,NULL,NULL,2),(22,6,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-16 22:29:02',NULL,'2026-04-16 14:59:47','2026-04-16 20:40:54',NULL,'2026-04-16 22:29:02',449,0,NULL,NULL,2),(23,6,3,'处理条件','COMPLIANCE_OFFICER','system','APPROVED','同意','2026-04-18 21:10:27',NULL,'2026-04-16 14:59:47','2026-04-16 22:29:02',NULL,'2026-04-18 21:10:27',3250,0,NULL,NULL,2),(24,6,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-20 11:59:27',NULL,'2026-04-16 14:59:47','2026-04-18 21:10:27',NULL,'2026-04-20 11:59:27',5579,0,NULL,NULL,2),(26,7,1,'处理条件','BUSINESS_MANAGER','bm02','APPROVED','同意','2026-04-16 15:15:36',NULL,'2026-04-16 15:07:58','2026-04-16 15:07:58',NULL,'2026-04-16 15:15:36',7,0,NULL,NULL,2),(27,7,2,'处理条件','RISK_OFFICER','ro02','APPROVED','同意','2026-04-16 22:30:04',NULL,'2026-04-16 15:07:58','2026-04-16 15:15:36',NULL,'2026-04-16 22:30:04',442,0,NULL,NULL,2),(28,7,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-17 20:25:08',NULL,'2026-04-16 15:07:58','2026-04-16 22:30:04',NULL,'2026-04-17 20:25:08',1757,0,NULL,NULL,2),(29,7,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-17 20:25:57',NULL,'2026-04-16 15:07:58','2026-04-17 20:25:08',NULL,'2026-04-17 20:25:57',1757,0,NULL,NULL,2),(31,8,1,'处理条件','BUSINESS_MANAGER','bm02','APPROVED','同意','2026-04-16 15:16:00',NULL,'2026-04-16 15:10:43','2026-04-16 15:10:43',NULL,'2026-04-16 15:16:00',5,0,NULL,NULL,2),(32,8,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-16 15:17:43',NULL,'2026-04-16 15:10:43','2026-04-16 15:16:00',NULL,'2026-04-16 15:17:43',6,0,NULL,NULL,2),(33,8,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-16 15:18:55',NULL,'2026-04-16 15:10:43','2026-04-16 15:17:43',NULL,'2026-04-16 15:18:55',8,0,NULL,NULL,2),(34,8,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意，已入库','2026-04-16 15:20:38',NULL,'2026-04-16 15:10:43','2026-04-16 15:18:55',NULL,'2026-04-16 15:20:38',9,0,NULL,NULL,2),(36,9,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-18 08:47:28',NULL,'2026-04-16 15:12:46','2026-04-18 08:23:19',NULL,'2026-04-18 08:47:28',2494,0,NULL,NULL,4),(37,9,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-18 09:24:46',NULL,'2026-04-16 15:12:46','2026-04-18 08:47:28',NULL,'2026-04-18 09:24:46',2531,0,NULL,NULL,4),(38,9,3,'处理条件','COMPLIANCE_OFFICER','co02','APPROVED','同意，已增加了瓶灵','2026-04-18 09:32:19',NULL,'2026-04-16 15:12:46','2026-04-18 09:24:46',NULL,'2026-04-18 09:32:19',2539,0,NULL,NULL,4),(39,9,4,'处理条件','WAREHOUSE_MANAGER','wm02','APPROVED','同意,    确认掌天瓶完整 ','2026-04-18 09:34:41',NULL,'2026-04-16 15:12:46','2026-04-18 09:32:19',NULL,'2026-04-18 09:34:41',2541,0,NULL,NULL,4),(41,10,1,'处理条件','BUSINESS_MANAGER','bm02','APPROVED','同意','2026-04-17 19:49:08',NULL,'2026-04-17 19:42:24','2026-04-17 19:42:24',NULL,'2026-04-17 19:49:08',6,0,NULL,NULL,2),(42,10,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-17 20:23:40',NULL,'2026-04-17 19:42:24','2026-04-17 19:49:08',NULL,'2026-04-17 20:23:40',41,0,NULL,NULL,2),(43,10,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-17 20:25:01',NULL,'2026-04-17 19:42:24','2026-04-17 20:23:40',NULL,'2026-04-17 20:25:01',42,0,NULL,NULL,2),(44,10,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-17 20:26:04',NULL,'2026-04-17 19:42:24','2026-04-17 20:25:01',NULL,'2026-04-17 20:26:04',43,0,NULL,NULL,2),(45,11,1,'处理条件','BUSINESS_MANAGER',NULL,'PENDING',NULL,NULL,NULL,'2026-04-17 19:51:29','2026-04-17 19:51:29',NULL,NULL,NULL,0,NULL,NULL,1),(46,11,2,'处理条件','RISK_OFFICER',NULL,'NOT_STARTED',NULL,NULL,NULL,'2026-04-17 19:51:29','2026-04-17 19:51:29',NULL,NULL,NULL,0,NULL,NULL,0),(47,11,3,'处理条件','COMPLIANCE_OFFICER',NULL,'NOT_STARTED',NULL,NULL,NULL,'2026-04-17 19:51:29','2026-04-17 19:51:29',NULL,NULL,NULL,0,NULL,NULL,0),(48,11,4,'处理条件','WAREHOUSE_MANAGER',NULL,'NOT_STARTED',NULL,NULL,NULL,'2026-04-17 19:51:29','2026-04-17 19:51:29',NULL,NULL,NULL,0,NULL,NULL,0),(49,12,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-20 12:10:17',NULL,'2026-04-17 19:57:38','2026-04-17 19:57:38',NULL,'2026-04-20 12:10:17',3852,0,NULL,NULL,2),(50,12,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-20 17:42:50',NULL,'2026-04-17 19:57:38','2026-04-20 12:10:17',NULL,'2026-04-20 17:42:50',4185,0,NULL,NULL,2),(51,12,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-20 17:43:11',NULL,'2026-04-17 19:57:38','2026-04-20 17:42:50',NULL,'2026-04-20 17:43:11',4185,0,NULL,NULL,2),(52,12,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-21 09:48:14',NULL,'2026-04-17 19:57:38','2026-04-20 17:43:11',NULL,'2026-04-21 09:48:14',5150,0,NULL,NULL,2),(53,13,1,'处理条件','BUSINESS_MANAGER','bm02','APPROVED','同意','2026-04-18 09:56:44',NULL,'2026-04-18 09:51:36','2026-04-18 09:51:36',NULL,'2026-04-18 09:56:44',5,0,NULL,NULL,2),(54,13,2,'处理条件','RISK_OFFICER','ro02','APPROVED','同意','2026-04-18 14:02:11',NULL,'2026-04-18 09:51:36','2026-04-18 09:56:44',NULL,'2026-04-18 14:02:11',250,0,NULL,NULL,2),(55,13,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-20 11:58:51',NULL,'2026-04-18 09:51:36','2026-04-18 14:02:11',NULL,'2026-04-20 11:58:51',3007,0,NULL,NULL,2),(56,13,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-20 11:59:33',NULL,'2026-04-18 09:51:36','2026-04-20 11:58:51',NULL,'2026-04-20 11:59:33',3007,0,NULL,NULL,2),(57,14,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-20 12:10:27',NULL,'2026-04-18 09:59:15','2026-04-18 09:59:15',NULL,'2026-04-20 12:10:27',3011,0,NULL,NULL,2),(58,14,2,'处理条件','RISK_OFFICER',NULL,'PENDING',NULL,NULL,NULL,'2026-04-18 09:59:15','2026-04-20 12:10:27',NULL,NULL,NULL,0,NULL,NULL,1),(59,14,3,'处理条件','COMPLIANCE_OFFICER',NULL,'NOT_STARTED',NULL,NULL,NULL,'2026-04-18 09:59:15','2026-04-18 09:59:15',NULL,NULL,NULL,0,NULL,NULL,0),(60,14,4,'处理条件','WAREHOUSE_MANAGER',NULL,'NOT_STARTED',NULL,NULL,NULL,'2026-04-18 09:59:15','2026-04-18 09:59:15',NULL,NULL,NULL,0,NULL,NULL,0),(61,15,1,'处理条件','BUSINESS_MANAGER','bm02','APPROVED','同意','2026-04-18 10:07:29',NULL,'2026-04-18 10:02:48','2026-04-18 10:02:48',NULL,'2026-04-18 10:07:29',4,0,NULL,NULL,2),(62,15,2,'处理条件','RISK_OFFICER','system','APPROVED','同意','2026-04-18 14:04:12',NULL,'2026-04-18 10:02:48','2026-04-18 10:07:29',NULL,'2026-04-18 14:04:12',241,0,NULL,NULL,2),(63,15,3,'处理条件','COMPLIANCE_OFFICER','system','APPROVED','同意','2026-04-18 14:04:39',NULL,'2026-04-18 10:02:48','2026-04-18 14:04:12',NULL,'2026-04-18 14:04:39',241,0,NULL,NULL,2),(64,15,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-20 11:59:45',NULL,'2026-04-18 10:02:48','2026-04-18 14:04:39',NULL,'2026-04-20 11:59:45',2996,0,NULL,NULL,2),(65,16,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-20 12:10:10',NULL,'2026-04-18 10:05:19','2026-04-18 10:05:19',NULL,'2026-04-20 12:10:10',3004,0,NULL,NULL,2),(66,16,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-21 13:25:47',NULL,'2026-04-18 10:05:19','2026-04-20 12:10:10',NULL,'2026-04-21 13:25:47',4520,0,NULL,NULL,2),(67,16,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-21 17:44:10',NULL,'2026-04-18 10:05:19','2026-04-21 13:25:47',NULL,'2026-04-21 17:44:10',4778,0,NULL,NULL,2),(68,16,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-21 17:45:17',NULL,'2026-04-18 10:05:19','2026-04-21 17:44:11',NULL,'2026-04-21 17:45:17',4779,0,NULL,NULL,2),(69,17,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-18 13:48:54',NULL,'2026-04-18 13:48:50','2026-04-18 13:48:50',NULL,'2026-04-18 13:48:54',0,0,NULL,NULL,2),(70,17,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-18 13:52:50',NULL,'2026-04-18 13:48:50','2026-04-18 13:48:54',NULL,'2026-04-18 13:52:50',4,0,NULL,NULL,2),(71,17,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-18 13:54:02',NULL,'2026-04-18 13:48:50','2026-04-18 13:52:50',NULL,'2026-04-18 13:54:02',5,0,NULL,NULL,2),(72,17,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 13:57:17',NULL,'2026-04-18 13:48:50','2026-04-18 13:54:02',NULL,'2026-04-18 13:57:17',8,0,NULL,NULL,2),(73,18,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-18 13:50:49',NULL,'2026-04-18 13:50:41','2026-04-18 13:50:41',NULL,'2026-04-18 13:50:49',0,0,NULL,NULL,2),(74,18,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-18 13:51:34',NULL,'2026-04-18 13:50:41','2026-04-18 13:50:49',NULL,'2026-04-18 13:51:34',0,0,NULL,NULL,2),(75,18,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-18 13:53:52',NULL,'2026-04-18 13:50:41','2026-04-18 13:51:34',NULL,'2026-04-18 13:53:52',3,0,NULL,NULL,2),(76,18,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-18 13:54:55',NULL,'2026-04-18 13:50:41','2026-04-18 13:53:52',NULL,'2026-04-18 13:54:55',4,0,NULL,NULL,2),(77,19,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-20 09:17:17',NULL,'2026-04-20 09:17:12','2026-04-20 09:17:12',NULL,'2026-04-20 09:17:17',0,0,NULL,NULL,2),(78,19,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-20 11:58:10',NULL,'2026-04-20 09:17:12','2026-04-20 09:17:17',NULL,'2026-04-20 11:58:10',160,0,NULL,NULL,2),(79,19,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-20 11:59:00',NULL,'2026-04-20 09:17:12','2026-04-20 11:58:10',NULL,'2026-04-20 11:59:00',161,0,NULL,NULL,2),(80,19,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-20 12:00:10',NULL,'2026-04-20 09:17:12','2026-04-20 11:59:00',NULL,'2026-04-20 12:00:10',162,0,NULL,NULL,2),(81,20,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-20 11:20:43',NULL,'2026-04-20 11:20:05','2026-04-20 11:20:05',NULL,'2026-04-20 11:20:43',0,0,NULL,NULL,2),(82,20,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-20 11:58:17',NULL,'2026-04-20 11:20:05','2026-04-20 11:20:43',NULL,'2026-04-20 11:58:17',38,0,NULL,NULL,2),(83,20,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-20 17:43:26',NULL,'2026-04-20 11:20:05','2026-04-20 11:58:17',NULL,'2026-04-20 17:43:26',383,0,NULL,NULL,2),(84,20,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-20 17:44:18',NULL,'2026-04-20 11:20:05','2026-04-20 17:43:26',NULL,'2026-04-20 17:44:18',384,0,NULL,NULL,2),(85,21,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-20 12:10:03',NULL,'2026-04-20 11:27:10','2026-04-20 11:27:10',NULL,'2026-04-20 12:10:03',42,0,NULL,NULL,2),(86,21,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-20 17:42:44',NULL,'2026-04-20 11:27:10','2026-04-20 12:10:03',NULL,'2026-04-20 17:42:44',375,0,NULL,NULL,2),(87,21,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-20 17:43:18',NULL,'2026-04-20 11:27:10','2026-04-20 17:42:44',NULL,'2026-04-20 17:43:18',376,0,NULL,NULL,2),(88,21,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-20 17:44:09',NULL,'2026-04-20 11:27:10','2026-04-20 17:43:18',NULL,'2026-04-20 17:44:09',376,0,NULL,NULL,2),(89,22,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-20 17:40:33',NULL,'2026-04-20 12:12:59','2026-04-20 12:12:59',NULL,'2026-04-20 17:40:33',327,0,NULL,NULL,2),(90,22,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-20 17:42:38',NULL,'2026-04-20 12:12:59','2026-04-20 17:40:33',NULL,'2026-04-20 17:42:38',329,0,NULL,NULL,2),(91,22,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-21 09:49:52',NULL,'2026-04-20 12:12:59','2026-04-20 17:42:38',NULL,'2026-04-21 09:49:52',1296,0,NULL,NULL,2),(92,22,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-21 17:45:01',NULL,'2026-04-20 12:12:59','2026-04-21 09:49:52',NULL,'2026-04-21 17:45:01',1772,0,NULL,NULL,2),(93,23,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-20 17:40:41',NULL,'2026-04-20 13:46:36','2026-04-20 15:48:39',NULL,'2026-04-20 17:40:41',234,0,NULL,NULL,2),(94,23,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-20 17:42:32',NULL,'2026-04-20 13:46:36','2026-04-20 17:40:41',NULL,'2026-04-20 17:42:32',235,0,NULL,NULL,2),(95,23,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-20 17:43:33',NULL,'2026-04-20 13:46:36','2026-04-20 17:42:32',NULL,'2026-04-20 17:43:33',236,0,NULL,NULL,2),(96,23,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-20 17:43:59',NULL,'2026-04-20 13:46:36','2026-04-20 17:43:33',NULL,'2026-04-20 17:43:59',237,0,NULL,NULL,2),(97,24,1,'处理条件','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-21 08:28:02',NULL,'2026-04-21 08:27:50','2026-04-21 08:27:56',NULL,'2026-04-21 08:28:02',0,0,NULL,NULL,2),(98,24,2,'处理条件','RISK_OFFICER','ro01','APPROVED','同意','2026-04-21 08:28:51',NULL,'2026-04-21 08:27:50','2026-04-21 08:28:02',NULL,'2026-04-21 08:28:51',1,0,NULL,NULL,2),(99,24,3,'处理条件','COMPLIANCE_OFFICER','co01','APPROVED','同意','2026-04-21 12:43:45',NULL,'2026-04-21 08:27:50','2026-04-21 08:28:51',NULL,'2026-04-21 12:43:45',255,0,NULL,NULL,2),(100,24,4,'处理条件','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-21 12:44:34',NULL,'2026-04-21 08:27:50','2026-04-21 12:43:45',NULL,'2026-04-21 12:44:34',256,0,NULL,NULL,2);
/*!40000 ALTER TABLE `warehouse_in_approval` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warehouse_in_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_in_files` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_in_id` bigint DEFAULT NULL,
  `file_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint DEFAULT NULL,
  `upload_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `file_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE',
  `download_count` int DEFAULT '0',
  `last_download_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wh_in` (`wh_in_id`),
  KEY `idx_wh_in_files_upload_time` (`upload_time`),
  KEY `idx_wh_in_files_type` (`file_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warehouse_in_files` WRITE;
/*!40000 ALTER TABLE `warehouse_in_files` DISABLE KEYS */;
INSERT INTO `warehouse_in_files` VALUES (1,23,'方程豹1.jpeg','WAREHOUSE_IN','WAREHOUSE_IN/2026-04/20/eec84232563d48bdbf32dad2c6a90086____1.jpeg',87704,'业务经理 张三','2026-04-20 15:37:34','06a1dd3dc89046c110abf7c0577830cf','image/jpeg',NULL,NULL,NULL,'ACTIVE',6,'2026-04-21 08:25:55',NULL,NULL,'2026-04-21 08:25:55',NULL,0),(2,23,'方程豹2.jpeg','WAREHOUSE_IN','WAREHOUSE_IN/2026-04/20/b781dbc733634bd2a018939cd6196c18____2.jpeg',58532,'业务经理 张三','2026-04-20 15:37:34','7455b787f1f9ef0edf1b8cd865cf1df1','image/jpeg',NULL,NULL,NULL,'ACTIVE',5,'2026-04-21 08:25:30',NULL,NULL,'2026-04-21 08:25:30',NULL,0);
/*!40000 ALTER TABLE `warehouse_in_files` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warehouse_out_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_out_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wh_out_id` bigint NOT NULL,
  `step_number` int NOT NULL,
  `step_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `comments` text COLLATE utf8mb4_unicode_ci,
  `approved_at` datetime DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wh_out_step` (`wh_out_id`,`step_number`),
  KEY `idx_wh_out_approval_status` (`wh_out_id`,`step_number`,`status`),
  KEY `idx_wh_out_approval_role` (`approver_role`,`status`),
  CONSTRAINT `warehouse_out_approval_ibfk_1` FOREIGN KEY (`wh_out_id`) REFERENCES `collateral_warehouse_out` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warehouse_out_approval` WRITE;
/*!40000 ALTER TABLE `warehouse_out_approval` DISABLE KEYS */;
INSERT INTO `warehouse_out_approval` VALUES (1,1,1,'仓库主管审批','WAREHOUSE_MANAGER','admin','APPROVED','','2026-04-18 07:18:47',NULL,NULL,0),(2,10,1,'风险审核','RISK_OFFICER','wm02','APPROVED','同意','2026-04-18 18:07:02',NULL,NULL,0),(3,10,2,'合规复核','COMPLIANCE_OFFICER','wm02','APPROVED','同意','2026-04-18 18:07:03',NULL,NULL,0),(4,10,3,'仓库主管出库确认','WAREHOUSE_MANAGER','wm02','APPROVED','同意','2026-04-18 18:07:05',NULL,NULL,0),(5,10,4,'业务最后核实','BUSINESS_MANAGER','wm02','APPROVED','同意','2026-04-18 18:07:18',NULL,NULL,0),(6,11,1,'风险审核','RISK_OFFICER','wm01','APPROVED','同意','2026-04-20 18:19:54',NULL,NULL,0),(7,11,2,'合规复核','COMPLIANCE_OFFICER','wm02','APPROVED','同意','2026-04-20 18:20:43',NULL,NULL,0),(8,11,3,'仓库主管出库确认','WAREHOUSE_MANAGER','bm01','APPROVED','同意','2026-04-20 18:21:47',NULL,NULL,0),(9,11,4,'业务最后核实','BUSINESS_MANAGER','co01','APPROVED','同意','2026-04-20 18:22:52',NULL,NULL,0),(10,12,1,'风险审核','RISK_OFFICER','co01','APPROVED','同意','2026-04-21 13:03:22',NULL,NULL,0),(11,12,2,'合规复核','COMPLIANCE_OFFICER',NULL,'PENDING',NULL,NULL,NULL,NULL,0),(12,12,0,'取消申请','OPERATOR','6','CANCELLED','用户取消申请','2026-04-21 13:54:03',NULL,NULL,0),(13,13,1,'风险审核','RISK_OFFICER','co01','APPROVED','同意','2026-04-21 14:27:19',NULL,NULL,0),(14,13,2,'合规复核','COMPLIANCE_OFFICER','ro01','APPROVED','同意','2026-04-21 14:29:07',NULL,NULL,0),(15,13,3,'仓库主管出库确认','WAREHOUSE_MANAGER','wm01','APPROVED','同意','2026-04-21 14:29:54',NULL,NULL,0),(16,13,4,'业务最后核实','BUSINESS_MANAGER','bm01','APPROVED','同意','2026-04-21 14:30:40',NULL,NULL,0);
/*!40000 ALTER TABLE `warehouse_out_approval` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warehouse_zone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_zone` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `zone_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE',
  `deleted` int DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `zone_code` (`zone_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warehouse_zone` WRITE;
/*!40000 ALTER TABLE `warehouse_zone` DISABLE KEYS */;
INSERT INTO `warehouse_zone` VALUES (1,'ZONE-SH-001','华东监管库区','SUPERVISED','上海市浦东新区XX路1号','张三','13800138001','ACTIVE',0,'2026-04-17 07:40:27',NULL,NULL,NULL),(2,'ZONE-SZ-001','华南自管库区','SELF_MANAGED','深圳市南山区YY路2号','李四','13800138002','ACTIVE',0,'2026-04-17 07:40:27',NULL,NULL,NULL),(5,'ZONE-XJ-001','西部自管库区','SELF_MANAGED','新疆喀什','百里炎','13875282998','ACTIVE',0,'2026-04-18 05:00:13',NULL,NULL,NULL);
/*!40000 ALTER TABLE `warehouse_zone` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

